Imports System.IO

Module modMain

#Region "Initialization . . . "

	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Public conSql As New SqlClient.SqlConnection
	Public conSqlCommonDB As New SqlClient.SqlConnection

	'Friend ConSql As New SqlClient.SqlConnection
	''
	Public gStrServerName As String = ""
	Public gStrUserName As String = ""
	Public gStrDataBaseName As String = ""
	Public gStrPassWord As String = ""
	Public gBlnBITSSec As Boolean = False

	'' holds the current selected language...
	Public gStrLang As String = "en"

	'' Company Declarations
	Friend gIntCompanyNumber As Integer
	Friend gStrCompanyName As String
	Friend gIntCompanyCurrID As Integer
	Friend gIntCompanyCurrID2 As Integer
	Friend gDtCompanyBeginDate As Date
	Friend gDtCompanyEndDate As Date

	''
	Friend strSQL As String
	Friend strSQLCommonDB As String

	Friend strMsg As String
	Public gIntUserID As Integer = 0
	Public gIntCompanyID As Integer = 0
	Public gIntBranchID As Integer = 0
	Public gIntDepartment As Integer = 0
	Public MainForm As frmApplicationMain

	Dim mblnLoginSucces As Boolean	'' set by returned value from login form; login OK/Not...
	Public gStrXMLFileName As String = "bitsConBillling.xml"
	Public gStrXMLCommonDB As String = "bitsConCommonDB.xml"
	''
	Public gUserLevel As enmUserLevel
	'Public dsData As New DataSet
	Dim ioFile As System.IO.File

	Dim dsData As New DataSet
	Dim dsCommonDB As New DataSet

	''
	Public gStrFilter As String
	Public gStrFilterStatment As String

	' Languages
	Public gilArabic As InputLanguage
	Public gilEnglish As InputLanguage
	'
	Public appMain As frmApplicationMain

	'User Preferences'
	Public gintDecDigit As Integer = 0
	Public gblnUseComma As Boolean = False
	Public gstrSharedDataPath As String = ""

	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'Friend gStrPicDest As String = "C:\Program Files\BitSolutions\LCAALicensing\Data\PIC\"
	'Friend gPicPathSource As String
	'Friend intPersonnelID As Integer
	''Friend strTableName As String
	'Friend gIntLicID As Integer
	'Friend gBlnLREdit As Boolean = False

	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'Friend intDriver As Integer
	'Friend dtTrxDate As Date
	'Friend intDayID As Integer
	'Friend strDriverName As String
	'Friend strRptName As enmReports
	'Friend dtFrom As Date
	'Friend DtTo As Date

	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'Public WithEvents frmCon As dataService.frmSelectServer
	'Public WithEvents mClsFrmLogin As frmLogin  '' holds an instance of frmLogin...
	''''''''''''''''''''''''''''''''''''''

	Public Enum enmReports
		rptDailyDistribution
		rptDailyWorkDetail
		rptDailyProductSales
		rptDailySumProductSales
		rptDetailInvoice
	End Enum
	''
	Public Enum enmUserLevel
		AdminLevel = 1
		MngrLevel = 2
		UserLevel = 3
	End Enum

#End Region


	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' Sub main(): Application Entry Point...
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'Sub main()
	'   'Try
	'   'gIntCompanyID = 2

	'   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'   '' chkeck Legal Copy...
	'   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'   If getLegalFileAccessInfo() = False Then
	'      '' exist
	'      End
	'   End If

	'   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'   '' display splash...
	'   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'   'Dim clsFrmSplash As New frmSplash
	'   'clsFrmSplash.ShowDialog()

	'   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'   '' chkeck XML connection information file...
	'   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'   If ioFile.Exists(gStrXMLFileName) Then
	'      '' File Exists...
	'      dsData.ReadXml(gStrXMLFileName)
	'      If CheckConnection(CType(dsData.Tables(0).Rows(0).Item(0), Integer)) = False Then
	'         getDataSource()
	'      End If
	'   Else
	'      getDataSource()
	'   End If

	'   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'   '' GetLanguages
	'   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'   GetLanguages()

	'   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'   '' reached this point, ok; continue with login
	'   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'   'clsFrmSplash.Hide()
	'   mblnLoginSucces = False
	'   mClsFrmLogin = New frmLogin
	'   mClsFrmLogin.StartPosition = FormStartPosition.CenterScreen
	'   mClsFrmLogin.ShowDialog()

	'   ''
	'   '' show frmLogin, frmApplicationMain then continue next...
	'   If mblnLoginSucces Then
	'      mClsFrmLogin.Close()
	'      ''
	'      Dim frmApplicationMainain As New frmApplicationMain
	'      clsfrmApplicationMain.ShowDialog()
	'      'clsFrmSplash.Close()
	'   End If

	'End Sub

	Public Sub GetLanguages()
		' Gets the list of installed languages.
		Dim lang As InputLanguage

		For Each lang In InputLanguage.InstalledInputLanguages
			If lang.Culture.EnglishName.ToLower().StartsWith("ar") Then
				gilArabic = lang
			ElseIf lang.Culture.EnglishName.ToLower().StartsWith("en") Then
				gilEnglish = lang
			End If
		Next lang

		If (gilArabic Is Nothing) Then
			gilArabic = InputLanguage.DefaultInputLanguage
		End If

		If (gilEnglish Is Nothing) Then
			gilEnglish = InputLanguage.DefaultInputLanguage
		End If

	End Sub

	'Private Sub getDataSource()
	'   '' IF not successful connection...
	'   frmCon = New dataService.frmSelectServer
	'   frmCon.xmlFileName = gStrXMLFileName
	'   frmCon.ShowDialog()
	'End Sub
	''
	'If ioFile.Exists(gStrXMLFileName) Then
	'   'If ioFile.Exists("C:\BITSConLCAAL.xml") Then
	'   dsData.ReadXml(gStrXMLFileName)
	'   'dsData.ReadXml("C:\BITSConLCAAL.xml")
	'   If CheckConnection(CType(dsData.Tables(0).Rows(0).Item(0), Integer)) = False Then
	'      frmCon = New dataService.frmSelectServer
	'      frmCon.xmlFileName = gStrXMLFileName
	'      frmCon.ShowDialog()
	'   Else
	'      clsFrmSplash.Hide()
	'      mblnLoginSucces = False
	'      mClsFrmLogin = New frmLogin
	'      mClsFrmLogin.StartPosition = FormStartPosition.CenterScreen
	'      mClsFrmLogin.ShowDialog()
	'      ''
	'      '' showing frmLogin; frmApplicationMain then continues next...
	'      If mblnLoginSucces Then
	'         mClsFrmLogin.Close()
	'         ''
	'         Dim clfrmApplicationMainn As New frmApplicationMain
	'         clsfrmApplicationMain.ShowDialog()
	'         clsFrmSplash.Close()
	'      End If
	'   End If
	'Else
	'   frmCon = New dataService.frmSelectServer
	'   frmCon.ShowDialog()
	'End If
	'
	'nd Sub

	Public Function getLegalFileAccessInfo() As Boolean
		'' tempFix Airport issues - 26 Dec 2007
		getLegalFileAccessInfo = True
		Exit Function

		''12:55:05 PM
		'WS1-Mdm. Siham: Dim dtModified As Date = "4/19/2006 12:25:56 PM"
		'WS2-Mdm. Lina:
		'Dim dtModified As Date = "4/19/2006 1:52:37 PM"
		'Dim ioFile As File

		'''''''''''''''''''''''''''''''' TEST
		'' temp till done!
		'Dim smsg As String
		'smsg = "fDT:" & ioFile.GetLastAccessTime(Application.StartupPath & "\CollabExt1227.dll") & "x"
		'smsg = smsg & vbCrLf & "xDT:" & dtModified & "x"
		'smsg = smsg & vbCrLf & "dt:" & 
		'MsgBox(smsg & " : " & (ioFile.GetLastAccessTime(Application.StartupPath & "\CollabExt1227.dll") = dtModified))
		'MsgBox(smsg & " : " & DateDiff(DateInterval.Second, ioFile.GetLastAccessTime(Application.StartupPath & "\CollabExt1227.dll"), dtModified))

		Dim frmX As New frmRegistrationCode
		frmX.ShowDialog()
		''
		getLegalFileAccessInfo = gBlnBITSSec

		Exit Function
		''''''''''''''''''''''''''''''' TEST

		''
		getLegalFileAccessInfo = False

		''
		'If ioFile.Exists(Application.StartupPath & "\CollabExt1227.dll") = True Then
		'   'If (ioFile.GetLastAccessTime(Application.StartupPath & "\CollabExt1227.dll") = dtModified) Then
		'   If DateDiff(DateInterval.Second, ioFile.GetLastAccessTime(Application.StartupPath & "\CollabExt1227.dll"), dtModified) = 0 Then
		'      getLegalFileAccessInfo = True
		'      Exit Function
		'   End If
		'End If
		''
		MsgBox("Illegal BIT Solution Product License, Contact BIT Solutions to eleminate any further damage!", MsgBoxStyle.Critical, "Warning")

	End Function


#Region "functions"

	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'Private Sub frmLogin_OnOkClick(ByVal pBlnPassed As Boolean, ByVal pIntUserID As Integer, ByVal pIntUserLevel As Integer, ByVal pIntBranchID As Integer, ByVal pIntCompanyID As Integer) Handles mClsFrmLogin.OnOkClick
	'   If pBlnPassed = True Then
	'      gIntUserID = pIntUserID
	'      gIntBranchID = pIntBranchID
	'      gIntCompanyID = pIntCompanyID
	'      mblnLoginSucces = True
	'      gUserLevel = CType(pIntUserLevel, enmUserLevel) 'pIntUserLevel 'CType(pIntUserLevel, enmUserLevel)

	'      ' get other company info
	'      Dim cmd As SqlClient.SqlCommand
	'      Dim sdr As SqlClient.SqlDataReader

	'      cmd = New SqlClient.SqlCommand("SELECT * FROM tblCompany WHERE CompanyID = " & gIntCompanyID, conSql)
	'      conSql.Open()
	'      sdr = cmd.ExecuteReader()
	'      If sdr.Read() Then
	'         gIntCompanyNumber = sdr("CompanyNumber")
	'         gStrCompanyName = sdr("CompanyName")
	'         gIntCompanyCurrID = sdr("CurrID")
	'         gDtCompanyBeginDate = sdr("DateFrom")
	'         gDtCompanyEndDate = sdr("DateTo")
	'      Else
	'         Throw New Exception("Company Not Found!! CompanyID = " & gIntCompanyID)
	'      End If
	'      conSql.Close()
	'   End If
	'End Sub

	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'Public Function CheckConnection(ByVal pConType As Integer) As Boolean
	'   CheckConnection = True
	'   Try
	'      If dsData.Tables(0).Columns.Count = 5 Then
	'         gStrServerName = CType(dsData.Tables(0).Rows(0).Item(1), String)
	'         gStrDataBaseName = CType(dsData.Tables(0).Rows(0).Item(4), String)
	'         gStrUserName = CType(dsData.Tables(0).Rows(0).Item(2), String)
	'         gStrPassWord = CType(dsData.Tables(0).Rows(0).Item(3), String)

	'         OpenConnection(pConType, CType(dsData.Tables(0).Rows(0).Item(4), String), CType(dsData.Tables(0).Rows(0).Item(2), String), CType(dsData.Tables(0).Rows(0).Item(1), String), CType(dsData.Tables(0).Rows(0).Item(3), String))
	'      Else
	'         gStrServerName = CType(dsData.Tables(0).Rows(0).Item(1), String)
	'         gStrDataBaseName = CType(dsData.Tables(0).Rows(0).Item(2), String)
	'         OpenConnection(pConType, CType(dsData.Tables(0).Rows(0).Item(2), String), , CType(dsData.Tables(0).Rows(0).Item(1), String))
	'      End If

	'      If conSql.State <> ConnectionState.Open Then CheckConnection = False
	'      conSql.Close()

	'   Catch exSql As SqlClient.SqlException
	'      CheckConnection = False
	'      MsgBox("Error Number 1 . SqlServer.Server.CheckConnnection " & vbCrLf & exSql.Message & " Please take Note and call BitSolution.")

	'   Catch exGeneral As Exception
	'      MsgBox(("Error Number 3 . SqlServer.Server.CheckConnnection " & vbCrLf & exGeneral.Message & " Please take Note and call BitSolution."))
	'      CheckConnection = False
	'   End Try
	'End Function

	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'Public Sub OpenConnection(ByVal pConType As Integer, ByVal pDatabaseName As String, Optional ByVal pUserName As String = "", Optional ByVal pServerName As String = "", Optional ByVal pPassword As String = "")
	'   If pConType = 0 Then
	'      conSql.ConnectionString = "packet size=4096;integrated security=SSPI;data source= " & pServerName & " ;persist security info=False;initial catalog= " & pDatabaseName
	'   Else
	'      conSql.ConnectionString = "Data Source = " & pServerName & " ; User id = " & pUserName & " ; initial Catalog = " & pDatabaseName & " ; password = " & pPassword
	'   End If
	'   conSql.Open()
	'End Sub

	'Private Sub frmCon_ReturnSqlConnection(ByVal Value As System.Data.SqlClient.SqlConnection) Handles frmCon.ReturnSqlConnection
	'   conSql = Value
	'End Sub


#End Region


End Module
