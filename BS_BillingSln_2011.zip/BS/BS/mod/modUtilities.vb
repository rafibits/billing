''
Imports Microsoft.Win32

Module modUtilities

	Public Function getKeyValue(ByRef pStrSubKeyName As String, ByRef pStrName As String) As String
		''
		Dim rk As RegistryKey
		'' check if exist, first time create subKey...
		Try
			rk = Registry.LocalMachine.OpenSubKey(pStrSubKeyName, True)
			If rk Is Nothing Then
				rk = Registry.LocalMachine.CreateSubKey(pStrSubKeyName)
			End If
			''
			Return rk.GetValue(pStrName)

		Catch ex As Exception
			Return Err.Description
		End Try

	End Function

	Public Function setKeyValue(ByRef pStrSubKeyName As String, ByRef pStrName As String, ByVal pStrValue As String) As String
		''
		Dim rk As RegistryKey
		'' check if exist, first time create subKey...
		Try
			rk = Registry.LocalMachine.OpenSubKey(pStrSubKeyName, True)
			If rk Is Nothing Then
				rk = Registry.LocalMachine.CreateSubKey(pStrSubKeyName)
			End If
			''
			rk.SetValue(pStrName, pStrValue)

		Catch ex As Exception
			Return Err.Description
		End Try

	End Function


	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' Set Forms' Grid Last settings...
	''
	'' LoadProfile(pStrSubKeyName, pDGrdView)
	'' param: 
	''      [pStrSubKeyName] registry's subKey name as a string ref
	''      [pDGrdView] ref to calling form's DataGridView
	''
	'' This method allows users to load grid width and visibility values from win.registry.
	'' 
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Public Sub LoadProfile(ByRef pStrSubKeyName As String, ByRef pDGrdView As Windows.Forms.DataGridView)

		Dim rk As RegistryKey
		Dim col As Windows.Forms.DataGridViewColumn
		Dim cv As String, colV() As String
		Dim cw As String, colW() As String
		Dim i As Integer

		'' check if subKey exists, if not return(first time)...
		Try
			rk = Registry.LocalMachine.OpenSubKey(pStrSubKeyName)
			If rk Is Nothing Then
				Return
			End If
			''
			cv = rk.GetValue("Visible")
			cw = rk.GetValue("Widths")
		Catch ex As Exception
			Return
		End Try

		'' split values into arry/collection...
		colV = cv.Split(",")
		colW = cw.Split(",")

		''
		'' If Registry or Grd_Num_Of_Cols has chgd error is rised, 
		'' del entire subKey and on frmClose it is regenerated...
		''
		If pDGrdView.Columns.Count <> colV.Length Then
			'' del entire subKey...
			Registry.LocalMachine.DeleteSubKeyTree(pStrSubKeyName)
			Exit Sub
		End If

		''
		'' set saved settings...
		''
		i = 0
		'pDGrdView.BeginEdit(True)
		For Each col In pDGrdView.Columns
			col.Visible = Convert.ToBoolean(colV(i))
			col.Width = Convert.ToInt32(colW(i))
			i += 1
		Next
		'pDGrdView.EndEdit()


	End Sub

	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' Set Forms' Grid Last settings...
	''
	'' SaveProfile(pStrSubKeyName, pDGrdView)
	'' param: 
	''      [pStrSubKeyName] registry's subKey name as a string ref
	''      [pDGrdView] ref to calling form's DataGridView
	''
	'' This method allows users to save grid width and visibility values into win.registry.
	'' 
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Public Sub SaveProfile(ByRef pStrSubKeyName As String, ByRef pDGrdView As Windows.Forms.DataGridView)

		Dim rk As RegistryKey
		Dim col As System.Windows.Forms.DataGridViewColumn
		Dim cv As String = String.Empty
		Dim cw As String = String.Empty

		'' load col width and visiblity...
		For Each col In pDGrdView.Columns
			If cv <> String.Empty Then
				cv = cv & ", "
				cw = cw & ", "
			End If
			cv = cv & col.Visible
			cw = cw & col.Width
		Next

		'' check if exist, first time create subKey...
		Try
			rk = Registry.LocalMachine.OpenSubKey(pStrSubKeyName, True)
			If rk Is Nothing Then
				rk = Registry.LocalMachine.CreateSubKey(pStrSubKeyName)
			End If
		Catch ex As Exception
			Return
		End Try

		''
		rk.SetValue("Visible", cv)
		rk.SetValue("Widths", cw)

	End Sub

	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	''called when leaving cbo to detect new entries..
	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'	Public Function AddNewValueToCbo(ByRef pclsMr As BITSConn.ClsMain, ByRef pcboX As ComboBox, ByVal psTblName As String, _
	'	ByVal psIDFieldName As String, ByVal psValFieldName As String, ByVal psIDFieldName As String, ByVal psValFieldName As String) As Boolean
	Public Function AddNewValueToCbo(ByRef pclsMr As BITSConn.ClsMain, ByRef pcboX As ComboBox, ByVal psTblName As String, _
	ByVal psIDFieldName As String, ByVal psFieldValue As String, _
	Optional ByVal psParentFieldName As String = "", Optional ByVal piParentFieldValue As Integer = 0) As Boolean
		''           
		If pcboX.Text = "" Then
			''
			'' if empty/no selection...
			''
			Return False

		ElseIf pcboX.FindStringExact(pcboX.Text) <> -1 Then
			''
			'' ITEM FOUND...
			''
			Return True
		Else
			''
			'' if NOT FOUND...
			''
			'' value not found; ?ask user to add it?
			If MsgBox("[" & pcboX.Text & "] could not be found. Would you like to ADD it?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
				''
				'' Do not want to add it...
				''
				pcboX.SelectedIndex = -1
				pcboX.Text = ""
				Return False
			Else
				''
				'' ADD IT, insert new value into tbl and reflect chages in form...
				''
				Dim lngNextRecID As Long
				Dim strNewVal As String

				''
				'' Get Next RecID...
				lngNextRecID = pclsMr.GetMaxNumber(psIDFieldName, psTblName) + 1
				strNewVal = pcboX.Text

				''
				If psParentFieldName = "" Then
					'' Insert SINGLE value into given table...
					strSQL = "INSERT INTO " & psTblName & " (" & psIDFieldName & ", " & psFieldValue & ", Del " & ") "
					strSQL &= " VALUES (" & lngNextRecID & ", N'" & pcboX.Text & "',0 )"
				Else
					'' Insert value with a Parent into given table...
					strSQL = "INSERT INTO " & psTblName & " ("
					strSQL &= psIDFieldName & ", " & psFieldValue & ", " & psParentFieldName & ", Del " & ") "
					strSQL &= " VALUES (" & lngNextRecID & ", N'" & pcboX.Text & "', " & piParentFieldValue & ",0 )"
				End If
				''
				'' go...
				Dim cmdSql As New SqlClient.SqlCommand(strSQL, conSql)
				conSql.Open()
				cmdSql.ExecuteNonQuery()
				conSql.Close()
				''
				'' Insert new row into dataView...
				''
				Dim dv As DataView
				Dim drv As DataRowView

				dv = pcboX.DataSource

				'' add it...
				drv = dv.AddNew()
				''
				drv(psIDFieldName) = lngNextRecID
				drv(psFieldValue) = strNewVal

				''NB:11-Sept-07
				If psParentFieldName <> "" Then
					drv(psParentFieldName) = piParentFieldValue
				End If

				''
				drv.EndEdit()

				'' set focus to new element in cbo..
				pcboX.SelectedValue = lngNextRecID
				' pcboX.SelectedValue = lngNextRecID
				''
				'' Just added it...
				Return True
			End If
		End If

	End Function

	Public Function CheckComboValue(ByRef pDsSource As DataSet, ByVal pstrTableName As String, ByVal pStrFieldName As String, ByVal pCbo As ComboBox) As Boolean
		Try
			If pCbo.Text = "" Then Exit Function
			Dim Key(0) As String
			Dim intRowNumber As Integer
			CheckComboValue = True
			Key(0) = pCbo.Text
			' dsData.Tables(pstrTableName).DefaultView.Sort = pStrFieldName
			intRowNumber = pDsSource.Tables(pstrTableName).DefaultView.Find(Key(0))
			If intRowNumber = -1 Then Beep() : pCbo.Focus() : MsgBox("Please Select a Value from the List") : Return False
		Catch ex As Exception
			MsgBox(ex.Message)
			Return False
		End Try
	End Function


	Public Sub FillCombo(ByVal pcbo As ComboBox, ByVal pstrTableName As DataTable, ByVal pDisplayMemeber As String, ByVal pValueMemeber As String)
		With pcbo
			.DataSource = pstrTableName.DefaultView
			.DisplayMember = pDisplayMemeber
			.ValueMember = pValueMemeber
		End With
	End Sub


	Public Sub ReadOnlyThis(ByVal Flag As Boolean, ByVal ParamArray Argts() As Object)
		Dim Crtl As Object
		For Each Crtl In Argts
			Crtl.ReadOnly = Flag
		Next
	End Sub
	Public Sub EnableThis(ByVal Flag As Boolean, ByVal ParamArray Argts() As Object)
		Dim Crtl As Object
		For Each Crtl In Argts
			Crtl.Enabled = Flag
		Next
	End Sub


	Public Sub DeleteRecord(ByVal pStrtableName As String, ByVal pRecordNumber As Integer, ByVal pFieldName As String)
		Dim cmd As New SqlClient.SqlCommand("Update " & pStrtableName & " set Del = 1  where " & pFieldName & " = " & pRecordNumber, conSql)

		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()
	End Sub

	Public Sub FlipControls(ByVal RootControl As Control)
		RootControl.SuspendLayout()
		FlipControlsRec(RootControl)
		RootControl.ResumeLayout()
	End Sub

	Private Sub FlipControlsRec(ByVal RootControl As Control)

		If RootControl.RightToLeft = RightToLeft.Yes Then
			RootControl.RightToLeft = RightToLeft.No
		Else
			RootControl.RightToLeft = RightToLeft.Yes
		End If

		If RootControl.Controls.Count = 0 Then
			Exit Sub
		End If

		Dim aControl As Control
		Dim w As Integer, h As Integer

		w = RootControl.Width
		h = RootControl.Height

		For Each aControl In RootControl.Controls
			aControl.Left = w - aControl.Width - aControl.Left

			If ((aControl.Anchor And AnchorStyles.Left) = AnchorStyles.Left) Xor ((aControl.Anchor And AnchorStyles.Right) = AnchorStyles.Right) Then
				If aControl.Anchor And AnchorStyles.Left Then
					aControl.Anchor = aControl.Anchor Or AnchorStyles.Right
					aControl.Anchor = aControl.Anchor And (Not AnchorStyles.Left)
				Else
					If aControl.Anchor And AnchorStyles.Right Then
						aControl.Anchor = aControl.Anchor Or AnchorStyles.Left
						aControl.Anchor = aControl.Anchor And (Not AnchorStyles.Right)
					End If
				End If
			End If

			FlipControlsRec(aControl)
		Next

	End Sub
	''' Nb:30-Aug-07

	Public Function GetRate(ByVal pFromCurr As Int16, ByVal pToCurr As Int16, ByVal pdtpPaymentDateValue As Date) As Double
		Debug.WriteLine("GetRate")
		'    Try
		Dim Rate As Double
		If pFromCurr = pToCurr Then
			Return 1
		End If
		Dim cmd As New SqlClient.SqlCommand("spGetRate", conSql)
		cmd.CommandType = CommandType.StoredProcedure
		cmd.Parameters.AddWithValue("@fromCurrID", pFromCurr)
		cmd.Parameters.AddWithValue("@toCurrID", pToCurr)

		'cmd.Parameters.AddWithValue("@dat", pdtpPaymentDate.Value)
		cmd.Parameters.AddWithValue("@dat", pdtpPaymentDateValue)
		conSql.Open()
		Rate = cmd.ExecuteScalar
		conSql.Close()
		Return Rate

	End Function

	Public Function GetOperation(ByVal pFromCurr As Int16, ByVal pToCurr As Int16, ByVal pdtpPaymentDateValue As Date) As String
		Debug.WriteLine("GetRate")
		'    Try
		Dim operation As String
		'If pFromCurr = pToCurr Then
		'   Return 1
		'End If
		Dim cmd As New SqlClient.SqlCommand("spGetOperation", conSql)
		cmd.CommandType = CommandType.StoredProcedure
		cmd.Parameters.AddWithValue("@fromCurrID", pFromCurr)
		cmd.Parameters.AddWithValue("@toCurrID", pToCurr)

		' cmd.Parameters.AddWithValue("@dat", dtpPaymentDate.Value) ''
		cmd.Parameters.AddWithValue("@dat", pdtpPaymentDateValue) ''

		conSql.Open()
		operation = cmd.ExecuteScalar
		conSql.Close()
		Return operation

	End Function
	Public Function GetExchangeValue(ByVal pFromCurr As Int16, ByVal pToCurr As Int16, ByVal pdtpPaymentDateValue As String, ByVal pAmount As Double, Optional ByVal pRate As Decimal = -1) As Double
		Dim mAmount As Double
		Dim strOperation As Object = GetOperation(pFromCurr, pToCurr, pdtpPaymentDateValue)

		If strOperation = "/" Then
			If pRate <> -1 Then
				mAmount = pAmount / pRate
			Else
				mAmount = pAmount / GetRate(pFromCurr, pToCurr, pdtpPaymentDateValue)
			End If

			Return mAmount
		ElseIf strOperation = "*" Then
			If pRate <> -1 Then
				mAmount = pAmount * pRate
			Else
				mAmount = pAmount * GetRate(pFromCurr, pToCurr, pdtpPaymentDateValue)
			End If

			Return mAmount
		ElseIf strOperation Is Nothing Then
			Return pAmount
		End If

	End Function

	Public Function GetAcctCurrency(ByVal pAcctID As Long)
		Dim acctCurrency As Integer = 0
		Try
			Dim AcctID As Integer = 0


			Dim cmd2 As New SqlClient.SqlCommand("SELECT  CurrencyID   FROM tblClient where ClientID= " & pAcctID, conSql)
			conSql.Open()
			acctCurrency = cmd2.ExecuteScalar()
			conSql.Close()
			Return acctCurrency
		Catch ex As Exception
			acctCurrency = 0
			conSql.Close()
		End Try
	End Function

	Public Function GetAcctID(ByVal pClientID As Long)
		Dim AcctID As Integer = 0
		Dim cmd1 As New SqlClient.SqlCommand("SELECT ClientID FROM tblClient WHERE ClientID= " & pClientID, conSql)
		Try
			conSql.Open()
			AcctID = cmd1.ExecuteScalar()
			conSql.Close()
		Catch ex As Exception
			conSql.Close()
		End Try

		Return AcctID
	End Function

	''Get Company Currency symbol
	Public Function GetCompanyCurrencySymbol() As String
		Dim strCurrSymbol As String = ""

		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdCurrency As SqlClient.SqlCommand

		''
		strSQL = "SELECT * FROM dbo.tblCurrency INNER JOIN dbo.tblCompany ON dbo.tblCurrency.CurrID = dbo.tblCompany.CurrID WHERE dbo.tblCompany.companyID=  " & gIntCompanyID
		''
		cmdCurrency = New SqlClient.SqlCommand(strSQL, conSql)
		cmdCurrency.CommandType = CommandType.Text
		Try
			If conSql.State = ConnectionState.Closed Then
				conSql.Open()
			End If

			dRdr = cmdCurrency.ExecuteReader()
			If dRdr.Read Then
				strCurrSymbol = dRdr("Symbol")
			End If
			dRdr.Close()
			conSql.Close()
			If strCurrSymbol <> "" Then
				GetCompanyCurrencySymbol = strCurrSymbol
			Else
				GetCompanyCurrencySymbol = 0
			End If
			''
			Return GetCompanyCurrencySymbol

		Catch ex As Exception
			dRdr.Close()
			conSql.Close()
		End Try
		''
		Return 0
	End Function

	''Get Company Currency symbol
	Public Function GetCompanyCurrencySymbol2() As String
		Dim strCurrSymbol As String = ""

		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdCurrency As SqlClient.SqlCommand

		''
		strSQL = "SELECT * FROM  dbo.tblCurrency INNER JOIN dbo.tblCompany ON dbo.tblCurrency.CurrID = dbo.tblCompany.CurrID2 WHERE dbo.tblCompany.companyID=  " & gIntCompanyID
		''
		cmdCurrency = New SqlClient.SqlCommand(strSQL, conSql)
		cmdCurrency.CommandType = CommandType.Text
		Try
			If conSql.State = ConnectionState.Closed Then
				conSql.Open()
			End If

			dRdr = cmdCurrency.ExecuteReader()
			If dRdr.Read Then
				strCurrSymbol = dRdr("Symbol")
			End If
			dRdr.Close()
			conSql.Close()
			If strCurrSymbol <> "" Then
				GetCompanyCurrencySymbol2 = strCurrSymbol
			Else
				GetCompanyCurrencySymbol2 = 0
			End If
			''
			Return GetCompanyCurrencySymbol2

		Catch ex As Exception
			dRdr.Close()
			conSql.Close()
		End Try

		''
		Return 0

	End Function

	Public Function GetAccount(ByVal pID As Integer)

		''Get Accounts of the Fixed Account
		Dim StrAccount As String = ""

		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdAccount As SqlClient.SqlCommand

		strSQL = "Select * from tblAccountFixedRef where AcctFixedID= " & pID
		cmdAccount = New SqlClient.SqlCommand(strSQL, conSql)
		cmdAccount.CommandType = CommandType.Text
		Try
			If conSql.State = ConnectionState.Closed Then
				conSql.Open()
			End If

			dRdr = cmdAccount.ExecuteReader()
			If dRdr.Read Then
				StrAccount = "(" & dRdr("AcctID") & " ," & dRdr("Acct1ID") & " ) "
			End If
			dRdr.Close()
			conSql.Close()
			If StrAccount <> "" Then
				Return StrAccount
			Else
				Return 0
			End If
		Catch ex As Exception
			conSql.Close()
		End Try
    End Function

	Public Sub AutoComplete(ByVal cbo As ComboBox, ByVal e As KeyPressEventArgs)

		If Char.IsControl(e.KeyChar) Then Return

		With cbo

			Dim ToFind As String = .Text.Substring(0, .SelectionStart) & e.KeyChar
			Dim Index As Integer = .FindStringExact(ToFind)

			If Index = -1 Then Index = .FindString(ToFind)
			If Index = -1 Then Return

			.SelectedIndex = Index
			.SelectionStart = ToFind.Length
			.SelectionLength = .Text.Length - .SelectionStart

			e.Handled = True

		End With

    End Sub

    Public Sub Renumbering(ByVal pDataGrid As DataGridView)
        ''
        Dim j As Integer
        ''
        For j = 0 To pDataGrid.Rows.Count - 1
            ''
            pDataGrid.Rows(j).Cells("Line").Value = j + 1
        Next
    End Sub

End Module
