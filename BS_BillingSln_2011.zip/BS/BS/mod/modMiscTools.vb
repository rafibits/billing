Module PIModule1
   Public Sub characters_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
      If (e.KeyChar >= "!" And e.KeyChar <= "@") Or (e.KeyChar >= "[" And e.KeyChar <= "_") Or (e.KeyChar >= "{" And e.KeyChar <= "~") And Asc(e.KeyChar) <> 8 Then

         e.Handled = True
      End If
   End Sub
   Public Sub EMAIL_Validated(ByVal sender As Object, ByVal e As System.EventArgs)
      If sender.Text.IndexOf(".") = -1 Or sender.Text.IndexOf("@") = -1 Then
         MsgBox("E-mail address must be valid e-mail address format." + ControlChars.Cr + "For example 'someone@microsoft.com'", MsgBoxStyle.Exclamation, "Data validation error")
         sender.SelectionStart = 0
         sender.SelectionLength = Len(sender.Text)
         sender.Focus()
      End If
   End Sub
   Public Sub Alpha_Keypress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
      If Not ((Asc(e.KeyChar) >= 47 And Asc(e.KeyChar) <= 57) Or _
      (Asc(e.KeyChar) >= 65 And Asc(e.KeyChar) <= 90) Or _
      (Asc(e.KeyChar) >= 97 And Asc(e.KeyChar) <= 122) Or Asc(e.KeyChar) = 8) Then
         'if it is anything else then escape the pressed character
         e.Handled = True
      End If
   End Sub
   Public Sub Integers_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
      If (Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57) And Asc(e.KeyChar) <> 8 Then
         'if it is anything else then escape the pressed character
         e.Handled = True
      End If
   End Sub
   Public Sub delete_press(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
      If e.KeyCode = Keys.Delete Then
         'if it is anything else then escape the pressed character
         e.Handled = True
      End If
   End Sub

   Public Sub IntDecimal_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
      If (Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57) And Asc(e.KeyChar) <> 46 And Asc(e.KeyChar) <> 8 Then
         'if it is anything else then escape the pressed character
         e.Handled = True
      Else

         If (Asc(e.KeyChar) = 46 And InStr(sender.Text, ".") > 0) Then
            e.Handled = True
            Exit Sub

         End If
      End If

   End Sub

   'Public Sub AutoComplete(ByVal cbo As ComboBox, ByVal e As KeyPressEventArgs)

   '   If Char.IsControl(e.KeyChar) Then Return

   '   With cbo

   '      Dim ToFind As String = .Text.Substring(0, .SelectionStart) & e.KeyChar
   '      Dim Index As Integer = .FindStringExact(ToFind)

   '      If Index = -1 Then Index = .FindString(ToFind)
   '      If Index = -1 Then Return

   '      .SelectedIndex = Index
   '      .SelectionStart = ToFind.Length
   '      .SelectionLength = .Text.Length - .SelectionStart

   '      e.Handled = True

   '   End With

   'End Sub


End Module
