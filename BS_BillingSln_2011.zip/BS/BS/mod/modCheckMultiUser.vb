﻿Imports System.Data.SqlClient
''
Module modCheckMultiUser

#Region " Functions . . . "
    ''
    Public Function CheckUserGenInvoice() As Integer
        ''
        Dim IntUserGenInvoice As Integer
        ''
        Dim cmd As New SqlCommand("Select UserGenInvoiceID from tblUserGenInvoice ", conSql)
        ''
        Try
            conSql.Open()
            IntUserGenInvoice = cmd.ExecuteScalar
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try
        ''
        If IntUserGenInvoice > 0 Then
            ''
            Return IntUserGenInvoice
        Else
            ''
            Return -1
        End If
        ''
    End Function

    Public Function CheckDate() As Boolean
        ''
        Dim DateGen As DateTime
        ''
        Dim cmd As New SqlCommand("Select GenDate from tblUserGenInvoice ", conSql)
        Try
            conSql.Open()
            DateGen = cmd.ExecuteScalar
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
            Return False
        End Try
        ''
        ''if after 15 mns from Generate Invoice the Table tblUserGenInvoice Not Empty 
        ''
        If DateDiff(DateInterval.Minute, DateGen, Now) < 15 Then
            ''
            Return True
        Else
            Return False
        End If
    End Function

    Public Sub DeleteUserGenInvoice()
        ''
        Dim intUserID As Integer
        ''
        intUserID = CheckUserGenInvoice()
        ''
        If intUserID = gIntUserID Then
            ''
            Dim cmd As New SqlCommand("DELETE from tblUserGenInvoice ", conSql)
            ''
            Try
                conSql.Open()
                cmd.ExecuteNonQuery()
                conSql.Close()
            Catch ex As Exception
                conSql.Close()
            End Try
            ''
        End If
        ''
    End Sub

    Public Function GetComputerName() As String
        ''
        Dim StrComputerName As String
        ''
        Dim cmd As New SqlCommand("Select ComputerName from tblUserGenInvoice ", conSql)
        Try
            conSql.Open()
            StrComputerName = cmd.ExecuteScalar
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try
        '' 
        If StrComputerName <> "" Then
            Return StrComputerName
        Else
            Return ""
        End If
        ''
    End Function

    Public Sub SetUserGenInvoice()
        ''
        Dim strUserName As String
        Dim strComputerName As String = ""

        ''
        Dim cmd As New SqlCommand("SELECT UserName FROM vwUsers WHERE EmployeeID=" & gIntUserID, conSql)
        Try
            conSql.Open()
            strUserName = cmd.ExecuteScalar
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
            ''
        End Try
        ''
        strComputerName = My.Computer.Name
        ''
        'Dim cmdInsert As New SqlCommand("INSERT INTO tblUserGenInvoice(UserGenInvoiceID, UserGenInvoiceName, ComputerName,GenDate, Del)VALUES(" & gIntUserID & " ,'" & strUserName & "','" & strComputerName & "'," & Now.Date.ToString("") & ",1)", conSql)
        Dim cmdInsert As New SqlCommand("INSERT INTO tblUserGenInvoice(UserGenInvoiceID, UserGenInvoiceName, ComputerName,GenDate, Del)VALUES(@IntUserID ,@strUserName ,@strComputerName ,@Date,1)", conSql)
        'gIntUserID & " ,'" & strUserName & "','" & strComputerName & "'," & Now.Date.ToString("") & ",1)", conSql)
        cmdInsert.Parameters.AddWithValue("@IntUserID", gIntUserID)
        cmdInsert.Parameters.AddWithValue("@strUserName", strUserName)
        cmdInsert.Parameters.AddWithValue("@strComputerName", strComputerName)
        cmdInsert.Parameters.AddWithValue("@Date", Now)

        Try
            conSql.Open()
            cmdInsert.ExecuteScalar()
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try
        ''
    End Sub


#End Region

End Module
