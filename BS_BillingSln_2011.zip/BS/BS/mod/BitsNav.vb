Public Class BitsNav

   Private CurrManager As CurrencyManager

   Private dtTable As DataTable

   Public Event BeforeNext()
   Public Event BeforePrevious()
   Public Event BeforeLast()
   Public Event beforeFirst()
   Public Event AfterNext()
   Public Event AfterPrevious()
   Public Event AfterLast()
   Public Event AfterFirst()

   Private mlblNumbers As Label

   Sub New()
   End Sub

   Sub New(ByVal lblNumbers As Label)
      mlblNumbers = lblNumbers
   End Sub

   Public Sub GotoFirst()
      RaiseEvent beforeFirst()
      CurrManager.Position = 0
      SetLabel(CurrManager.Position + 1, dtTable.DefaultView.Count)
      RaiseEvent AfterFirst()
   End Sub

   Private Sub SetLabel(ByVal pIntCurrentPosition As Integer, ByVal pIntRowCount As Integer)
      If Not (mlblNumbers Is Nothing) Then
			mlblNumbers.Text = CStr(pIntCurrentPosition) + " of " + CStr(pIntRowCount)
      End If
   End Sub

   Public Sub GotoPrev()
      RaiseEvent BeforePrevious()
      If CurrManager.Position < 0 Then
         CurrManager.Position = 0
      Else
         CurrManager.Position -= 1
      End If
      SetLabel(CurrManager.Position + 1, dtTable.DefaultView.Count)
      RaiseEvent AfterPrevious()
   End Sub

   Public Sub GotoNext()
      RaiseEvent BeforeNext()
      If CurrManager.Position = dtTable.DefaultView.Count Then
         CurrManager.Position = dtTable.DefaultView.Count - 1
      Else

         CurrManager.Position += 1
      End If

      SetLabel(CurrManager.Position + 1, dtTable.DefaultView.Count)
      RaiseEvent AfterNext()
   End Sub

   Public Sub GotoLast()
      RaiseEvent BeforeLast()
      CurrManager.Position = dtTable.Rows.Count - 1
      SetLabel(CurrManager.Position + 1, dtTable.DefaultView.Count)
      RaiseEvent AfterLast()
   End Sub

   Public Sub SetFilteredPosition(ByVal Value As Integer)
      If Value < 0 Then Exit Sub
      CurrManager.Position = Value
      SetLabel(CurrManager.Position + 1, dtTable.DefaultView.Count) 'dtTable.Rows.Count)
   End Sub

   Public Sub Refresh()
      SetLabel(CurrManager.Position + 1, dtTable.DefaultView.Count)
   End Sub

   Public Property CurrentPosition() As Integer
      Get
         Return CurrManager.Position
      End Get
      Set(ByVal Value As Integer)
         CurrManager.Position = Value
         SetLabel(CurrManager.Position + 1, dtTable.DefaultView.Count)
      End Set
   End Property

   Public Sub RejectChanges()
      CurrManager.CancelCurrentEdit()
      dtTable.RejectChanges()
      SetLabel(CurrManager.Position + 1, dtTable.DefaultView.Count)
   End Sub

   Public Sub AddNew()
      CurrManager.EndCurrentEdit()
      CurrManager.AddNew()
      Refresh()
   End Sub

   Public Sub RemoveAt(ByVal pPosition As Integer)
      CurrManager.RemoveAt(pPosition)
   End Sub

   Public Sub EndCurrentEdit()
      CurrManager.EndCurrentEdit()
   End Sub

   Public Sub CancelCurrentEdit()
      CurrManager.CancelCurrentEdit()
   End Sub

   Public Sub SetCurrency(ByVal pFrm As System.Windows.Forms.Control, ByVal pdsdata As DataSet, ByVal pstrTableName As String)
      CurrManager = pFrm.BindingContext(pdsdata.Tables(pstrTableName).DefaultView)
      dtTable = pdsdata.Tables(pstrTableName)
      SetLabel(CurrManager.Position + 1, dtTable.DefaultView.Count)
   End Sub

   Public Sub Reset()
      SetLabel(CurrManager.Position + 1, dtTable.DefaultView.Count)
   End Sub

End Class
