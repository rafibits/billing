''
''
Imports BITSConn


Public Class frmCompany

#Region "Form-Declarations"
	Private clsMr As ClsMain
	Private dsData As New DataSet

	Private mstrTableName As String = "tblCompany"
	Private daCompany As SqlClient.SqlDataAdapter
	Private dgStyle As New DataGridTableStyle
	Private dabranch As SqlClient.SqlDataAdapter
	Private daAccount As SqlClient.SqlDataAdapter
	Private mStrCurrentState As String
	Private mStrPicSource As String '' Pic source path 
	Private WithEvents Nav As BitsNav

	Private blnLoading As Boolean
	Private DataChange As Boolean = False
	Dim blncbo As Boolean = True
	Dim ifSave As Boolean = False
	Dim blnPic As Boolean = False	' Pic Boolean 

#End Region


#Region "Form-Load..."

	Private Sub frmCompany_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		''
		' bug fix:
		' If Me.Parent.Parent Is Nothing Then Return
		blnLoading = True

		clsMr = New ClsMain(conSql)

		Nav = New BitsNav()
		MakeDataAdapter()
		FillComboBox()
		SetDataBinding()
		SetAutoNumber()
		SetCurrencyManager()
		SetDefaultValue()

		''
		Dim dv As DataView

		dv = dsData.Tables("tblBranch").DefaultView()
		dv.AllowNew = False
		dv.AllowEdit = False
		grdBranch.DataSource = dv
		dgStyle.MappingName = "tblBranch"
		grdBranch.TableStyles.Add(dgStyle)

		'' Set columns width...
		dgStyle.GridColumnStyles("BranchID").Width = 0
		dgStyle.GridColumnStyles("CompanyID").Width = 0
		dgStyle.GridColumnStyles("BranchName").Width = 150
		dgStyle.GridColumnStyles("CreateBy").Width = 0
		dgStyle.GridColumnStyles("Del").Width = 0

		formatDecimal()
		'  DisableCompanyName()
		' BringPicFromDataBase()
		blncbo = False

		'Disabled()
		dtpDateFrom.Enabled = False
		dtpDateTo.Enabled = False
		' BringPicFromDataBase()
		DrawGrid()
		filterGrid()
		setState("BROWSE")

		blnLoading = False

	End Sub

#End Region

#Region "Form-Initialization"

	Public Sub MakeDataAdapter()
		strSQL = "SELECT * FROM tblCompany WHERE CompanyID=" & gIntCompanyID
		daCompany = clsMr.BuildSqlAdapter(strSQL, mstrTableName)
		clsMr.BuildSqlAdapter("SELECT CurrID, Symbol FROM tblCurrency WHERE del = 0", "CurrID")
		clsMr.BuildSqlAdapter("SELECT CurrID, Symbol FROM tblCurrency WHERE del = 0", "CurrID2")
		dabranch = clsMr.BuildSqlAdapter("SELECT * FROM tblBranch WHERE del=0 AND CompanyID=" & gIntCompanyID, "tblBranch")
		''
		'' populate da's for combos on form...
		''
		dsData = clsMr.getDataSet
	End Sub

	Public Sub FillComboBox()
		clsMr.FillComboBox("CurrID", cboCurrID, "Symbol", "CurrID")
		clsMr.FillComboBox("CurrID2", cboCurrency2, "Symbol", "CurrID")
	End Sub

	Public Sub SetAutoNumber()
		clsMr.SetAutoNumber(mstrTableName, "CompanyID")
		clsMr.SetAutoNumber("tblBranch", "BranchID")
	End Sub

	Public Sub SetCurrencyManager()
		Nav.SetCurrency(Me, dsData, mstrTableName)
	End Sub

	Public Sub SetDataBinding()
		clsMr.BindDateTimePicker(dtpDateFrom, mstrTableName, "DateFrom")
		clsMr.BindDateTimePicker(dtpDateTo, mstrTableName, "DateTo")
		clsMr.BindTextBox(txtCompanyName, mstrTableName, "CompanyName")
		clsMr.BindTextBox(txtNote, mstrTableName, "Note")
		clsMr.BindTextBox(txtCompanyNumber, mstrTableName, "CompanyNumber")
		clsMr.BindTextBox(txtCurrBal, mstrTableName, "CurrBal")
		clsMr.BindComboBox(cboCurrID, mstrTableName, "CurrID")
		clsMr.BindComboBox(cboCurrency2, mstrTableName, "CurrID2")
	End Sub

	Public Sub SetDefaultValue()
		clsMr.SetDefaults(mstrTableName, "Del", 0)
		clsMr.SetDefaults(mstrTableName, "CreateBy", gIntUserID)
		clsMr.SetDefaults("tblbranch", "CreateBy", gIntUserID)
		clsMr.SetDefaults(mstrTableName, "CreateDate", Now())
		clsMr.SetDefaults("tblBranch", "CompanyID", gIntCompanyID, "Del", 0)
		clsMr.SetDefaults(mstrTableName, "CurrBal", 0)
	End Sub

#End Region


#Region "Form-Functions"

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		'   If ifSave = True Then
		'      Dim res As MsgBoxResult
		'res = MsgBox("Do you want to save the changes", MsgBoxStyle.Question + MsgBoxStyle.YesNoCancel, "BitSolution")
		'      If res = MsgBoxResult.Yes Then
		'         save()
		'      End If
		'   End If
		'   Me.Close()

		If ifSave Then
			Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
				Case MsgBoxResult.Yes
					'' call save...
					If lstDataErr.Items.Count <> 0 Then
						MsgBox("Cannot save.Please check error list")
						Exit Sub
					Else
						btnSave.PerformClick()
						Me.Close()
					End If
				Case MsgBoxResult.No
					'' ignore changes...

					Try
						Nav.CancelCurrentEdit()
					Catch ex As Exception

					End Try
					Me.Close()
				Case MsgBoxResult.Cancel
					'' ignore close press..
					'' do nothing...

			End Select
		Else
			Me.Close()
		End If
	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		If btnSave.Text = "E d i t" Then
			setState("EDIT")
			Exit Sub
		End If
		save()
	End Sub

	Private Sub save()
		'Try
		If txtCompanyName.ReadOnly = False Then
			dsData.Tables(mstrTableName).DefaultView.Item(0).EndEdit()
			clsMr.Update(daCompany, mstrTableName)

			'If blnPic Then SavePicToDB()
		End If

		Dim al As ArrayList
		Dim dv As DataView
		Dim drv As DataRowView
		Dim i As Integer

		al = New ArrayList
		dv = dsData.Tables("tblBranch").DefaultView
		For i = 0 To dv.Count - 1
			drv = dv.Item(i)
			If drv.Row.RowState = DataRowState.Added Then
				al.Add(drv)
			End If
		Next

		clsMr.Update(dabranch, "tblBranch")

		' create accounts for new branches
		For Each drv In al
			' AcctTypeID 5 = Branch Stock
			'CreateAccount(drv("BranchId"), drv("BranchName"), 5)
			' AcctTypeID 6 = Branch Cash Sales
			'CreateAccount(drv("BranchId"), drv("BranchName"), 6)
		Next
		ifSave = False
		btnSave.Enabled = False
		'Catch ex As Exception
		'   MsgBox(ex.Message)
		'End Try
		'clsMr.Update(dabranch, "tblBranch")

		'Dim dr1 As DataRow
		'dr1 = dsData.Tables("tblBranch").NewRow()
		'dr1("CompanyID") = grdBranch.Item(grdBranch.CurrentRowIndex, 1)

		'dr1("BranchID") = grdBranch.Item(grdBranch.CurrentRowIndex, 0)
		'dr1("BranchName") = grdBranch.Item(grdBranch.CurrentRowIndex, 2)

		'dsData.Tables("tblBranch").Rows.Add(dr1)
		'clsMr.Update(dabranch, "tblBranch")
		'dabranch.Update(dsData, "tblBranch")
		setState("SAVE")
	End Sub

	Private Sub formatDecimal()
		'txtCurrBal.Text = Convert.ToDecimal(txtCurrBal.Text).ToString("#0.00")
	End Sub

	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' This function gets the row index of the current record
	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Public Function GetRowIndex() As Integer
		Dim i As Integer
		For i = 0 To dsData.Tables(mstrTableName).DefaultView.Count - 1
			If dsData.Tables(mstrTableName).DefaultView.Item(i)("CompanyID") = gIntCompanyID Then
				Return i
			End If
		Next
		Return -1
	End Function

#End Region



#Region "frmPhotoNew"

	Private Sub btnGetPicture_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetPicture.Click
		blnPic = True
		ofdGetPhoto.Filter = "jpg (*.jpg)|*.jpg|bmp (*.bmp)|*.bmp|All files (*.*)|*.*"
		ofdGetPhoto.FilterIndex = 1
		ofdGetPhoto.RestoreDirectory = True
		ofdGetPhoto.ShowDialog()
		txtLocation.Text = ofdGetPhoto.FileName
		mStrPicSource = ofdGetPhoto.FileName
		'txtLocation.Text = mStrPicSource
		If Not mStrPicSource = "" Then PicPersonnel.Image = Image.FromFile(txtLocation.Text)
	End Sub

	Private Sub SavePicToDB() ''''''' Save Picture to data base 

		If mStrPicSource = "" Then Exit Sub
		Dim ms As New System.IO.MemoryStream

		'' read Picture and convert to bytes 
		PicPersonnel.Image.Save(ms, PicPersonnel.Image.RawFormat)
		Dim arrImage() As Byte = ms.GetBuffer

		' Close the stream object to release the resource.
		ms.Close()

		'' Update record 
		Dim strSQL As String = "update  tblCompany  set  CompanyLogo = @Picture where CompanyID = " & gIntCompanyID

		Dim cmd As New SqlClient.SqlCommand(strSQL, conSql)
		With cmd
			.Parameters.Add(New SqlClient.SqlParameter("@Picture", _
				 SqlDbType.Image)).Value = arrImage
		End With
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()

		blnPic = False	 '' Convert Boolean to false 
	End Sub
	
	Private Sub txtDataFile_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)
		ofdGetPhoto.Filter = "All files (*.*)|*.*"
		'ofdGetPhoto.InitialDirectory = txtDataFile.Text
		ofdGetPhoto.ShowDialog()
	End Sub

#End Region



#Region "Form-DataError..."

	Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
		'' Show/Hide error list...
		If lstDataErr.Visible = True Then
			lstDataErr.Visible = False
		Else
			lstDataErr.Visible = True
			lstDataErr.Height = 251
			lstDataErr.BringToFront()
		End If
	End Sub
	
	Private Sub checkValues()
		''
		If blnLoading = True Then Exit Sub
		''
		DataChange = True
		btnCancel.Enabled = True
		''
		'' clear entir list & start fresh check...
		''
		lstDataErr.Items.Clear()
		Dim intErrCount As Int16 = 0

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' check Error - Mandatory Data Objects...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''
		If Me.txtCompanyName.Text = String.Empty Then
			lstDataErr.Items.Add("Missing Company Name")
			intErrCount += 1
		End If

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' Set appropriate controls based on errors check results...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		If lstDataErr.Items.Count = 0 Then
			lstDataErr.Visible = False
			btnDataErr.Visible = False

		Else
			btnDataErr.Visible = True
		End If
		''
		If DataChange And intErrCount = 0 Then
			btnSave.Enabled = True
		Else
			btnSave.Enabled = False
		End If

	End Sub

#End Region



#Region "Branch-Name..."

	Private Sub btnBrNameOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrNameOK.Click
		''
		If txtBranchName.Text.Trim = String.Empty Then
			MsgBox("Please Enter Branch Name")
			txtBranchName.Focus()
			Exit Sub
		End If

		Dim dv As DataView
		Dim drv As DataRowView

		dv = dsData.Tables("tblBranch").DefaultView

		If gpBranchName.Tag = "New" Then
			dv.AllowNew = True
			drv = dv.AddNew()
			drv("BranchName") = txtBranchName.Text
			drv.EndEdit()
			dv.AllowNew = False
		Else
			dv.AllowEdit = True
			drv = dv.Item(grdBranch.CurrentRowIndex)
			drv("BranchName") = txtBranchName.Text
			drv.EndEdit()
			dv.AllowEdit = False
		End If

		'daCompany.Fill(dsData.Tables("tblBranch"))
		btnBrNameCancel.PerformClick()

		ifSave = True
		btnSave.Enabled = True
		SaveBranch()

	End Sub

	Private Sub btnBrNameCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrNameCancel.Click
		''
		pnlCompanyInfo.Enabled = True
		pnlCompanyInfo.BackColor = System.Drawing.SystemColors.Control
		txtCompanyName.BackColor = System.Drawing.SystemColors.Control
		txtNote.BackColor = System.Drawing.SystemColors.Control
		gpBranchName.Visible = False
	End Sub

	Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
		txtBranchName.Text = ""
		AddEditBranchName("New")
	End Sub

	Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
		If grdBranch.CurrentRowIndex = -1 Then
			Exit Sub
		End If

		Dim dv As DataView
		Dim drv As DataRowView

		dv = dsData.Tables("tblBranch").DefaultView
		drv = dv.Item(grdBranch.CurrentRowIndex)
		txtBranchName.Text = drv("BranchName")
		AddEditBranchName("Edit")
	End Sub

	Private Sub AddEditBranchName(ByVal Mode As String)

		pnlCompanyInfo.Enabled = False
		pnlCompanyInfo.BackColor = System.Drawing.SystemColors.ControlDarkDark
		txtCompanyName.BackColor = System.Drawing.SystemColors.ControlDarkDark

		txtNote.BackColor = System.Drawing.SystemColors.ControlDarkDark

		gpBranchName.Left = pnlCompanyInfo.Left + (pnlCompanyInfo.Width - gpBranchName.Width) / 2
		gpBranchName.Top = (pnlCompanyInfo.Height - gpBranchName.Height) / 2
		gpBranchName.Visible = True
		gpBranchName.BringToFront()
		gpBranchName.Tag = Mode
		'  gpBranchName.Enabled = True
		txtBranchName.Focus()

	End Sub

#End Region











#Region "frmBranchAccounts"

	Private Sub CboAcctType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
		''
		If blncbo = True Then
			Return
		End If
		''
		filterGrid()
	End Sub

	Private Sub filterGrid()
		''
		If blncbo = True Then
			Exit Sub
		End If
		''
		If grdBranch.CurrentRowIndex = -1 Then Exit Sub
		strSQL = "( True "
		'' Filter for BranchID Filter...
		'If cboBranch.SelectedIndex <> -1 Then
		Dim drRowToEdit As DataRow

		drRowToEdit = dsData.Tables("tblBranch").DefaultView.Item(grdBranch.CurrentRowIndex).Row

		strSQL = strSQL & " AND (BranchID=" & drRowToEdit("BranchID") & ")"
		'End If

		'' Filter On Selected AcctType...
		strSQL = strSQL & ")"

		''
		'  dsData.Tables("vwAccountBrAndType").DefaultView.RowFilter = strSQL
		blncbo = False

	End Sub

	Private Sub AccountSaved(ByVal sender As Object, ByVal e As EventArgs)
		dsData.Tables("vwAccountBrAndType").Rows.Clear()
		strSQL = "SELECT * FROM vwAccountBrAndType"
		daAccount = clsMr.BuildSqlAdapter(strSQL, "vwAccountBrAndType")
	End Sub

	Private Sub DrawGrid()
		''
		Dim dgStyle As New DataGridTableStyle
		''
		dgStyle.MappingName = "vwAccountBrAndType"
		''
		If gStrLang = "ar" Then
			dgStyle.GridColumnStyles("BranchName").HeaderText = "��� �����"
			dgStyle.GridColumnStyles("AcctType").HeaderText = "��� ������"
			dgStyle.GridColumnStyles("AcctNumber").HeaderText = "��� ������"
			dgStyle.GridColumnStyles("ClientName").HeaderText = "��� ������"
			dgStyle.GridColumnStyles("Balance").HeaderText = "������"
			dgStyle.GridColumnStyles("Symbol").HeaderText = "������"
			dgStyle.GridColumnStyles("LedgerNumber").HeaderText = "ledger"
		End If

	End Sub

	'Private Sub btnNewBranchMaintenance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
	'	' Select Case (CboAcctType.SelectedValue)
	'	'Case (6)
	'	'   Dim frm As New FrmAccount(0, "")
	'	'   frm.AcctTypeID = 6
	'	'   frm.Text = "BranchSales"
	'	'   MainForm.AddModelTabPage(frm, frmApplicationMain.eFormType.BranchSales)
	'	'   AddHandler frm.Closed, AddressOf AccountSaved

	'	'Case (7)
	'	'    Dim frm As New frmAccountNew(0, "")
	'	'    frm.AcctTypeID = 7
	'	'    'frm.cboLedger.SelectedValue = 549
	'	'    frm.Text = "BranchAccount"
	'	'    'frm.initControl()
	'	'    'MainForm.addModelTabPage(frm, frmApplicationMain.eFormType.BranchAccounts)
	'	'    ''frmApplicationMain.addModelTabPage(frm, frmApplicationMain.eFormType.BranchAccounts)
	'	'    frm.Show()
	'	'    AddHandler frm.Closed, AddressOf AccountSaved
	'	'Case (8)
	'	'    Dim frm As New frmAccountNew(0, "")
	'	'    frm.AcctTypeID = 8
	'	'    'frm.cboLedger.SelectedValue = 549
	'	'    frm.Text = "PurchaseExpense"
	'	'    'frm.initControl()
	'	'    frm.Show()
	'	'    'MainForm.addModelTabPage(frm, frmApplicationMain.eFormType.PurchaseExpenses)
	'	'    AddHandler frm.Closed, AddressOf AccountSaved

	'	' End Select
	'End Sub

	''Private Sub tcBranches_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tcBranches.SelectedIndexChanged
	''	If tcBranches.SelectedTab Is tpBranchAccts Then
	''		filterGrid()
	''	End If

	''End Sub

	Private Sub CboAcctType_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
		filterGrid()
	End Sub

	Private Sub grdBranch_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdBranch.CurrentCellChanged
		filterGrid()
	End Sub

	Private Sub SaveBranch()
		Dim al As ArrayList
		Dim dv As DataView
		Dim drv As DataRowView
		Dim i As Integer

		al = New ArrayList
		dv = dsData.Tables("tblBranch").DefaultView
		For i = 0 To dv.Count - 1
			drv = dv.Item(i)
			If drv.Row.RowState = DataRowState.Added Then
				al.Add(drv)
			End If
		Next

		clsMr.Update(dabranch, "tblBranch")

		ifSave = False
		btnSave.Enabled = False
	End Sub

#End Region


	Private Sub setState(ByRef pStrMode As String)
		''
		mStrCurrentState = UCase(pStrMode)
		'' 
		Select Case mStrCurrentState
			Case Is = "NEW"
				Me.btnSave.Enabled = False
				Me.btnCancel.Enabled = True
				Me.btnNew.Enabled = False
				btnGetPicture.Enabled = True
				grpCompanyInfo.Enabled = True
				grpBranchAccounts.Enabled = True
				btnSave.Text = "S a v e"

			Case Is = "EDIT"
				Me.btnSave.Enabled = False
				Me.btnCancel.Enabled = True
				Me.btnNew.Enabled = False
				btnGetPicture.Enabled = True
				grpCompanyInfo.Enabled = True
				grpBranchAccounts.Enabled = True

				btnSave.Text = "S a v e"

			Case Is = "SAVE"
				Me.btnSave.Enabled = True
				Me.btnCancel.Enabled = False
				Me.btnNew.Enabled = True
				btnGetPicture.Enabled = False
				btnSave.Text = "E d i t"
				grpCompanyInfo.Enabled = False
				grpBranchAccounts.Enabled = False

			Case Is = "BROWSE"
				Me.btnSave.Enabled = True
				Me.btnCancel.Enabled = False
				Me.btnNew.Enabled = True
				btnGetPicture.Enabled = False
				btnSave.Text = "E d i t"
				grpCompanyInfo.Enabled = False
				grpBranchAccounts.Enabled = False
		End Select
	End Sub

	Private Sub dtpDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateFrom.ValueChanged
		checkValues()
	End Sub

	Private Sub dtpDateTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateTo.ValueChanged
		checkValues()
	End Sub

	Private Sub txtNote_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNote.TextChanged
		checkValues()
	End Sub

	Private Sub txtCompanyName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCompanyName.TextChanged
		checkValues()
	End Sub



	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
		If ifSave Then
			If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

				Try
					Nav.CancelCurrentEdit()
				Catch ex As Exception

				End Try

				ifSave = False

				setState("BROWSE")
			End If
		Else
			setState("BROWSE")
			'AddMode = False
		End If
	End Sub


End Class