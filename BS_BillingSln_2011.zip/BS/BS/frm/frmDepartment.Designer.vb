<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDepartment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtID = New System.Windows.Forms.TextBox
        Me.txtCode = New System.Windows.Forms.TextBox
        Me.txtShortName = New System.Windows.Forms.TextBox
        Me.grpInfo = New System.Windows.Forms.GroupBox
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.CboArea = New System.Windows.Forms.ComboBox
        Me.lblArea = New System.Windows.Forms.Label
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.txtExt = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtLongName = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtTel = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.rdbContains = New System.Windows.Forms.RadioButton
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.grplist = New System.Windows.Forms.GroupBox
        Me.txtSearch = New System.Windows.Forms.TextBox
        Me.lstDepartment = New System.Windows.Forms.ListBox
        Me.grpControls = New System.Windows.Forms.GroupBox
        Me.btnEmployee = New BHBut.BouncingHoverButton
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.lblFormTitleLine = New System.Windows.Forms.Panel
        Me.lblFormTitle = New System.Windows.Forms.Label
        Me.grpInfo.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.grplist.SuspendLayout()
        Me.grpControls.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(271, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "DepartmentID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.DarkRed
        Me.Label2.Location = New System.Drawing.Point(237, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Short Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.DarkRed
        Me.Label3.Location = New System.Drawing.Point(6, 36)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Department Code"
        '
        'txtID
        '
        Me.txtID.Enabled = False
        Me.txtID.Location = New System.Drawing.Point(332, 14)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(50, 20)
        Me.txtID.TabIndex = 5
        '
        'txtCode
        '
        Me.txtCode.Location = New System.Drawing.Point(109, 32)
        Me.txtCode.Name = "txtCode"
        Me.txtCode.Size = New System.Drawing.Size(126, 20)
        Me.txtCode.TabIndex = 8
        '
        'txtShortName
        '
        Me.txtShortName.Location = New System.Drawing.Point(306, 33)
        Me.txtShortName.Name = "txtShortName"
        Me.txtShortName.Size = New System.Drawing.Size(201, 20)
        Me.txtShortName.TabIndex = 5
        '
        'grpInfo
        '
        Me.grpInfo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpInfo.Controls.Add(Me.CboArea)
        Me.grpInfo.Controls.Add(Me.lblArea)
        Me.grpInfo.Controls.Add(Me.txtEmail)
        Me.grpInfo.Controls.Add(Me.txtExt)
        Me.grpInfo.Controls.Add(Me.Label8)
        Me.grpInfo.Controls.Add(Me.txtLongName)
        Me.grpInfo.Controls.Add(Me.Label4)
        Me.grpInfo.Controls.Add(Me.txtTel)
        Me.grpInfo.Controls.Add(Me.txtCode)
        Me.grpInfo.Controls.Add(Me.Label6)
        Me.grpInfo.Controls.Add(Me.Label2)
        Me.grpInfo.Controls.Add(Me.txtShortName)
        Me.grpInfo.Controls.Add(Me.Label3)
        Me.grpInfo.Enabled = False
        Me.grpInfo.Location = New System.Drawing.Point(226, 51)
        Me.grpInfo.Name = "grpInfo"
        Me.grpInfo.Size = New System.Drawing.Size(568, 324)
        Me.grpInfo.TabIndex = 84
        Me.grpInfo.TabStop = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(457, 16)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(215, 17)
        Me.lstDataErr.TabIndex = 96
        Me.lstDataErr.Visible = False
        '
        'CboArea
        '
        Me.CboArea.FormattingEnabled = True
        Me.CboArea.Location = New System.Drawing.Point(109, 120)
        Me.CboArea.Name = "CboArea"
        Me.CboArea.Size = New System.Drawing.Size(139, 21)
        Me.CboArea.TabIndex = 94
        '
        'lblArea
        '
        Me.lblArea.ForeColor = System.Drawing.Color.DarkRed
        Me.lblArea.Location = New System.Drawing.Point(43, 127)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(55, 13)
        Me.lblArea.TabIndex = 93
        Me.lblArea.Text = "Area"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(291, 93)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(216, 20)
        Me.txtEmail.TabIndex = 91
        '
        'txtExt
        '
        Me.txtExt.AcceptsReturn = True
        Me.txtExt.Location = New System.Drawing.Point(203, 93)
        Me.txtExt.Name = "txtExt"
        Me.txtExt.Size = New System.Drawing.Size(45, 20)
        Me.txtExt.TabIndex = 92
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(253, 100)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(35, 13)
        Me.Label8.TabIndex = 90
        Me.Label8.Text = "E-mail"
        '
        'txtLongName
        '
        Me.txtLongName.Location = New System.Drawing.Point(108, 61)
        Me.txtLongName.Name = "txtLongName"
        Me.txtLongName.Size = New System.Drawing.Size(399, 20)
        Me.txtLongName.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.DarkRed
        Me.Label4.Location = New System.Drawing.Point(31, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(67, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Department "
        '
        'txtTel
        '
        Me.txtTel.Location = New System.Drawing.Point(108, 93)
        Me.txtTel.Name = "txtTel"
        Me.txtTel.Size = New System.Drawing.Size(90, 20)
        Me.txtTel.TabIndex = 87
        '
        'Label6
        '
        Me.Label6.ForeColor = System.Drawing.Color.DarkRed
        Me.Label6.Location = New System.Drawing.Point(43, 93)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 86
        Me.Label6.Text = "Tel"
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(668, 14)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(67, 23)
        Me.btnDataErr.TabIndex = 123
        Me.btnDataErr.TabStop = False
        Me.btnDataErr.Text = "Error"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.LightYellow
        Me.GroupBox2.Controls.Add(Me.rdbContains)
        Me.GroupBox2.Controls.Add(Me.RadioButton1)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 17)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(193, 27)
        Me.GroupBox2.TabIndex = 89
        Me.GroupBox2.TabStop = False
        '
        'rdbContains
        '
        Me.rdbContains.AutoSize = True
        Me.rdbContains.Checked = True
        Me.rdbContains.Location = New System.Drawing.Point(55, 8)
        Me.rdbContains.Name = "rdbContains"
        Me.rdbContains.Size = New System.Drawing.Size(67, 17)
        Me.rdbContains.TabIndex = 91
        Me.rdbContains.TabStop = True
        Me.rdbContains.Text = "Contains"
        Me.rdbContains.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(6, 8)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(43, 17)
        Me.RadioButton1.TabIndex = 90
        Me.RadioButton1.Text = "Like"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'grplist
        '
        Me.grplist.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grplist.Controls.Add(Me.txtSearch)
        Me.grplist.Controls.Add(Me.lstDepartment)
        Me.grplist.Controls.Add(Me.GroupBox2)
        Me.grplist.Location = New System.Drawing.Point(8, 51)
        Me.grplist.Name = "grplist"
        Me.grplist.Size = New System.Drawing.Size(210, 324)
        Me.grplist.TabIndex = 97
        Me.grplist.TabStop = False
        Me.grplist.Text = "Find Department"
        '
        'txtSearch
        '
        Me.txtSearch.Location = New System.Drawing.Point(6, 56)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(193, 20)
        Me.txtSearch.TabIndex = 91
        '
        'lstDepartment
        '
        Me.lstDepartment.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstDepartment.FormattingEnabled = True
        Me.lstDepartment.Location = New System.Drawing.Point(6, 79)
        Me.lstDepartment.Name = "lstDepartment"
        Me.lstDepartment.Size = New System.Drawing.Size(193, 225)
        Me.lstDepartment.TabIndex = 90
        '
        'grpControls
        '
        Me.grpControls.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpControls.Controls.Add(Me.btnEmployee)
        Me.grpControls.Controls.Add(Me.btnCancel)
        Me.grpControls.Controls.Add(Me.btnNew)
        Me.grpControls.Controls.Add(Me.btnSave)
        Me.grpControls.Controls.Add(Me.btnClose)
        Me.grpControls.Location = New System.Drawing.Point(8, 382)
        Me.grpControls.Name = "grpControls"
        Me.grpControls.Size = New System.Drawing.Size(764, 52)
        Me.grpControls.TabIndex = 381
        Me.grpControls.TabStop = False
        '
        'btnEmployee
        '
        Me.btnEmployee.AlternativeGroup = Nothing
        Me.btnEmployee.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEmployee.BackColor1 = System.Drawing.Color.White
        Me.btnEmployee.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEmployee.BorderHover = True
        Me.btnEmployee.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEmployee.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEmployee.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnEmployee.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEmployee.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEmployee.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEmployee.DrawBorder = True
        Me.btnEmployee.Enabled = False
        Me.btnEmployee.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEmployee.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnEmployee.ForeColor = System.Drawing.Color.Navy
        Me.btnEmployee.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnEmployee.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnEmployee.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEmployee.Location = New System.Drawing.Point(333, 19)
        Me.btnEmployee.Name = "btnEmployee"
        Me.btnEmployee.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnEmployee.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnEmployee.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEmployee.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnEmployee.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnEmployee.SelectedText = Nothing
        Me.btnEmployee.Size = New System.Drawing.Size(105, 28)
        Me.btnEmployee.TabIndex = 16
        Me.btnEmployee.Text = "E m p l o y e e"
        Me.btnEmployee.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCancel.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Location = New System.Drawing.Point(217, 18)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(105, 28)
        Me.btnCancel.TabIndex = 15
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNew.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.Location = New System.Drawing.Point(13, 18)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(90, 28)
        Me.btnNew.TabIndex = 13
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnSave.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.Location = New System.Drawing.Point(115, 18)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(90, 28)
        Me.btnSave.TabIndex = 14
        Me.btnSave.Text = "E d i t"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.Location = New System.Drawing.Point(650, 18)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(90, 28)
        Me.btnClose.TabIndex = 12
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'lblFormTitleLine
        '
        Me.lblFormTitleLine.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblFormTitleLine.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblFormTitleLine.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lblFormTitleLine.Location = New System.Drawing.Point(0, 40)
        Me.lblFormTitleLine.Name = "lblFormTitleLine"
        Me.lblFormTitleLine.Size = New System.Drawing.Size(772, 3)
        Me.lblFormTitleLine.TabIndex = 393
        '
        'lblFormTitle
        '
        Me.lblFormTitle.AutoEllipsis = True
        Me.lblFormTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblFormTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblFormTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.Black
        Me.lblFormTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(772, 40)
        Me.lblFormTitle.TabIndex = 392
        Me.lblFormTitle.Text = "Department"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmDepartment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(772, 446)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.lblFormTitleLine)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.lblFormTitle)
        Me.Controls.Add(Me.grpControls)
        Me.Controls.Add(Me.grplist)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.grpInfo)
        Me.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me.Name = "frmDepartment"
        Me.Text = "Department"
        Me.grpInfo.ResumeLayout(False)
        Me.grpInfo.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.grplist.ResumeLayout(False)
        Me.grplist.PerformLayout()
        Me.grpControls.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents Label2 As System.Windows.Forms.Label
   Friend WithEvents Label3 As System.Windows.Forms.Label
   Friend WithEvents txtID As System.Windows.Forms.TextBox
   Friend WithEvents txtCode As System.Windows.Forms.TextBox
   Friend WithEvents txtShortName As System.Windows.Forms.TextBox
   Friend WithEvents grpInfo As System.Windows.Forms.GroupBox
   Friend WithEvents Label4 As System.Windows.Forms.Label
   Friend WithEvents txtTel As System.Windows.Forms.TextBox
   Friend WithEvents Label6 As System.Windows.Forms.Label
   Friend WithEvents txtEmail As System.Windows.Forms.TextBox
   Friend WithEvents Label8 As System.Windows.Forms.Label
   Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
   Friend WithEvents rdbContains As System.Windows.Forms.RadioButton
   Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
   Friend WithEvents txtLongName As System.Windows.Forms.TextBox
   Friend WithEvents txtExt As System.Windows.Forms.TextBox
   Friend WithEvents grplist As System.Windows.Forms.GroupBox
   Friend WithEvents lstDepartment As System.Windows.Forms.ListBox
   Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
   Friend WithEvents txtSearch As System.Windows.Forms.TextBox
   Friend WithEvents btnDataErr As System.Windows.Forms.Button
   Friend WithEvents CboArea As System.Windows.Forms.ComboBox
   Friend WithEvents lblArea As System.Windows.Forms.Label
   Friend WithEvents grpControls As System.Windows.Forms.GroupBox
   Friend WithEvents btnCancel As BHBut.BouncingHoverButton
   Friend WithEvents btnNew As BHBut.BouncingHoverButton
   Friend WithEvents btnSave As BHBut.BouncingHoverButton
   Friend WithEvents btnClose As BHBut.BouncingHoverButton
   Friend WithEvents lblFormTitleLine As System.Windows.Forms.Panel
	Friend WithEvents lblFormTitle As System.Windows.Forms.Label
	Friend WithEvents btnEmployee As BHBut.BouncingHoverButton
End Class
