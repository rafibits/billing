Imports System.Data.SqlClient
Imports BITSConn
''
Public Class frmCheckClearing

#Region " Form Declaration  .   .  ."
    ''
    Dim dsData As DataSet
    Dim clsMr As ClsMain
    Dim Nav As New BitsNav
    Dim blnLoading As Boolean
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\CheckClearing\Settings"
    Private mstrCurrentGridName As String

#End Region

#Region " Form Initialization . . . "

    Private Sub frmCheckClearing_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmCheckClearing_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        clsMr = New ClsMain(conSql)
        Nav = New BitsNav

        blnLoading = True
        MakeDataAdapter()
        FillComboBox()
        SetCurrency()

        DrawGrid()
        ChangeColor()
        cboType.SelectedIndex = -1
        cboBank.SelectedIndex = -1
        cboClient.SelectedIndex = -1
        blnLoading = False
        FilterGrid()
        ''MD May 21,2010
        btnClear.Enabled = False

    End Sub

    Private Sub MakeDataAdapter()
        '' 
        clsMr.BuildSqlAdapter("SELECT * FROM vwCheckPMT WHERE Del = 0 AND Amount > 0 AND PaymentTypeID IN(2,4)", "vwCheckPMT")
        clsMr.BuildSqlAdapter("SELECT * FROM tblPaymentDetail WHERE Del = 0 AND Amount > 0 AND PaymentTypeID IN(2,4)", "tblPaymentDetail")
        clsMr.BuildSqlAdapter("SELECT ClientName, ClientID, Del FROM tblClient WHERE Del = 0", "tblClient")
        clsMr.BuildSqlAdapter("SELECT BankName, BankID, Del FROM tblBank WHERE Del = 0", "tblBank")
        clsMr.BuildSqlAdapter("SELECT PaymentType, PaymentTypeID FROM tblPaymentType WHERE PaymentTypeID IN (2,4)", "tblPaymentType")
        ''
        dsData = clsMr.getDataSet
    End Sub

    Private Sub FillComboBox()
        ''
        clsMr.FillComboBox("tblClient", cboClient, "ClientName", "ClientID")
        clsMr.FillComboBox("tblBank", cboBank, "BankName", "BankID")
        clsMr.FillComboBox("tblPaymentType", cboType, "PaymentType", "PaymentTypeID")

    End Sub

    Private Sub SetCurrency()
        Nav.SetCurrency(Me, dsData, "vwCheckPMT")
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

    End Sub

#End Region

#Region " Form Functions   .   .   ."

    Private Sub DrawGrid()

        With grdPMT

            .DataSource = dsData.Tables("vwCheckPMT").DefaultView
            .Columns("PaymentType").HeaderText = "Pmt Type"
            .Columns("PaymentNum").HeaderText = "Pmt #"
            .Columns("ChkNumber").HeaderText = "Check #"
            .Columns("ValueDate").HeaderText = "Value Date"
            .Columns("Cleared").HeaderText = "Clear"
            .Columns("ClientName").HeaderText = "Client Name"
            ''
            .Columns("PaymentTypeID").Visible = False
            .Columns("paymentDetailID").Visible = False
            .Columns("PaymentID").Visible = False
            .Columns("ClientID").Visible = False
            .Columns("Del").Visible = False
            .Columns("BankID").Visible = False
            .Columns("StatusID").Visible = False
            ''
            .Columns("Amount").ReadOnly = True
            .Columns("PaymentType").ReadOnly = True
            .Columns("PaymentNum").ReadOnly = True
            .Columns("ChkNumber").ReadOnly = True
            .Columns("ValueDate").ReadOnly = True
            .Columns("Cleared").ReadOnly = True
            .Columns("ClientName").ReadOnly = True
            .Columns("PaymentTypeID").ReadOnly = True
            .Columns("paymentDetailID").ReadOnly = True
            .Columns("PaymentID").ReadOnly = True
            .Columns("ClientID").ReadOnly = True
            .Columns("Del").ReadOnly = True
            .Columns("BankID").ReadOnly = True
            ''
            .ColumnHeadersHeight = btnShowHide.Height + 2
            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
            dsData.Tables("vwCheckPMT").DefaultView.AllowNew = False
        End With
        grdPMT.MultiSelect = False

        LoadProfile(mStrSubKeyName, Me.grdPMT)

    End Sub

    Private Sub RemoveLstItems()

        chkLstGridCol.Items.Remove("PaymentTypeID")
        chkLstGridCol.Items.Remove("paymentDetailID")
        chkLstGridCol.Items.Remove("PaymentID")
        chkLstGridCol.Items.Remove("ClientID")
        chkLstGridCol.Items.Remove("Del")
        chkLstGridCol.Items.Remove("BankID")
        chkLstGridCol.Items.Remove("StatusID")
    End Sub

    Private Sub ChangeColor()

        Dim i As Integer
        Dim intStatus As Integer
        For i = 0 To dsData.Tables("vwCheckPMT").DefaultView.Count - 1
            intStatus = dsData.Tables("vwCheckPMT").DefaultView.Item(i)("PaymentTypeID")
            Select Case intStatus
                Case 1
                    grdPMT.Rows(i).DefaultCellStyle.BackColor = Color.LightYellow
                Case 2
                    grdPMT.Rows(i).DefaultCellStyle.BackColor = Color.Lavender
            End Select
        Next

    End Sub

    Private Sub FilterGrid()

        If blnLoading Then Exit Sub

        Dim s As String '= " True"

        s = "(ValueDate >= '" & dtpFromFilter.Value.ToString("yyyy-M-d") & "') AND (ValueDate <= '" & dtpToFilter.Value.ToString("yyyy-M-d") & "')"

        If cboType.SelectedIndex <> -1 Then
            s = s & " AND (PaymentTypeID = " & cboType.SelectedValue & ")"
        Else
            If cboType.Text <> "" And cboType.SelectedIndex = -1 Then
                s = s & " AND (PaymentTypeID = " & -1 & ")"
            End If

        End If

        If cboClient.SelectedIndex <> -1 Then
            s = s & " AND (ClientID = " & cboClient.SelectedValue & ")"
        Else
            If cboClient.Text <> String.Empty And cboClient.SelectedIndex = -1 Then
                s = s & "AND (ClientID = " & -1 & ")"
            End If
        End If

        If cboBank.SelectedIndex <> -1 Then
            s = s & " AND (BankID = " & cboBank.SelectedValue & ")"
        Else
            If cboBank.SelectedIndex = -1 And cboBank.Text <> "" Then
                s = s & " AND (BankID = " & -1 & ")"
            End If
        End If

        If txtNumber.Text <> String.Empty Then
            Dim tn As Integer
            Try
                tn = Convert.ToInt64(txtNumber.Text)
                s = s & "AND (PaymentNum =" & tn & ")"
            Catch ex As Exception
                txtNumber.Text = String.Empty
            End Try
        End If

        dsData.Tables("vwCheckPMT").DefaultView.RowFilter = s
        ChangeColor()

    End Sub

#End Region

#Region " UI Events          .  .  ."

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ''
        If grdPMT.Rows.Count = 0 Then Exit Sub

        '' enable btnPayment
        btnEditPayment.Enabled = True
        ''
        For i As Integer = 0 To grdPMT.RowCount - 1
            'MsgBox("ROW:" & grdPMT.Item("PaymentNum", i).Value)
            If grdPMT.Item("Cleared", i).Value = True Then
                ''
                Dim dr As DataRow()
                dr = dsData.Tables("tblPaymentDetail").Select("PaymentDetailID = " & grdPMT.Item("PaymentdetailID", i).Value)
                ''
                'MsgBox("ROW:" & grdPMT.Item("PaymentNum", i).Value & " :" & dr(0)("PaymentDetailID"))

                Dim sqlcommand1 As New SqlCommand("Update tblPaymentDetail SET Cleared = 1 WHERE PaymentDetailID = " & dr(0)("PaymentDetailID"), conSql)
                Dim sqlcommand2 As New SqlCommand("Update tblClient SET PendingBal= PendingBal - '" & grdPMT.CurrentRow.Cells("Amount").Value & "'  , Balance= Balance - '" & grdPMT.CurrentRow.Cells("Amount").Value & "' WHERE ClientID= '" & grdPMT.CurrentRow.Cells("ClientID").Value & "'", conSql)
                Try
                    conSql.Open()
                    sqlcommand1.ExecuteNonQuery()
                    sqlcommand2.ExecuteNonQuery()
                    conSql.Close()
                Catch ex As Exception
                    conSql.Close()
                End Try
                '
                ' UpDate tblClient Balance
                ' Decrement Pending balance by  Check Amount
                ' add to    balance the decremented   amount
                'Dim amount As Long
                'amount = dr(0)("Amount")
            End If
            'MsgBox("Please Select the check to Clear")
        Next

        btnClear.Enabled = False

        ''
        btnRefresh.PerformClick()

    End Sub



    Private Sub btnDetailClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetailClose.Click
        Me.Close()
    End Sub

    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click

        Dim i As Integer

        For i = 0 To Me.chkLstGridCol.Items.Count - 1
            Me.grdPMT.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
        Next
        '
        Me.grpShowHideColumns.Visible = False

    End Sub

    Private Sub btnShowHide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowHide.Click

        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()

            mstrCurrentGridName = "ChkPMT"
            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdPMT.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next
        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If
        RemoveLstItems()

    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        If blnLoading Then Exit Sub
        dsData.Tables("vwCheckPMT").Clear()
        clsMr.BuildSqlAdapter("SELECT * FROM vwCheckPMT WHERE Del = 0 AND Amount > 0 AND PaymentTypeID IN(2,4)", "vwCheckPMT")
        ChangeColor()
    End Sub

    Private Sub dtpFromFilter_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpFromFilter.ValueChanged
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub dtpToFilter_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpToFilter.ValueChanged
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub cboType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboType.SelectedIndexChanged
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub cboClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub cboBank_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboBank.SelectedIndexChanged
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub txtNumber_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNumber.TextChanged
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub cboClient_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyUp
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub cboBank_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboBank.KeyUp
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub cboType_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboType.KeyUp
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

#End Region

    Private Sub btnEditPayment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditPayment.Click

        If grdPMT.Rows.Count = 0 Then Exit Sub
        btnClear.Enabled = True
        With grdPMT
            .Columns("Amount").ReadOnly = True
            .Columns("PaymentType").ReadOnly = True
            .Columns("PaymentNum").ReadOnly = True
            .Columns("ChkNumber").ReadOnly = True
            .Columns("ValueDate").ReadOnly = True
            .Columns("Cleared").ReadOnly = False
            .Columns("ClientName").ReadOnly = True
            .Columns("PaymentTypeID").ReadOnly = True
            .Columns("paymentDetailID").ReadOnly = True
            .Columns("PaymentID").ReadOnly = True
            .Columns("ClientID").ReadOnly = True
            .Columns("Del").ReadOnly = True
            .Columns("BankID").ReadOnly = True
        End With

        btnEditPayment.Enabled = False
    End Sub
End Class