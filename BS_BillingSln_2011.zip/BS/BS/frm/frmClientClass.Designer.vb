<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmClientClass
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.grdClientClass = New System.Windows.Forms.DataGridView
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.txtClientClassID = New System.Windows.Forms.TextBox
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnDelete = New BHBut.BouncingHoverButton
        Me.btnShowCol = New System.Windows.Forms.Button
        CType(Me.grdClientClass, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpButtons.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Comic Sans MS", 15.75!)
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(613, 40)
        Me.lblfrmTitle.TabIndex = 341
        Me.lblfrmTitle.Text = "  Client Class"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(613, 3)
        Me.pnlTitle.TabIndex = 342
        '
        'grdClientClass
        '
        Me.grdClientClass.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdClientClass.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdClientClass.Location = New System.Drawing.Point(10, 49)
        Me.grdClientClass.Name = "grdClientClass"
        Me.grdClientClass.Size = New System.Drawing.Size(595, 347)
        Me.grdClientClass.TabIndex = 343
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnDelete)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Location = New System.Drawing.Point(10, 400)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(595, 54)
        Me.grpButtons.TabIndex = 344
        Me.grpButtons.TabStop = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.HoverColor2 = System.Drawing.Color.White
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCancel.Location = New System.Drawing.Point(216, 15)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCancel.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(99, 31)
        Me.btnCancel.TabIndex = 117
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(490, 15)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(99, 31)
        Me.btnClose.TabIndex = 116
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(111, 15)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(99, 31)
        Me.btnSave.TabIndex = 115
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.HoverColor2 = System.Drawing.Color.White
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNew.Location = New System.Drawing.Point(6, 15)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(99, 31)
        Me.btnNew.TabIndex = 114
        Me.btnNew.Text = "New"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'txtClientClassID
        '
        Me.txtClientClassID.AcceptsReturn = True
        Me.txtClientClassID.Location = New System.Drawing.Point(335, 14)
        Me.txtClientClassID.Name = "txtClientClassID"
        Me.txtClientClassID.Size = New System.Drawing.Size(100, 20)
        Me.txtClientClassID.TabIndex = 345
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(55, 50)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 184)
        Me.grpShowHideColumns.TabIndex = 347
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 155)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 124)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnDelete
        '
        Me.btnDelete.AlternativeGroup = Nothing
        Me.btnDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDelete.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnDelete.BackColor1 = System.Drawing.Color.White
        Me.btnDelete.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnDelete.BorderHover = True
        Me.btnDelete.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDelete.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDelete.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDelete.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDelete.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDelete.DrawBorder = True
        Me.btnDelete.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnDelete.ForeColor = System.Drawing.Color.Navy
        Me.btnDelete.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDelete.HoverColor2 = System.Drawing.Color.White
        Me.btnDelete.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDelete.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnDelete.Location = New System.Drawing.Point(321, 15)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDelete.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnDelete.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDelete.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDelete.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnDelete.SelectedText = Nothing
        Me.btnDelete.Size = New System.Drawing.Size(99, 31)
        Me.btnDelete.TabIndex = 118
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(13, 50)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 24)
        Me.btnShowCol.TabIndex = 346
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'frmClientClass
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(613, 456)
        Me.Controls.Add(Me.grpShowHideColumns)
        Me.Controls.Add(Me.btnShowCol)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grdClientClass)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.txtClientClassID)
        Me.Name = "frmClientClass"
        Me.Text = "Client Class"
        CType(Me.grdClientClass, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpButtons.ResumeLayout(False)
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents grdClientClass As System.Windows.Forms.DataGridView
    Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
    Friend WithEvents btnCancel As BHBut.BouncingHoverButton
    Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents btnSave As BHBut.BouncingHoverButton
    Friend WithEvents btnNew As BHBut.BouncingHoverButton
    Friend WithEvents txtClientClassID As System.Windows.Forms.TextBox
    Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
    Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
    Friend WithEvents btnShowCol As System.Windows.Forms.Button
    Friend WithEvents btnDelete As BHBut.BouncingHoverButton
End Class
