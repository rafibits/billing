Imports BITSConn
Imports System.Data.SqlClient

Public Class frmClientContract
#Region "Declaration"
    Dim dsdata As New DataSet
    Dim ClsMr As ClsMain
    Dim mStrTableName As String = "tblClientContract"
    Dim StrSql As String = "SELECT * From tblClientContract where Del =0"
    Dim daClientContract As New SqlClient.SqlDataAdapter
    Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Settings\ClientList"

#End Region
#Region "Initialization"
    Private Sub frmClientContract_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ClsMr = New ClsMain(conSql)
        MakeDataAdapter()
        DrawGrid()
    End Sub
    Private Sub frmClientList_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        SaveProfile(mStrSubKeyName, grdClientList)
    End Sub
    Enum eFormType
        A
        B
        C
        D
    End Enum

#End Region

#Region "Function"
    Private Sub MakeDataAdapter()
        ClsMr.BuildSqlAdapter("SELECT ClientNum,ClientName,ClientImage,Del,ClientID,ClientClassID,ClientManagerID From tblClient where Del =0", "Client")
        dsdata = ClsMr.getDataSet

    End Sub
    Private Sub DrawGrid()

        With grdClientList
            .DataSource = dsdata.Tables("Client").DefaultView
            .Columns("Del").Visible = False
            .Columns("ClientID").Visible = False
            .Columns("ClientClassID").Visible = False
            .Columns("ClientManagerID").Visible = False
            ''
            .ReadOnly = True
            .ColumnHeadersHeight = btnShowCol.Height + 2
            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        End With
        LoadProfile(mStrSubKeyName, Me.grdClientList)
    End Sub
    Private Sub RemoveNonVisibleField()
        chkLstGridCol.Items.Remove("Del")
        chkLstGridCol.Items.Remove("ClientID")
        chkLstGridCol.Items.Remove("ClientClassID")
        chkLstGridCol.Items.Remove("ClientManagerID")
    End Sub

#End Region
#Region "GridSetting"
    Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()

            '' populate list with grid's dataSource fields...
            ''

            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdClientList.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next
            RemoveNonVisibleField()
        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If

    End Sub
    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim i As Integer

        For i = 0 To Me.chkLstGridCol.Items.Count - 1
            Me.grdClientList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
        Next

        ''
        Me.grpShowHideColumns.Visible = False
    End Sub
    Public Sub RefreshForm(ByVal Sender As Object, ByVal e As System.EventArgs)
        dsdata.Tables("Client").Rows.Clear()
        ClsMr.BuildSqlAdapter("SELECT ClientNum,ClientName,ClientImage,Del,ClientID,ClientClassID,ClientManagerID From tblClient where Del =0", "Client")
    End Sub
#End Region
#Region "UI-Controls"
    Private Sub btnNewClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewClient.Click
        Dim frm As New frmClient_V1(0)
        addTabPage(frm, eFormType.A)
        AddHandler frm.Closed, AddressOf RefreshForm

    End Sub
#End Region
    Private Sub btnCloseList_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCloseList.Click
        ''Close
        Me.Close()
    End Sub
    Public Function addTabPage(ByVal frm As Form, ByVal frmType As eFormType) As Boolean
        '' set mousePointer to wait...
        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ''
        Dim title As String = ""
        addTabPage = False
        ''
        Select Case frmType
            ''
            ''Accounts
            ''
            Case eFormType.A
                AddHandler CType(frm, frmClient_V1).Closed, AddressOf closeModelTabPage
                title = "Client"

            Case eFormType.B
                AddHandler CType(frm, frmClEmployeeList).Closed, AddressOf closeModelTabPage
                title = " Client Employee List "

                'Case eFormType.C
                '   AddHandler CType(frm, frmPatientMedicalHistory).Closed, AddressOf closeModelTabPage
                '   title = " Patient Medical History "

        End Select
        ''
        '' if item is open, already exit...

        Dim i As Integer
        For i = 0 To tcMain.Controls.Count - 1
            If tcMain.TabPages.Item(i).Text Is title Then
                tcMain.SelectedTab = tcMain.TabPages.Item(i)
                Exit Function
            End If
        Next

        '' go open item in a new tab...
        Dim tp As New TabPage
        ''tp = New TabPage
        tp.Text = title
        tcMain.TabPages.Add(tp)
        ''
        frm.TopLevel = False
        frm.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        frm.Dock = DockStyle.Fill
        frm.Visible = True
        ''
        '' add it to main tab control...
        tp.Controls.Add(frm)
        tcMain.SelectedTab = tp
        ''
        '' set defaults...
        Windows.Forms.Cursor.Current = Cursors.Default
        addTabPage = True
    End Function

    Private Sub CloseTabPage(ByVal sender As Object, ByVal e As System.EventArgs)
        ''
        Dim tp As TabPage
        ''
        tp = CType(sender, Form).Parent
        tcMain.TabPages.Remove(tp)
    End Sub

    Private Sub closeModelTabPage(ByVal sender As Object, ByVal e As System.EventArgs)
        ''
        Dim tp As TabPage
        ''
        tp = CType(sender, Form).Parent
        tcMain.TabPages.Remove(tp)

        '' enable all tabs + navigation menu + menubar
        For Each tp In tcMain.TabPages
            tp.Enabled = True
        Next
    End Sub

    Private Sub btnEditClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditClient.Click
        If grdClientList.Rows.Count > 0 Then
            Dim dr As DataRow = dsdata.Tables("Client").DefaultView.Item(grdClientList.CurrentRow.Index).Row
            Dim frm As New frmClient_V1(dr("ClientID"))
            addTabPage(frm, eFormType.A)
            AddHandler frm.Closed, AddressOf RefreshForm
        End If
    End Sub

    Private Sub btnEmployeeList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmployeeList.Click
        Dim dr As DataRow = dsdata.Tables("Client").DefaultView.Item(grdClientList.CurrentRow.Index).Row
        Dim frm As New frmClEmployeeList(dr("ClientID"))
        addTabPage(frm, eFormType.B)
        'MsgBox(dr("ClientID"))
        'AddHandler frm.Closed, AddressOf RefreshForm

    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
End Class