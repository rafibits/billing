Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmPayment


#Region " Form Declaration  .  .  ."
    ''
	Dim dsData As DataSet
	Dim clsMr As ClsMain
	Dim daPayment As SqlDataAdapter
	Dim daPaymentDetail As SqlDataAdapter
    Dim blnLoading As Boolean = True
	Dim blndataChange As Boolean = False
	Dim blnEditMode As Boolean = False
	Dim blnAddMode As Boolean
	Dim WithEvents Nav As New BitsNav
	Private daTafkeet As SqlDataAdapter
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Payment\Settings"
    Private mstrCurrentGridNameInvoice As String
    Private mstrCurrentGridNamePmtDetails As String
    Private mInvoiceID As Integer
    Private mPaymentID As Integer
    Private IntCurr As Integer
	Dim mblnLoginSucces As Boolean = False
	Private mblnSetNums As Boolean = False
	Private mblnDGCAAccount As Boolean = False
	Public WithEvents mClsFrmLogin As frmPassword
    Private blnAddPayment As Boolean = False
#End Region


#Region " Form Initialization . . ."

    Private Sub frmPayment_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmPayment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ''
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav
        ''
        ' cboCurrency.SelectedIndex = -1
        ''
        blnLoading = True
        MakeDataAdapter()
        SetDefaults()
        SetAutoNumber()
        FillComboBox()
        SetDataBinding()
        SetCurrency()
        DrawGrid()
        ''
        setState("Browse")
        ''
        If mPaymentID = 0 Then
            ' New Record
            NewRecord()
            cboBank.SelectedIndex = -1
        Else
            'Edit
            'EditPayment()
            Nav.CurrentPosition = GetRowIndex(mPaymentID)
            'lblNetCurr.Text=
            'setState("Browse")
            ''
            If cboStatus.SelectedValue = 2 Then
                setState("POST")
            Else
                setState("BROWSE")
            End If
            ''
        End If

        cboEmployee.SelectedValue = gIntUserID
        grpCheck.Enabled = False
        ''
        '' initialize controls . . .
        'FlipTabPage("Open")
        'FlipTabPage("Close")
        ''
        CalculateInvoicesTotals()
        txtInvoiceTotal.Text = Double.Parse(txtInvoiceTotal.Text).ToString("#,###0.##")
        txtInvoiceTotal2.Text = Double.Parse(txtInvoiceTotal2.Text).ToString("#,###0.##")
        ''
        If txtPmtTotal.Text <> String.Empty Then
            ''
            txtPmtTotal2.Text = Double.Parse(txtPmtTotal2.Text).ToString("#,###0.##")
            txtPmtTotal.Text = Double.Parse(txtPmtTotal.Text).ToString("#,###0.##")
        End If
        ''
        txtNet.Text = Double.Parse(txtNet.Text).ToString("#,###0.##")
        txtNet2.Text = Double.Parse(txtNet2.Text).ToString("#,###0.##")
        ''
        lblCurrency.Text = GetCurrency()
        lblNetCurr.Text = GetCurrency()
        ''
        CalculatePmtTotals()
        ''
        blnLoading = False
        ''
        grpNums.Enabled = False
    End Sub

    Private Sub MakeDataAdapter()
        ''
        daPayment = clsMr.BuildSqlAdapter("SELECT * FROM tblPayment WHERE PaymentID = " & mPaymentID & " AND  Del = 0", "tblPayment")
        daPaymentDetail = clsMr.BuildSqlAdapter("SELECT * FROM tblPaymentDetail WHERE PaymentID = " & mPaymentID & " AND Del = 0 ", "tblPaymentDetail")
        '' grid of 1st Tab
        'clsMr.BuildSqlAdapter("SELECT * FROM vwPaymentList WHERE Del = 0", "vwPaymentList")
        'clsMr.BuildSqlAdapter("SELECT * FROM vwPayment WHERE Del = 0", "vwPayment")
        clsMr.BuildSqlAdapter("SELECT InvoiceNumber, Description, Total,TotalCurr2 InvoiceID, CurrencyID, Del FROM tblInvoice WHERE Del = 0 AND InvoiceID = 0", "tblInvoice")
        ''
        '' grd in 2nd tab Payment
        clsMr.BuildSqlAdapter("SELECT PaymentNum, PaymentType, PaymentDesc, ChkNumber, ValueDate, Cleared, Symbol, Amount, BankName, PaymentID, PaymentDetailID, PaymentTypeID, InvoiceID, CurrID, BankID, Del FROM vwPaymentDetails WHERE PaymentID = " & mPaymentID & " AND  Del= 0 AND Amount > 0", "vwPmtDetails")
        '' grd in 2nd tab Invoices
        clsMr.BuildSqlAdapter("SELECT InvoiceNumber, Description, SymbolInv, Amount, Total, PaymentID, PaymentDetailID, InvoiceID, CurrID, Del  FROM vwPaymentDetails WHERE PaymentID = " & mPaymentID & " AND Del= 0 AND Amount < 0", "vwInvoiceDetails")
        ''
        clsMr.BuildSqlAdapter("SELECT ClientName, ClientID, Del FROM tblClient WHERE Del = 0 ORDER BY ClientName", "tblClient")
        clsMr.BuildSqlAdapter("SELECT * FROM vwEmployeeName WHERE Del = 0", "vwEmployeeName")
        clsMr.BuildSqlAdapter("SELECT PaymentType, PaymentTypeID FROM tblPaymentType", "tblPaymentType")
        clsMr.BuildSqlAdapter("SELECT Symbol, CurrID, Del FROM tblCurrency WHERE Del = 0", "tblCurrency")
        clsMr.BuildSqlAdapter("SELECT Status, StatusID, Del FROM tblStatus WHERE Del = 0", "tblStatus")
        clsMr.BuildSqlAdapter("SELECT BankID, BankName FROM tblBank WHERE Del = 0", "tblBank")
        daTafkeet = clsMr.BuildSqlAdapter("SELECT * from tblTafkeet WHERE InvoiceID = -1", "tblTafkeet")
        dsData = clsMr.getDataSet
    End Sub

    Private Sub SetDataBinding()
        ''
        clsMr.BindTextBox(txtPaymentID, "tblPayment", "PaymentID")
        clsMr.BindTextBox(txtPaymentYY, "tblPayment", "PaymentYY")
        clsMr.BindDateTimePicker(dtpPmtDate, "tblPayment", "PaymentDate")
        clsMr.BindTextBox(txtPmtNum, "tblPayment", "PaymentNum")
        clsMr.BindTextBox(txtReceiptNum, "tblPayment", "ReceiptNum")
        clsMr.BindTextBox(txtPmtTrxNum, "tblPayment", "PmtTrxNum")
        clsMr.BindTextBox(txtReceiptNum2, "tblPayment", "ReceiptNum")
        clsMr.BindTextBox(txtPmtTrxNum2, "tblPayment", "PmtTrxNum")
        clsMr.BindComboBox(cboClient, "tblPayment", "ClientID")
        clsMr.BindTextBox(txtPmtTotal, "tblPayment", "Amount")
        clsMr.BindTextBox(txtPmtDescription, "tblPayment", "Note")
        clsMr.BindComboBox(cboStatus, "tblPayment", "StatusID")
        clsMr.BindCheckBox(chkWhithStamp, "tblPayment", "WhithStamp")
    End Sub

    Private Sub FillComboBox()
        ''
        clsMr.FillComboBox("tblClient", cboClient, "ClientName", "ClientID")
        clsMr.FillComboBox("vwEmployeeName", cboEmployee, "Employee", "EmployeeID")
        clsMr.FillComboBox("tblPaymentType", cboPaymentType, "PaymentType", "PaymentTypeID")
        clsMr.FillComboBox("tblCurrency", cboCurrency, "Symbol", "CurrID")
        clsMr.FillComboBox("tblStatus", cboStatus, "Status", "StatusID")
        clsMr.FillComboBox("tblBank", cboBank, "BankName", "BankID")
    End Sub

    Private Sub SetAutoNumber()
        ''
        clsMr.SetAutoNumber("tblPayment", "PaymentID")
        clsMr.SetAutoNumber("tblPayment", "PaymentNum")
        clsMr.SetAutoNumber("tblPaymentDetail", "PaymentDetailID")
    End Sub

    Private Sub SetDefaults()
        ''
        clsMr.SetDefaults("tblPayment", "Del", 0, "PaymentDate", Now.Date)
        clsMr.SetDefaults("tblPayment", "EmployeeID", gIntUserID)
        clsMr.SetDefaults("tblPayment", "WhithStamp", 0, "StatusID", 1)
        clsMr.SetDefaults("tblPaymentDetail", "Del", 0, "CreatedDate", Now.Date, "CreateByID", gIntUserID, "ValueDate", Now.Date)
        clsMr.SetDefaults("tblPaymentDetail", "CurrID", 2)
    End Sub

    Private Sub SetCurrency()
        ''
        Nav.SetCurrency(Me, clsMr.getDataSet, "tblPayment")
    End Sub

#End Region


#Region " UI - Events     .  .  .  "

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.click
		''
		If blndataChange Then
			Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
				Case MsgBoxResult.Yes
					'' call save...
					If lstDataErr.Items.Count <> 0 Then
						MsgBox("Cannot save.Please check error list")
						Exit Sub
					Else
						Save()
						Me.Close()
					End If
				Case MsgBoxResult.No
					'' ignore changes...

					Try
						Nav.CancelCurrentEdit()
					Catch ex As Exception

					End Try
					Me.Close()
				Case MsgBoxResult.Cancel
					'' ignore close press..
					'' do nothing...

			End Select
		Else
			Me.Close()
		End If
	End Sub

	Private Sub NewRecord()
		''
		blndataChange = True
		Nav.AddNew()
		cboStatus.SelectedIndex = 0
		cboEmployee.SelectedValue = gIntUserID
		blnAddMode = True
		''
		ResetDetails()
		txtAmount.Text = ""
		txtInvoiceTotal.Text = ""
		txtInvoiceTotal2.Text = ""
		txtPaymentYY.Text = Now.Date.Year
		txtPaymentYY.Text = txtPaymentYY.Text.Substring(2, 2)
		setState("NEW")
		checkValues()
	End Sub

	'Private Sub btnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
	'    ''
	'    editSelectedPayment()
	'End Sub

	'Private Sub grdPayments_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs)
	'    ''
	'    editSelectedPayment()
	'End Sub

	'Private Sub btnDelete_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
	'    ''
	'    If grdPayments.RowCount = 0 Then
	'        Exit Sub
	'    End If
	'    If OkToDelete() Then
	'        If MsgBox("Are you sure you want to delete Payment?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
	'            ''
	'            strSQL = "Update tblPayment SET Del = 1 WHERE PaymentID = " & grdPayments.Item("PaymentID", grdPayments.CurrentRow.Index).Value
	'            Dim cmd As New SqlCommand(strSQL, conSql)
	'            ''
	'            Try
	'                conSql.Open()
	'                cmd.ExecuteNonQuery()
	'                conSql.Close()
	'                ''
	'                grdPayments.Item("Del", grdPayments.CurrentRow.Index).Value = 1
	'                dsData.Tables("vwPaymentList").DefaultView(grdPayments.CurrentRow.Index).Delete()
	'            Catch ex As Exception
	'                conSql.Close()
	'            End Try
	'        End If
	'        ''
	'    End If
	'    '' Delete Pmts Details . . . 
	'End Sub

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
		''
		If blndataChange = True Then
            ''
            If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Try
                    ''
                    Nav.CancelCurrentEdit()
                    ''
                    If blnAddMode Then
                        blnAddMode = False
                        RefreshGrids()
                        Me.Close()
                        Exit Sub
                    End If
                    ''
                    If blndataChange = True Then
                        ''
                        setState("Browse")
                    End If
                    RefreshGrids()
                Catch ex As Exception
                    ''
                    setState("Browse")
                    Me.Close()
                    Exit Sub
                    '' If tbl has now rows   -   CancelCurrentEdit will cause error binding
                    '' In general this problem occurs once at initialy stages of the system
                End Try
                ''
                'setState("Cancel")
                CalculatePmtTotals()
            End If
		Else
            ''
            setState("Cancel")
		End If
    End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        ''
        Save()
	End Sub

	'Private Sub btnShowColPmt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
	'    ''
	'    CustomColumns("Pmt", grdPayments)
	'    RemoveGrdListItems("Pmt")
	'End Sub

	Private Sub btnShowColInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowColInvoice.Click
		''
		'CustomColumns("Invoices", grdInvoices)
		'RemoveGrdListItems("Invoices")
		''
		If Me.grpShowHideColumnsInvoice.Visible = False Then
			Me.grpShowHideColumnsInvoice.Visible = True
			Me.grpShowHideColumnsInvoice.BringToFront()
			mstrCurrentGridNameInvoice = "InvoiceList"
			''
			'' populate list with grid's dataSource fields...
			''
			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridColInvoice.Items.Clear()
			For Each col In grdInvoices.Columns
				Me.chkLstGridColInvoice.Items.Add(col.HeaderText, col.Visible)
			Next
			RemoveGrdListItems()
		Else
			Me.grpShowHideColumnsInvoice.Visible = False
			Me.grpShowHideColumnsInvoice.SendToBack()
		End If

		''
	End Sub

	Private Sub btnShowColPmtDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowColPmtDetails.Click
		''
		'CustomColumns("PmtDetails", grdPaymentDetails)
		'RemoveGrdListItems("PmtDetails")
		If Me.grpShowHideColumnsPmtDetails.Visible = False Then
			Me.grpShowHideColumnsPmtDetails.Visible = True
			Me.grpShowHideColumnsPmtDetails.BringToFront()
			mstrCurrentGridNamePmtDetails = "PaymentList"
			''
			'' populate list with grid's dataSource fields...
			''
			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridColPmtDetails.Items.Clear()
			For Each col In grdPaymentDetails.Columns
				Me.chkLstGridColPmtDetails.Items.Add(col.HeaderText, col.Visible)
			Next
			RemoveGrdListItems()
		Else
			Me.grpShowHideColumnsPmtDetails.Visible = False
			Me.grpShowHideColumnsPmtDetails.SendToBack()
		End If
	End Sub

	'Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
	'    ''
	'    Select Case mstrCurrentGridName
	'        'Case "Pmt"
	'        '	SaveSettings(grdPayments)
	'        Case "Invoices"
	'            SaveSettings(grdInvoices)
	'        Case "PmtDetails"
	'            SaveSettings(grdPaymentDetails)
	'    End Select
	'End Sub

	'Private Sub btnDetailClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
	'    ''
	'    If txtNet.Text < 0 Then
	'        MsgBox("You Must Pay All The Amount, Your Net Balance Is = " & txtNet.Text)
	'        Exit Sub
	'    End If
	'    If blndataChange = True Then

	'        ''
	'        Dim res As MsgBoxResult
	'        res = MsgBox("Do You Want To Save Changes?", MsgBoxStyle.YesNoCancel)
	'        ''
	'        Select Case res
	'            Case MsgBoxResult.Yes
	'                btnSave.PerformClick()
	'                'FlipTabPage("Close")
	'            Case MsgBoxResult.No
	'                Try
	'                    Nav.CancelCurrentEdit()
	'                    'FlipTabPage("Close")
	'                Catch ex As Exception
	'                    'FlipTabPage("Close")
	'                    'ChangeColor()
	'                    ReSelectPmtList()
	'                End Try
	'            Case MsgBoxResult.Cancel
	'                Exit Sub
	'        End Select
	'    End If
	'    'FlipTabPage("Close")
	'    ReSelectPmtList()
	'    'ReselectPayment()
	'    setState("Browse")
	'    'ChangeColor()
	'End Sub

	Private Sub btnInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInvoice.Click
		''
		'' Get All InvoiceID in grdInvoice
		''
		Dim strIDs As String
		Dim j As Integer = 0
		strIDs = String.Empty
		For j = 0 To grdInvoices.RowCount - 1
			If strIDs <> String.Empty Then
				strIDs &= ", "
			End If
			strIDs &= grdInvoices.Rows(j).Cells("InvoiceID").Value
		Next
		''
		Dim frm As New frmInvoicesGet(cboClient.SelectedValue, strIDs)
		frm.ShowDialog()
		''
		dsData.Tables("tblInvoice").Clear()
		clsMr.BuildSqlAdapter("SELECT InvoiceNumber, Description, Total,TotalCurr2, InvoiceID, CurrencyID, Del FROM tblInvoice WHERE Del = 0", "tblInvoice")
		''
		Dim i As Integer
		For i = 0 To frm.arrPay.Length - 1
			If frm.arrPay(i) <> -1 Then
				''
				dsData.Tables("vwInvoiceDetails").DefaultView.AllowNew = True
				''
				Dim drs() As DataRow = dsData.Tables("tblInvoice").Select("InvoiceID=" & frm.arrPay(i))
				If drs.Length <> 0 Then


					Dim dr As DataRow = dsData.Tables("vwInvoiceDetails").NewRow
					dr("InvoiceNumber") = drs(0)("InvoiceNumber")
					dr("Description") = drs(0)("Description")
					''
					If Not IsDBNull(drs(0)("Total")) Then
						dr("Amount") = drs(0)("Total") * -1
					Else
						dr("Amount") = 0
					End If
					''
					If Not IsDBNull(drs(0)("TotalCurr2")) Then
						dr("Total") = drs(0)("TotalCurr2") * -1
					Else
						dr("Total") = 0
					End If
					'dr("Total") = drs(0)("TotalCurr2")
					dr("InvoiceID") = drs(0)("InvoiceID")
					dr("CurrID") = drs(0)("CurrencyID")
					If dr("CurrID") = 1 Then
						lblInvoiceCurr1.Text = "LBP"
					Else
						lblInvoiceCurr1.Text = "$"
					End If

					dr("Del") = 0

					If drs(0)("CurrencyID") = 1 Then
						lblInvoiceCurr1.Text = "LBP"
					Else
						lblInvoiceCurr1.Text = "$"
					End If
					''
					dsData.Tables("vwInvoiceDetails").Rows.Add(dr)
					dsData.Tables("vwInvoiceDetails").DefaultView.AllowNew = False
				End If
			End If
		Next
		dsData.Tables("vwInvoiceDetails").DefaultView.AllowNew = False
		CalculateInvoicesTotals()
		If grdInvoices.RowCount <> 0 Then
			grpPmtDetail.Enabled = True
			btnNewPMT.Enabled = True
			btnDeletePMT.Enabled = True
			btnEditPmt.Enabled = True
		End If
		''
		'SetInvoiceAsSettled(True)
		''
		checkValues()
	End Sub

	Private Sub btnPost_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPost.Click
		''
		If btnPost.Text = "P o s t" Then
			If MsgBox("Are you sure you want to Post?", MsgBoxStyle.Critical + MsgBoxStyle.YesNo, "Warning") = MsgBoxResult.Yes Then
				''
				'If txtNet.Text < 0 Then
				'    MsgBox("You Must Pay All The Amount, Your Net Balance Is = " & txtNet.Text)
				'    Exit Sub
				'End If
				''
				blndataChange = True
				cboStatus.SelectedValue = 2
				''
				btnSave.Text = "S a v e"
				''
				Nav.EndCurrentEdit()
				clsMr.Update(daPayment, "tblPayment")
				'' Credit Client
				UpdateClientBalance()
				''
				SetInvoiceAsSettled(True)
				blndataChange = False
				setState("POST")
			End If
		Else
			If MsgBox("Are you sure you want to Unpost?", MsgBoxStyle.Critical + MsgBoxStyle.YesNo, "Warning") = MsgBoxResult.Yes Then
				mblnLoginSucces = False
				mClsFrmLogin = New frmPassword
				mClsFrmLogin.StartPosition = FormStartPosition.CenterScreen
				mClsFrmLogin.ShowDialog()

				If mblnLoginSucces Then
					mClsFrmLogin.Close()
				Else
					Exit Sub
				End If
				cboStatus.SelectedValue = 3
				'dataChange = True
				Save()
				Nav.EndCurrentEdit()
				clsMr.Update(daPayment, "tblPayment")
				'' Debit Client
				UpdateClientBalance()
				SetInvoiceAsSettled(False)
				setState("UNPOST")
				blndataChange = False
			End If
		End If
	End Sub

	Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
		''
		'' Show/Hide error list...
		If lstDataErr.Visible = True Then
			lstDataErr.Visible = False
		Else
			lstDataErr.Visible = True
			lstDataErr.Height = 251
			lstDataErr.BringToFront()
		End If

	End Sub

	Private Sub txtPmtNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPmtNum.TextChanged
		''
		checkValues()
	End Sub

	Private Sub cboClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
		AutoComplete(cboClient, e)
	End Sub

	Private Sub cboClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
		''
		If blnLoading Then Exit Sub
		checkValues()
		''
		grpInvoices.Enabled = True
		btnInvoice.Enabled = True
		grdInvoices.Columns("Description").ReadOnly = False
	End Sub

	Private Sub cboEmployee_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboEmployee.SelectedIndexChanged
		''
		If blnLoading Then Exit Sub
		checkValues()
	End Sub

	Private Sub txtAmount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAmount.TextChanged
		''
		checkValues()
		CheckPmtValues()
	End Sub

	Private Sub frmPassword_OnOkClick(ByVal pBlnPassed As Boolean, ByVal pIntUserID As Integer, ByVal pIntUserLevel As Integer) Handles mClsFrmLogin.OnOkClick
		If pBlnPassed = True Then
			gIntUserID = pIntUserID
			mblnLoginSucces = True
			gUserLevel = CType(pIntUserLevel, enmUserLevel)
		End If
	End Sub

	Private Sub cboClient_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyDown
		''
		If blnAddMode Then
			''
			If e.KeyCode = Keys.F3 Then
				Dim frm As New frmClientGet
				frm.ShowDialog()
				''
				cboClient.SelectedValue = frm.CboValue
			End If
			''
		End If
	End Sub

	Private Sub grdInvoices_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdInvoices.KeyDown
		''
		If blnAddMode Then
			''
			If e.KeyCode = Keys.F5 Then
				btnInvoice.PerformClick()
			End If
			''
		End If
	End Sub

	Private Sub grdPaymentDetails_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdPaymentDetails.CellClick
		'' 
		'UpdatePaymentFields()
	End Sub

	Private Sub btnDeletePMT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeletePMT.Click

		If grdPaymentDetails.RowCount = 0 Then Exit Sub
		''
		'Dim drInvoice As DataView
		'drInvoice = dsData.Tables("vwAddress").DefaultView

		'If MsgBox(" Are you sure you want to Delete? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution") = MsgBoxResult.Yes Then

		'    Dim drDel() As DataRow
		'    drDel = dsData.Tables("tblAddress").Select("AddressID = " & drAddress(grdViewAddress.CurrentRow.Index)("AddressID"))
		'    If drDel.Length > 0 Then
		'        drDel(0).Delete()
		'        Nav.EndCurrentEdit()
		'        clsMr.Update(daAddress, "tblAddress")
		'    End If

		'    dsData.Tables("vwAddress").DefaultView(grdViewAddress.CurrentRow.Index).Delete()

		'    If grdViewAddress.Rows.Count = 0 Then
		'        btnDeleteAddress.Enabled = False
		'    End If
		'End If
		If MsgBox("Are you sure you want to remove Payment?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
			dsData.Tables("vwPmtDetails").DefaultView.Item(grdPaymentDetails.CurrentRow.Index).Delete()
            CalculatePmtTotals()
            ''
            checkValues()
			'Update db 

		End If
		''
		'Dim dr As DataView
		'dr = dsData.Tables("vwPmtDetails").DefaultView

		'If MsgBox(" Are you sure you want to Delete? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution") = MsgBoxResult.Yes Then


		'    Dim i As Integer

		'    Dim dv As DataGridViewSelectedRowCollection = grdPaymentDetails.SelectedRows
		'    For i = 0 To dv.Count - 1
		'        ''updatedetail
		'        Dim cmd As New SqlCommand("UPDATE tblPaymentDetail SET Del=1 WHERE PaymentDetailID=" & dv(i).Cells("PaymentDetailID").Value, conSql)
		'        conSql.Open()
		'        cmd.ExecuteNonQuery()
		'        conSql.Close()
		'        'dsdata.Tables("vwInvoiceDetail").DefaultView(grdInvoiceDetail.CurrentRow.Index).Delete()
		'        dsData.Tables("vwPmtDetails").Rows.Remove(dsData.Tables("vwPmtDetails").DefaultView(grdPaymentDetails.CurrentRow.Index).Row)
		'    Next
		'    ''
		'    'If grdPaymentDetails.Rows.Count = 0 Then
		'    '    btnRemoveService.Enabled = False
		'    '    cboCategory.Enabled = True
		'    'End If

		'    ' CalculateTotal()
		'    'dataChange = True
		'    Save()

		'End If
		''
	End Sub

	Private Sub btnCancelPMT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelPMT.Click
        grpPmtDetails.Visible = False
        setState("Edit")
        checkValues()
    End Sub

	Private Sub btnSavePMT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSavePMT.Click
        ''
        If blnEditMode = True Then
            EditPayment()
            grpPmtDetails.Visible = False
            blnEditMode = False
        Else
            AddPaymentToGrid()
        End If
		''
		CalculatePmtTotals()
		lblCurrency.Text = cboCurrency.Text
        lblNetCurr.Text = cboCurrency.Text
        ''
        setState("Edit")
        checkValues()
    End Sub

	Private Sub btnRemoveInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveInvoice.Click
		''
		If grdInvoices.RowCount = 0 Then Exit Sub
		mInvoiceID = grdInvoices.CurrentRow.Cells("InvoiceID").Value '.Cells("PaymentID").Value(.Item("InvoiceID", i).Value
		If MsgBox("Are you sure you want to remove Invoice", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
			dsData.Tables("vwInvoiceDetails").DefaultView.Item(grdInvoices.CurrentRow.Index).Delete()
			CalculateInvoicesTotals()
		End If
        'SetInvoiceAsSettled(False)
        'SetInvoiceAsPosted()
        UpdateInvoiceStatusByID(2)
		''
		checkValues()
	End Sub

	Private Sub btnNewPMT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewPMT.Click
        ''
        blnEditMode = False
        blnAddPayment = True
		Dim dblInvoiceTotal As Double
		Dim dblInvoiceTotal2 As Double
		''
		dblInvoiceTotal = txtInvoiceTotal.Text
		dblInvoiceTotal2 = txtInvoiceTotal2.Text
		If txtPmtTotal.Text <> String.Empty Then
			''
			If txtPmtTotal.Text = Math.Abs(dblInvoiceTotal) Or txtPmtTotal.Text = Math.Abs(dblInvoiceTotal2) Then
				MsgBox("You Have paid The Total Amount Required", MsgBoxStyle.OkOnly, "Thank You")
				Exit Sub
			End If
		End If
		'dblInvoiceTotal = Math.Abs(txtInvoiceTotal.Text)
		'' If txtNet.Text = String.Empty Or txtNet.Text = 0 Then
		'If txtPmtTotal.Text = Or txtPmtTotal.Text = Math.Abs(txtInvoiceTotal2.Text) Then
		'    MsgBox("You Have paid The Total Amount Required", MsgBoxStyle.OkOnly, "Thank You")
		'    ' setState("Browse")
		'    Exit Sub
		'End If
		' ''
		Dim mPayment As Double
		Dim mInvoice As Double
		''
		grpPmtDetails.Visible = True
		grpPmtDetails.Enabled = True
		If grdPaymentDetails.Rows.Count > 0 Then
			cboCurrency.Enabled = False
		Else
			cboCurrency.SelectedValue = 1
			cboCurrency.Enabled = True
		End If
		''
		cboPaymentType.SelectedIndex = -1
		''
		If txtPmtTotal.Text <> String.Empty Then
			mPayment = CDbl(txtPmtTotal.Text)
		Else
			mPayment = 0
		End If
		If cboCurrency.SelectedValue = 1 Then
			mInvoice = txtInvoiceTotal.Text
		Else
			mInvoice = txtInvoiceTotal2.Text
		End If
		''
		'txtAmount.Text = txtInvoiceTotal.Text * -1
		txtAmount.Text = Math.Abs(mInvoice) - mPayment
		txtAmount.Text = Double.Parse(txtAmount.Text).ToString("#,###0.##")
		''
		txtNote.Text = ""
		txtCheckNum.Text = ""
		chkClear.Checked = False
		setState("NewPayment")
		grpDetails.Enabled = True
		dtpPmtDate.Enabled = False
		cboClient.Enabled = False
		btnSavePMT.Enabled = False
        checkValues()
        ''
        grpInvoices.Enabled = False
        grpPmtDetailButtons.Enabled = False
    End Sub

	Private Sub btnEditPmt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditPmt.Click
        ''
        blnAddPayment = False
		If grdPaymentDetails.RowCount = 0 Then Exit Sub
		grpPmtDetails.Visible = True
		blnEditMode = True
        GetPaymentToEdit()
        ''
        grpInvoices.Enabled = False
        'setState("NewPayment")
        cboCurrency.Enabled = False
        grpPmtDetailButtons.Enabled = False
	End Sub

	Private Sub txtCheckNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCheckNum.TextChanged
		CheckPmtValues()
	End Sub

	Private Sub cboBank_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboBank.TextChanged
		If blnLoading Then Exit Sub
		CheckPmtValues()
	End Sub

	Private Sub cboBank_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboBank.Leave
		'CheckPmtValues()
		AddNewValueToCbo(clsMr, Me.cboBank, "tblBank", "BankID", "BankName")

	End Sub

	Private Sub btnReciept_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReciept.Click
		''
		If txtPaymentID.Text = "" Then Exit Sub
		If txtPmtTotal.Text = "" Then Exit Sub
		''
        Dim frm As New frmQuickReport
		ClearTable()
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
        ''
		Dim rpt As New rptReceipt
		Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
		Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
		''
		For Each tbCurrent In rpt.Database.Tables
			tliCurrent = tbCurrent.LogOnInfo
			''
			With tliCurrent.ConnectionInfo
				.ServerName = gStrServerName
				.DatabaseName = gStrDataBaseName
                .UserID = ""
                .Password = ""
			End With
			''
			tbCurrent.ApplyLogOnInfo(tliCurrent)
		Next tbCurrent
		''
		frm.crvInstantViewer.SelectionFormula = "{vwPaymentListrpt.PaymentID}=" & Me.txtPaymentID.Text '& " AND {vwPaymentListrpt.Amount} < 0 " '& " AND {vwPaymentInvoice.PaymentID}=" & Me.txtPaymentID.Text '
        ''
		rpt.SetParameterValue("CurrSymbol", lblCurrency.Text)
		rpt.SetParameterValue("CurrSymbol1", lblCurrency.Text)
        rpt.SetParameterValue("CurrSymbol2", lblCurrency.Text)
        rpt.SetParameterValue("CurrSymbol3", lblCurrency.Text)

        ''
        Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand
		''
		Dim strUnitName As String
		Dim strPartUnitName As String
		Dim strSymbol As String
		Dim strUnitNameEn As String
		Dim strPartUnitNameEn As String
		Dim strSymbolEn As String
		''
		strSQL = "select * FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID	  ' IntCurr
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text
		''
		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			strUnitName = dRdr("UnitName")
			strPartUnitName = dRdr("PartUnitName")
			strSymbol = dRdr("Symbol")
		End If
		dRdr.Close()
		conSql.Close()
		''
		strSQL = "select * FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID2
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text

		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			strUnitNameEn = dRdr("UnitName")
			strPartUnitNameEn = dRdr("PartUnitName")
			strSymbolEn = dRdr("Symbol")
		End If
		dRdr.Close()
		conSql.Close()
		''
		Dim strWord As String
		Dim strWordEn As String
        ''
		'If IntCurr = 2 Then
		'	If txtPmtTotal.Text Mod 1 > 0 Then
		'		txtPmtTotal.Text = (txtPmtTotal.Text - (txtPmtTotal.Text Mod 1)) + 1
		'	End If
		'End If
		''
		strWordEn = ToWordsEn(txtPmtTotal.Text, strUnitNameEn, strPartUnitNameEn)
		strWord = ToWords(txtPmtTotal.Text, strUnitName, strPartUnitName)
        ''
		Dim drNew As DataRow = dsData.Tables("tblTafkeet").NewRow
		drNew("Tafkeet") = strWord
		drNew("TafkeetEn") = strWordEn
		drNew("InvoiceID") = txtPaymentID.Text
		dsData.Tables("tblTafkeet").Rows.Add(drNew)
		daTafkeet.Update(dsData, "tblTafkeet")
        ''
		frm.crvInstantViewer.ReportSource = rpt
		frm.crvInstantViewer.Refresh()
		frm.Show()
        ''
		frm.crvInstantViewer.DisplayToolbar = True
		Windows.Forms.Cursor.Current = Cursors.Default()
	End Sub

	Private Sub cboPaymentType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboPaymentType.SelectedIndexChanged
		''
        If blnLoading = True Then Exit Sub
		ShowCheckInfo()
		''
		checkValues()
		CheckPmtValues()
    End Sub

	Private Sub cboBank_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboBank.SelectedIndexChanged

	End Sub

	Private Sub btnSaveSettingsInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettingsInvoice.Click
		''
		Dim i As Integer
		''
		For i = 0 To Me.chkLstGridColInvoice.Items.Count - 1
			Me.grdInvoices.Columns(i).Visible = Me.chkLstGridColInvoice.GetItemChecked(i)
		Next
		''
		Me.grpShowHideColumnsInvoice.Visible = False
		''
	End Sub

	Private Sub btnSaveSettingsPmtDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettingsPmtDetails.Click
		''
		Dim i As Integer
		''
		For i = 0 To Me.chkLstGridColPmtDetails.Items.Count - 1
			Me.grdPaymentDetails.Columns(i).Visible = Me.chkLstGridColPmtDetails.GetItemChecked(i)
		Next
		''
		Me.grpShowHideColumnsPmtDetails.Visible = False
		''
	End Sub

	Private Sub cboBank_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboBank.KeyPress
		AutoComplete(cboBank, e)
	End Sub

	Private Sub cboCurrency_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCurrency.SelectedIndexChanged
		''
		If blnLoading Then Exit Sub
		''
		Dim mPayment As Double
		Dim mInvoice As Double
		''
		lblCurrency.Text = cboCurrency.Text
		lblNetCurr.Text = cboCurrency.Text
		''
		If txtPmtTotal.Text <> String.Empty Then
			mPayment = CDbl(txtPmtTotal.Text)
		Else
			mPayment = 0
		End If
		''
		If cboCurrency.SelectedValue = 1 Then
			''
			mInvoice = txtInvoiceTotal.Text
			''
		Else
			mInvoice = txtInvoiceTotal2.Text
			''
		End If
        ''
        If blnAddPayment Then
            txtAmount.Text = Math.Abs(mInvoice) - mPayment
            ''
            txtAmount.Text = Double.Parse(txtAmount.Text).ToString("#,###0.##")
        End If
    End Sub

	Private Sub txtPmtTrxNum2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPmtTrxNum2.TextChanged
		''
		checkValues()
	End Sub

	Private Sub txtReceiptNum2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtReceiptNum2.TextChanged
		''
		checkValues()

	End Sub

	Private Sub btnSetNum_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetNum.Click
		''	 
		grpNums.Enabled = True
		''
		setState("SETNUMS")
	End Sub

    Private Sub btnSaveNums_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        If txtReceiptNum2.Text = String.Empty Then
            txtReceiptNum2.Text = 0
        End If
        ''
        If txtPmtTrxNum2.Text = String.Empty Then
            txtPmtTrxNum2.Text = 0
        End If
        ''
        Dim cmd As New SqlCommand("UPDATE tblPayment SET [ReceiptNum]=" & txtReceiptNum2.Text & " , [PmtTrxNum]=" & txtPmtTrxNum2.Text & " WHERE PaymentID=" & txtPaymentID.Text, conSql)
        conSql.Open()
        cmd.ExecuteNonQuery()
        conSql.Close()
        ''
        Try
            ''
        Catch ex As Exception
            conSql.Close()
        End Try
        ''
        txtReceiptNum.Text = txtReceiptNum2.Text
        txtPmtTrxNum.Text = txtPmtTrxNum2.Text
        ''
        grpNums.Visible = False
    End Sub

    Private Sub btnCancelNums_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        grpNums.Visible = False
    End Sub

	Private Sub cboClient_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.TextChanged
		''
		checkValues()
	End Sub

#End Region


#Region " Form Functions   .  .  . "

	Private Sub DrawGrid()
		''
		With grdInvoices
			''
			.DataSource = dsData.Tables("vwInvoiceDetails").DefaultView
			''
			'.ReadOnly = True
			.Columns("InvoiceNumber").ReadOnly = True
			.Columns("Description").ReadOnly = True
			.Columns("SymbolInv").ReadOnly = True
			.Columns("Amount").ReadOnly = True
			''
			.Columns("InvoiceNumber").HeaderText = "Invoice #"
            .Columns("SymbolInv").HeaderText = "Symbol"
            .Columns("SymbolInv").Visible = False
			''
			.Columns("CurrID").Visible = False
			.Columns("InvoiceID").Visible = False
			.Columns("PaymentID").Visible = False
			.Columns("PaymentDetailID").Visible = False
			.Columns("Del").Visible = False
			''
            .Columns("Amount").HeaderText = "Total LBP"
            .Columns("Total").HeaderText = "Total $"
            .Columns("Amount").DefaultCellStyle.Format = "#,###.##"
            .Columns("Total").DefaultCellStyle.Format = "#,###.##"
            .Columns("Description").Width = 200
            ''
			.ColumnHeadersHeight = btnShowColInvoice.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
			dsData.Tables("vwInvoiceDetails").DefaultView.AllowNew = False
		End With

		''
		With grdPaymentDetails
			''
			.DataSource = dsData.Tables("vwPmtDetails").DefaultView
			.Columns("PaymentNum").HeaderText = "Payment #"
			.Columns("PaymentType").HeaderText = "Payment Type"
			.Columns("PaymentDesc").HeaderText = "Description"
			.Columns("ChkNumber").HeaderText = "Check/Card #"
            .Columns("ValueDate").HeaderText = "Value Date"
            .Columns("ValueDate").DefaultCellStyle.Format = "dd-MMM-yyyy"
			''
			.Columns("PaymentDetailID").Visible = False
			.Columns("PaymentID").Visible = False
			.Columns("PaymentTypeID").Visible = False
			.Columns("InvoiceID").Visible = False
			.Columns("CurrID").Visible = False
			.Columns("BankID").Visible = False
			.Columns("Del").Visible = False
			'.Columns("Amount").DefaultCellStyle.Format = "###,###,###,###,###.00#"
			.Columns("Amount").DefaultCellStyle.Format = "#,###.##"
			''
			.ColumnHeadersHeight = btnShowColPmtDetails.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
			dsData.Tables("vwPmtDetails").DefaultView.AllowNew = False
		End With
		''
		RemoveGrdListItems()
		'RemoveGrdListItems("PmtDetails")
		LoadProfile(mStrSubKeyName & "\Invoices", Me.grdInvoices)
		LoadProfile(mStrSubKeyName & "\PmtDetails", Me.grdPaymentDetails)
	End Sub

	Private Sub RemoveGrdListItems(ByVal pIdentity As String)
		''
		Select Case (pIdentity)
			'Case "Pmt"
			'	With chkLstGridCol
			'		.Items.Remove("ClientID")
			'		.Items.Remove("EmployeeID")
			'		.Items.Remove("StatusID")
			'		.Items.Remove("PaymentID")
			'		.Items.Remove("Del")
			'		Exit Sub
			'	End With
			''
			Case "Invoices"
				'With chkLstGridCol
				'    .Items.Remove("Amount")
				'End With
				''
			Case "PmtDetails"
				'With chkLstGridCol
				'	.Items.Remove("BankID")
				'	''
				'End With
		End Select
		chkLstGridColInvoice.Items.Remove("CurrID")
		chkLstGridColInvoice.Items.Remove("PaymentID")
		chkLstGridColInvoice.Items.Remove("PaymentTypeID")
		chkLstGridColInvoice.Items.Remove("CurrID")
		chkLstGridColInvoice.Items.Remove("InvoiceID")
		chkLstGridColInvoice.Items.Remove("PaymentDetailID")
		chkLstGridColInvoice.Items.Remove("Del")
	End Sub

	'Private Sub CustomColumns(ByVal pStrGridName As String, ByRef pGrd As DataGridView)
	'	''
	'       If Me.grpShowHideColumnsInvoice.Visible = False Then
	'           Me.grpShowHideColumnsInvoice.Visible = True
	'           Me.grpShowHideColumnsInvoice.BringToFront()
	'           mstrCurrentGridName = pStrGridName
	'           ''
	'           '' populate list with grid's dataSource fields...
	'           ''
	'           Dim col As Windows.Forms.DataGridViewColumn
	'           ''
	'           Me.chkLstGridCol.Items.Clear()
	'           For Each col In pGrd.Columns
	'               Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
	'           Next
	'       Else
	'           Me.grpShowHideColumnsInvoice.Visible = False
	'           Me.grpShowHideColumnsInvoice.SendToBack()
	'       End If

	'   End Sub

	Private Sub SaveSettings(ByRef pGrd As DataGridView)
		''
		Dim i As Integer

		For i = 0 To Me.chkLstGridColInvoice.Items.Count - 1
			pGrd.Columns(i).Visible = Me.chkLstGridColInvoice.GetItemChecked(i)
		Next
		''
		Me.grpShowHideColumnsInvoice.Visible = False
	End Sub

	'Private Sub FilterGrid()
	'	''    
	'	If blnLoading Then Exit Sub
	'	''    
	'	Dim s As String = " True"
	'	Dim strStatus As String
	'	'' 
	'	's = "(PaymentDate >= '" & Format(dtpFromFilter.Value, "dd /MMM / yyyy") & "') AND (PaymentDate <= '" & Format(dtpToFilter.Value, "dd /MMM / yyyy") & "')"
	'	s = "(PaymentDate >= '" & dtpFromFilter.Value.ToShortDateString() & "') AND (PaymentDate <= '" & dtpToFilter.Value.ToShortDateString() & "')"
	'	''
	'	If txtPmtNumFilter.Text <> String.Empty Then
	'		Dim tn As Integer
	'		Try
	'			tn = Convert.ToInt32(txtPmtNumFilter.Text)
	'			s = s & " AND  (PaymentNum = " & tn & ")"
	'		Catch ex As Exception
	'			txtPmtNumFilter.Text = ""
	'		End Try
	'	End If
	'	''
	'	If cboClientFilter.SelectedIndex <> -1 Then
	'		s = s & " AND (ClientID = " & cboClientFilter.SelectedValue & ")"
	'	Else
	'		If cboClientFilter.Text <> "" And cboClientFilter.SelectedIndex = -1 Then
	'			s = s & " & AND (ClientID = " & -1 & ")"
	'		End If
	'	End If
	'	''
	'	If chkFilterPosted.Checked = False And chkFilterNotposted.Checked = False And chkFilterNew.Checked = False Then
	'		s = s & " AND (StatusID = 0) "
	'	Else
	'		''
	'		strStatus = " AND StatusID IN ("
	'		If chkFilterPosted.Checked = True Then

	'			strStatus = strStatus & "2"
	'		End If
	'		''
	'		If chkFilterNotposted.Checked = True Then
	'			If strStatus = " AND StatusID IN (" Then
	'				strStatus = strStatus & "3"
	'			Else
	'				strStatus = strStatus & ",3"
	'			End If
	'		End If
	'		''
	'		If chkFilterNew.Checked = True Then
	'			If strStatus = " AND StatusID IN (" Then
	'				strStatus = strStatus & "1"
	'			Else
	'				strStatus = strStatus & ",1"
	'			End If

	'		End If
	'		strStatus = strStatus & ")"
	'	End If
	'	s = s & strStatus
	'	''
	'	dsData.Tables("vwPaymentList").DefaultView.RowFilter = s
	'	ChangeColor()

	'	If grdPayments.Rows.Count > 0 Then
	'		btnOpen.Enabled = True
	'		btnDelete.Enabled = True
	'		btnPreview.Enabled = True
	'	Else
	'		btnOpen.Enabled = False
	'		btnDelete.Enabled = False
	'		btnPreview.Enabled = False
	'	End If
	'End Sub

	Private Sub ClearTable()
		''
		Dim cmd As New SqlClient.SqlCommand("Delete from tblTafkeet", conSql)
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()
		dsData.Tables("tblTafkeet").Rows.Clear()
	End Sub

	Private Sub setState(ByRef pStrMode As String)
		''
		Dim mStrCurrentState As String
		mStrCurrentState = UCase(pStrMode)
		'' 
		Select Case mStrCurrentState
			''
			Case Is = "NEW"
                ''
				btnSave.Text = "S a v e"
				btnPost.Text = "P o s t"
				''
				btnReciept.Enabled = False
				btnInvoice.Enabled = False
				btnSave.Enabled = False
				btnPost.Enabled = False
				btnCancel.Enabled = True
				''
				cboPaymentType.SelectedIndex = -1
				cboClient.SelectedIndex = -1
				''
				grpDetails.Enabled = True
				grpInvoices.Enabled = False
				grpPmtDetail.Enabled = False
				grpPmtDetails.Visible = False
                ''
				btnSetNum.Enabled = False
				grpNums.Enabled = False

			Case Is = "EDIT"
				''
				btnSave.Text = "S a v e"
				btnReciept.Enabled = False
				btnInvoice.Enabled = True
				btnRemoveInvoice.Enabled = True
				grdInvoices.Columns("Description").ReadOnly = False
				btnSave.Enabled = False
				btnPost.Enabled = False
				btnCancel.Enabled = True
                ''
				grpDetails.Enabled = True
				grpPmtDetail.Enabled = True
				grpInvoices.Enabled = True
				grpDetails.Enabled = True
				''
				btnNewPMT.Enabled = True
				btnDeletePMT.Enabled = True
				btnEditPmt.Enabled = True
				''
				btnSetNum.Enabled = True
				grpNums.Enabled = False
                grpPmtDetailButtons.Enabled = True

			Case Is = "SAVE"
				''
				btnSave.Text = "E d i t"
				btnReciept.Enabled = True
				btnInvoice.Enabled = False
				btnRemoveInvoice.Enabled = False
				btnSave.Enabled = True
				btnPost.Enabled = True
				btnCancel.Enabled = False
                ''
				grpDetails.Enabled = False
                ''
				btnNewPMT.Enabled = False
				btnDeletePMT.Enabled = False
				btnEditPmt.Enabled = False
				btnSetNum.Enabled = True
				grpNums.Enabled = False

			Case Is = "BROWSE"
				''
				If cboStatus.SelectedValue = 2 Then
					''
					btnPost.Text = "U n  P o s t"
				Else
					btnPost.Text = "P o s t"
				End If
				''
				btnSave.Text = "E d i t"
				''
				btnReciept.Enabled = True
				btnInvoice.Enabled = False
				btnRemoveInvoice.Enabled = False
				btnSave.Enabled = True
				btnPost.Enabled = True
				btnCancel.Enabled = False
				''
				grpDetails.Enabled = False
				grpCheck.Enabled = True
				grpPmtDetails.Visible = False
				grdInvoices.ReadOnly = True
				grdPaymentDetails.ReadOnly = True
				''
				btnNewPMT.Enabled = False
				btnDeletePMT.Enabled = False
				btnEditPmt.Enabled = False
				btnSetNum.Enabled = True
				grpNums.Enabled = False

			Case Is = "OPEN"
				''
				grpDetails.Enabled = False
				btnSave.Text = "E d i t"
				''
				btnReciept.Enabled = True
				btnInvoice.Enabled = False
				btnRemoveInvoice.Enabled = False
				btnSave.Enabled = True
				btnPost.Enabled = True
				btnCancel.Enabled = False
				''
				btnNewPMT.Enabled = False
				btnDeletePMT.Enabled = False
				btnEditPmt.Enabled = False
				grdInvoices.ReadOnly = True
				grdPaymentDetails.ReadOnly = True
				grpDetails.Enabled = False
				''
				btnSetNum.Enabled = True
				grpNums.Enabled = False

			Case Is = "CANCEL"
				grpDetails.Enabled = False
				btnSave.Text = "E d i t"
				''
				btnReciept.Enabled = True
				btnInvoice.Enabled = False
				btnSave.Enabled = True
				btnPost.Enabled = False
				btnCancel.Enabled = False
				''
				btnSetNum.Enabled = True
				grpNums.Enabled = False

			Case "NEWPAYMENT"
				''
                grpDetails.Enabled = False
                grpInvoices.Enabled = False
                grpPmtDetail.Enabled = False
				btnSave.Text = "S a v e"
				''
				btnReciept.Enabled = False
				btnInvoice.Enabled = False
				btnSave.Enabled = True
				btnPost.Enabled = True
				btnCancel.Enabled = True
				''
				btnSetNum.Enabled = False
				grpNums.Enabled = False

            Case "EDITPAYMENT"
                ''
                grpDetails.Enabled = False
                grpInvoices.Enabled = False
                grpPmtDetail.Enabled = False
                btnSave.Text = "S a v e"
                ''
                btnReciept.Enabled = False
                btnInvoice.Enabled = False
                btnSave.Enabled = True
                btnPost.Enabled = True
                btnCancel.Enabled = True
                ''
                btnSetNum.Enabled = False
                grpNums.Enabled = False

			Case Is = "POST"
				''
				btnSave.Text = "S a v e"
				btnPost.Text = "U n  P o s t"
				grpDetails.Enabled = False
				''

				btnReciept.Enabled = True
				btnInvoice.Enabled = False
				btnSave.Enabled = False
				btnPost.Enabled = True
				btnCancel.Enabled = False
				btnSetNum.Enabled = False
				grpNums.Enabled = False
				''
			Case Is = "UNPOST"
				''
				btnSave.Text = "E d i t"
				btnPost.Text = "P o s t"
				grpDetails.Enabled = True

				btnReciept.Enabled = True
				btnInvoice.Enabled = False
				btnSave.Enabled = True
				btnPost.Enabled = True
				btnCancel.Enabled = False
				''
				btnSetNum.Enabled = True
				grpNums.Enabled = False

			Case Is = "SETNUMS"
				''
				btnSave.Text = "S a v e"
                btnCancel.Enabled = True
                grpNums.Enabled = True
				btnSetNum.Enabled = False
        End Select
        ''
        DGCA.LoadPermissionsSetState(Me, Me.Name)
	End Sub

	Private Sub frmPayment_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		'' Save User Grid Setting...
		SaveProfile(mStrSubKeyName & "\Invoices", Me.grdInvoices)
		SaveProfile(mStrSubKeyName & "\PmtDetails", Me.grdPaymentDetails)
	End Sub

	'Public Sub FlipTabPage(ByVal strState As String)

	'	'' Open or close Payment TapPage
	'	Select Case strState
	'		''
	'		Case "Open"
	'               'If Not tcPayment.TabPages.Contains(tpPayment) Then
	'               '	tcPayment.TabPages.Add(tpPayment)
	'               '	'tcPayment.SelectedIndex = 1
	'               '	tcPayment.SelectedTab = tpPayment
	'               'End If
	'		Case "Close"
	'               'If tcPayment.TabPages.Contains(tpPayment) Then
	'               '	tcPayment.TabPages.Remove(tpPayment)
	'               'End If
	'               'tcPayment.SelectedIndex = 0
	'               ''tcPayment.SelectedTab = tpPaymentsList
	'	End Select
	'	grpPmtDetails.Visible = False

	'End Sub

	Private Sub ReSelectPmtList()
		''
		'' After Creating new Payment and Payment Detail
		'' Reselect  the view inorder to see the changes
		dsData.Tables("vwPaymentList").Clear()
		clsMr.BuildSqlAdapter("SELECT * FROM vwPaymentList WHERE Del = 0", "vwPaymentList")
	End Sub

	Private Sub ResetDetails()
		''
		'' New Payment in PmtDetail tab requires to initialize the controls
		'' InOrder to add new Payment this requires  initialize  the  grids
		'If blnLoading = True Then Exit Sub
		dsData.Tables("vwPmtDetails").Clear()
		dsData.Tables("vwInvoiceDetails").Clear()
		clsMr.BuildSqlAdapter("SELECT PaymentNum, PaymentType, PaymentDesc, ChkNumber, ValueDate, Cleared, Symbol, Amount, PaymentID, PaymentDetailID, PaymentTypeID, InvoiceID, CurrID, Del FROM vwPaymentDetails WHERE Del= 0 AND Amount > 0 AND PaymentID=" & mPaymentID, "vwPmtDetails")
		clsMr.BuildSqlAdapter("SELECT InvoiceNumber, Description, Amount, PaymentID, PaymentDetailID, InvoiceID, CurrID, Del  FROM vwPaymentDetails WHERE Del= 0 AND Amount < 0 AND PaymentID=" & mPaymentID, "vwInvoiceDetails")
	End Sub

	Public Function GetRowIndex(ByVal pPmtID As Long) As Integer
		''
		Dim i As Integer
		''
		For i = 0 To dsData.Tables("tblPayment").DefaultView.Count - 1
			If dsData.Tables("tblPayment").DefaultView.Item(i)("PaymentID") = pPmtID Then
				Return i
			End If
		Next
		''
		Return -1

	End Function

	Private Sub Save()
		''
		If btnSave.Text = "E d i t" Then
			setState("Edit")
			checkValues()
			blndataChange = True
		Else
			'' If CheckPaidAmount() = True Then
			'' Paid Amount is less than the Invoice Total
			'' Y   O   U     C   A   N     S   A   V   E
			'If txtAmount.Text = String.Empty Then
			'    lstDataErr.Items.Add("Missing Payment Amount")
			'    Exit Sub
			'End If
            SaveInvoiceDetails()
            ''
            'If CInt(txtNet.Text) <> 0 Then
            '    ''
            '    UpdateInvoiceStatusByIDs(6)
            'Else
            ''
            UpdateInvoiceStatusByIDs(4)
            'End If
            ''
            SavePaymentDetails()
            Nav.EndCurrentEdit()
            clsMr.Update(daPayment, "tblPayment")
            ''
            CalculatePmtTotals()
            setState("Save")
            blndataChange = False
        End If
	End Sub

	Private Function GetCurrency() As String
		''
		'Dim IntCurr As Integer
		Dim StrCurr As String
		Dim cmdCurrID As New SqlCommand("SELECT CurrID FROM tblPaymentDetail WHERE PaymentID =" & mPaymentID & " AND Amount >0", conSql)
		''
		conSql.Open()
		IntCurr = cmdCurrID.ExecuteScalar
		conSql.Close()
		''
		Dim cmdSymbol As New SqlCommand("SELECT Symbol FROM tblCurrency WHERE CurrID =" & IntCurr, conSql)
		''
		conSql.Open()
		StrCurr = cmdSymbol.ExecuteScalar
		conSql.Close()
		Return StrCurr
	End Function
	''

	Private Sub UpdateClientBalance()
		''
		'' When Post and UnPost the balance of the Client
		'' must be updated by the current Payments Amount
		''
		Dim TotalCharge As Decimal
		Dim AcctCurrID As Integer = GetAcctCurrency(cboClient.SelectedValue)
		''
		If GetOperation(gIntCompanyCurrID, AcctCurrID, dtpPmtDate.Value) = "/" Then
			TotalCharge = Decimal.Parse(txtPmtTotal.Text) / GetRate(cboCurrency.SelectedValue, AcctCurrID, dtpPmtDate.Value)
		Else
			TotalCharge = Decimal.Parse(txtPmtTotal.Text) * GetRate(cboCurrency.SelectedValue, AcctCurrID, dtpPmtDate.Value)
		End If
		''
		'' Return TotalCharge
		''
		Dim command As New SqlClient.SqlCommand
		''
		If txtCheckNum.Text = String.Empty Then
			command.CommandText = "SpUpdateClientBalance"
		Else
			If chkClear.Checked Then
				command.CommandText = "SpUpdateClientBalance"
			Else
				command.CommandText = "SpUpdateClientPendingBalance"
			End If
		End If
		''
		Try
			command.Connection = conSql
			command.CommandType = CommandType.StoredProcedure
			If cboStatus.SelectedValue = 2 Then
				command.Parameters.AddWithValue("@balance", -TotalCharge)
			Else
				If cboStatus.SelectedValue = 3 Then
					command.Parameters.AddWithValue("@balance", TotalCharge)
				End If
			End If
			''
			command.Parameters.AddWithValue("@ClientID", GetAcctID(cboClient.SelectedValue))
			conSql.Open()
			command.ExecuteNonQuery()
			conSql.Close()
		Catch ex As Exception
			conSql.Close()
		End Try

	End Sub

	Private Sub SaveInvoiceDetails()
		''
		Dim intCounter As Integer
		Dim drAdd As DataRow
		Dim drUpdate() As DataRow
		Dim drDelete() As DataRow
		Dim dt As DataTable
		''
		'' Check if new row (s)  added
		dt = dsData.Tables("vwInvoiceDetails").GetChanges(DataRowState.Added)
		''
		If Not (dt Is Nothing) Then
			For intCounter = 0 To dt.Rows.Count - 1
				drAdd = dsData.Tables("tblPaymentDetail").NewRow()
				drAdd("PaymentID") = txtPaymentID.Text
                drAdd("InvoiceID") = dt.Rows(intCounter)("InvoiceID")
                ''
                If cboCurrency.SelectedValue = 2 Then
                    ''
                    drAdd("Amount") = dt.Rows(intCounter)("Total")
                Else
                    ''
                    drAdd("Amount") = dt.Rows(intCounter)("Amount")
                End If
                ''
                drAdd("Description") = dt.Rows(intCounter)("Description")
                drAdd("CurrID") = cboCurrency.SelectedValue
				dsData.Tables("tblPaymentDetail").Rows.Add(drAdd)
				dt.Rows(intCounter).EndEdit()
			Next
		End If
		'' Check if  rows are changed
		'dt = dsData.Tables("tblInvoice").GetChanges(DataRowState.Modified)
		dt = dsData.Tables("vwInvoiceDetails").GetChanges(DataRowState.Modified)
		''  
		If Not (dt Is Nothing) Then
			For intCounter = 0 To dt.Rows.Count - 1
				drUpdate = dsData.Tables("tblPaymentDetail").Select("InvoiceID=" & dt.Rows(intCounter)("InvoiceID"))
				drUpdate(0).BeginEdit()
				drUpdate("InvoiceID") = dt.Rows(intCounter)("InvoiceID")
				drUpdate("Amount") = dt.Rows(intCounter)("Amount")
                drUpdate("Description") = dt.Rows(intCounter)("Description")
                drAdd("CurrID") = cboCurrency.SelectedValue
				drUpdate(0).EndEdit()
			Next
		End If
		''
		dt = dsData.Tables("vwInvoiceDetails").GetChanges(DataRowState.Deleted)
		''
		If Not (dt Is Nothing) Then
			dt.RejectChanges()
			For intCounter = 0 To dt.Rows.Count - 1
				drDelete = dsData.Tables("tblPaymentDetail").Select("InvoiceID=" & dt.Rows(intCounter)("InvoiceID"))
				If drDelete.Length > 0 Then
					drDelete(0).Delete()
				End If
			Next
		End If
		''
		dt = dsData.Tables("tblPaymentDetail").GetChanges
		''
		If Not (dt Is Nothing) Then
			daPaymentDetail.Update(dt)
			dsData.Tables("tblPaymentDetail").AcceptChanges()
			dsData.Tables("vwInvoiceDetails").AcceptChanges()
		End If
		dsData.EnforceConstraints = True
	End Sub

	Private Sub SavePaymentDetails()

		'' Update DataSet
		Dim intCounter As Integer
		Dim drAdd As DataRow
		Dim drUpdate() As DataRow
		Dim drdelete() As DataRow
		Dim dt As DataTable
		''
		'check if new rows are added
		dt = dsData.Tables("vwPmtDetails").GetChanges(DataRowState.Added)
		''
		If Not (dt Is Nothing) Then
			For intCounter = 0 To dt.Rows.Count - 1
				drAdd = dsData.Tables("tblPaymentDetail").NewRow()
				drAdd("PaymentID") = dt.Rows(intCounter)("PaymentID")
				drAdd("PaymentTypeID") = dt.Rows(intCounter)("PaymentTypeID")
				'drAdd("PaymentNum") = dt.Rows(intCounter)("PaymentNum")
				drAdd("Description") = dt.Rows(intCounter)("PaymentDesc")
				drAdd("Amount") = dt.Rows(intCounter)("Amount")
				If (cboPaymentType.SelectedValue = 1) Or (cboPaymentType.SelectedValue = 2) Or (cboPaymentType.SelectedValue = 3) Or (cboPaymentType.SelectedValue = 4) Or (cboPaymentType.SelectedValue = 5) Then
					''
					drAdd("Cleared") = dt.Rows(intCounter)("Cleared")
					drAdd("ValueDate") = dt.Rows(intCounter)("ValueDate")
					drAdd("chkNumber") = dt.Rows(intCounter)("chkNumber")
					drAdd("BankID") = dt.Rows(intCounter)("BankID")
					'Else
					'	'' if BankID is null affect the vw ask wissam tomorrow Feb 6 2008
					'	drAdd("BankID") = 1
				End If
				''
				drAdd("CurrID") = dt.Rows(intCounter)("CurrID")
				drAdd("Del") = 0
				dsData.Tables("tblPaymentDetail").Rows.Add(drAdd)
				dt.Rows(intCounter).EndEdit()
			Next

		End If
		''check if  rows are changed
		dt = dsData.Tables("vwPmtDetails").GetChanges(DataRowState.Modified)

		If Not (dt Is Nothing) Then
			''
			For intCounter = 0 To dt.Rows.Count - 1
				dsData.Tables("tblPaymentDetail").Clear()
				daPaymentDetail = clsMr.BuildSqlAdapter("SELECT * FROM tblPaymentDetail WHERE Del = 0 ", "tblPaymentDetail")
				''
				drUpdate = dsData.Tables("tblPaymentDetail").Select("PaymentDetailID =" & dt.Rows(intCounter)("PaymentDetailID"))
				drUpdate(0).BeginEdit()
				drUpdate(0)("PaymentID") = dt.Rows(intCounter)("PaymentID")
				drUpdate(0)("PaymentTypeID") = cboPaymentType.SelectedValue	'dt.Rows(intCounter)("PaymentTypeID")
				drUpdate(0)("Description") = dt.Rows(intCounter)("PaymentDesc")
				drUpdate(0)("Amount") = dt.Rows(intCounter)("Amount")
				If cboBank.SelectedIndex <> -1 Then
					drUpdate(0)("BankID") = cboBank.SelectedValue 'dt.Rows(intCounter)("BankID")
				End If
				drUpdate(0)("BankID") = dt.Rows(intCounter)("BankID")
				drUpdate(0)("Cleared") = dt.Rows(intCounter)("Cleared")
				drUpdate(0)("ValueDate") = dt.Rows(intCounter)("ValueDate")
				drUpdate(0)("chkNumber") = dt.Rows(intCounter)("chkNumber")
				drUpdate(0)("CurrID") = dt.Rows(intCounter)("CurrID")
				drUpdate(0)("Del") = dt.Rows(intCounter)("Del")
				drUpdate(0).EndEdit()
				''
			Next
		End If
		''
		''
		dt = dsData.Tables("vwPmtDetails").GetChanges(DataRowState.Deleted)

		If Not (dt Is Nothing) Then
			dt.RejectChanges()
			For intCounter = 0 To dt.Rows.Count - 1
				drdelete = dsData.Tables("tblPaymentDetail").Select("PaymentDetailID=" & dt.Rows(intCounter)("PaymentDetailID"))
				drdelete(0).Delete()
			Next
		End If
		''
		dt = dsData.Tables("tblPaymentDetail").GetChanges
		''
		If Not (dt Is Nothing) Then
			daPaymentDetail.Update(dt)
			dsData.Tables("tblPaymentDetail").AcceptChanges()
			dsData.Tables("vwPmtDetails").AcceptChanges()
		End If
		dsData.EnforceConstraints = True
		''
	End Sub

	Private Sub checkValues()
		''
		If blnLoading = True Then Exit Sub
		''
		blndataChange = True
		''
		lstDataErr.Items.Clear()
		''
		Dim intErrCount As Int16 = 0
		''
		If Me.cboClient.SelectedIndex = -1 Or cboClient.Text = String.Empty Then
			lstDataErr.Items.Add("Missing Client")
			intErrCount += 1
		End If
		''
		If grdInvoices.RowCount = 0 Then
			lstDataErr.Items.Add("Choose Invoice before perform payment")
			intErrCount += 1
		End If
		''
		'If grdInvoices.Rows.Count = 0 Then
		'	lstDataErr.Items.Add("Error: Select Invoice")
		'	intErrCount += 1
		'End If
		''
		If Me.cboPaymentType.SelectedIndex = -1 Then
			lstDataErr.Items.Add("Missing Payment Type")
			intErrCount += 1
		End If
        ''
        If grdPaymentDetails.Rows.Count = 0 Then
            ''
            lstDataErr.Items.Add("Missing Payment Details")
            intErrCount += 1
        End If
		'If txtAmount.Text = String.Empty Then
		'    lstDataErr.Items.Add("Missing Payment Amount")
		'    intErrCount += 1
		'End If
		''
        If lstDataErr.Items.Count = 0 Then
            lstDataErr.Visible = False
            btnDataErr.Visible = False
        Else
            btnDataErr.Visible = True
        End If
		''
		If blndataChange And intErrCount = 0 Then
			btnSave.Enabled = True
			'btnPost.Enabled = True
		Else
			btnSave.Enabled = False
			'btnPost.Enabled = False
		End If

	End Sub

	Private Function CheckPaidAmount() As Boolean
		'' Check Paid amount if it exceed the Invoice total
		If cboCurrency.SelectedValue = 1 Then
			''
			If Double.Parse(txtAmount.Text) < Double.Parse(txtInvoiceTotal.Text) Then
				MsgBox("Paid Amount can't be less than the Invoice Total")
				Return False
			Else
				Return True
			End If
		Else
			If Double.Parse(txtAmount.Text) < Double.Parse(txtInvoiceTotal2.Text) Then
				MsgBox("Paid Amount can't be less than the Invoice Total")
				Return False
			Else
				Return True
			End If
		End If
	End Function

	Private Sub FormatAmountFiled()
		'' Delete and use the Function
		If txtAmount.Text = String.Empty Then
			txtAmount.Text = 0
		End If
		Try
			' txtAmount.Text = Double.Parse(txtAmount.Text).ToString("#0.00#")
			txtAmount.Text = Double.Parse(txtAmount.Text).ToString("#,###0.##")

		Catch ex As Exception
			MsgBox("check the Amount correctly . . .")
			txtAmount.Text = String.Empty
		End Try

	End Sub

	Private Sub SetPostOptions(ByVal strState As String)
		''
		If strState = "Post" Then
			'' P o s t
			Me.btnSave.Enabled = False
			Me.btnCancel.Enabled = False
			'Me.btnNew.Enabled = False
			btnInvoice.Enabled = False
			'btnNewPayment.Enabled = False
			'btnDeleteInvoice.Enabled = False
			btnPost.Enabled = True
			grpDetails.Enabled = False
			btnSave.Text = "E d i t"
			btnPost.Text = "U n  P o s t"
		Else
			'' U n  p o s t
			Me.btnSave.Enabled = True
			Me.btnCancel.Enabled = False
			'Me.btnNew.Enabled = True
			btnInvoice.Enabled = True
			grdInvoices.Columns("Description").ReadOnly = False
			'btnDeleteInvoice.Enabled = True
			'btnNewPayment.Enabled = True
			grpDetails.Enabled = False
			btnSave.Text = "E d i t"
			btnPost.Text = "P o s t"
		End If
	End Sub

	Private Sub ShowCheckInfo()
		''
		'' Determine wether to show the check number and value date or not
		'' Apply  this  if payment type is  credit card  with  lbl changes
		''
		Select Case cboPaymentType.SelectedValue
            Case 2, 6
                '' Check
                'grpCheck.Visible = True
                grpCheck.Enabled = True
                lblCheckNum.Text = "Check #"
                lblValueDate.Text = "Value Date"
                txtCheckNum.Enabled = True
                cboBank.Enabled = True
                'grpPmtDetails.Width = grpPmtDetails.Width + grpCheck.Width + 50

			Case 3
				''DGCA Account
				txtCheckNum.Text = ""
				cboBank.SelectedIndex = -1
				grpCheck.Enabled = True
                cboBank.Enabled = True
                txtCheckNum.Enabled = True
				chkClear.Enabled = False
				dtpValueDate.Enabled = True
				btnSavePMT.Enabled = True
				mblnDGCAAccount = True

			Case 4
				'' Credit Card
				grpCheck.Enabled = True
				txtCheckNum.Enabled = True
				cboBank.Enabled = True
				lblCheckNum.Text = "Card #"
				lblValueDate.Text = "Expiry Date"
				'grpPmtDetails.Width = grpPmtDetails.Width + grpCheck.Width + 50

			Case 5
				''Bank transfer
				grpCheck.Enabled = True
				lblCheckNum.Text = "Card #"
                txtCheckNum.Enabled = True
                lblValueDate.Text = "Expiry Date"
                txtCheckNum.Text = ""
                cboBank.SelectedIndex = -1
                cboBank.Enabled = True
                chkClear.Enabled = False
                dtpValueDate.Enabled = True
                btnSavePMT.Enabled = True

            Case Else
                'grpPmtDetails.Width = grpPmtDetails.Width - grpCheck.Width - 50
                txtCheckNum.Text = ""
                cboBank.SelectedIndex = -1
                grpCheck.Enabled = False
        End Select
	End Sub

	Private Function OkToDelete() As Boolean
		''
		''Here goes ... checking if current Payment 
		''Can     be     deleted      or        not
		''
		Return True
	End Function

	Private Sub SetInvoiceAsSettled(ByVal blnState As Boolean)

		'' Set  Invoice  Status as Settled when posted
        '' Redo Status when Unpost, Set status Posted
        '' 2 Posted              -          4 Settled

		Dim i As Integer
		'Dim frm As New frmClientGet
		''
		For i = 0 To grdInvoices.RowCount - 1
            'If blnState = True Then
            strSQL = "Update tblInvoice SET StatusID = 4 WHERE InvoiceID = " & grdInvoices.Item("InvoiceID", i).Value 'mInvoiceID	'
            'Else
            '             strSQL = "Update tblInvoice SET StatusID = 2 WHERE InvoiceID = " & mInvoiceID 'grdInvoices.Item("InvoiceID", i).Value 'mInvoiceID	'
            'End If
            ''
            Dim cmd As New SqlCommand(strSQL, conSql)
            '    ''
            Try
                conSql.Open()
                cmd.ExecuteNonQuery()
                conSql.Close()
                ''
            Catch ex As Exception
                conSql.Close()
            End Try
        Next
		''
	End Sub

    Private Sub SetInvoiceAsPosted()
        ''
        strSQL = "Update tblInvoice SET StatusID = 2 WHERE InvoiceID = " & mInvoiceID
        ''
        Dim cmd As New SqlCommand(strSQL, conSql)
        '    ''
        Try
            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()
            ''
        Catch ex As Exception
            conSql.Close()
        End Try
    End Sub

	'Private Sub ChangeColor()
	'	'change color of visits according to status
	'	Dim i As Integer
	'	Dim intStatus As Integer
	'	For i = 0 To dsData.Tables("vwPaymentList").DefaultView.Count - 1
	'		intStatus = dsData.Tables("vwPaymentList").DefaultView.Item(i)("StatusID")
	'		Select Case intStatus
	'               'Case 1
	'               '	grdPayments.Rows(i).DefaultCellStyle.BackColor = Color.LightYellow

	'               'Case 2
	'               '	grdPayments.Rows(i).DefaultCellStyle.BackColor = Color.LightSteelBlue

	'               'Case 3
	'               '	grdPayments.Rows(i).DefaultCellStyle.BackColor = Color.MistyRose
	'           End Select
	'	Next
	'End Sub

	Private Sub CalculateInvoicesTotals()
		''
		If grdInvoices.Rows.Count = 0 Then
			txtInvoiceTotal.Text = 0
			txtInvoiceTotal2.Text = 0
			Exit Sub
		End If
		''
		Dim gt As Double
		Dim gt2 As Double
		''
		Dim dv As DataView = dsData.Tables("vwInvoiceDetails").DefaultView
		If dv.Count <> 0 Then
			Dim i As Integer
			For i = 0 To dv.Count - 1
				gt += dv(i)("Amount")
				If Not IsDBNull(dv(i)("Total")) Then
					gt2 += dv(i)("Total")
				End If
			Next
		End If
		''
		If gt < 0 Then
			'txtInvoiceTotal.Text = gt.ToString("###,###,###,###,###.00#")
			txtInvoiceTotal.Text = gt.ToString("#,###0.##")
			txtInvoiceTotal2.Text = gt2.ToString("#,###0.##")
		Else
			'txtPmtTotal.Text = txtPmtTotal.Text.ToString("###,###,###,###,###.00#")
			'txtInvoiceTotal.Text = gt.ToString("###,###,###,###,###.00#") * -1
			If txtPmtTotal.Text <> String.Empty Then
				txtPmtTotal.Text = txtPmtTotal.Text.ToString("#,###0.##")
			End If
			''
			If txtPmtTotal2.Text <> String.Empty And txtPmtTotal2.Text <> 0 Then
				txtPmtTotal2.Text = txtPmtTotal2.Text.ToString("#,###0.##")
			End If
			''
			txtInvoiceTotal.Text = gt.ToString("#,###0.##") * -1
			txtInvoiceTotal2.Text = gt.ToString("#,###0.##") * -1
		End If
	End Sub

	Private Sub CalculatePmtTotals()
		''
		If grdPaymentDetails.RowCount = 0 Then
			txtPmtTotal.Text = 0
			Exit Sub
		End If
		''
		Dim gt As Double
		Dim gt2 As Double
		Dim intCurr As Integer
		''
		Dim dv As DataView = dsData.Tables("vwPmtDetails").DefaultView
		If dv.Count <> 0 Then
			Dim i As Integer
			For i = 0 To dv.Count - 1
				'If cboCurrency.SelectedValue = 1 Then

				'End If

				If dv(i)("Amount") Is DBNull.Value Then
					dv(i)("Amount") = 0
				End If
				gt += dv(i)("Amount")
				''
				'If dv(i)("TotalCurr2") Is DBNull.Value Then
				'    dv(i)("TotalCurr2") = 0
				'End If
				'gt2 += dv(i)("TotalCurr2")
				intCurr = dv(i)("CurrID")
			Next
		End If
		'txtPmtTotal.Text = gt.ToString("###,###,###,###,###.00#")
		txtPmtTotal.Text = gt.ToString("#,###0.##")
		' txtPmtTotal2.Text = gt2.ToString("#,###.##")

		'' Calculate Net
		If intCurr = 1 Then
			gt2 = Double.Parse(txtInvoiceTotal.Text) + Double.Parse(txtPmtTotal.Text)
		Else
			gt2 = Double.Parse(txtInvoiceTotal2.Text) + Double.Parse(txtPmtTotal.Text)
		End If
		'txtNet2.Text = Double.Parse(txtInvoiceTotal2.Text) + Double.Parse(txtPmtTotal2.Text)

		txtNet.Text = gt2.ToString("#,###0.##")
		''
        If txtNet.Text < 0 And blnLoading = False Then
            'If cboCurrency.SelectedValue = 1 Then
            MsgBox("Net balance is: " & txtNet.Text)
            'Else
            '    MsgBox("Net balance is: " & txtNet2.Text)
            'End If
        End If

	End Sub

	Private Sub GetPaymentToEdit()
		''
		If grdPaymentDetails.RowCount = 0 Then Exit Sub
		Dim dr As DataRow = dsData.Tables("vwPmtDetails").DefaultView.Item(grdPaymentDetails.CurrentRow.Index).Row
		If IsDBNull(dr("PaymentType")) Then
			''
		Else
			cboPaymentType.Text = dr("PaymentType")
		End If
		''
		txtAmount.Text = dr("Amount")
		txtAmount.Text = Double.Parse(txtAmount.Text).ToString("#,###0.##")
		txtNote.Text = dr("PaymentDesc")

		If Not dr("ChkNumber") Is DBNull.Value Then
			txtCheckNum.Text = dr("ChkNumber")
			cboBank.SelectedValue = dr("BankID")
			dtpValueDate.Value = dr("ValueDate")
		Else
			txtCheckNum.Text = String.Empty
		End If
        ''
        If Not IsDBNull(dr("ValueDate")) Then
            dtpValueDate.Value = dr("ValueDate")
        End If
        ''
        cboCurrency.SelectedValue = dr("CurrID")
        If chkClear.Checked = False Then
            chkClear.Checked = False
        Else
            chkClear.Checked = True
        End If
    End Sub

	Private Sub EditPayment()
		''
		Dim dr As DataRow = dsData.Tables("vwPmtDetails").DefaultView.Item(grdPaymentDetails.CurrentRow.Index).Row

		If cboPaymentType.Text <> "" Then
			dr("PaymentType") = cboPaymentType.Text
		End If

		dr("Amount") = txtAmount.Text
		dr("Amount") = Double.Parse(dr("Amount")).ToString("#,###0.##")
		dr("PaymentDesc") = txtNote.Text
        dr("Symbol") = cboCurrency.Text
        ''
        If txtCheckNum.Text <> "" Then
            dr("ChkNumber") = CInt(txtCheckNum.Text)
        Else
            dr("ChkNumber") = DBNull.Value
        End If
        ''
        If cboBank.SelectedIndex <> -1 Then
            dr("BankID") = cboBank.SelectedValue
        Else
            dr("BankID") = -1
        End If
        ''
        dr("ValueDate") = dtpValueDate.Value
        dr("BankName") = cboBank.Text
        'End If
        ''
        dr("ValueDate") = dtpValueDate.Value
        ''
        If chkClear.Checked = False Then
            chkClear.Checked = False
        Else
            chkClear.Checked = True
        End If
        ''

    End Sub

	'Private Sub Tafkeet()
	'   If blnLoading = True Then Exit Sub
	'   ''
	'   Dim drReader As SqlDataReader
	'   Dim PartName, PartUnitName As String
	'   ''
	'   Dim cmd As New SqlCommand("SELECT UnitName, PartUnitName FROM tblCurrency WHERE CurrID =" & cboCurrency.SelectedValue, conSql)
	'   ''
	'   Try
	'      conSql.Open()
	'      drReader = cmd.ExecuteReader()
	'      While (drReader.Read)
	'         PartName = drReader("UnitName")
	'         PartUnitName = drReader("PartUnitName")
	'         ''
	'         txtWord.Text = ToWords(txtAmount.Text, PartName, PartUnitName)
	'         ''
	'         If txtAmount.Text = String.Empty Then
	'            txtWord.Text = String.Empty
	'         End If
	'         ''
	'      End While

	'      conSql.Close()
	'   Catch ex As Exception
	'      conSql.Close()
	'   End Try
	'   ''
	'   checkValues()
	'End Sub

	Private Sub AddPaymentToGrid()
        ''
		Dim pmt As Decimal
        ''
		If Not Decimal.TryParse(txtAmount.Text, pmt) Then
			txtAmount.Text = String.Empty
			MsgBox("The Amount is Invalid")
			Exit Sub
		End If
		''
		dsData.Tables("vwPmtDetails").DefaultView.AllowNew = True
		Dim dr As DataRow
		''
		dr = dsData.Tables("vwPmtDetails").NewRow
        ''
		dr("PaymentNum") = txtPmtNum.Text
        dr("PaymentType") = cboPaymentType.Text
        ''
        If (cboPaymentType.SelectedValue <> 1) Then
            dr("ChkNumber") = Integer.Parse(txtCheckNum.Text)
            dr("Cleared") = chkClear.Checked
            dr("BankID") = cboBank.SelectedValue
            dr("BankName") = cboBank.Text
        End If
        ''
        dr("ValueDate") = dtpValueDate.Value
		dr("PaymentDesc") = txtNote.Text
		dr("CurrID") = cboCurrency.SelectedValue
        dr("Amount") = pmt
		dr("Symbol") = cboCurrency.Text
		dr("PaymentID") = txtPaymentID.Text
		dr("PaymentTypeID") = cboPaymentType.SelectedValue
		dr("Del") = 0
		''
		dsData.Tables("vwPmtDetails").Rows.Add(dr)
		dsData.Tables("vwPmtDetails").DefaultView.AllowNew = False
        ''
		grpPmtDetails.Visible = False
    End Sub

	Private Sub AddStamp()

		Dim dr As DataRow
		dr = dsData.Tables("vwInvoiceDetails").NewRow
		dr("PaymentID") = txtPaymentID.Text
		''dr("InvoiceID") = 0
		dr("Amount") = -1000
		dr("Description") = "Stamp"
		dr("Symbol") = "LBP"
		dsData.Tables("vwInvoiceDetails").Rows.Add(dr)
		CalculateInvoicesTotals()

	End Sub

    Private Sub CheckPmtValues()
        ''
        Dim blnChkInfo As Boolean
        ''
        If grpCheck.Enabled Then
            If cboBank.SelectedIndex = -1 Or txtCheckNum.Text = String.Empty Then
                blnChkInfo = False
            Else
                blnChkInfo = True
            End If
        Else
            blnChkInfo = True
        End If
        ''
        If mblnDGCAAccount = True Then
            blnChkInfo = True
        End If
        ''
        If blnChkInfo = False Or cboPaymentType.SelectedIndex = -1 Or txtAmount.Text = String.Empty Then
            btnSavePMT.Enabled = False
        Else
            btnSavePMT.Enabled = True
        End If
        ''
        blnChkInfo = False
    End Sub

	Public Sub New(Optional ByVal pPaymentID As Integer = -1)

		' This call is required by the Windows Form Designer.
		InitializeComponent()
        mPaymentID = pPaymentID

		' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

	Private Sub editSelectedPayment()
        ''
		ResetDetails()
		dsData.Tables("vwPmtDetails").Clear()
		dsData.Tables("vwInvoiceDetails").Clear()
		clsMr.BuildSqlAdapter("SELECT PaymentNum, PaymentType, PaymentDesc, ChkNumber, ValueDate, Cleared, Symbol, Amount, PaymentID, PaymentDetailID, PaymentTypeID, InvoiceID, CurrID, Del FROM vwPaymentDetails WHERE Del= 0 AND Amount > 0", "vwPmtDetails")
		clsMr.BuildSqlAdapter("SELECT InvoiceNumber, Description, Amount, PaymentID, PaymentDetailID, InvoiceID, CurrID, Del  FROM vwPaymentDetails WHERE Del= 0 AND Amount < 0", "vwInvoiceDetails")
        ''
		CalculateInvoicesTotals()
		CalculatePmtTotals()
		setState("Open")
		GetPaymentToEdit()
		''
		If cboStatus.SelectedValue = 2 Then	  '' Posted
			SetPostOptions("Post")
		Else
			If cboStatus.SelectedValue = 3 Then
				SetPostOptions("NotPosted")
			End If
		End If
		''
		ShowCheckInfo()
		blndataChange = False

	End Sub

	Private Sub RemoveGrdListItems()
		''
		With chkLstGridColInvoice
			'PaymentID, PaymentDetailID, InvoiceID, CurrID, Del
			.Items.Remove("PaymentID")
			.Items.Remove("PaymentDetailID")
			.Items.Remove("InvoiceID")
			.Items.Remove("CurrID")
            .Items.Remove("Del")
		End With
		''
		With chkLstGridColPmtDetails
            ''
			.Items.Remove("PaymentID")
			.Items.Remove("PaymentDetailID")
			.Items.Remove("PaymentTypeID")
			.Items.Remove("InvoiceID")
			.Items.Remove("CurrID")
			.Items.Remove("BankID")
			.Items.Remove("Del")
		End With
    End Sub

    Private Sub RefreshGrids()
        ''
        dsData.Tables("vwPmtDetails").Rows.Clear()
        dsData.Tables("vwInvoiceDetails").Rows.Clear()
        '' 
        clsMr.BuildSqlAdapter("SELECT PaymentNum, PaymentType, PaymentDesc, ChkNumber, ValueDate, Cleared, Symbol, Amount, BankName, PaymentID, PaymentDetailID, PaymentTypeID, InvoiceID, CurrID, BankID, Del FROM vwPaymentDetails WHERE PaymentID = " & mPaymentID & " AND  Del= 0 AND Amount > 0", "vwPmtDetails")
        clsMr.BuildSqlAdapter("SELECT InvoiceNumber, Description, SymbolInv, Amount, Total, PaymentID, PaymentDetailID, InvoiceID, CurrID, Del  FROM vwPaymentDetails WHERE PaymentID = " & mPaymentID & " AND Del= 0 AND Amount < 0", "vwInvoiceDetails")
    End Sub

    Private Sub UpdateInvoiceStatusByID(ByVal pStatusID As Integer)
        ''
        strSQL = "Update tblInvoice SET StatusID =" & pStatusID & " WHERE InvoiceID = " & mInvoiceID
        ''
        Dim cmd As New SqlCommand(strSQL, conSql)
        '    ''
        Try
            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()
            ''
        Catch ex As Exception
            conSql.Close()
        End Try
    End Sub

    Private Sub UpdateInvoiceStatusByIDs(ByVal pStatusID As Integer)
        ''
        Dim i As Integer
        ''
        For i = 0 To grdInvoices.RowCount - 1
            ''
            strSQL = "Update tblInvoice SET StatusID = " & pStatusID & " WHERE InvoiceID = " & grdInvoices.Item("InvoiceID", i).Value
            ''
            Dim cmd As New SqlCommand(strSQL, conSql)
            ''
            Try
                conSql.Open()
                cmd.ExecuteNonQuery()
                conSql.Close()
                ''
            Catch ex As Exception
                conSql.Close()
            End Try
        Next
    End Sub

#End Region


End Class