''
Imports BITSConn
Imports System.Data.SqlClient
'' Ali 
Public Class frmPurchaseOrder

#Region " Form Declaration . . . "
    ''
    Dim clsMr As ClsMain
    Dim dsData As New DataSet
    Dim WithEvents Nav As New BitsNav
    '' Data Adapters . . .
    Dim daPurchaseOrder As SqlClient.SqlDataAdapter
    Private daCurrencyRate As SqlClient.SqlDataAdapter
    Dim daPurchaseOrderDetail As SqlClient.SqlDataAdapter
    Dim daVoucher As SqlClient.SqlDataAdapter
    Dim daVoucherDetail As SqlClient.SqlDataAdapter
    Public WithEvents mClsFrmLogin As frmPassword
    '' DataType variables . . .
    Dim AddMode As Boolean
    Dim blnLoading As Boolean = True
    Dim blnGridHeaderClicked As Boolean
    Dim mblnLoginSucces As Boolean = False
    Dim dataChange As Boolean = False
    ''
    Dim mPOID As Integer
    Dim intAcctCurr As Integer
    Dim CurrID1 As Integer
    Dim CurrID2 As Integer
    ''
    Dim Cost As Long = 0
    Dim TotalCost As Long = 0
    ''
    Dim POExpense As Long = 0
    Dim TotalPOExpense As Long = 0
    Dim POVehExpense As Long = 0
    Dim TotalPOVehExpense As Long = 0
    Dim TotalExpense As Long = 0
    ''
    Dim PurchaseAccount As Long = -1
    Dim PurchaseAccountCurrency As Long = -1
    Dim CashAccount As Long = -1
    Dim CashAccountCurrency As Integer = -1
    ''
    Dim TotalExpenseAmount As Double
    Dim mVoucherExpenseID As Double
    ''
    Private mStrCurrentState As String
    Private mStrSubKeyName As String = "Software\BIT Solutions\CarzTrack\Settings\PurchaseOrder"
    Private mstrCurrentGridName As String
#End Region

#Region " Form Initialization . . . "

    Private Sub frmPurchaseOrder_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ''
        blnLoading = True
        '' Set Up UI - dataSource connection
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav()

        '' Set up Fuction
        MakeDataAdapter()
        FillComboBox()
        SetDataBinding()
        SetCurrencyManager()
        SetDefaultValue()
        SetAutoNumber()
        ''
        DrawGrid()
        GetCompanyCurrencies()
        PopulateAccountsFixedRef()
        '' Can not Delete Posted transaction
        OpenDeleteOptions()
        '' Color the transaction record according to its Status
        ChangeColor()
        '' Control Initializing . . .
        lblCompCurr.Text = GetCompanyCurrencySymbol()
        tcPurchaseOrder.TabPages.Remove(tpPurchaseOrderDetail)
        cboFilterSupplier.SelectedIndex = -1
        cboStatus.SelectedIndex = -1
        cboAcctID.SelectedIndex = -1
        cboEmployee.SelectedIndex = -1
        dtpFilterFrom.Value = Today.AddMonths(-1)
        ''
        If mPOID <> -1 Then
            ''
            Nav.CurrentPosition = GetRowIndex(mPOID)
            If Nav.CurrentPosition <> -1 Then
                dtpFilterFrom.Value = dsData.Tables("tblPurchaseOrder").DefaultView.Item(Nav.CurrentPosition)("PODate")
                FilterGrid()
                reSelectPODetails(dsData.Tables("tblPurchaseOrder").DefaultView.Item(Nav.CurrentPosition)("PurchaseOrderID"))
                ''Visual Effects
                resetButtons()
                btnOpen.Selected = True
                ''
                '' Add PO Detail Tab and show Details 
                If Not tcPurchaseOrder.TabPages.Contains(tpPurchaseOrderDetail) Then
                    tcPurchaseOrder.TabPages.Add(tpPurchaseOrderDetail)
                End If
                ''
                tcPurchaseOrder.SelectedIndex = 1
                '' 
                setState("BROWSE")
                If grdPO.Item("StatusID", grdPO.CurrentRow.Index).Value = 2 Then
					btnPost.Text = "UnPost"
					setState("POST")
                    '' setState("POST")
                Else
                    btnPost.Text = "Post"
                    CalculateTotal1()
                End If
            End If
			'  setState("EDIT")

        End If
        ''
        'blnGridHeaderClicked = False

        'If grdPO.Rows(Nav.CurrentPosition).Displayed Then
        '    grdPO.Rows(Nav.CurrentPosition).Selected = True
        'Else
        '' ajalen 3'air mosamma .............
        'End If
        ''grdPO.CurrentCell = grdPO.Item("PurchaseOrderID", grdPO.CurrentRow.Index).Value

        ''
        blnLoading = False

    End Sub

    Private Sub MakeDataAdapter()
        ''
        Dim strSqlAcctName As String
        Dim strSqlAcctNameList As String
        Dim strSqlVwEmployee As String
        ''
        daCurrencyRate = clsMr.BuildSqlAdapter("SELECT * FROM tblCurrencyRate", "tblCurrencyRate")
        daPurchaseOrder = clsMr.BuildSqlAdapter("SELECT * FROM tblPurchaseOrder WHERE Del = 0 AND BranchID = " & gIntBranchID, "tblPurchaseOrder")
		daPurchaseOrderDetail = clsMr.BuildSqlAdapter("SELECT * FROM tblPurchaseOrderDetail WHERE Del = 0", "tblPurchaseOrderDetail")
		clsMr.BuildSqlAdapter("SELECT SalesOrderDetailID,VehicleID FROM tblSalesOrderDetail WHERE Del = 0 and SalesOrderDetailID=-1", "tblSalesOrderDetail")
        daVoucher = clsMr.BuildSqlAdapter("SELECT * FROM tblVoucher WHERE Del=0 AND BranchID = " & gIntBranchID & " AND VoucherID=0", "tblVoucher")
        daVoucherDetail = clsMr.BuildSqlAdapter("SELECT * FROM tblVoucherDetail WHERE Del=0 AND  VoucherID=0", "tblVoucherDetail")
        ''
        clsMr.BuildSqlAdapter("SELECT * FROM  vwPurchaseOrder WHERE Del = 0", "vwPurchaseOrder")
        clsMr.BuildSqlAdapter("SELECT * FROM vwPurchaseOrderDetails WHERE Del=0 AND Del=1", "vwPurchaseOrderDetails")
        ''
        strSqlAcctName = "SELECT * FROM tblAccount WHERE AcctTypeID=1 AND BranchID = " & gIntBranchID
        strSqlAcctName += " ORDER BY AcctName"
        clsMr.BuildSqlAdapter(strSqlAcctName, "tblAcctName")
        ''
        strSqlAcctNameList = "SELECT * FROM tblAccount WHERE AcctTypeID=1 AND BranchID = " & gIntBranchID
        strSqlAcctNameList += " ORDER BY AcctName"
        clsMr.BuildSqlAdapter(strSqlAcctNameList, "tblListAcctName")
        clsMr.BuildSqlAdapter("SELECT StatusID, Status FROM tblStatus WHERE Del = 0", "tblStatus")
        ''
        strSqlVwEmployee = "SELECT EmployeeID, BranchID, Del, FName + ' ' + MName + ' ' + LName AS FullName "
        strSqlVwEmployee += " FROM tblEmployee WHERE Del = 0 ORDER BY FullName"
        clsMr.BuildSqlAdapter(strSqlVwEmployee, "vwEmployee")
        ''
        dsData = clsMr.getDataSet
    End Sub

    Private Sub FillComboBox()
        ''
        clsMr.FillComboBox("tblAcctName", cboFilterSupplier, "AcctName", "AcctID")
        clsMr.FillComboBox("tblListAcctName", cboAcctID, "AcctName", "AcctID")
        clsMr.FillComboBox("vwEmployee", cboEmployee, "FullName", "EmployeeID")
        clsMr.FillComboBox("tblStatus", cboStatus, "Status", "StatusID")
        ''
    End Sub

    Private Sub SetDataBinding()
        '' 
        clsMr.BindComboBox(Me.cboEmployee, "tblPurchaseOrder", "EmployeeID")
        clsMr.BindComboBox(Me.cboAcctID, "tblPurchaseOrder", "AcctID")
        clsMr.BindComboBox(Me.cboStatus, "tblPurchaseOrder", "StatusID")
        ''
        clsMr.BindTextBox(Me.txtPOID, "tblPurchaseOrder", "PurchaseOrderID")
        clsMr.BindTextBox(Me.txtPONum, "tblPurchaseOrder", "PONum")
        clsMr.BindTextBox(Me.txtDescription, "tblPurchaseOrder", "Description")
        clsMr.BindTextBox(Me.txtQuantity, "tblPurchaseOrder", "Quantity")
        clsMr.BindTextBox(Me.txtPOTotal, "tblPurchaseOrder", "POTotal")
        clsMr.BindTextBox(Me.txtInvoiceNum, "tblPurchaseOrder", "RefInvoiceNumber")
        clsMr.BindTextBox(Me.txtPOVehExp, "tblPurchaseOrder", "POVehExpense")
        clsMr.BindTextBox(Me.txtPOExp, "tblPurchaseOrder", "POExpense")
        clsMr.BindTextBox(Me.txtPORate, "tblPurchaseOrder", "PORate")
        ''
        clsMr.BindDateTimePicker(Me.dtpPODate, "tblPurchaseOrder", "PODate")
        clsMr.BindDateTimePicker(Me.dtpInvDate, "tblPurchaseOrder", "RefINvoiceDate")
        '
    End Sub

    Private Sub SetAutoNumber()
        clsMr.SetAutoNumber("tblPurchaseOrder", "PurchaseOrderID")
        clsMr.SetAutoNumber("tblCurrencyRate", "CurrRateID")
    End Sub

    Private Sub SetCurrencyManager()
        ''Nav.SetCurrency(Me, clsMr.getDataSet, "tblPurchaseOrder")
        Nav.SetCurrency(Me, dsData, "tblPurchaseOrder")
    End Sub

    Private Sub SetDefaultValue()
        ''
        clsMr.SetDefaults("tblPurchaseOrder", "BranchID", gIntBranchID, "RefINvoiceDate", Now.Date)
        clsMr.SetDefaults("tblPurchaseOrder", "PODate", Now.Date, "StatusID", 1)
        clsMr.SetDefaults("tblPurchaseOrder", "CreateDate", Now.Date, "CreateBy", gIntUserID, "Del", 0)
        ''
    End Sub

#End Region

#Region " UI _ Events . . . "
    ''
    ''PO LIST Events
    ''
    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
		''
		'' Demo Check...
		If DemoCount("tblPurchaseOrderDetail", "PurchaseOrderDetailID") = False Then
			Exit Sub
		End If

        ''Visual Effects
        resetButtons()
        btnNew.Selected = True
        ''
        AddMode = True
        If Not tcPurchaseOrder.TabPages.Contains(tpPurchaseOrderDetail) Then
            tcPurchaseOrder.TabPages.Add(tpPurchaseOrderDetail)
        End If
        grdPO.ClearSelection()
        dsData.Tables("vwPurchaseOrderDetails").Clear()
        tcPurchaseOrder.SelectedIndex = 1
        ''
        Nav.AddNew()
        InitializeNewRecValues()
        setState("NEW")
        checkValues()
        CalculateQuantity()
        ''SetPostOptions()
		''
	
	End Sub

    Private Sub btnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpen.Click
        ''
        ''Visual Effects
        resetButtons()
        btnOpen.Selected = True
        ' ''        
        'Dim i As Integer
        'Dim blnControl As Boolean =true
        ' ''
        'For i = 0 To grdPO.Rows.Count - 1
        '    ''If grdPO.Rows(i).Selected = False Then
        '    If grdPO.Rows.Item(i).Selected = False Then
        '        blnControl = False
        '    Else
        '        blnControl = True
        '        Exit For
        '        ''i = grdPO.Rows.Count + 1
        '    End If
        'Next
        ' ''
        'If blnControl = False Then
        '    MsgBox("Select Purchase Order to Open ")
        '    Exit Sub
        'Else
        '    btnOpen.Enabled = blnControl
        ''End If
        ''
        '' if grdPO has rows to Edit then Skip . . .
        ''
        If grdPO.Rows.Count <> 0 Then
            '' Add PO Detail Tab and show Details 
            'If Not tcPurchaseOrder.TabPages.Contains(tpPurchaseOrderDetail) Then
            '    tcPurchaseOrder.TabPages.Add(tpPurchaseOrderDetail)
            'End If
            ''
            PODetailTabPage("Open")
            ''
            Nav.CurrentPosition = GetRowIndex(grdPO.Item("PurchaseOrderID", grdPO.CurrentRow.Index).Value)
            reSelectPODetails(grdPO.Item("PurchaseOrderID", grdPO.CurrentRow.Index).Value)
            ''Nav.CurrentPosition = grdPO.CurrentRow.Cells("PurchaseOrderID").Value
            ''
            tcPurchaseOrder.SelectedIndex = 1
            '' 
            setState("BROWSE")
            If grdPO.Item("StatusID", grdPO.CurrentRow.Index).Value = 2 Then
                btnPost.Text = "UnPost"
                '' setState("POST")
            Else
                btnPost.Text = "Post"
                CalculateTotal1()
            End If
        End If
		' setState("EDIT")

        ''
        If btnPost.Text = "UnPost" Then
            ''
			'If (txtPOExp.Text = 0.0) Then
			'    btnExpense.Enabled = False
			'Else
			'    btnExpense.Enabled = True
			'End If
			' ''
			'If (txtPOVehExp.Text = 0.0) Then
			'    btnPOvehExpense.Enabled = False
			'Else
			'    btnPOvehExpense.Enabled = True
			'End If
			' ''
			setState("POST")

		
		End If
		''
		'blnGridHeaderClicked = False
		''
    End Sub

    Private Sub DeleteVoucher(ByVal strSqlStat As String)
        ' strSQL = "UPDATE tblVoucher SET Del = 1 WHERE (TrxID='" & txtPOID.Text & "' AND TrxType = '" & "PO" & "') OR ( TrxID= '" & txtPOID.Text & "' AND  TrxType = '" & "POExpense" & "')"
        Dim cmdDeleteVoucher As New SqlCommand(strSqlStat, conSql)

        Try
            conSql.Open()
            cmdDeleteVoucher.ExecuteNonQuery()
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        ''    
        ''Visual Effects
        resetButtons()
        btnDelete.Selected = True

        '' Dim cmd As New SqlCommand("UPDATE tblPurchaseOrder SET Del=1 WHERE PurchaseOrderID=" & grdPO.Item("PurchaseOrderID", grdPO.CurrentRow.Index).Value, conSql)
        If grdPO.Rows.Count <> 0 Then
            If grdPO.Item("StatusID", grdPO.CurrentRow.Index).Value = 2 Then
                MsgBox("Cannot Delete a posted purchase order!")
                Exit Sub
            End If
            If MsgBox("Are you sure you want to delete?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub

            ''delete vouchers

            strSQL = "UPDATE tblVoucher SET Del = 1 WHERE (TrxID='" & txtPOID.Text & "' AND TrxType = '" & "PO" & "') OR ( TrxID= '" & txtPOID.Text & "' AND  TrxType = '" & "POExpense" & "')"
            DeleteVoucher(strSQL)


            ''GetDetails
            dsData.Tables("vwPurchaseOrderDetails").Clear()
            dsData.Tables("tblPurchaseOrderDetail").Clear()

            clsMr.BuildSqlAdapter("SELECT * FROM vwPurchaseOrderDetails WHERE Del=0 AND PurchaseOrderID = " & txtPOID.Text, "vwPurchaseOrderDetails")
            daPurchaseOrderDetail = clsMr.BuildSqlAdapter("SELECT * FROM tblPurchaseOrderDetail WHERE Del = 0 AND PurchaseOrderID=" & txtPOID.Text, "tblPurchaseOrderDetail")

            Dim drs() As DataRow
            drs = dsData.Tables("vwPurchaseOrderDetails").Select("PurchaseOrderID=" & txtPOID.Text)

            ' dv.RowFilter = "PurchaseOrderID" = txtPOID.Text
            If drs.length <> 0 Then
                Dim dr As DataRow
                For Each dr In drs
                    strSQL = "UPDATE tblVoucher SET Del = 1 WHERE (TrxID='" & dr("PurchaseOrderDetailID") & "' AND TrxType = '" & "POVehExpense" & "') OR ( TrxID= '" & dr("PurchaseOrderDetailID") & "' AND  TrxType = '" & "Veh" & "')"
                    DeleteVoucher(strSQL)
                Next
            End If
            ''
            grdPO.Item("Del", grdPO.CurrentRow.Index).Value = 1
            ''Soft Delete of Purchase Order
            Dim cmdPO As New SqlCommand("UPDATE tblPurchaseOrder SET Del=1 WHERE PurchaseOrderID=" & grdPO.Item("PurchaseOrderID", grdPO.CurrentRow.Index).Value(), conSql)
            '' Dim cmd As New SqlCommand("UPDATE tblPurchaseOrder SET Del=1 WHERE PurchaseOrderID=" & grdPO.CurrentRow.Cells("PurchaseOrderID").Value, conSql)
            ''
            Try
                conSql.Open()
                cmdPO.ExecuteNonQuery()
                conSql.Close()
            Catch ex As Exception
                conSql.Close()
            End Try
            '' Soft Delete of Purchase Order Details
            Dim cmdPODetails As New SqlCommand("UPDATE tblPurchaseOrderDetail SET Del=1 WHERE PurchaseOrderID=" & grdPO.Item("PurchaseOrderID", grdPO.CurrentRow.Index).Value(), conSql)
            Try
                conSql.Open()
                cmdPODetails.ExecuteNonQuery()
                conSql.Close()
            Catch ex As Exception
                conSql.Close()
            End Try

            'strSQL = "UPDATE tblVoucher SET Del = 1 WHERE (TrxID='" & grdPODetails.Item("PurchaseOrderDetailID", grdPODetails.CurrentRow.Index).Value & "' AND TrxType = '" & "POVehExpense" & "') OR ( TrxID= '" & grdPODetails.Item("PurchaseOrderDetailID", grdPODetails.CurrentRow.Index).Value & "' AND  TrxType = '" & "Veh" & "')"
            'strSQL = "UPDATE tblVoucher SET Del = 1 WHERE (TrxID='" & grdPODetails.Item("PurchaseOrderDetailID", grdPODetails.CurrentRow.Index).Value & "' AND TrxType = '" & "POVehExpense" & "') OR ( TrxID= '" & grdPODetails.Item("PurchaseOrderDetailID", grdPODetails.CurrentRow.Index).Value & "' AND  TrxType = '" & "Veh" & "')"
            'DeleteVoucher(strSQL)
            '
            '
            'Dim cmdDeleteVoucher As New SqlCommand(strSQL, conSql)

            'Try
            '    conSql.Open()
            '    cmdDeleteVoucher.ExecuteNonQuery()
            '    conSql.Close()
            'Catch ex As Exception
            '    conSql.Close()
            'End Try
            'strSQL = "UPDATE tblVoucher SET Del = 1 WHERE (TrxID='" & grdPODetails.Item("PurchaseOrderDetailID", grdPODetails.CurrentRow.Index).Value & "' AND TrxType = '" & "POVehExpense" & "') OR ( TrxID= '" & grdPODetails.Item("PurchaseOrderDetailID", grdPODetails.CurrentRow.Index).Value & "' AND  TrxType = '" & "Veh" & "')"
            'cmdDeleteVoucher.CommandText = strSQL
            'cmdDeleteVoucher.Connection = conSql
            'Try
            '    conSql.Open()
            '    cmdDeleteVoucher.ExecuteNonQuery()
            '    conSql.Close()
            'Catch ex As Exception
            '    conSql.Close()
            'End Try
            ''
            '' Dim dv As DataView = dsdata.Tables("tblSalesOrderDetail").DefaultView
            dsData.Tables("vwPurchaseOrder").DefaultView(grdPO.CurrentRow.Index).Delete()
            '' 
            'tcPurchaseOrder.TabPages.Remove(tpPurchaseOrderDetail)
            'Nav.EndCurrentEdit()
            'daPurchaseOrder.Update(dsdata, "tblPurchaseOrder")
            ''" BranchID=" & gIntBranchID & " AND
            setState("BROWSE")
        End If
        ''
    End Sub

    Private Sub BtnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
    ''
    ''PO Details LIST Events
    ''
    Private Sub btnVehicle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVehicle.Click
        ''
        ''Visual Effects
        resetButtons()
        btnVehicle.Selected = True
        ''
        'If Me.btnSave.Enabled Then
        'If blnSaved = True Then
        '   Save()
        'Else
        '   MsgBox("You must save PO before adding a vehicle!", MsgBoxStyle.Critical, "CarzTrack")
        '   Exit Sub
        'End If

        'NB:14-Sept-07
        'If AddMode Then
        '   If lstDataErr.Items.Count <> 0 Then
        '      MsgBox("Please check errors before adding vehicles")
        '      Exit Sub
        '   Else
        '      Save()
        '   End If

        'End If
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        Dim frm As New frmPurchaseOrderVehicle(Me.txtPOID.Text)
        frm.ShowDialog()
        ''
        '' reselect Veh to reflect any change...
        ''
        reSelectPODetails(txtPOID.Text)
        dataChange = True
        ''
        '' recalculate Totals
        ''
        TotalExpenseAmount = Double.Parse(txtPOExp.Text)
        CalculateItemExpense()
        CalculateTotal1()
        setState("Vehicle")
        ''
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        ''
        ''Visual Effects
        resetButtons()
        btnSave.Selected = True
        ''
        Save()
        btnSave.Enabled = False
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ''
        ''Visual Effects
        resetButtons()
        btnCancel.Selected = True
        ''
        If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Try
                Nav.CancelCurrentEdit()
                If grdPODetails.RowCount = 0 Then
                    ClosePODetailTp()
                End If
                ''setState("BROWSE")
            Catch ex As Exception
                If grdPODetails.RowCount = 0 Then
                    ClosePODetailTp()
                End If
            End Try
            AddMode = False
			dataChange = False

			setState("Browse")
			btnCancel.Enabled = False
			btnSave.Enabled = False
        End If
    End Sub

    Private Sub btPost_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPost.Click
        ''
        '' Post
        '' 1 - Perform Save
        '' 2 - Create Vouchers
        '' 3 - Update Acct Balance
        '' Unpost
        '' 1 - Update Acct Balance
        '' 2 - UnPost Vouchers
        ''

        ''Visual Effects
        resetButtons()
        btnPost.Selected = True

        If grdPODetails.RowCount = 0 Then
            '' No vehicles purchased 
            '' Totals = 0
            ''
            MsgBox("Purchase vehicle (s). . . then Post ", MsgBoxStyle.ApplicationModal)
            Exit Sub
        End If
        ''
        Try
            If btnPost.Text = "Post" Then
                ''
                cboStatus.SelectedValue = 2
                ''
                Save()
                ''
                intAcctCurr = GetAcctCurrency(cboAcctID.SelectedValue)
                ''
                dsData.Tables("tblVoucher").Rows.Clear()
                daVoucher = clsMr.BuildSqlAdapter("SELECT * FROM  tblVoucher WHERE Del = 0  AND BranchID=" & gIntBranchID & " AND TrxID=" & txtPOID.Text & " AND TrxType='" & "PO" & "'", "tblVoucher")

                ''VoucherStatus 
                ''1 Open
                ''2 Close
                ''
                Dim dvVoucherExists As DataView = dsData.Tables("tblVoucher").DefaultView
                If dvVoucherExists.Count = 0 Then
                    CreateVoucher(2, PurchaseAccount, PurchaseAccountCurrency, cboAcctID.SelectedValue, intAcctCurr, 1)
                    CreateVoucher(1, cboAcctID.SelectedValue, intAcctCurr, CashAccount, CashAccountCurrency, 0)
                Else
                    dvVoucherExists(0)("VoucherStatusID") = 2
                    dvVoucherExists(1)("VoucherStatusID") = 1
                    ''
                    daVoucher.Update(dsData, "tblVoucher")

                    ''
                    DeleteVoucherDetail(dvVoucherExists(0)("VoucherID"))
                    DeleteVoucherDetail(dvVoucherExists(1)("VoucherID"))
                    ''
                    CreateVoucherDetail(dvVoucherExists(0)("VoucherID"), cboAcctID.SelectedValue, intAcctCurr, True)
                    CreateVoucherDetail(dvVoucherExists(0)("VoucherID"), PurchaseAccount, PurchaseAccountCurrency, False)
                    ''
                    CreateVoucherDetail(dvVoucherExists(1)("VoucherID"), CashAccount, CashAccountCurrency, True)
                    CreateVoucherDetail(dvVoucherExists(1)("VoucherID"), cboAcctID.SelectedValue, intAcctCurr, False)
                    ''
                End If

                UpdateAccountBalance(-GetExchangeValue(CurrID1, intAcctCurr, dtpPODate.Value, txtTotal.Text, txtPORate.Text), cboAcctID.SelectedValue)
                UpdateAccountBalance(GetExchangeValue(CurrID1, intAcctCurr, dtpPODate.Value, txtTotal.Text, txtPORate.Text), PurchaseAccount)

                'Dim drVoucher() As DataRow = dsdata.Tables("tblVoucher").Select("VoucherID=" & mVoucherExpenseID)
                'If drVoucher.Length <> 0 Then
                '    drVoucher(0)("VoucherStatusID") = 2
                '    daVoucher.Update(dsdata, "tblVoucher")

                '    ''exp voucher
                '    dsdata.Tables("tblVoucherDetail").Rows.Clear()
                '    daVoucherDetail = clsMr.BuildSqlAdapter("SELECT * FROM  tblVoucherDetail WHERE  VoucherID=" & mVoucherExpenseID, "tblVoucherDetail")
                '    ''
                '    Dim dvVoucherdetail As DataView = dsdata.Tables("tblVoucherDetail").DefaultView
                '    Dim i As Integer
                '    ''
                '    For i = 0 To dvVoucherdetail.Count - 1
                '        ''update account
                '        If dvVoucherdetail(i)("Debit") Is DBNull.Value Then
                '            UpdateAccountBalance(-GetExchangeValue(dvVoucherdetail(i)("CurrID"), GetAcctCurrency(dvVoucherdetail(i)("AcctID")), dvVoucherExists(1)("VoucherDate"), dvVoucherdetail(i)("Credit")), dvVoucherdetail(i)("AcctID"))
                '        Else
                '            UpdateAccountBalance(+GetExchangeValue(dvVoucherdetail(i)("CurrID"), GetAcctCurrency(dvVoucherdetail(i)("AcctID")), dvVoucherExists(1)("VoucherDate"), dvVoucherdetail(i)("Debit")), dvVoucherdetail(i)("AcctID"))
                '        End If
                '    Next
                'End If
                ''

                dsData.Tables("tblVoucher").Rows.Clear()
                daVoucher = clsMr.BuildSqlAdapter("SELECT * FROM  tblVoucher WHERE Del = 0  AND BranchID=" & gIntBranchID & " AND TrxID=" & txtPOID.Text & " AND TrxType='" & "POExpense" & "'", "tblVoucher")

                Dim drPOVoucherExpense() As DataRow = dsData.Tables("tblVoucher").Select("BranchID=" & gIntBranchID & " AND Del=0 AND TrxID=" & txtPOID.Text & " AND TrxType='POExpense'")
                If drPOVoucherExpense.Length <> 0 Then
                    UpdateVoucherExpense(2, drPOVoucherExpense)
                End If

                Dim dv As DataView = dsData.Tables("VwPurchaseOrderDetails").DefaultView
                Dim drv As DataRowView

                If dv.Count <> 0 Then
                    For Each drv In dv
                        dsData.Tables("tblVoucher").Rows.Clear()
                        daVoucher = clsMr.BuildSqlAdapter("SELECT * FROM  tblVoucher WHERE Del = 0  AND BranchID=" & gIntBranchID & " AND TrxID=" & drv("PurchaseOrderDetailID") & " AND TrxType='" & "POVehExpense" & "'", "tblVoucher")

                        Dim drVehPOVoucherExpense() As DataRow = dsData.Tables("tblVoucher").Select("BranchID=" & gIntBranchID & " AND Del=0 AND TrxID=" & drv("PurchaseOrderDetailID") & " AND TrxType='POVehExpense'")
                        If drVehPOVoucherExpense.Length <> 0 Then
                            UpdateVoucherExpense(2, drVehPOVoucherExpense)
                        End If
                    Next
                End If


                Nav.EndCurrentEdit()
                clsMr.Update(daPurchaseOrder, "tblPurchaseOrder")
                setState("POST")
                ''
            Else
                ''
                Try
                    If MsgBox("Are you sure you want to Unpost Voucher ", _
                    MsgBoxStyle.Critical + MsgBoxStyle.YesNo, "Warning") = MsgBoxResult.Yes Then
                        ''
                        mblnLoginSucces = False
                        mClsFrmLogin = New frmPassword
                        mClsFrmLogin.StartPosition = FormStartPosition.CenterScreen
                        mClsFrmLogin.ShowDialog()
                        If mblnLoginSucces Then
                            mClsFrmLogin.Close()
                        Else
                            Exit Sub
                        End If
                    Else
                        Exit Sub
                    End If
                    ''
                    cboStatus.SelectedValue = 3
                    ''
                    ''UnPost AcctBalance
                    ''
                    UpdateAccountBalance(GetExchangeValue(CurrID1, intAcctCurr, dtpPODate.Value, txtTotal.Text, txtPORate.Text), cboAcctID.SelectedValue)
                    UpdateAccountBalance(-GetExchangeValue(CurrID1, intAcctCurr, dtpPODate.Value, txtTotal.Text, txtPORate.Text), PurchaseAccount)
                    ''
                    ''UnPost Vouchers
                    ''
                    dsData.Tables("tblVoucher").Rows.Clear()
                    daVoucher = clsMr.BuildSqlAdapter("SELECT * FROM  tblVoucher WHERE Del = 0  AND BranchID=" & gIntBranchID & _
                    " AND TrxID=" & txtPOID.Text & " AND TrxType='" & "PO" & "'", "tblVoucher")
                    ''
                    Dim DvVoucherExists As DataView
                    DvVoucherExists = dsData.Tables("tblVoucher").DefaultView
                    ''
                    If DvVoucherExists.Count <> 0 Then
                        DvVoucherExists(0)("VoucherStatusID") = 3
                        ''
                        If DvVoucherExists(1)("VoucherStatusID") = 2 Then
                            DvVoucherExists(1)("VoucherStatusID") = 3
                            ''update account
                            dsData.Tables("tblVoucherDetail").Rows.Clear()
                            daVoucherDetail = clsMr.BuildSqlAdapter("SELECT * FROM  tblVoucherDetail WHERE  VoucherID=" & DvVoucherExists(1)("VoucherID"), "tblVoucherDetail")
                            Dim dvVoucherdetail As DataView = dsData.Tables("tblVoucherDetail").DefaultView
                            Dim i As Integer
                            For i = 0 To dvVoucherdetail.Count - 1
                                ''update account
                                If dvVoucherdetail(i)("Debit") Is DBNull.Value Then
                                    UpdateAccountBalance(+GetExchangeValue(dvVoucherdetail(i)("CurrID"), GetAcctCurrency(dvVoucherdetail(i)("AcctID")), DvVoucherExists(1)("VoucherDate"), dvVoucherdetail(i)("Credit")), dvVoucherdetail(i)("AcctID"))
                                Else
                                    UpdateAccountBalance(-GetExchangeValue(dvVoucherdetail(i)("CurrID"), GetAcctCurrency(dvVoucherdetail(i)("AcctID")), DvVoucherExists(1)("VoucherDate"), dvVoucherdetail(i)("Debit")), dvVoucherdetail(i)("AcctID"))
                                End If
                            Next
                        End If
                        ''
                        daVoucher.Update(dsData, "tblVoucher")
                    End If
                    cboStatus.SelectedValue = 3
                    ''
                    Save()
                    ''
                    dsData.Tables("tblVoucher").Rows.Clear()
                    daVoucher = clsMr.BuildSqlAdapter("SELECT * FROM  tblVoucher WHERE Del = 0  AND BranchID=" & gIntBranchID & " AND TrxID=" & txtPOID.Text & " AND TrxType='" & "POExpense" & "'", "tblVoucher")
                    Dim drPOVoucherExpense() As DataRow = dsData.Tables("tblVoucher").Select("BranchID=" & gIntBranchID & " AND Del=0 AND TrxID=" & txtPOID.Text & " AND TrxType='POExpense'")

                    If drPOVoucherExpense.Length <> 0 Then
                        UpdateVoucherExpense(3, drPOVoucherExpense)
                    End If

                    Dim dv As DataView = dsData.Tables("VwPurchaseOrderDetails").DefaultView
                    Dim drv As DataRowView

                    If dv.Count <> 0 Then
                        For Each drv In dv
                            dsData.Tables("tblVoucher").Rows.Clear()
                            daVoucher = clsMr.BuildSqlAdapter("SELECT * FROM  tblVoucher WHERE Del = 0  AND BranchID=" & gIntBranchID & " AND TrxID=" & drv("PurchaseOrderDetailID") & " AND TrxType='" & "POVehExpense" & "'", "tblVoucher")
                            Dim drVehPOVoucherExpense() As DataRow = dsData.Tables("tblVoucher").Select("BranchID=" & gIntBranchID & " AND Del=0 AND TrxID=" & drv("PurchaseOrderDetailID") & " AND TrxType='POVehExpense'")
                            If drVehPOVoucherExpense.Length <> 0 Then
                                UpdateVoucherExpense(3, drVehPOVoucherExpense)
                            End If
                        Next
                    End If

                    ''Nav.EndCurrentEdit()
                    ''clsMr.Update(daPurchaseOrder, "tblPurchaseOrder")
                    ''
                Catch ex As Exception
                    conSql.Close()
                End Try
				'  setState("BROWSE")
				setState("UNPOST")
            End If
            ''
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub UpdateVoucherExpense(ByVal pStatus As Integer, ByRef pDrVoucherExpense() As DataRow)
        ' Dim drVoucher() As DataRow = dsdata.Tables("tblVoucher").Select("VoucherID=" & mVoucherExpenseID)
        '  If drVoucher.Length <> 0 Then
        pDrVoucherExpense(0)("VoucherStatusID") = pStatus
        daVoucher.Update(dsData, "tblVoucher")

        ''exp voucher
        dsData.Tables("tblVoucherDetail").Rows.Clear()
        daVoucherDetail = clsMr.BuildSqlAdapter("SELECT * FROM  tblVoucherDetail WHERE  VoucherID=" & pDrVoucherExpense(0)("VoucherID"), "tblVoucherDetail")
        ''
        Dim dvVoucherdetail As DataView = dsData.Tables("tblVoucherDetail").DefaultView
        Dim i As Integer
        ''
        For i = 0 To dvVoucherdetail.Count - 1
            ''update account
            If pStatus = 2 Then
                If dvVoucherdetail(i)("Debit") Is DBNull.Value Then ''-->credit-->minus(cause post)
                    UpdateAccountBalance(-GetExchangeValue(dvVoucherdetail(i)("CurrID"), GetAcctCurrency(dvVoucherdetail(i)("AcctID")), pDrVoucherExpense(0)("VoucherDate"), dvVoucherdetail(i)("Credit")), dvVoucherdetail(i)("AcctID"))
                Else
                    UpdateAccountBalance(+GetExchangeValue(dvVoucherdetail(i)("CurrID"), GetAcctCurrency(dvVoucherdetail(i)("AcctID")), pDrVoucherExpense(0)("VoucherDate"), dvVoucherdetail(i)("Debit")), dvVoucherdetail(i)("AcctID"))
                End If
            Else
                If dvVoucherdetail(i)("Debit") Is DBNull.Value Then ''-->credit-->plus(cause unpost)
                    UpdateAccountBalance(+GetExchangeValue(dvVoucherdetail(i)("CurrID"), GetAcctCurrency(dvVoucherdetail(i)("AcctID")), pDrVoucherExpense(0)("VoucherDate"), dvVoucherdetail(i)("Credit")), dvVoucherdetail(i)("AcctID"))
                Else
                    UpdateAccountBalance(-GetExchangeValue(dvVoucherdetail(i)("CurrID"), GetAcctCurrency(dvVoucherdetail(i)("AcctID")), pDrVoucherExpense(0)("VoucherDate"), dvVoucherdetail(i)("Debit")), dvVoucherdetail(i)("AcctID"))
                End If
            End If
        Next
        ' End If
    End Sub

    Private Sub btnExpense_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExpense.Click
        ''
        ''Visual Effects
        resetButtons()
        btnExpense.Selected = True
        ''
        Dim frm As New frmExpenseV2(txtPOID.Text, "POExpense", txtPONum.Text)
        frm.ShowDialog()
        ''
        TotalExpenseAmount = frm.mTotalExpenseAmount
        mVoucherExpenseID = frm.mExpenseVoucherID
        ''
        txtPOExp.Text = TotalExpenseAmount
        If txtPOVehExp.Text = "" Then
            txtPOVehExp.Text = 0
        End If
        '  txtExTotal.Text = (Double.Parse(txtPOExp.Text) + Double.Parse(txtPOVehExp.Text)).ToString("#0.0#")
        txtExTotal.Text = (Double.Parse(txtPOExp.Text) + Double.Parse(txtPOVehExp.Text))
        txtExTotal.Text = GetUserDecimalFormat(txtExTotal.Text)
        CalculateItemExpense()
        '' CalculateItemExpense will call Save Function . . .
        CalculateQuantity()
		' setState("EXPENSE")

		If btnPost.Text = "Post" Then
			setState("UNPOST")
		Else
			setState("POST")
		End If

    End Sub

    Private Sub btnPOvehExpense_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPOvehExpense.Click
        ''
        ''Visual Effects
        resetButtons()
        btnPOvehExpense.Selected = True
        ''
        If grdPODetails.Rows.Count = 0 Then Exit Sub
        ''
        Dim PODetailID As Integer
        Dim VIN As String
        PODetailID = grdPODetails.Item("PurchaseOrderDetailID", grdPODetails.CurrentRow.Index).Value
        VIN = "PO Num:" & txtPONum.Text & " " & grdPODetails.Item("VIN", grdPODetails.CurrentRow.Index).Value

        ''Dim frm As New frmExpenseV2(grdPODetails.Item("PurchaseOrderDetailID", grdPODetails.CurrentRow.Index).Value, "POVehExpense", )
        Dim frm As New frmExpenseV2(PODetailID, "POVehExpense", VIN)
        frm.ShowDialog()
        ''
        TotalExpenseAmount = frm.mTotalExpenseAmount
        grdPODetails.Item("POVehExpense", grdPODetails.CurrentRow.Index).Value = TotalExpenseAmount
        ''
        CalculateItemExpense()
        '' CalculateItemExpense will call Save function 
        ''
		' setState("EXPENSE")

		If btnPost.Text = "Post" Then
			setState("UNPOST")
		Else
			setState("POST")
		End If

	End Sub

    Private Sub btnDetailClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetailClose.Click
        ''
        ''Visual Effects
        resetButtons()
        btnDetailClose.Selected = True
        ''
        'If grdPODetails.RowCount = 0 And dataChange = False Then
        '   Select Case MsgBox("Purchase Vehicle (s) before closing, inorder to Save a new PO", MsgBoxStyle.Critical + MsgBoxStyle.YesNo)
        '      ''
        '      '' Yes : Get a new vehicle
        '      '' No  : Delete the current PO that has no vehicles purchased
        '      ''
        '      Case MsgBoxResult.Yes
        '         btnVehicle.Enabled = True
        '         btnVehicle.PerformClick()
        '         Exit Sub
        '      Case MsgBoxResult.No
        '         ''
        '         Dim sqlcommand As New SqlCommand("UPDATE tblPurchaseOrder SET Del = 1 WHERE PurchaseOrderID = " & txtPOID.Text, conSql)
        '         Try
        '            conSql.Open()
        '            sqlcommand.ExecuteNonQuery()
        '            conSql.Close()
        '            ClosePODetailTp()
        '            reSelectPO()
        '            Exit Sub
        '            ''
        '         Catch ex As Exception
        '            ''
        '            conSql.Close()
        '            ClosePODetailTp()
        '            Exit Sub
        '         End Try
        '   End Select
        'End If
        ''
        If dataChange Then
            Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
                ''Select Case MsgBox("Close Form ?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
                Case MsgBoxResult.Yes
                    If lstDataErr.Items.Count <> 0 Then
                        MsgBox("Cannot save.Please check error list")
                        Exit Sub
                    Else
                        Save()
                        ClosePODetailTp()
                        setState("SAVE")
                    End If
                    ''
                Case MsgBoxResult.No
                    Try
                        Nav.CancelCurrentEdit()
                    Catch ex As Exception
                    End Try
                    ClosePODetailTp()
                    setState("Browse")
                    ''
                Case MsgBoxResult.Cancel
                    '   '' ignore close press..
                    '   '' do nothing...
            End Select
            ''
        Else
            ClosePODetailTp()
            setState("BROWSE")
        End If
        '' 
        CalculateQuantity()
        ''reSelectPO()
        ''grdPO.CurrentRow.Cells("Quantity").Value = txtQuantity.Text
    End Sub

    Private Sub txtDescription_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDescription.TextChanged
        ''
        'FilterGrid()
        dataChange = True
        If txtDescription.Text.Length > 75 Then
            MsgBox("Description cannot exceed 75 characters")
            txtDescription.Focus()
        End If
        ''
        checkValues()
    End Sub

    Private Sub CalculateItemExpense()

        If grdPODetails.Rows.Count = 0 Then Exit Sub
        If TotalExpenseAmount = 0 Or txtTotal.Text = 0 Or txtTotal.Text = "" Then Exit Sub

        Dim itemExpense As Double
        If txtPOExp.Text = "" Then
            txtPOExp.Text = 0
        End If
        itemExpense = (Double.Parse(txtTotal.Text) + Double.Parse(txtPOExp.Text)) / Double.Parse(txtTotal.Text)
        Dim x As Double
        Dim dblNetCost As Double
        Dim i As Integer

        'Dim drs() As DataRow = dsdata.Tables("vwPurchaseOrderDetails").Select("PurchaseOrderID=" & txtPOID.Text)
        For i = 0 To grdPODetails.Rows.Count - 1
            dsData.Tables("vwPurchaseOrderDetails").DefaultView.Item(i).Row.BeginEdit()
            'drs(i)("POExpense") = (itemExpense * drs(i)("Cost")) - drs(i)("Cost")
            dblNetCost = grdPODetails.Item("Cost", i).Value - grdPODetails.Item("Discount", i).Value
            x = (itemExpense * dblNetCost) - dblNetCost
            grdPODetails.Item("POExpense", i).Value = x
            dsData.Tables("vwPurchaseOrderDetails").DefaultView.Item(i).Row.EndEdit()
        Next
        ''update
        CalculateTotal1()
        ''update po
        Save()
        'txtPOExp.Text = TotalExpenseAmount

    End Sub

    Private Sub frmPassword_OnOkClick(ByVal pBlnPassed As Boolean, ByVal pIntUserID As Integer, ByVal pIntUserLevel As Integer) Handles mClsFrmLogin.OnOkClick
        ''
        If pBlnPassed = True Then
            gIntUserID = pIntUserID
            mblnLoginSucces = True
            gUserLevel = CType(pIntUserLevel, enmUserLevel)
        End If
    End Sub

    Private Sub btnDeleteVeh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteVeh.Click
        'If grdPODetails.Rows.Count = -1 Then Exit Sub

        'Dim dr As DataView
        'dr = dsdata.Tables("vwPurchaseOrderDetails").DefaultView

        'If MsgBox(" Are you sure you want to Remove Vehicle? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution") = MsgBoxResult.Yes Then

        '    Dim drDel() As DataRow
        '    drDel = dsdata.Tables("tblPurchaseOrderDetail").Select("PurchaseOrderDetailID = " & dr(grdPODetails.CurrentRow.Index)("PurchaseOrderDetailID"))
        '    If drDel.Length > 0 Then
        '        drDel(0).Delete()
        '        clsMr.Update(daPurchaseOrderDetail, "tblPurchaseOrderDetail")
        '    End If

        '    dsdata.Tables("vwSalesOrderDetail").DefaultView(grdPODetails.CurrentRow.Index).Delete()
        '    ' dsdata.Tables("vwVisitServices").Rows.Remove(dsdata.Tables("vwVisitServices").DefaultView(grdViewServices.CurrentRow.Index).Row)
        '    If grdPODetails.Rows.Count = 0 Then
        '        btnDeleteVeh.Enabled = False
        '    End If
        '    CalculateTotal()
        '    Nav.EndCurrentEdit()
        '    daPurchaseOrder.Update(dsdata, "tblPurchaseOrder")

        'End If
    End Sub

    Private Sub grdPO_RowsDefaultCellStyleChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grdPO.RowsDefaultCellStyleChanged
        ChangeColor()
    End Sub

    Private Sub btnRemoveVehicle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveVehicle.Click
        ''Visual Effects
        resetButtons()
        btnRemoveVehicle.Selected = True
        ''
        If grdPODetails.Rows.Count = 0 Then Exit Sub

        Dim dr As DataView
        dr = dsData.Tables("vwPurchaseOrderDetails").DefaultView

		If MsgBox(" Are you sure you want to Delete? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution") = MsgBoxResult.Yes Then

			dsData.Tables("tblSalesOrderDetail").Rows.Clear()
			clsMr.BuildSqlAdapter("SELECT SalesOrderDetailID,VehicleID FROM tblSalesOrderDetail WHERE Del = 0 and VehicleID=" & dr(grdPODetails.CurrentRow.Index)("PurchaseOrderDetailID"), "tblSalesOrderDetail")

			If dsData.Tables("tblSalesOrderDetail").Rows.Count <> 0 Then
				MsgBox("Cannot delete a sold Vehicle")
				Exit Sub
			End If

			Dim drDel() As DataRow
			drDel = dsData.Tables("tblPurchaseOrderDetail").Select("PurchaseOrderDetailID = " & dr(grdPODetails.CurrentRow.Index)("PurchaseOrderDetailID"))
			If drDel.Length > 0 Then
				drDel(0).Delete()
				clsMr.Update(daPurchaseOrderDetail, "tblPurchaseOrderDetail")
			End If

			dsData.Tables("vwPurchaseOrderDetails").DefaultView(grdPODetails.CurrentRow.Index).Delete()
			' dsdata.Tables("vwVisitServices").Rows.Remove(dsdata.Tables("vwVisitServices").DefaultView(grdViewServices.CurrentRow.Index).Row)
			If grdPODetails.Rows.Count = 0 Then
				btnRemoveVehicle.Enabled = False
			End If

			''

			TotalExpenseAmount = Me.txtPOExp.Text

			''recalculate totalcost
			Dim i As Integer
			Dim dblTotalCost As Double = 0

			For i = 0 To grdPODetails.Rows.Count - 1
				If (grdPODetails.Item("Cost", i).Value) Is DBNull.Value Then
					grdPODetails.Item("Cost", i).Value = 0
				End If

				If (grdPODetails.Item("Discount", i).Value) Is DBNull.Value Then
					grdPODetails.Item("Discount", i).Value = 0
				End If

				dblTotalCost += grdPODetails.Item("Cost", i).Value - grdPODetails.Item("Discount", i).Value
			Next
			'
			txtTotal.Text = dblTotalCost.ToString("#0.0#")

			''recalculate exp
			CalculateItemExpense()

			''recal financialfields
			CalculateTotal1()

			Nav.EndCurrentEdit()
			daPurchaseOrder.Update(dsData, "tblPurchaseOrder")
			checkValues()
		End If
    End Sub

    Private Sub txtPORate_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPORate.TextChanged
        checkValues()
    End Sub

    Private Sub BouncingHoverButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim frm As New frmInventory
        frm.Show()
    End Sub

    Private Sub btnPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreview.Click
        ''
        ''Visual Effects
        resetButtons()
        btnPreview.Selected = True
        ''
        If grdPO.Rows.Count = 0 Then Exit Sub

        Dim frm As New frmQuickReport
        Dim intAcctCurr As Integer = GetAcctCurrency(grdPO.Item("AcctID", grdPO.CurrentRow.Index).Value)
        If intAcctCurr = CurrID1 Then
            ''
            Windows.Forms.Cursor.Current = Cursors.WaitCursor()
            Dim rpt As New rptPurchaseOrderDetail
            Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table

            Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
            ''
            For Each tbCurrent In rpt.Database.Tables
                tliCurrent = tbCurrent.LogOnInfo
                ''
                With tliCurrent.ConnectionInfo
                    .ServerName = gStrServerName
                    .DatabaseName = gStrDataBaseName
                    .UserID = "" 'gStrUserName
                    .Password = "" 'gStrPassword
                End With

                tbCurrent.ApplyLogOnInfo(tliCurrent)
            Next tbCurrent

            rpt.SetParameterValue("POID", grdPO.Item("PurchaseOrderID", grdPO.CurrentRow.Index).Value)
            rpt.SetParameterValue("CurrSymbol", GetCurrencySymbol(intAcctCurr))
            frm.crvInstantViewer.ReportSource = rpt
            frm.crvInstantViewer.Refresh()
            frm.Show()

            frm.crvInstantViewer.DisplayToolbar = True
            Windows.Forms.Cursor.Current = Cursors.Default()

        Else
            ''
            Windows.Forms.Cursor.Current = Cursors.WaitCursor()
            Dim rpt As New rptPurchaseOrderDetailAcctCurr
            Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table

            Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
            ''
            For Each tbCurrent In rpt.Database.Tables
                tliCurrent = tbCurrent.LogOnInfo
                ''
                With tliCurrent.ConnectionInfo
                    .ServerName = gStrServerName
                    .DatabaseName = gStrDataBaseName
                    .UserID = "" 'gStrUserName
                    .Password = "" 'gStrPassword
                End With

                tbCurrent.ApplyLogOnInfo(tliCurrent)
            Next tbCurrent

            rpt.SetParameterValue("POID", grdPO.Item("PurchaseOrderID", grdPO.CurrentRow.Index).Value)
            rpt.SetParameterValue("CurrOperation", GetOperation(CurrID1, intAcctCurr, dtpPODate.Value))
            rpt.SetParameterValue("CurrSymbol", GetCurrencySymbol(intAcctCurr))
            frm.crvInstantViewer.ReportSource = rpt
            frm.crvInstantViewer.Refresh()
            frm.Show()

            frm.crvInstantViewer.DisplayToolbar = True
            Windows.Forms.Cursor.Current = Cursors.Default()


        End If

    End Sub

    Private Sub grdPO_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdPO.CellClick
        Nav.CurrentPosition = GetRowIndex(grdPO.Item("PurchaseOrderID", grdPO.CurrentRow.Index).Value)
    End Sub

#End Region

#Region " Check Values . . . "

    Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
        ''
        '' Show/Hide error list...
        If lstDataErr.Visible = True Then
            lstDataErr.Visible = False
        Else
            lstDataErr.Visible = True
            lstDataErr.Height = 100
            lstDataErr.BringToFront()
        End If
    End Sub

    Private Sub checkValues()
        ''
        If blnLoading = True Then Exit Sub
        ''
        dataChange = True
		btnCancel.Enabled = True
        '' clear entire list & start fresh check...
        ''
        lstDataErr.Items.Clear()
        Dim intErrCount As Int16 = 0

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' check Error - Mandatory Data Objects...
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''
        If Me.cboAcctID.SelectedIndex = -1 Then
            lstDataErr.Items.Add("Error: Missing Account Name")
            intErrCount += 1
        End If
        ''
        If Me.txtDescription.Text = "" Then
            lstDataErr.Items.Add("Error: Missing Description")
            intErrCount += 1
        End If
        If Me.txtPORate.Text = "" Then
            lstDataErr.Items.Add("Error: Missing Rate")
            intErrCount += 1
        End If
        'If Me.grdPODetails.RowCount = 0 Then
        '   lstDataErr.Items.Add("Error: Missing Vehicle")
        '   intErrCount += 1
        'End If
        ''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' Set appropriate controls based on errors check results...
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''
        If lstDataErr.Items.Count = 0 Then
            lstDataErr.Visible = False
            btnDataErr.Visible = False
        Else
            btnDataErr.Visible = True

        End If
        ''
        If dataChange And intErrCount = 0 Then
            btnSave.Enabled = True
            ''Can't Post at this stage
            ''New Purchase Order with no Vehicles
            ''btnPost.Enabled = True
        Else
            btnSave.Enabled = False
            ''btnPost.Enabled = False
        End If
    End Sub

    Private Sub cboAcctID_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboAcctID.KeyUp
        checkValues()
    End Sub

    Private Sub cboAcctID_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboAcctID.SelectedIndexChanged
        If blnLoading Then Exit Sub
        dataChange = True
        checkValues()

        If cboAcctID.SelectedIndex <> -1 Then
            lblAcctCurrency.Text = GetCurrencySymbol((GetAcctCurrency(cboAcctID.SelectedValue)))
        Else
            lblAcctCurrency.Text = ""
        End If
        If lblAcctCurrency.Text = lblCompCurr.Text Then
            txtPORate.Enabled = False
            txtPORate.Text = 1
        Else
            txtPORate.Enabled = True
            ' txtPORate.Text = ""
        End If
    End Sub

    Private Sub cboSalesPerson_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboEmployee.SelectedIndexChanged
        checkValues()
    End Sub

    Private Sub cboSalesPerson_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboEmployee.KeyUp
        checkValues()
    End Sub

    Private Sub txtPONum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPONum.TextChanged
        dataChange = True
    End Sub

    Private Sub tcPurchaseOrder_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tcPurchaseOrder.SelectedIndexChanged
        If tcPurchaseOrder.SelectedIndex = 1 Then
            dataChange = False
        End If
    End Sub

    Private Sub dtpPODate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpPODate.ValueChanged
        dataChange = True
    End Sub

#End Region

#Region " Grid Set Up . . . "
    ''
    Private Sub DrawGrid()
        ''
        '' Set up the data source
        ''
        grdPO.DataSource = dsData.Tables("vwPurchaseOrder").DefaultView
        grdPODetails.DataSource = dsData.Tables("vwPurchaseOrderDetails").DefaultView
        ''
        dsData.Tables("vwPurchaseOrder").DefaultView.AllowNew = False
        dsData.Tables("vwPurchaseOrderDetails").DefaultView.AllowNew = False
        ''
        ''Visual Effects
        ''Makes the Grid's header and the btnShowColPODetails of the same height
        ''
        grdPO.ColumnHeadersHeight = btnShowColPO.Height + 4
        grdPO.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        ''
        grdPODetails.ColumnHeadersHeight = btnShowColPODetails.Height + 4
        grdPODetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        ''
        RemoveGrdListItems("PO")
        RemoveGrdListItems("PODetails")

        ''LoadProfile(mStrSubKeyName & "\PO", Me.grdPO)
        ''LoadProfile(mStrSubKeyName & "\PODetails", Me.grdPODetails)
        ''
        ''
        '' Set up Grids'Columns Visibility 
        ''
        With grdPO
            ''
            .Columns("PONum").HeaderText = "PO Number"
            .Columns("PODate").HeaderText = "PO Date"
            .Columns("POExpense").HeaderText = "PO Expense"
            .Columns("POVehExpense").HeaderText = "PO Vehicle Expense"
            .Columns("totalExpenses").HeaderText = "Total Expenses"
            .Columns("POTotal").HeaderText = "PO Total"
            ''  
            .Columns("PurchaseOrderID").Visible = False
            .Columns("AcctID").Visible = False
            .Columns("Status").Visible = False
            .Columns("StatusID").Visible = False
            .Columns("Del").Visible = False
            .Columns("RefInvoiceNumber").Visible = False
            ''
            '.Columns("totalExpenses").DefaultCellStyle.Format = "#0.0#"
            '.Columns("POTotal").DefaultCellStyle.Format = "#0.0#"
            '.Columns("POExpense").DefaultCellStyle.Format = "#0.0#"
            '.Columns("POVehExpense").DefaultCellStyle.Format = "#0.0#"

            GetUserDecimalFormatGrid(grdPO.Columns("totalExpenses"))
            GetUserDecimalFormatGrid(grdPO.Columns("POTotal"))
            GetUserDecimalFormatGrid(grdPO.Columns("POExpense"))
            GetUserDecimalFormatGrid(grdPO.Columns("POVehExpense"))
        End With
        ''
        With grdPODetails

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '  Column                  Header             Visible            
            '
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' VIN                      x                  T
            '' VehYear                 Year                T
            '' VehMake                 Make                T
            '' VehModel                Model               T
            '' VehClass                Class               T
            '' VehEngine               Engine              T
            '' VehColor                Color               T
            '' Mileage                   x                 T
            '' AT                        x                 T
            '' AC                        x                 T
            '' Leather                  LTHR               T
            '' FourByFour               4x4                T
            '' TradeIn                   x                 F ''
            '' Cost                      x                 T
            '' Discount                  x                 T
            '' POExpense               PO Expense          T
            '' POVehExpense            PO Vehicle Expense  T
            '' VehExpense              Vehicle Expense     T
            '' SRP                       x                 T             
            '' Note                      x                 T
            '' Destination               x                 T
            '' Sold                      x                 T
            '' PlateNum                  x                 F
            '' VehColorNum               x                 F
            '' PurchaseOrderDetailID     x                 F
            '' PurchaseOrderID           x                 F
            '' ExtColorID                x                 F
            '' VehClassID                x                 F
            '' VehYearID                 x                 F
            '' VehMakeID                 x                 F
            '' VehModelID                x                 F
            '' DestinationID             x                 F
            '' Del                       x                 F
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            '' Totals   11 fields Headertext change    
            ''          12 Visibility False
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            '' fields must change their header text
            .Columns("VehYear").HeaderText = "Year"
            .Columns("VehMake").HeaderText = "Make"
            .Columns("VehModel").HeaderText = "Model"
            .Columns("VehClass").HeaderText = "Class"
            .Columns("VehEngine").HeaderText = "Engine"
            .Columns("VehColor").HeaderText = "Color"
            ''
            .Columns("Leather").HeaderText = "LTHR"
            .Columns("FourByFour").HeaderText = "4x4"
            ''
            .Columns("POExpense").HeaderText = "PO Expense"
            .Columns("POVehExpense").HeaderText = "PO Vehicle Expense"
            .Columns("VehExpense").HeaderText = "Vehicle Expense"

            '' fields must set visibility False
            ''	
            .Columns("TradeIn").Visible = False
            .Columns("PlateNum").Visible = False
            .Columns("VehColorNum").Visible = False
            .Columns("PurchaseOrderDetailID").Visible = False
            .Columns("PurchaseOrderID").Visible = False
            .Columns("ExtColorID").Visible = False
            .Columns("VehClassID").Visible = False
            .Columns("VehYearID").Visible = False
            .Columns("VehMakeID").Visible = False
            .Columns("VehModelID").Visible = False
            .Columns("DestinationID").Visible = False
            .Columns("Del").Visible = False
            ''
            '' Cell formant
            '.Columns("POExpense").DefaultCellStyle.Format = "#0.0#"
            '.Columns("Cost").DefaultCellStyle.Format = "#0.0#"
            '.Columns("POVehExpense").DefaultCellStyle.Format = "#0.0#"
            '.Columns("SRP").DefaultCellStyle.Format = "#0.0#"
            '.Columns("Discount").DefaultCellStyle.Format = "#0.0#"
            '' .Columns("POExpense").DefaultCellStyle.Format = "#0.0#"
            '.Columns("TotalExpense").DefaultCellStyle.Format = "#0.0#"
            '.Columns("TotalCost").DefaultCellStyle.Format = "#0.0#"
            '.Columns("Costacct").DefaultCellStyle.Format = "#0.0#"
            ''.Columns("SRPacct").DefaultCellStyle.Format = "#0.0#"
            '.Columns("DiscountAcct").DefaultCellStyle.Format = "#0.0#"

            GetUserDecimalFormatGrid(grdPODetails.Columns("POExpense"))
            GetUserDecimalFormatGrid(grdPODetails.Columns("Cost"))
            GetUserDecimalFormatGrid(grdPODetails.Columns("POVehExpense"))
            GetUserDecimalFormatGrid(grdPODetails.Columns("SRP"))
            GetUserDecimalFormatGrid(grdPODetails.Columns("Discount"))
            GetUserDecimalFormatGrid(grdPODetails.Columns("TotalExpense"))
            GetUserDecimalFormatGrid(grdPODetails.Columns("TotalCost"))
            GetUserDecimalFormatGrid(grdPODetails.Columns("Costacct"))
            GetUserDecimalFormatGrid(grdPODetails.Columns("DiscountAcct"))
        End With
        ''
        ''LOAD GRIDS WIDTH AND VISIBILITY VALUES FROM WIN.REGISTRY
        ''
        LoadProfile(mStrSubKeyName & "\PO", Me.grdPO)
        LoadProfile(mStrSubKeyName & "\PODetails", Me.grdPODetails)
    End Sub

    Private Sub RemoveGrdListItems(ByVal pPO As String)
        ''
        '' chkLstGridCol.SetItemCheckState(0, CheckState.Checked)
        ''
        Select Case (pPO)
            Case "PO"
                With chkLstGridCol
                    .Items.Remove("PONum")
                    .Items.Remove("AcctID")
                    .Items.Remove("StatusID")
                    .Items.Remove("RefInvoiceNumber")
                End With
                ''
            Case "PODetails"
                With chkLstGridCol
                    .Items.Remove("TradeIn")
                    .Items.Remove("PlateNum")
                    .Items.Remove("VehColorNum")
                    .Items.Remove("PurchaseOrderDetailID")
                    .Items.Remove("ExtColorID")
                    .Items.Remove("VehClassID")
                    .Items.Remove("VehYearID")
                    .Items.Remove("VehMakeID")
                    .Items.Remove("VehModelID")
                    .Items.Remove("DestinationID")
                End With
        End Select
        '' 
        Me.chkLstGridCol.Items.Remove("PurchaseOrderID")
        Me.chkLstGridCol.Items.Remove("Del")
    End Sub

    Private Sub FilterGrid()
        ''
        If blnLoading Then Exit Sub
        ''
        Dim strStatus As String
        Dim s As String = " True"
        ''
        s = "(PODate >= '" & Format(dtpFilterFrom.Value, "dd /MMM / yyyy") & "') AND (PODate <= '" & Format(dtpFilterTo.Value, "dd /MMM / yyyy") & "')"
        ''
        If txtFilterPONum.Text <> String.Empty Then
            Dim tn As Integer
            Try
                tn = Convert.ToInt32(txtFilterPONum.Text)
                s = s & " AND  (PONum = " & tn & ")"
            Catch ex As Exception
                txtFilterPONum.Text = ""
            End Try
        End If
        ''
        If cboFilterSupplier.SelectedIndex <> -1 Then
            s = s & " AND (AcctID = " & cboFilterSupplier.SelectedValue & ")"
        Else

            If cboFilterSupplier.Text <> "" And cboFilterSupplier.SelectedIndex = -1 Then
                s = s & " AND (AcctID = " & -1 & ")"
            End If
        End If
        ''
        If chkFilterPosted.Checked = False And chkFilterUnposted.Checked = False And chkFilterNew.Checked = False Then
            '' Do Nothing
            s = s & " AND StatusID=0"
        Else
            strStatus = " AND StatusID IN ("
            If chkFilterPosted.Checked = True Then
                strStatus = strStatus & "2"
            End If
            ''
            If chkFilterUnposted.Checked = True Then
                If strStatus = " AND StatusID IN (" Then
                    strStatus = strStatus & "3"
                Else
                    strStatus = strStatus & ",3"
                End If
            End If
            ''
            If chkFilterNew.Checked = True Then
                If strStatus = " AND StatusID IN (" Then
                    strStatus = strStatus & "1"
                Else
                    strStatus = strStatus & ",1"
                End If
            End If
            ''
            strStatus = strStatus & ")"
        End If
        s = s & strStatus
        ''
        dsData.Tables("vwPurchaseOrder").DefaultView.RowFilter = s
        ''
        ChangeColor()
    End Sub

    Private Sub CustomColumns(ByVal pStrGridName As String, ByRef pGrd As DataGridView)
        ''
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()
            mstrCurrentGridName = pStrGridName
            ''
            '' populate list with grid's dataSource fields...
            ''
            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In pGrd.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next

        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If

        'If pStrGridName = "PODetails" Then
        '	Dim p As Point
        '	p.X = btnShowColPODetails.Location.X + 100
        '	p.Y = btnShowColPODetails.Location.Y
        '	grpShowHideColumns.Location = p
        'End If

    End Sub

    Private Sub SaveSettings(ByRef pGrd As DataGridView)
        ''
        Dim i As Integer

        For i = 0 To Me.chkLstGridCol.Items.Count - 1
            pGrd.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
        Next

        ''
        Me.grpShowHideColumns.Visible = False
    End Sub
    ''
    '' Events - UI
    ''  	
    Private Sub btnShowColPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowColPO.Click
        CustomColumns("PO", grdPO)
        RemoveGrdListItems("PO")
    End Sub

    Private Sub btnShowColPODetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowColPODetails.Click
        CustomColumns("PODetails", grdPODetails)
        RemoveGrdListItems("PODetails")
    End Sub

    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
        ''
        Select Case mstrCurrentGridName
            Case "PO"
                SaveSettings(grdPO)
            Case "PODetails"
                SaveSettings(grdPODetails)
        End Select
    End Sub


    Private Sub frmPurchaseOrder_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        '' Save User Grid Setting...
        SaveProfile(mStrSubKeyName & "\PO", Me.grdPO)
        SaveProfile(mStrSubKeyName & "\PODetails", Me.grdPODetails)
    End Sub
    ''
    Private Sub dtpFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpFilterFrom.ValueChanged
        FilterGrid()
    End Sub

    Private Sub dtpTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpFilterTo.ValueChanged
        FilterGrid()
    End Sub

    Private Sub cboSupplier_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFilterSupplier.SelectedIndexChanged
        FilterGrid()
    End Sub

    Private Sub chkPosted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFilterPosted.CheckedChanged
        FilterGrid()
    End Sub

    Private Sub chkUnPosted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFilterUnposted.CheckedChanged
        FilterGrid()
    End Sub

    Private Sub chkNew_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFilterNew.CheckedChanged
        FilterGrid()
    End Sub

    Private Sub cboSupplier_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboFilterSupplier.KeyUp
        FilterGrid()
    End Sub

    Private Sub txtFilterPONum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFilterPONum.TextChanged
        FilterGrid()
    End Sub
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '' Prevent Edit When Grid's Header Clicked
    '' Edit enabled When row Clicked..........
    '' Once the grid Header Clicked, .........
    ''  - CoumnHeaderMouseClick Event issued..
    ''  - boolean variable blnGridHeaderClicked assigned True
    '' Then CellDoubleClick Event will be executed by default
    ''  - blnGridHeaderClicked assigned False.
    ''  - Edit Event ignored..........
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Private Sub grdPO_ColumnHeaderMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdPO.ColumnHeaderMouseClick
        ''MsgBox("Hello ... Im ColumnHeaderMouseClick :")
        blnGridHeaderClicked = True
        ChangeColor()
    End Sub

    Private Sub grdPO_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdPO.CellDoubleClick
        ''MsgBox("Hello ... Im CellDoubleClick :")
        If blnGridHeaderClicked = True Then
            blnGridHeaderClicked = False
            ChangeColor()
        Else
            btnOpen.PerformClick()
            ChangeColor()
            'Exit Sub
        End If
        'btnOpen.PerformClick()
    End Sub
    ''
    Private Sub grdPODetails_ColumnHeaderMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdPODetails.ColumnHeaderMouseClick
        blnGridHeaderClicked = True
        ChangeColor()
    End Sub

    Private Sub grdPODetails_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdPODetails.CellDoubleClick
        ''
		'If blnGridHeaderClicked = True Then
		'    blnGridHeaderClicked = False
		'    ChangeColor()
		'Else
		'    btnSave.Text = "Edit"
		'    btnSave.PerformClick()
		'    ChangeColor()
		'End If
		'ChangeColor()
    End Sub
    ''
    ''''Update Financial fields evey time New vehicle Purchased..
    ''
    Private Sub grdPODetails_RowsAdded(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewRowsAddedEventArgs) Handles grdPODetails.RowsAdded
        '' 
        If blnLoading = True Then
            Exit Sub
        End If
        checkValues()
        'UpdateFinancialFields()
        CalculateTotal1()
        CalculateQuantity()
        ChangeColor()
    End Sub

    Private Sub grdPO_CellEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdPO.CellEnter
        OpenDeleteOptions()
    End Sub

#End Region

#Region " Form Functions . . . "

    '''''''''''''''''''''''''''''''''''''
    '' This function add new entered rate
    '''''''''''''''''''''''''''''''''''''

    Private Sub AddRate(ByVal pRateValue As Double, Optional ByVal pFromCurrID As Integer = -1, Optional ByVal pToCurrID As Integer = -1, Optional ByVal pCurrOperation As String = "")
        Debug.WriteLine("addRate")
        Dim dr As DataRow
        dr = dsData.Tables("tblCurrencyRate").NewRow
        dr("FromCurrID") = pFromCurrID
        dr("ToCurrID") = pToCurrID
        dr("CurrRate") = pRateValue
        dr("CurrDate") = dtpPODate.Value
        dr("CurrOperation") = pCurrOperation
        dr("Del") = 0
        dsData.Tables("tblCurrencyRate").Rows.Add(dr)
        daCurrencyRate.Update(dsData.Tables("tblCurrencyRate").GetChanges)
        dsData.Tables("tblCurrencyRate").AcceptChanges()
    End Sub

    Public Sub New(Optional ByVal pPOID As Integer = -1)
        mPOID = pPOID
        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.
    End Sub

    Public Function GetRowIndex(ByVal pPOID As Long) As Integer
        ''
        Dim i As Integer
        ''
        For i = 0 To dsData.Tables("tblPurchaseOrder").DefaultView.Count - 1
            If dsData.Tables("tblPurchaseOrder").DefaultView.Item(i)("PurchaseOrderID") = pPOID Then
                Return i
            End If
        Next
        ''
        Return -1
    End Function

    Private Sub CalculateQuantity()
        '' How many Vehicle did current PurchaseOrder Include
        txtQuantity.Text = grdPODetails.RowCount()
        ' grdPO.CurrentRow.Cells("Quantity").Value = txtQuantity.Text
        ''tcPurchaseOrder.TabPages("tpPurchaseOrder").
    End Sub

    Private Sub GetCompanyCurrencies()
        ''
        CurrID1 = gIntCompanyCurrID
        Dim dRdr As SqlClient.SqlDataReader
        Dim cmdX As SqlClient.SqlCommand
        ''
        strSQL = "SELECT * FROM  dbo.tblCompany  WHERE dbo.tblCompany.companyID=  " & gIntCompanyID
        ''
        cmdX = New SqlClient.SqlCommand(strSQL, conSql)
        cmdX.CommandType = CommandType.Text

        conSql.Open()
        dRdr = cmdX.ExecuteReader()
        If dRdr.Read Then

            CurrID2 = dRdr("CurrID2")
        End If
        dRdr.Close()
        conSql.Close()
    End Sub

    Private Sub PopulateAccountsFixedRef()
        ''
        Dim cmdX As SqlClient.SqlCommand
        Dim dRdr As SqlClient.SqlDataReader
        ''
        strSQL = "SELECT dbo.tblAccountFixedRef.*, dbo.tblAccount.CurrencyID FROM dbo.tblAccountFixedRef INNER JOIN  dbo.tblAccount ON dbo.tblAccountFixedRef.AcctID = dbo.tblAccount.AcctID"

        cmdX = New SqlClient.SqlCommand(strSQL, conSql)
        cmdX.CommandType = CommandType.Text
        ''
        Try
            conSql.Open()
            dRdr = cmdX.ExecuteReader()
            ''
            While dRdr.Read()

                Select Case dRdr("AcctFixedID")
                    Case 1
                        If Not (dRdr("AcctID") Is DBNull.Value) Then
                            PurchaseAccount = dRdr("AcctID")
                            PurchaseAccountCurrency = dRdr("CurrencyID")
                        End If
                    Case 3
                        If Not (dRdr("AcctID") Is DBNull.Value) Then
                            CashAccount = dRdr("AcctID")
                            CashAccountCurrency = dRdr("CurrencyID")
                        End If
                End Select

            End While
            ''
            conSql.Close()
            ''
        Catch ex As Exception
            conSql.Close()
        End Try

    End Sub

    Private Sub CreateVoucher(ByVal pVoucherStatusID As Integer, ByVal pAcctDB As Long, ByVal pCurrAcctDb As Integer, ByVal pAcctCr As Long, ByVal pCurrAcctCr As Integer, ByVal pReadOnly As Int16)
        ''
        Dim drVoucher As DataRow = dsData.Tables("tblVoucher").NewRow
        ''
        drVoucher.BeginEdit()
        drVoucher("VoucherID") = clsMr.GetMaxNumber("VoucherID", "tblVoucher") + 1
        drVoucher("VoucherNumber") = clsMr.GetMaxNumber("Select Case WHEN MAX (VoucherNumber) is Null then 1 else Max (VoucherNumber) END FROM tblVoucher WHERE VoucherTypeID=1") + 1
        drVoucher("VoucherTypeID") = 1
        drVoucher("Del") = 0
        drVoucher("ReadOnly") = pReadOnly
        drVoucher("AutoGenerated") = 1
        drVoucher("VoucherDate") = Now.Date
        drVoucher("VoucherStatusID") = pVoucherStatusID
        drVoucher("TrxID") = txtPOID.Text
        drVoucher("BranchID") = gIntBranchID
        drVoucher("TrxType") = "PO"
        drVoucher("Description") = "Automatically generated voucher PO: " & txtPONum.Text
        ' drVoucher("CreateBy") = gIntUserID
        ' drVoucher("CreateDate") = Now.Date
        drVoucher.EndEdit()
        ''
        dsData.Tables("tblVoucher").Rows.Add(drVoucher)
        daVoucher.Update(dsData, "tblVoucher")
        ''
        CreateVoucherDetail(drVoucher("VoucherID"), pAcctDB, pCurrAcctDb, True)
        CreateVoucherDetail(drVoucher("VoucherID"), pAcctCr, pCurrAcctCr, False)
        ''
    End Sub

    Private Sub CreateVoucherDetail(ByVal pVoucherID As Long, ByVal pAcctID As Long, ByVal pCurrID As Integer, ByVal IsDebit As Boolean)
        ''
        ''CreateDetail 1
        Dim drDetail As DataRow = dsData.Tables("tblVoucherDetail").NewRow
        drDetail.BeginEdit()
        drDetail("VoucherDetailID") = clsMr.GetMaxNumber("VoucherDetailID", "tblVoucherDetail") + 1
        drDetail("VoucherID") = pVoucherID
        drDetail("AcctID") = pAcctID
        drDetail("CurrID") = pCurrID
        ''
        If IsDebit = True Then
            drDetail("Debit") = GetExchangeValue(CurrID1, drDetail("CurrID"), dtpPODate.Value, txtTotal.Text)
        Else
            drDetail("Credit") = GetExchangeValue(CurrID1, drDetail("CurrID"), dtpPODate.Value, txtTotal.Text)
        End If

        drDetail("Rate1") = GetRate(drDetail("CurrID"), CurrID1, dtpPODate.Value) 'txtPORate.Text
        drDetail("Rate2") = GetRate(drDetail("CurrID"), CurrID2, dtpPODate.Value)
        drDetail("Eq1") = txtTotal.Text 'GetExchangeValue(drDetail("CurrID"), CurrID1, dtpPODate.Value, txtTotal.Text)
        drDetail("Eq2") = GetExchangeValue(drDetail("CurrID"), CurrID2, dtpPODate.Value, txtTotal.Text)
        drDetail("Del") = 0
        drDetail.BeginEdit()
        ''
        dsData.Tables("tblVoucherDetail").Rows.Add(drDetail)
        daVoucherDetail.Update(dsData, "tblVoucherDetail")
    End Sub

    Private Sub DeleteVoucherDetail(ByRef pVoucherID As Integer)
        ''
        '' Dim dvVoucherDetail As DataRowView
        ''
        dsData.Tables("tblVoucherDetail").Rows.Clear()
        daVoucherDetail = clsMr.BuildSqlAdapter("SELECT * FROM  tblVoucherDetail WHERE  VoucherID=" & pVoucherID, "tblVoucherDetail")
        Dim i As Integer
        Dim count As Integer = dsData.Tables("tblVoucherDetail").DefaultView.Count
        For i = 0 To count - 1
            dsData.Tables("tblVoucherDetail").DefaultView.Item(count - 1 - i).Delete()
        Next
        daVoucherDetail.Update(dsData, "tblVoucherDetail")
    End Sub

    Private Sub UpdateAccountBalance(ByVal pAmount As Double, ByVal pAcctID As Long)
        ''
        Dim command As New SqlClient.SqlCommand
        command.CommandText = "SpUpdateAcctBalance"
        Try
            command.Connection = conSql
            command.CommandType = CommandType.StoredProcedure
            ''
            command.Parameters.AddWithValue("@balance", pAmount)
            command.Parameters.AddWithValue("@AcctID", pAcctID)
            ''
            conSql.Open()
            command.ExecuteNonQuery()
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try
    End Sub

    Private Sub CalculateTotal1()

        If grdPODetails.Rows.Count = 0 Then Exit Sub
        Dim i As Integer
        Dim dblPOExp As Double = 0
        Dim dblVehPOExp As Double = 0
        Dim dblTotalCost As Double = 0

        For i = 0 To grdPODetails.Rows.Count - 1
            If (grdPODetails.Item("Cost", i).Value) Is DBNull.Value Then
                grdPODetails.Item("Cost", i).Value = 0
            End If

            If (grdPODetails.Item("POExpense", i).Value) Is DBNull.Value Then
                grdPODetails.Item("POExpense", i).Value = 0
            End If
            If (grdPODetails.Item("Discount", i).Value) Is DBNull.Value Then
                grdPODetails.Item("Discount", i).Value = 0
            End If
            If (grdPODetails.Item("POVehExpense", i).Value) Is DBNull.Value Then
                grdPODetails.Item("POVehExpense", i).Value = 0
            End If
            If (grdPODetails.Item("VehExpense", i).Value) Is DBNull.Value Then
                grdPODetails.Item("VehExpense", i).Value = 0
            End If

            grdPODetails.Item("TotalCost", i).Value = (grdPODetails.Item("Cost", i).Value) + grdPODetails.Item("POExpense", i).Value + grdPODetails.Item("POVehExpense", i).Value - grdPODetails.Item("Discount", i).Value
            grdPODetails.Item("TotalExpense", i).Value = (grdPODetails.Item("VehExpense", i).Value) + grdPODetails.Item("POExpense", i).Value + grdPODetails.Item("POVehExpense", i).Value
            dblPOExp += grdPODetails.Item("POExpense", i).Value
            dblVehPOExp += grdPODetails.Item("POVehExpense", i).Value
            dblTotalCost += grdPODetails.Item("Cost", i).Value - grdPODetails.Item("Discount", i).Value
        Next
        ''
        ''For Save Process
        'txtPOExp.Text = (dblPOExp).ToString("#0.0#")
        'txtPOVehExp.Text = (dblVehPOExp).ToString("#0.0#")
        ' ''
        'txtTotal.Text = dblTotalCost.ToString("#0.0#")
        'txtExTotal.Text = (dblPOExp + dblVehPOExp).ToString("#0.0#")
        'txtPOTotal.Text = (dblTotalCost + dblPOExp + dblVehPOExp).ToString("#0.0#")
        txtPOExp.Text = (dblPOExp)
        txtPOExp.Text = GetUserDecimalFormat(txtPOExp.Text)

        txtPOVehExp.Text = (dblVehPOExp)
        txtPOVehExp.Text = GetUserDecimalFormat(txtPOVehExp.Text)
        ''
        txtTotal.Text = dblTotalCost
        txtTotal.Text = GetUserDecimalFormat(txtTotal.Text)

        txtExTotal.Text = (dblPOExp + dblVehPOExp)
        txtExTotal.Text = GetUserDecimalFormat(txtExTotal.Text)

        txtPOTotal.Text = (dblTotalCost + dblPOExp + dblVehPOExp)
        txtPOTotal.Text = GetUserDecimalFormat(txtPOTotal.Text)

    End Sub

    Private Sub CalculateTotal()
        '' txtPOExpense...
        If txtExTotal.Text.Length = 0 Then
            Me.txtExTotal.Text = 0
        End If
        ''
        If Me.txtPOTotal.Text.Length = 0 Then
            txtPOTotal.Text = 0
        End If
        ''
        txtTotal.Text = Double.Parse(txtPOTotal.Text) + Double.Parse(txtExTotal.Text)
    End Sub

    Private Sub UpdateFinancialFields()
        '' 
        '' Set up loop control
        '' Start up loop and get the  values of specific cells inorder to calculate the total
        '' update total to the specific fields
        ''
        Dim rowIndex As Integer = 0
        ''
        rowIndex = grdPODetails.RowCount
        Dim i As Integer
        For i = 0 To grdPODetails.Rows.Count - 1
            ''
            If (grdPODetails.Item("Cost", i).Value) Is DBNull.Value Then
                Cost = 0
            Else
                Cost = grdPODetails.Item("Cost", i).Value
            End If
            TotalCost = TotalCost + Cost
            ''
            If (grdPODetails.Item("POExpense", i).Value) Is DBNull.Value Then
                POExpense = 0
            Else
                POExpense = grdPODetails.Item("POExpense", i).Value
            End If
            TotalPOExpense = TotalExpense + POExpense
            ''
            If (grdPODetails.Item("POVehExpense", i).Value) Is DBNull.Value Then
                POVehExpense = 0
            Else
                POVehExpense = grdPODetails.Item("POVehExpense", i).Value
            End If
            ''
            TotalPOVehExpense = TotalExpenseAmount
            ''TotalPOVehExpense = TotalPOVehExpense + POVehExpense
            ''
        Next
        ''
        TotalExpense = TotalPOExpense + TotalPOVehExpense
        ''
        txtPOTotal.Text = TotalCost
        txtExTotal.Text = TotalExpense
        ''
        txtTotal.Text = (TotalCost + TotalExpense) - Decimal.Parse(txtDiscount.Text)
        ''
    End Sub

    Private Sub InitializeNewRecValues()
        ''
        cboAcctID.SelectedIndex = -1
        cboEmployee.SelectedValue = gIntUserID
        ''
        txtTotal.Text = 0
        txtExTotal.Text = 0
        txtPOTotal.Text = 0
        txtPOExp.Text = 0
        txtPOVehExp.Text = 0
        ''
        Dim lngMax As Long
        lngMax = clsMr.GetMaxNumber("SELECT CASE WHEN MAX(PONum)IS NULL THEN 1 " & _
        "ELSE (Max(PONum) + 1) END " & _
        "FROM tblPurchaseOrder WHERE BranchID=" & gIntBranchID)
        txtPONum.Text = lngMax.ToString
    End Sub

    Private Sub reSelectPO()
        ''
        dsData.Tables("vwPurchaseOrder").Clear()
        clsMr.BuildSqlAdapter("SELECT * FROM vwPurchaseOrder WHERE Del=0", "vwPurchaseOrder")
        ''clsMr.BuildSqlAdapter("SELECT * FROM vwPurchaseOrder WHERE Del=0 AND PurchaseOrderID = " & txtPOID.Text, "vwPurchaseOrder")
    End Sub

    Private Sub reSelectPODetails(ByVal pID As String)
        ''

        dsData.Tables("vwPurchaseOrderDetails").Clear()
        dsData.Tables("tblPurchaseOrderDetail").Clear()
        ''clsMr.BuildSqlAdapter("SELECT * FROM vwPurchaseOrderDetails WHERE Del=0 AND PurchaseOrderID = " & txtPOID.Text, "vwPurchaseOrderDetails")
        clsMr.BuildSqlAdapter("SELECT * FROM vwPurchaseOrderDetails WHERE Del=0 AND PurchaseOrderID = " & pID, "vwPurchaseOrderDetails")
        daPurchaseOrderDetail = clsMr.BuildSqlAdapter("SELECT * FROM tblPurchaseOrderDetail WHERE Del = 0 AND PurchaseOrderID=" & pID, "tblPurchaseOrderDetail")
        ''clsMr.BuildSqlAdapter("SELECT * FROM vwPurchaseOrderDetails WHERE Del=0 AND PurchaseOrderID = " & grdPO.CurrentRow.Cells("PurchaseOrderID").Value, "vwPurchaseOrderDetails")
        '' MsgBox("PO ID = " & txtPOID.Text)
    End Sub

    Private Sub setState(ByRef pStrMode As String)
        ''
        mStrCurrentState = UCase(pStrMode)
        '' 
        Select Case mStrCurrentState

            Case Is = "NEW"
                '' Tab 1 . . .
                btnNew.Enabled = False
                btnOpen.Enabled = False
                btnDelete.Enabled = False
                btnSave.Enabled = False
                '' Tab 2 . . . 
                btnVehicle.Enabled = False
                btnCancel.Enabled = True
                btnExpense.Enabled = False
                btnPOvehExpense.Enabled = False
                btnPost.Enabled = False
                grpDetails.Enabled = True
                ''
                Me.btnSave.Text = "Save"
                Me.btnPost.Text = "Post"

				'        Case Is = "EDIT"
				'            '' Tab 1 . . .
				'            btnNew.Enabled = False
				'            btnOpen.Enabled = False
				'            btnDelete.Enabled = False
				'btnSave.Enabled = False
				'            '' Tab 2 . . . 
				'            btnExpense.Enabled = True
				'            btnPOvehExpense.Enabled = True
				'            btnVehicle.Enabled = True
				'            btnCancel.Enabled = False
				'            btnPost.Enabled = True
				'            grpDetails.Enabled = True
				'            btnSave.Text = "Save"
				'            ' grpDetails.Enabled = True

            Case Is = "BROWSE"
                '' DELETE & CANCEL
                ''
                '' Tab 1 . . .
                btnNew.Enabled = True
                btnOpen.Enabled = True
                btnDelete.Enabled = True
                ''btnSave.Enabled = False
				btnSave.Enabled = False
                '' Tab 2 . . . 
             
				btnCancel.Enabled = False
                btnExpense.Enabled = True
                btnPOvehExpense.Enabled = True
                ''btnPost.Enabled = True
                btnPost.Enabled = True
                grpDetails.Enabled = True
                ''
                ''
                ''Me.btnSave.Text = "Edit"
				'  btnPost.Text = "Post"
                ''SetPostOptions()
				btnVehicle.Enabled = True
				btnRemoveVehicle.Enabled = True
            Case Is = "SAVE"
                '' Tab 1 . . .
                btnNew.Enabled = True
                btnOpen.Enabled = True
                btnDelete.Enabled = True
                '' Tab 2 . . . 
                btnCancel.Enabled = False
                ''17 Sep 2007
                ''btnVehicle.Enabled = True
                ''btnPOvehExpense.Enabled = True
                ''btnExpense.Enabled = True
                btnVehicle.Enabled = False
                btnPOvehExpense.Enabled = False
                btnExpense.Enabled = False
                btnPost.Enabled = False
                grpDetails.Enabled = False
                ''

            Case Is = "VEHICLE"
                '' Tab 1 . . .
                btnNew.Enabled = False
                btnOpen.Enabled = False
                btnDelete.Enabled = False
                '' Tab 2 . . . 
                btnVehicle.Enabled = True
                btnCancel.Enabled = True
                btnExpense.Enabled = True
                btnPOvehExpense.Enabled = True
                btnSave.Enabled = True
                btnPost.Enabled = True
                btnPost.Text = "Post"
                btnSave.Text = "Save"
                ''

            Case Is = "EXPENSE"
                '' Tab 1 . . .
                btnNew.Enabled = True
                btnOpen.Enabled = True
                btnDelete.Enabled = True
                '' Tab 2 . . . 
                btnVehicle.Enabled = True
                btnCancel.Enabled = True
                btnExpense.Enabled = True
                btnPOvehExpense.Enabled = True
                btnPost.Enabled = True
                btnSave.Text = "Save"
                ''
            Case Is = "POST"
                '' Tab 1 . . .
                btnNew.Enabled = False
                btnOpen.Enabled = False
                btnDelete.Enabled = False
                '' Tab 2 . . . 
                btnVehicle.Enabled = False
                btnSave.Enabled = False
                btnCancel.Enabled = False
                btnPost.Enabled = True
                grpDetails.Enabled = False
                btnRemoveVehicle.Enabled = False
				btnPost.Text = "UnPost"

				If txtPOExp.Text = String.Empty Then
					txtPOExp.Text = 0
				End If
				If txtPOVehExp.Text = String.Empty Then
					txtPOVehExp.Text = 0
				End If

				If txtPOExp.Text = 0 Then
					btnExpense.Enabled = False
				Else
					btnExpense.Enabled = True
				End If

				If txtPOVehExp.Text = 0 Then
					btnPOvehExpense.Enabled = False
				Else
					btnPOvehExpense.Enabled = True
				End If

            Case Is = "UNPOST"
                Me.btnNew.Enabled = True
                Me.btnOpen.Enabled = True
                Me.btnSave.Enabled = False
                ''
                Me.btnCancel.Enabled = False
				Me.btnVehicle.Enabled = True
                Me.btnPost.Enabled = True
                Me.btnPost.Text = "Post"
				Me.btnDeleteVeh.Enabled = True
				btnRemoveVehicle.Enabled = True
                ''
        End Select

    End Sub

    Private Sub SavePODetail1()
        Dim intCounter As Integer

        'Dim drAdd As DataRow
        Dim drUpdate() As DataRow
        Dim dt As DataTable

        ''check if  rows are changed
        dt = dsData.Tables("vwPurchaseOrderDetails").GetChanges(DataRowState.Modified)

        If Not (dt Is Nothing) Then

            For intCounter = 0 To dt.Rows.Count - 1
                drUpdate = dsData.Tables("tblPurchaseOrderDetail").Select("PurchaseOrderDetailID=" & dt.Rows(intCounter)("PurchaseOrderDetailID"))
                drUpdate(0).BeginEdit()
                drUpdate(0)("POExpense") = dt.Rows(intCounter)("POExpense")
                drUpdate(0)("POVehExpense") = dt.Rows(intCounter)("POVehExpense")
                drUpdate(0).EndEdit()
            Next
        End If

        dt = dsData.Tables("tblPurchaseOrderDetail").GetChanges
        If Not (dt Is Nothing) Then
            daPurchaseOrderDetail.Update(dt)
            dsData.Tables("tblPurchaseOrderDetail").AcceptChanges()
            dsData.Tables("vwPurchaseOrderDetails").AcceptChanges()
        End If
        dsData.EnforceConstraints = True

    End Sub

    Private Sub SetPostOptions()
        ''
        If cboStatus.SelectedValue = 1 Or cboStatus.SelectedValue = 3 Then
            btnPost.Text = "Post"
            grpDetails.Enabled = True
            btnVehicle.Enabled = True
            btnRemoveVehicle.Enabled = True
            btnCancel.Enabled = True
        Else
            btnPost.Text = "UnPost"
            grpDetails.Enabled = False
            btnSave.Enabled = False
            btnVehicle.Enabled = False
            btnCancel.Enabled = False
            btnRemoveVehicle.Enabled = False
            'btnExpense.Enabled = False
            'btnPOvehExpense.Enabled = False
            ''btnRemoveVehicle.Enabled = False
        End If
    End Sub

    Private Sub OpenDeleteOptions()
        ''
        If grdPO.Rows.Count = 0 Then
            btnDelete.Enabled = False
            btnOpen.Enabled = False
            Exit Sub
        End If
        ''
        If grdPO.CurrentRow Is Nothing Then
            Exit Sub
        End If
        ''
        If grdPO.Item("StatusID", grdPO.CurrentRow.Index).Value = 2 Then
            btnDelete.Enabled = False
        Else
            btnDelete.Enabled = True
        End If
        ''
    End Sub

    Private Sub ClosePODetailTp()
        If tcPurchaseOrder.TabPages.Contains(tpPurchaseOrderDetail) Then
            tcPurchaseOrder.TabPages.Remove(tpPurchaseOrderDetail)
        End If
        tcPurchaseOrder.SelectedIndex = 0
    End Sub

    Public Sub PODetailTabPage(ByVal strState As String)
        '' Open or close PODetailTapPage According to State
        Select Case strState
            ''
            Case "Open"
                If Not tcPurchaseOrder.TabPages.Contains(tpPurchaseOrderDetail) Then
                    tcPurchaseOrder.TabPages.Add(tpPurchaseOrderDetail)
                End If
            Case "Close"
                If tcPurchaseOrder.TabPages.Contains(tpPurchaseOrderDetail) Then
                    tcPurchaseOrder.TabPages.Remove(tpPurchaseOrderDetail)
                End If
                tcPurchaseOrder.SelectedIndex = 0
        End Select
    End Sub

    Private Sub Save()
        ''
        'If btnSave.Text = "Edit" Then
        '	setState("EDIT")
        '	SetPostOptions()
        '	btnSave.Text = "Save"
        '	Exit Sub
        'End If
        ''
        ''CalculateQuantity()
        Nav.EndCurrentEdit()
        daPurchaseOrder.Update(dsData, "tblPurchaseOrder")
        SavePODetail1()
        ''
        If AddMode Then
            '' add new record to vwPurchaseOrder
            Dim dr As DataRow = dsData.Tables("vwPurchaseOrder").NewRow
            UpdateViewPurchaseOrder(dr)
            dsData.Tables("vwPurchaseOrder").Rows.Add(dr)
        Else
            ''update edit record to vwPurchaseOrder
            Dim drs() As DataRow = dsData.Tables("vwPurchaseOrder").Select("PurchaseOrderID=" & txtPOID.Text)
            If drs.Length <> 0 Then
                UpdateViewPurchaseOrder(drs(0))
            End If
        End If

        ''
        '' chk if entered rate is the latest else insert as new...
        '' 
        If lblAcctCurrency.Text <> lblCompCurr.Text Then
            intAcctCurr = GetAcctCurrency(cboAcctID.SelectedValue)
            If txtPORate.Text <> GetRate(intAcctCurr, CurrID1, dtpPODate.Value) Then
                AddRate(txtPORate.Text, intAcctCurr, CurrID1, GetOperation(intAcctCurr, CurrID1, dtpPODate.Value))
                AddRate(txtPORate.Text, CurrID1, intAcctCurr, GetOperation(CurrID1, intAcctCurr, dtpPODate.Value))
            End If
        End If

        ''
        AddMode = False
        dataChange = False
        'setState("SAVE")
        'btnSave.Text = "Edit"
		setState("BROWSE")
        ''
    End Sub

    Private Sub UpdateViewPurchaseOrder(ByRef pDr As DataRow)
        ''
        pDr("PONum") = txtPONum.Text
        pDr("PODate") = dtpPODate.Value
        pDr("Supplier") = cboAcctID.Text
        pDr("Description") = txtDescription.Text
        pDr("Quantity") = txtQuantity.Text
        pDr("POExpense") = TotalPOExpense
        pDr("POVehExpense") = TotalPOVehExpense
        ''
        pDr("POTotal") = txtPOTotal.Text
        pDr("Status") = cboStatus.Text
        pDr("RefInvoiceNumber") = txtInvoiceNum.Text
        pDr("PurchaseOrderID") = txtPOID.Text
        pDr("AcctID") = cboAcctID.SelectedValue
        pDr("StatusID") = cboStatus.SelectedValue
        pDr("Del") = dsData.Tables("tblPurchaseOrder").DefaultView.Item(Nav.CurrentPosition)("Del")
        ''pDr("EmployeeID") = cboSalesPerson.SelectedValue
    End Sub

    Private Sub ChangeColor()
        ''change color of visits according to status
        Dim i As Integer
        Dim intStatus As Integer
        For i = 0 To dsdata.Tables("vwPurchaseOrder").DefaultView.Count - 1
            intStatus = dsdata.Tables("vwPurchaseOrder").DefaultView.Item(i)("StatusID")

            Select Case intStatus
                Case 1
                    grdPO.Rows(i).DefaultCellStyle.BackColor = Color.LightYellow

                Case 2
                    grdPO.Rows(i).DefaultCellStyle.BackColor = Color.LightGray

                Case 3
                    grdPO.Rows(i).DefaultCellStyle.BackColor = Color.MistyRose

            End Select
        Next
    End Sub

    Private Sub resetButtons()
        ''
        '' hide Main btns... 
        btnNew.Selected = False
        btnOpen.Selected = False
        btnDelete.Selected = False
        btnVehicle.Selected = False
        btnSave.Selected = False
        btnCancel.Selected = False
        btnPost.Selected = False
        btnPOvehExpense.Selected = False
        btnExpense.Selected = False
        btnDetailClose.Selected = False
        btnRemoveVehicle.Selected = False
        btnPreview.Selected = False

        '' refresh btns.. after selection

        btnNew.Refresh()
        btnOpen.Refresh()
        btnDelete.Refresh()
        btnVehicle.Refresh()
        btnSave.Refresh()
        btnCancel.Refresh()
        btnPost.Refresh()
        btnPOvehExpense.Refresh()
        btnExpense.Refresh()
        btnDetailClose.Refresh()
        btnRemoveVehicle.Refresh()
        btnPreview.Refresh()
    End Sub

    Private Sub GetAccount()
        ''
        'ACCT TYPE IDee :) eees 
        '1	Supplier	
        '2	Customer	
        '3	Bank	
        ''
        Dim frm As New frmAccountGet(1)
        frm.ShowDialog()
        ''
        cboAcctID.SelectedValue = frm.CboValue
    End Sub

#End Region

	Private Sub grdPODetails_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdPODetails.DoubleClick
		If grdPODetails.Rows.Count = 0 Then Exit Sub
		''
		Dim frm As New frmPurchaseOrderVehicle(Me.txtPOID.Text, grdPODetails.Item("PurchaseOrderDetailID", grdPODetails.CurrentRow.Index).Value)
		frm.ShowDialog()
		''
		'' reselect Veh to reflect any change...
		''
		reSelectPODetails(txtPOID.Text)
		dataChange = True
		''
		'' recalculate Totals
		''
		TotalExpenseAmount = Double.Parse(txtPOExp.Text)
		CalculateItemExpense()
		CalculateTotal1()
		setState("Vehicle")
	End Sub

	Private Sub txtInvoiceNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInvoiceNum.TextChanged
		checkValues()
	End Sub

	Private Sub dtpInvDate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpInvDate.ValueChanged
		checkValues()
	End Sub

    'Private Sub frmPurchaseOrder_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
    '    ''
    '    If e.KeyCode = Keys.F3 Then
    '        GetAccount()
    '    End If
    'End Sub

    Private Sub cboAcctID_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboAcctID.KeyDown
        ''
        If e.KeyCode = Keys.F3 Then
            GetAccount()
        End If
    End Sub

End Class
