Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmServiceGet

#Region "Form-Declaration"
	''
	'' Declaration...
	''
	Private dsdata As DataSet
	Private clsMr As ClsMain
	''
	Private blnLoading As Boolean
	Private mStrTableName As String
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\GetService\Settings"
	Private mstrCurrentGridNameService As String
	Dim daService As SqlClient.SqlDataAdapter
	Public arr(1) As Integer
	Private mID As Integer = -1

	'Dim intCat As Integer = 0
	Dim strServices As String = ""
	Dim mstrCurrentGridName As String
	Private LabWorkCatID As Integer
	Private TypicalserviceCatID As Integer
	Dim mDv As DataView
	Private mCatID As Integer
#End Region

#Region "Form-Initialisation"

    Public Sub New(ByRef pDv As DataView, Optional ByVal pCatID As Integer = -1, Optional ByVal pID As Integer = 0) ', Optional ByVal pstrTableName As String = "", Optional ByVal pView As String = "")

        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        ''
        mID = pID
        mDv = pDv
        mCatID = pCatID
        ''
        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

    Private Sub MakeDataAdapter()
        '' set connection
        clsMr = New ClsMain(conSql)
        Dim strCat As String = ""
        If mCatID <> -1 Then
            strCat = " AND ServiceCatID=" & mCatID
        End If
        ''
        '' set the structure of the tables in the DataSet
        ''
        If mDv.Count <> 0 Then
            Dim drv As DataRowView
            For Each drv In mDv
                If strServices = "" Then
                    strServices = "(" & drv("ServiceID")
                Else
                    strServices = strServices & "," & drv("ServiceID")
                End If
            Next
            ''
            strServices = strServices & ")"
            ''
            clsMr.BuildSqlAdapter("SELECT  *  FROM vwGetService WHERE Del=0" & strCat & " and Not ServiceID IN " & strServices, "tblService")
            clsMr.BuildSqlAdapter("SELECT  ServiceID,ServiceName,ServiceCode  FROM tblService WHERE Del=0" & strCat & " and NOT ServiceID IN " & strServices, "ServiceSearch")
        Else
            ''
            clsMr.BuildSqlAdapter("SELECT  * FROM vwGetService WHERE Del=0" & strCat, "tblService")
            clsMr.BuildSqlAdapter("SELECT  ServiceID,ServiceName,ServiceCode  FROM tblService WHERE Del=0 " & strCat, "ServiceSearch")
        End If
        ''
        clsMr.BuildSqlAdapter("SELECT  SubCatID, SubCatType FROM tblServiceSubCategory WHERE Del=0", "tblServiceSubCategory")
        clsMr.BuildSqlAdapter("SELECT  ServiceTypeID,ServiceType FROM tblServiceType WHERE Del=0 ", "tblServiceType")
        ''
        dsdata = clsMr.getDataSet
    End Sub

    Private Sub FillComboBox()
        ''
        clsMr.FillComboBox("ServiceSearch", cboService, "ServiceName", "ServiceID")
        clsMr.FillComboBox("tblServiceSubCategory", cboSubCat, "SubCatType", "SubCatID")
        clsMr.FillComboBox("tblServiceType", cboType, "ServiceType", "ServiceTypeID")
    End Sub

#End Region

#Region "Form-Load"

	Private Sub frmGetService_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		SaveProfile(mStrSubKeyName, Me.grdServices)

    End Sub

    Private Sub frmServiceGet_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

	Private Sub frmGetService_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''
        clsMr = New ClsMain(conSql)
        'populateAccountsFixedRef()
		''
		blnLoading = True
		MakeDataAdapter()
		FillComboBox()
		blnLoading = False
        ''
		DrawGrid()
        ''
		cboService.SelectedIndex = -1
		cboSubCat.SelectedIndex = -1
		cboType.SelectedIndex = -1
    End Sub

#End Region

#Region "Form-UI/Methods"
	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
		Me.Close()
	End Sub
	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
		If grdServices.Rows.Count = 0 Then Exit Sub
		Dim i As Integer

		Dim dv As DataGridViewSelectedRowCollection = grdServices.SelectedRows

		ReDim arr(dv.Count)
		For i = 0 To dv.Count - 1
			Dim drv As DataGridViewRow = dv(i)
			arr(i) = dv(i).Cells("ServiceID").Value
		Next
		Me.Close()
	End Sub

#End Region

#Region "Form-Functions"
	Sub populateAccountsFixedRef()
		'' get'm from tbl...
		Dim cmdX As SqlClient.SqlCommand
		Dim dRdr As SqlClient.SqlDataReader
		''
		' Dim intItemStockID As Integer
		''
		StrSql = "SELECT * FROM dbo.tblSystemAccountsXRef"

		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text
		''
		'' go...
		Try
			conSql.Open()
			dRdr = cmdX.ExecuteReader()
			''
			While dRdr.Read()
				''
				''
				Select Case dRdr("SystemAcctXRefID")
					Case 8
						If Not (dRdr("RefID") Is DBNull.Value) Then
							LabWorkCatID = dRdr("RefID")

						End If
					Case 9
						If Not (dRdr("RefID") Is DBNull.Value) Then
							TypicalServiceCatID = dRdr("RefID")

						End If

				End Select

			End While

			conSql.Close()

		Catch ex As Exception
			''
			conSql.Close()

		End Try
	End Sub
	Private Sub DrawGrid()
		'' grdServices
		grdServices.DataSource = dsdata.Tables("tblService").DefaultView
		dsdata.Tables("tblService").DefaultView.AllowNew = False
		LoadProfile(mStrSubKeyName & "\Services", Me.grdServices)
		grdServices.ColumnHeadersHeight = btnShowCol.Height + 2
		grdServices.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		With grdServices

			.Columns("Del").Visible = False
			.Columns("ServiceCatID").Visible = False
			.Columns("ServiceSubCatID").Visible = False
			.Columns("ServiceTypeID").Visible = False
			.Columns("ServiceName").HeaderText = "Name"
			.Columns("SubCatType").HeaderText = "SubCategory"
			.Columns("ServiceType").HeaderText = "Type"
			.Columns("ServiceID").Visible = False
			.Columns("CompanyID").Visible = False
			.ReadOnly = True
			.RowsDefaultCellStyle.BackColor = Color.GhostWhite
		End With
	End Sub

#End Region

#Region "Form-Filter"
	Private Sub FilterGridServices()
		If blnLoading = True Then Exit Sub
		Dim s As String = "True"
		If cboService.SelectedIndex <> -1 Then
			s = s & " AND ServiceID=" & cboService.SelectedValue
		End If

		If cboSubCat.SelectedIndex <> -1 Then
			s = s & " AND ServiceSubCatID=" & cboSubCat.SelectedValue
		Else
			If cboSubCat.Text <> "" Then
				s = s & " AND ServiceSubCatID=-1"
			End If
		End If

		If cboType.SelectedIndex <> -1 Then
			s = s & " AND ServiceTypeID=" & cboType.SelectedValue
		Else
			If cboType.Text <> "" Then
				s = s & " AND ServiceTypeID=-1"
			End If
		End If
		dsdata.Tables("tblService").DefaultView.RowFilter = s

	End Sub

	Private Sub btnAddNewService_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddNewService.Click
		'Dim frm As New frmService(-1)
		'frm.ShowDialog()
		'frm.Activate()
		''AddHandler frm.Closed, AddressOf RefreshCombos
		RefreshCombos()
		

		cboService.SelectedIndex = -1
	End Sub
	Private Sub RefreshCombos() 'ByVal sender As System.Object, ByVal e As System.EventArgs)

		dsdata.Tables("tblService").Rows.Clear()
		dsdata.Tables("ServiceSearch").Rows.Clear()

		If strServices <> "" Then

			clsMr.BuildSqlAdapter("SELECT  *  FROM vwGetService WHERE Del=0 and ServiceID IN " & strServices, "tblService")
			clsMr.BuildSqlAdapter("SELECT  ServiceID,ServiceName,ServiceCode  FROM tblService WHERE Del=0 and ServiceID IN " & strServices, "ServiceSearch")


		Else
			clsMr.BuildSqlAdapter("SELECT  *  FROM vwGetService WHERE Del=0", "tblService")
			clsMr.BuildSqlAdapter("SELECT  ServiceID,ServiceName,ServiceCode  FROM tblService WHERE Del=0", "ServiceSearch")

		End If




	End Sub
	Private Sub cboSubCat_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboSubCat.KeyUp
		FilterServiceType()
		FilterGridServices()
	End Sub
	Private Sub cboSubCat_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSubCat.SelectedIndexChanged
		FilterServiceType()
		FilterGridServices()
	End Sub

	Private Sub cboService_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboService.SelectedIndexChanged
		FilterGridServices()
	End Sub

	Private Sub cboType_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboType.KeyUp
		FilterGridServices()
	End Sub
	Private Sub cboType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboType.SelectedIndexChanged
		FilterGridServices()
	End Sub
	Private Sub FilterServiceType()

		'If blnLoading = True Then Exit Sub

		'If cboSubCat.SelectedIndex = -1 Then
		'	dsdata.Tables("tblServicetype").DefaultView.RowFilter = "SubCatID=-1"
		'Else
		'	dsdata.Tables("tblServicetype").DefaultView.RowFilter = "SubCatID=" & cboSubCat.SelectedValue
		'	cboType.SelectedIndex = -1
		'End If
	End Sub
	Private Sub cboService_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboService.KeyUp
		If cboService.Text = "" Then
			dsdata.Tables("tblService").DefaultView.RowFilter = ""
		Else
			If rdbLike.Checked = True Then
				' dsdata.Tables("tblService").DefaultView.RowFilter = "ServiceName Like N'%" & cboService.Text.Trim
                dsdata.Tables("tblService").DefaultView.RowFilter = "ServiceName Like '" & cboService.Text.Trim & "%'" & " OR ServiceCode Like '" & cboService.Text.Trim & "%'"
			Else
				' dsdata.Tables("tblService").DefaultView.RowFilter = "Code Like N'%" & cboService.Text.Trim
                dsdata.Tables("tblService").DefaultView.RowFilter = "ServiceCode Like '%" & cboService.Text.Trim & "%'" & " OR ServiceName Like '%" & cboService.Text.Trim & "%'"
			End If
		End If

	End Sub
#End Region

#Region "GrdSetUP"
	Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
		If Me.grpShowHideColumns.Visible = False Then
			Me.grpShowHideColumns.Visible = True
			Me.grpShowHideColumns.BringToFront()
			mstrCurrentGridName = "Get Services"
			''
			'' populate list with grid's dataSource fields...
			''

			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridCol.Items.Clear()
			For Each col In grdServices.Columns
				Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
			Next
			chkLstGridCol.Items.Remove("Del")
			chkLstGridCol.Items.Remove("ServiceSubCatID")
			chkLstGridCol.Items.Remove("ServiceCatID")
			chkLstGridCol.Items.Remove("ServiceTypeID")
			chkLstGridCol.Items.Remove("ServiceID")
			chkLstGridCol.Items.Remove("CompanyID")
		Else
			Me.grpShowHideColumns.Visible = False
			Me.grpShowHideColumns.SendToBack()
		End If
	End Sub

	Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
		Dim i As Integer

		For i = 0 To Me.chkLstGridCol.Items.Count - 1
			Me.grdServices.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
		Next

		''
		Me.grpShowHideColumns.Visible = False
	End Sub
#End Region


End Class