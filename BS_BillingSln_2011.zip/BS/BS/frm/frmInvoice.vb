Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmInvoice

#Region "Form-Declaration......."

	Private dsdata As DataSet
	Private clsMr As ClsMain
	Private blnLoading As Boolean
	Private WithEvents Nav As BitsNav
	Private mstrCurrentGridName As String
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Invoice\Settings"
	Private daInvoice As SqlDataAdapter
	Private daInvoiceDetail As SqlDataAdapter
	Private daTafkeet As SqlDataAdapter
	Private mInvoiceID As Integer
	Dim dataChange As Boolean = False
	Private mStrCurrentState As String
	Private mPeriod As Integer
	Private mOldInvoiceID As Integer
	Private mCorrectInvoice As Boolean
	Private AddMode As Boolean = False
	Private mOldInvoiceNum As Integer
	Private mInvoiceNum As Integer
	Private InvoiceID As Integer
	''
	Dim mblnLoginSucces As Boolean = False
	Public WithEvents mClsFrmLogin As frmPassword
	Private CurrID2 As Integer
	Private mInvoiceType As Integer

#End Region


#Region "Form-Load.............."

    Private Sub frmInvoice_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub


    Private Sub frmInvoice_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''
        clsMr = New ClsMain(conSql)
        ''
        Nav = New BitsNav()
        blnLoading = True
        GetInvoiceID(mInvoiceNum)
        MakeDataAdapter()
        FillComboBox()
        SetDataBinding()
        SetAutoNumber()
        SetCurrencyManager()
        SetDefaultValue()
        DrawGrid()
        GetCompanyCurrencies()
        ''
        blnLoading = False
        ''
        If mInvoiceType = 2 Then
            lblfrmTitle.Text = "Bill"
            grpInvoiceInfo.Text = "Bill"
            lblInvoiceDateFrom.Visible = False
            dtpInvoiceDateFrom.Visible = False
            lblInvoiceDateTo.Visible = False
            dtpInvoiceDateTo.Visible = False
            cboCategory.Enabled = False
            cboCategory.Visible = False
            lblType.Visible = False
        Else
            lblfrmTitle.Text = "Invoice"
            grpInvoiceInfo.Text = "Invoice"
            lblInvoiceDateFrom.Visible = True
            dtpInvoiceDateFrom.Visible = True
            lblInvoiceDateTo.Visible = True
            dtpInvoiceDateTo.Visible = True
            cboCategory.Enabled = True
            cboCategory.Visible = True
            lblType.Visible = True
        End If
        ''
        If mInvoiceID = -1 Then
            ''
            NewRecord()
            btnPreview.Enabled = False
            ''
            If mInvoiceType = 2 Then
                ' category = 4 (other)
                cboCategory.SelectedValue = 4
                Nav.EndCurrentEdit()
            End If
        ElseIf mInvoiceID <> -2 Then
            ''Nav old
            Nav.CurrentPosition = GetRowIndex(mInvoiceID)
            FilterDetail()
            ''
            If cboStatus.SelectedValue = 2 Then
                setState("POST")
            Else
                setState("BROWSE")
            End If
            ''
            If txtTotal.Text = "" Then
                txtTotal.Text = 0
            End If
            ''
            'txtTotalCurr2.Text = GetExchangeValue(cboCurrency.SelectedValue, CurrID2, dtpInvoiceDate.Value, txtTotal.Text, txtRate.Text)
            ''
            If cboStatus.SelectedValue = 5 Then
                ''
                setState("CORRECTED")
            End If
        End If
        ''
        If mInvoiceNum > 0 Then
            Nav.CurrentPosition = GetRowIndex(GetInvoiceID(mInvoiceNum))
            FilterDetail()
            If cboStatus.SelectedValue = 2 Then
                setState("POST")
            Else
                setState("BROWSE")
            End If
            If txtTotal.Text = "" Then
                txtTotal.Text = 0
            End If
        End If
        ''
        If txtTotal.Text = "" Then
            txtTotal.Text = 0
        End If
        ''
        If txtTotalCurr2.Text = "" Then
            txtTotalCurr2.Text = 0
        End If
        ''
        Dim gt As Double
        Dim gt2 As Double
        Dim gtOld As Double
        ''
        CalculateTotal()
        ''
        If txtTotal.Text <> String.Empty Then
            gt = txtTotal.Text
        Else
            gt = 0
        End If
        ''
        If txtTotalCurr2.Text <> String.Empty Then
            gt2 = txtTotalCurr2.Text
        Else
            gt2 = 0
        End If
        ''
        gtOld = gt
        ''
        If gt Mod 1000 > 0 Then
            gt = (gt - (gt Mod 1000)) + 1000
            gt2 = gt * (gt2 / gtOld)
        Else
            gt = gt
        End If
        ''
        'If gt2 Mod 1 > 0 Then
        '	gt2 = (gt2 - (gt2 Mod 1)) + 1
        'Else
        '	gt2 = gt2
        'End If
        ''
        'txtTotal.Text = Double.Parse(txtTotal.Text).ToString("#0.##")
        txtTotal.Text = Double.Parse(gt).ToString("#,###0.##")
        'txtTotalCurr2.Text = Double.Parse(gt2).ToString("#,###.##")
        'txtTotalCurr2.Text = Double.Parse(txtTotalCurr2.Text).ToString("#0.##")
        lblCurrSymbol.Text = GetCompanyCurrencySymbol()
        lblCurrSymbol2.Text = GetCompanyCurrencySymbol2()
    End Sub

#End Region


#Region "Form-Initialisation...."

	Public Sub New(Optional ByVal pInvoiceID As Integer = -1, Optional ByVal pPeriod As Integer = -1, Optional ByVal pInvoiceType As Integer = -1, Optional ByVal pOldInvoiceID As Integer = -1, Optional ByVal pOldInvoiceNum As Integer = -1, Optional ByVal pCorrectInvoice As Boolean = False, Optional ByVal pRefID As Integer = -1)
		''
		' This call is required by the Windows Form Designer.
        InitializeComponent()

		' Add any initialization after the InitializeComponent() call.
		mInvoiceID = pInvoiceID
		mPeriod = pPeriod
		mInvoiceType = pInvoiceType
		mOldInvoiceID = pOldInvoiceID
		mCorrectInvoice = pCorrectInvoice
		mOldInvoiceNum = pOldInvoiceNum
        mInvoiceNum = pRefID
        ''
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

	Private Sub MakeDataAdapter()
		''
		'' set SQL for selecting active emp recs...
		If mCorrectInvoice Then
			daInvoice = clsMr.BuildSqlAdapter("SELECT * FROM tblInvoice WHERE Del=0 and BranchID=" & gIntBranchID & " AND InvoiceID=" & InvoiceID, "tblInvoice")
			daInvoiceDetail = clsMr.BuildSqlAdapter("SELECT *  FROM tblInvoiceDetail WHERE Del =0 AND InvoiceID=" & InvoiceID, "tblInvoiceDetail")
			clsMr.BuildSqlAdapter("SELECT *  FROM vwInvoiceDetail WHERE Del =0 AND InvoiceID=" & InvoiceID, "vwInvoiceDetail")
		Else
			daInvoice = clsMr.BuildSqlAdapter("SELECT * FROM tblInvoice WHERE Del=0 and BranchID=" & gIntBranchID & " AND InvoiceID=" & mInvoiceID, "tblInvoice")
			daInvoiceDetail = clsMr.BuildSqlAdapter("SELECT *  FROM tblInvoiceDetail WHERE Del =0 AND InvoiceID=" & mInvoiceID, "tblInvoiceDetail")
			clsMr.BuildSqlAdapter("SELECT *  FROM vwInvoiceDetail WHERE Del =0 AND InvoiceID=" & mInvoiceID, "vwInvoiceDetail")
		End If

		clsMr.BuildSqlAdapter("SELECT ClientID,ClientItemID,RegCode  FROM tblClientItem WHERE Del =0 ", "tblClientItem")
		clsMr.BuildSqlAdapter("SELECT EmployeeID,FName +' ' + LName as FullName FROM tblEmployee WHERE Del =0 ", "DG")
		clsMr.BuildSqlAdapter("SELECT EmployeeID,FName +' ' + LName as FullName FROM tblEmployee WHERE Del =0 ", "tblEmployee")
		clsMr.BuildSqlAdapter("SELECT ClientID,ClientName,Discount  from tblClient WHERE Del =0  ORDER BY ClientName", "ClientName")
		'	clsMr.BuildSqlAdapter("SELECT EmployeeID, DoctorName AS FullName from vwDoctorName WHERE Del =0  ORDER BY FullName", "DoctorName")
		clsMr.BuildSqlAdapter("SELECT * FROM tblStatus WHERE Del=0 ", "tblStatus")
		clsMr.BuildSqlAdapter("SELECT CurrID,Symbol FROM tblCurrency WHERE Del=0 ", "tblCurrency")
		clsMr.BuildSqlAdapter("SELECT ServiceID,ServiceName,Price,PriceUnitID,Vat FROM tblService WHERE Del=0 ", "tblService")
		clsMr.BuildSqlAdapter("SELECT ServiceID,ServiceName,Price,PriceUnitID,Vat FROM tblService WHERE Del=0 AND ServiceID=0", "ServiceChoosen")
		clsMr.BuildSqlAdapter("SELECT *  FROM tblPriceUnit WHERE Del =0 ", "PriceUnit")
		clsMr.BuildSqlAdapter("SELECT CatID,CatType  FROM tblServiceCategory WHERE Del =0 ", "tblServiceCategory")
		daTafkeet = clsMr.BuildSqlAdapter("SELECT * FROM tblTafkeet", "tblTafkeet")
		dsdata = clsMr.getDataSet

	End Sub

	Private Sub FillComboBox()

		clsMr.FillComboBox("ClientName", cboClient, "ClientName", "ClientID")
		clsMr.FillComboBox("tblStatus", cboStatus, "Status", "StatusID")
		clsMr.FillComboBox("tblCurrency", cboCurrency, "Symbol", "CurrID")
		clsMr.FillComboBox("DG", cboDG, "FullName", "EmployeeID")
		clsMr.FillComboBox("tblEmployee", cboEmployee, "FullName", "EmployeeID")
		clsMr.FillComboBox("tblServiceCategory", cboCategory, "CatType", "CatID")
		cboCategory.Items.Remove("Contract")
	End Sub

	Private Sub SetCurrencyManager()
		Nav.SetCurrency(Me, clsMr.getDataSet(), "tblInvoice")
	End Sub

	Private Sub SetDefaultValue()
		''
		clsMr.SetDefaults("tblInvoice", "CreateByID", gIntUserID, "CreateDate", Now.Date, "Del", 0, "StatusID", 1, "InvoiceDate", Now.Date, "InvoiceFrom", Now.Date, "InvoiceTo", Now.Date, "Total", 0, "BilledDate", Now.Date, "BranchID", gIntBranchID, "EmployeeID", gIntUserID, "CurrencyID", gIntCompanyCurrID, "TotalCurr2", 0, "AutoGel", 0)
		clsMr.SetDefaults("tblInvoiceDetail", "TotalCurr2", 0, "Quantity", 1)
		clsMr.SetDefaults("vwInvoiceDetail", "TotalCurr2", 0, "Quantity", 1)
	End Sub

	Private Sub SetAutoNumber()
		''
		'clsMr.SetAutoNumber("tblInvoice", "InvoiceID")
		'clsMr.SetAutoNumber("tblInvoice", "InvoiceNumber")
		' ''
		'clsMr.SetAutoNumber("tblInvoiceDetail", "InvoiceDetailID")
		clsMr.SetAutoNumber("vwInvoiceDetail", "InvoiceDetailID")
	End Sub

	Private Sub SetDataBinding()
		''
		clsMr.BindTextBox(txtInvoiceID, "tblInvoice", "InvoiceID")
		clsMr.BindTextBox(txtInvoiceNum, "tblInvoice", "InvoiceNumber")
		clsMr.BindTextBox(txtInvoiceYY, "tblInvoice", "InvoiceYY")
		clsMr.BindTextBox(txtDescription, "tblInvoice", "Description")
		clsMr.BindTextBox(txtTotal, "tblInvoice", "Total")
		clsMr.BindTextBox(txtTotalCurr2, "tblInvoice", "TotalCurr2")
		clsMr.BindTextBox(txtRate, "tblInvoice", "Rate")
		clsMr.BindTextBox(txtRefID, "tblInvoice", "RefID")
        clsMr.BindTextBox(txtRefIDTo, "tblInvoice", "RefIDTo")
        clsMr.BindTextBox(txtOverDueRemark, "tblInvoice", "OverDueDesc")
        ''
		clsMr.BindDateTimePicker(dtpInvoiceDate, "tblInvoice", "InvoiceDate")
		clsMr.BindDateTimePicker(dtpInvoiceDateFrom, "tblInvoice", "InvoiceFrom")
		clsMr.BindDateTimePicker(dtpInvoiceDateTo, "tblInvoice", "InvoiceTo")
		clsMr.BindDateTimePicker(dtpBilledDate, "tblInvoice", "BilledDate")
		''
		clsMr.BindComboBox(cboClient, "tblInvoice", "ClientID")
		clsMr.BindComboBox(cboStatus, "tblInvoice", "StatusID")
		clsMr.BindComboBox(cboCurrency, "tblInvoice", "CurrencyID")
		clsMr.BindComboBox(cboDG, "tblInvoice", "DGID")
		clsMr.BindComboBox(cboCategory, "tblInvoice", "CatID")
		clsMr.BindComboBox(cboEmployee, "tblInvoice", "EmployeeID")
	End Sub

#End Region


#Region "Form-UI/Methods........"

	Private Sub cboEmployee_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboEmployee.KeyPress
		AutoComplete(cboEmployee, e)
	End Sub

	Private Sub cboDG_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboDG.KeyPress
		AutoComplete(cboDG, e)
	End Sub

	Private Sub btnPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreview.Click
		''
		If txtInvoiceID.Text = "" Then Exit Sub
		Dim rpt As Object
		''
		'If grdSOList.Rows.Count = 0 Then Exit Sub
		''
		'if type of Category is contract
		If cboCategory.SelectedValue = 5 Then
			rpt = New RptContractInvoice
		Else
			rpt = New rptInvoice
		End If
		''
		Dim frm As New frmQuickReport
		ClearTable()
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
		''
		Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
		''
		For Each tbCurrent In rpt.Database.Tables
			tliCurrent = tbCurrent.LogOnInfo
			''
			With tliCurrent.ConnectionInfo
				.ServerName = gStrServerName
				.DatabaseName = gStrDataBaseName
				.UserID = "" 'gStrUserName
				.Password = ""	 'gStrPassword
			End With
			''
			tbCurrent.ApplyLogOnInfo(tliCurrent)
		Next tbCurrent
		''
		frm.crvInstantViewer.SelectionFormula = "{vwInvoiceRpt.InvoiceID}=" & txtInvoiceID.Text
		'frm.crvInstantViewer.SelectionFormula = " AND {tblUserPreferences.UserID}=" & gIntUserID
		''
		rpt.SetParameterValue("CurrSybl1", GetCompanyCurrencySymbol())
		'rpt.SetParameterValue("TotalCurr2", txtTotalCurr2.Text)
		rpt.SetParameterValue("CurrSybl2", GetCompanyCurrencySymbol2())
		rpt.SetParameterValue("DateFrom", Format(dtpInvoiceDateFrom.Value, "MMMM"))
		''
		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand
		If cboCategory.SelectedValue = 5 Then
			rpt.SetParameterValue("Total", txtTotal.Text)
			rpt.SetParameterValue("TotalCurr2", txtTotalCurr2.Text)
		End If
		''
		Dim strUnitName As String
		Dim strPartUnitName As String
		Dim strSymbol As String
		Dim strUnitNameEn As String
		Dim strPartUnitNameEn As String
		Dim strSymbolEn As String
		''
		strSQL = "select *   FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text
		''
		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			strUnitName = dRdr("UnitName")
			strPartUnitName = dRdr("PartUnitName")
			strSymbol = dRdr("Symbol")
		End If
		dRdr.Close()
		conSql.Close()
		''
		strSQL = "select *   FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID2
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text
		''
		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			strUnitNameEn = dRdr("UnitName")
			strPartUnitNameEn = dRdr("PartUnitName")
			strSymbolEn = dRdr("Symbol")
		End If
		dRdr.Close()
		conSql.Close()

		''
		Dim strWord As String
		Dim strWordEn As String
		'strWord = ToWords(JobCards.Current()("Total"), strUnitName, strPartUnitName)
		'rpt.SetParameterValue("Words", strWord)
		''
		If txtTotal.Text = String.Empty Then
			txtTotal.Text = 0
		End If
		''
		If txtTotalCurr2.Text = String.Empty Then
			txtTotalCurr2.Text = 0
		End If
		''
		'If txtTotalCurr2.Text <> String.Empty Then
		strWordEn = ToWordsEn(txtTotalCurr2.Text, strUnitNameEn, strPartUnitNameEn)
		'End If
		''
		'If txtTotal.Text <> String.Empty Then
		''
		strWord = ToWords(txtTotal.Text, strUnitName, strPartUnitName)
		'End If

		'	rpt.SetParameterValue("Words", strWord)
		Dim drNew As DataRow = dsdata.Tables("tblTafkeet").NewRow
		drNew("Tafkeet") = strWord
		drNew("TafkeetEn") = strWordEn
		drNew("InvoiceID") = txtInvoiceID.Text
		dsdata.Tables("tblTafkeet").Rows.Add(drNew)
		daTafkeet.Update(dsdata, "tblTafkeet")
		''
		frm.crvInstantViewer.ReportSource = rpt
		frm.crvInstantViewer.Refresh()
		frm.Show()

		frm.crvInstantViewer.DisplayToolbar = True
		Windows.Forms.Cursor.Current = Cursors.Default()
	End Sub

	Private Sub grdInvoiceDetail_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdInvoiceDetail.KeyDown
		If e.KeyCode = Keys.F5 Then
			GetServices()
		End If

	End Sub

	Private Sub grdInvoiceDetail_RowsRemoved(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsRemovedEventArgs) Handles grdInvoiceDetail.RowsRemoved
		CalculateTotal()
		checkValues()
	End Sub

	Private Sub btnRemoveService_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveService.Click
		If grdInvoiceDetail.Rows.Count = -1 Then Exit Sub

		Dim dr As DataView
		dr = dsdata.Tables("vwInvoiceDetail").DefaultView

		If MsgBox(" Are you sure you want to Delete? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution") = MsgBoxResult.Yes Then

			'Dim drDel() As DataRow
			'drDel = dsdata.Tables("tblInvoiceDetail").Select("InvoiceDetailID = " & dr(grdInvoiceDetail.CurrentRow.Index)("InvoiceDetailID"))

			'If drDel.Length > 0 Then
			'	UpdateSoldField(drDel(0)("VehicleID"), 0)
			'	drDel(0).Delete()
			'	clsMr.Update(daSODetail, "tblSalesOrderDetail")
			'End If


			Dim i As Integer

			Dim dv As DataGridViewSelectedRowCollection = grdInvoiceDetail.SelectedRows
			For i = 0 To dv.Count - 1
				'	''updatedetail
				'	Dim cmd As New SqlCommand("UPDATE tblInvoiceDetail SET Del=1 WHERE InvoiceDetailID=" & dv(i).Cells("InvoiceDetailID").Value, conSql)
				'	conSql.Open()
				'	cmd.ExecuteNonQuery()
				'	conSql.Close()
				dsdata.Tables("vwInvoiceDetail").DefaultView(grdInvoiceDetail.CurrentRow.Index).Delete()
				'	dsdata.Tables("vwInvoiceDetail").Rows.Remove(dsdata.Tables("vwInvoiceDetail").DefaultView(grdInvoiceDetail.CurrentRow.Index).Row)
			Next


			If grdInvoiceDetail.Rows.Count = 0 Then
				btnRemoveService.Enabled = False
				cboCategory.Enabled = True
			End If

			CalculateTotal()
			dataChange = True
			'Save()

		End If

	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		''
        If btnSave.Text = "E d i t" Then
            ''
            Select Case cboStatus.SelectedValue
                ''
                Case 4
                    MsgBox("Cannot Edit a paid invoice")
                    Exit Sub

                Case 5
                    ''
                    MsgBox("Cannot Edit a Corrected invoice")
                    Exit Sub
            End Select
            ''
            Select Case cboCategory.SelectedValue
                ''
                Case 5
                    MsgBox("Cannot Edit Contract invoice")
                    Exit Sub
            End Select
            ''
            setState("EDIT")
            checkValues()
            cboCategory.Focus()
            Exit Sub
        End If
        ''
        Save()
        ''
		If mCorrectInvoice Then
			Try
				Dim cmd As New SqlCommand("UPDATE tblInvoice SET StatusID = 5 , RefIDTo=" & txtInvoiceNum.Text & " WHERE InvoiceID=" & mOldInvoiceID, conSql)
				conSql.Open()
				cmd.ExecuteNonQuery()
				conSql.Close()
			Catch ex As Exception
				conSql.Close()
			End Try
			''
			'Update tblMessage Set InvoiceID = NULL Where INvoice
			If cboCategory.SelectedValue = 3 Then
				''
				Try
					Dim cmd As New SqlCommand("UPDATE tblMessage SET InvoiceID=" & txtInvoiceID.Text & " WHERE InvoiceID=" & mOldInvoiceID, conSql)
					conSql.Open()
					cmd.ExecuteNonQuery()
					conSql.Close()
				Catch ex As Exception
					conSql.Close()
				End Try
				''
			End If
		End If
        setState("SAVE")
        CalculateTotal()
		btnPreview.Enabled = True
	End Sub

	Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
		NewRecord()
	End Sub

	Private Sub btnGetService_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetService.Click
		If cboCategory.SelectedIndex = -1 Then
			MsgBox("Please choose invoice category first")
			Exit Sub
		End If
		GetServices()
	End Sub

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		'' check OK to close...
		If dataChange Then
			Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
				Case MsgBoxResult.Yes
					'' call save...
					If lstDataErr.Items.Count <> 0 Then
						MsgBox("Cannot save.Please check error list")
						Exit Sub
					Else
						Save()
						Me.Close()
					End If
				Case MsgBoxResult.No
					'' ignore changes...

					Try
						Nav.CancelCurrentEdit()
					Catch ex As Exception

					End Try
					Me.Close()
				Case MsgBoxResult.Cancel
					'' ignore close press..
					'' do nothing...

			End Select
		Else
			Me.Close()
		End If

	End Sub

	Private Sub cboClient_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyDown
		If e.KeyCode = Keys.F3 Then
			GetClient()
		End If
	End Sub

	Private Sub cboClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
		AutoComplete(cboClient, e)
	End Sub

	Private Sub cboClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged

		If blnLoading Then Exit Sub

		'If cboClient.SelectedIndex <> -1 Then
		'	cboCurrency.SelectedValue = GetAcctCurrency(cboClient.SelectedValue)
		'End If

		checkValues()

	End Sub

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ''
        If dataChange Then
            If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

                Try
                    Nav.CancelCurrentEdit()
                Catch ex As Exception

                End Try

                dataChange = False
                AddMode = False

            End If
        Else

            'AddMode = False
        End If

		If cboStatus.SelectedValue = 2 Then
			setState("POST")
		Else
			setState("BROWSE")
		End If
	End Sub

	Private Sub btnPost_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPost.Click
		If btnPost.Text = "P o s t" Then
			''
			cboStatus.SelectedValue = 2
			dtpBilledDate.Enabled = True
			'dtpBilledDate.Value = Now.Date
			dataChange = True
			Save()
			''update acct bal(add)
			UpdateClientBalance()
			setState("POST")

		Else
			'If cboCategory.SelectedValue = 5 Then
			'	MsgBox("You Cannot Unpost Contract Invoice")
			'	Exit Sub
			'End If

			If MsgBox("Are you sure you want to Unpost?", MsgBoxStyle.Critical + MsgBoxStyle.YesNo, "Warning") = MsgBoxResult.Yes Then


				mblnLoginSucces = False
				mClsFrmLogin = New frmPassword
				mClsFrmLogin.StartPosition = FormStartPosition.CenterScreen
				mClsFrmLogin.ShowDialog()

				If mblnLoginSucces Then
					mClsFrmLogin.Close()
				Else
					Exit Sub
				End If
				cboStatus.SelectedValue = 3
				dataChange = True
				Save()
				''update acct bal(subt)
				UpdateClientBalance()
				setState("UNPOST")
			End If
		End If
	End Sub

	Private Sub grdInvoiceDetail_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdInvoiceDetail.CellEndEdit
		''
        ''AddHandler dsdata.Tables("vwInvoiceDetail").ColumnChanged, AddressOf Column_Changed
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        Dim blnNoRepeat As Boolean = False

        If grdInvoiceDetail.Rows.Count = 0 Then Exit Sub

        If (grdInvoiceDetail.CurrentRow) Is Nothing Then
            Exit Sub
        End If

        Dim dgvr As DataGridViewRow

        dgvr = grdInvoiceDetail.Rows(grdInvoiceDetail.CurrentRow.Index)

        'Dim dgvcPrice As DataGridViewCell = grdInvoiceDetail.Item("Price", e.RowIndex)
        'Dim dgvcDiscount As DataGridViewCell = grdInvoiceDetail.Item("Discount", e.RowIndex)
        ''
        Select Case grdInvoiceDetail.Columns(e.ColumnIndex).Name
            ''
            Case "Discount", "Price", "VATAmount", "Quantity", "Note"

                ''
                If blnNoRepeat Then Exit Sub
                ''
                blnNoRepeat = True
                ''
                If dgvr.Cells("Discount").Value Is DBNull.Value Then
                    dgvr.Cells("Discount").Value = 0
                End If
                If dgvr.Cells("Price").Value Is DBNull.Value Then
                    dgvr.Cells("Price").Value = 0
                End If
                If dgvr.Cells("VatAmount").Value Is DBNull.Value Then
                    dgvr.Cells("VatAmount").Value = 0
                End If
                If dgvr.Cells("Quantity").Value Is DBNull.Value Then
                    dgvr.Cells("Quantity").Value = 1
                End If
                ''
                'Total = Quantity * (Price + VatAmount - Discount )

                Dim dv As DataView = dsdata.Tables("ServiceChoosen").DefaultView
                ''
                Dim discount As Decimal
                Dim Vat As Decimal

                'Discount = ((dgvr.Cells("Price").Value * dgvr.Cells("Discount").Value) / 100)
                dgvr.Cells("VatAmount").Value = (dgvr.Cells("Price").Value * GetVatByServiceID(dgvr.Cells("ServiceID").Value)) / 100
                'dgvr.Cells("Price").Value = dgvr.Cells("Price").Value - discount + Vat
                'dgvr.Cells("Total").Value = dgvr.Cells("Quantity").Value * dgvr.Cells("Price").Value
                ''
                If cboCategory.SelectedValue = 3 Or cboCategory.SelectedValue = 2 Then
                    dgvr.Cells("Total").Value = (dgvr.Cells("Price").Value + dgvr.Cells("VatAmount").Value - dgvr.Cells("Discount").Value)
                Else
                    dgvr.Cells("Total").Value = dgvr.Cells("Quantity").Value * (dgvr.Cells("Price").Value + dgvr.Cells("VatAmount").Value - dgvr.Cells("Discount").Value)
                End If
                ''
                dgvr.Cells("TotalCurr2").Value = GetExchangeValue(cboCurrency.SelectedValue, CurrID2, dtpInvoiceDate.Value, dgvr.Cells("Total").Value, txtRate.Text)
                CalculateTotal()
                ''
                blnNoRepeat = False

            Case "ServiceID"
                ''
                If blnNoRepeat Then Exit Sub
                blnNoRepeat = True
                dsdata.Tables("ServiceChoosen").Rows.Clear()
                clsMr.BuildSqlAdapter("SELECT ServiceID,ServiceName,Price,PriceUnitID,Vat FROM tblService WHERE Del=0 AND ServiceID=" & grdInvoiceDetail.Item("ServiceID", grdInvoiceDetail.CurrentRow.Index).Value, "ServiceChoosen")

                Dim dv As DataView = dsdata.Tables("ServiceChoosen").DefaultView

                If dv.Count <> 0 Then

                    If cboCurrency.SelectedValue <> gIntCompanyCurrID Then
                        dgvr.Cells("Price").Value = GetExchangeValue(gIntCompanyCurrID, cboCurrency.SelectedValue, dtpInvoiceDate.Value, dv(0)("Price"))
                        dgvr.Cells("VatAmount").Value = GetExchangeValue(gIntCompanyCurrID, cboCurrency.SelectedValue, dtpInvoiceDate.Value, dv(0)("Vat"))

                    Else
                        dgvr.Cells("Price").Value = dv(0)("Price")
                        dgvr.Cells("VatAmount").Value = dv(0)("Vat")
                    End If

                    If cboClient.SelectedIndex <> -1 Then
                        Dim drv As DataRowView = cboClient.SelectedItem
                        If drv("Discount") <> 0 Then
                            dgvr.Cells("Price").Value = dgvr.Cells("Price").Value - dgvr.Cells("Price").Value * drv("Discount") / 100
                        End If
                    End If
                    dgvr.Cells("PriceUnitID").Value = dv(0)("PriceUnitID")
                End If
                blnNoRepeat = False
                ''
                checkValues()
        End Select
        dataChange = True
	End Sub

#End Region


#Region "Form-Functions........."

	Private Sub GetCompanyCurrencies()


		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand
		''
		strSQL = "select * FROM  dbo.tblCompany  WHERE dbo.tblCompany.companyID=  " & gIntCompanyID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text

		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			CurrID2 = dRdr("CurrID2")
		End If
		dRdr.Close()
		conSql.Close()
	End Sub

	Private Function GetBranchBillingInfo()
		Dim intDGID As Integer

		Try
			Dim cmd As New SqlClient.SqlCommand("SELECT DGID FROM tblBranchBillingInfo WHERE BranchID=" & gIntBranchID, conSql)
			conSql.Open()
			intDGID = cmd.ExecuteScalar()
			conSql.Close()
			Return intDGID
		Catch ex As Exception
			conSql.Close()
			Return 0
		End Try

	End Function

	Private Sub ClearTable()
		Dim cmd As New SqlClient.SqlCommand("Delete from tblTafkeet", conSql)
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()
		dsdata.Tables("tblTafkeet").Rows.Clear()

	End Sub

	Private Sub GetClient()
		Dim frmClient As New frmClientGet()
		'appMain.addTabPage(frmClient, frmApplicationMain.eFormType.ClientGet)
		'AddHandler frmClient.Closed, AddressOf RefreshClient
		frmClient.ShowDialog()
		cboClient.SelectedValue = frmClient.CboValue
	End Sub

    Private Sub GetServices()
        ''
        Dim VatAmount As Decimal
        ''
        Dim dv As DataView = dsdata.Tables("vwInvoiceDetail").DefaultView
        Dim frm As frmServiceGet

        If cboCategory.SelectedIndex <> -1 Then
            frm = New frmServiceGet(dv, cboCategory.SelectedValue)
        Else
            frm = New frmServiceGet(dv, -1)
        End If

        'txtVisitID.Text, "Service", "vwVisitServices") 'txtVisitID.Text)
        frm.ShowDialog()
        ''Refresh visit Services
        ''aDD sERVICE
        Dim i As Integer
        For i = 0 To frm.arr.Length - 1
            If frm.arr(i) <> 0 Then
                ''Add Service
                'dataChange = True
                checkValues()

                dsdata.Tables("vwInvoiceDetail").DefaultView.AllowNew = True

                dsdata.Tables("tblService").Rows.Clear()
                clsMr.BuildSqlAdapter("SELECT ServiceID,ServiceName,Price,PriceUnitID,Vat FROM tblService WHERE Del=0 ", "tblService")
                Dim drs() As DataRow = dsdata.Tables("tblService").Select("ServiceID=" & frm.arr(i))
                If drs.Length <> 0 Then

                    Dim dr As DataRow = dsdata.Tables("vwInvoiceDetail").NewRow

                    dr("ServiceID") = drs(0)("ServiceID")
                    'dr("ServiceName") = drs(0)("ServiceName")
                    'TODO':dr("InvoiceID") = txtInvoiceID.Text

                    If Not drs(0)("Vat") Is DBNull.Value Then
                        ''
                        If drs(0)("Price") Is DBNull.Value Then
                            drs(0)("Price") = 0
                        End If
                        ''
                        VatAmount = (drs(0)("Vat") * drs(0)("Price")) / 100
                        ''
                        If cboCurrency.SelectedValue <> gIntCompanyCurrID Then
                            'dr("VatAmount") = GetExchangeValue(gIntCompanyCurrID, cboCurrency.SelectedValue, dtpInvoiceDate.Value, drs(0)("Vat"))
                            dr("VatAmount") = GetExchangeValue(gIntCompanyCurrID, cboCurrency.SelectedValue, dtpInvoiceDate.Value, VatAmount)

                        Else
                            'dr("VatAmount") = drs(0)("Vat")
                            dr("VatAmount") = VatAmount
                        End If

                    Else
                        dr("VatAmount") = 0
                    End If

                    If Not drs(0)("Price") Is DBNull.Value Then
                        If cboCurrency.SelectedValue <> gIntCompanyCurrID Then
                            dr("Price") = GetExchangeValue(gIntCompanyCurrID, cboCurrency.SelectedValue, dtpInvoiceDate.Value, drs(0)("Price"))
                        Else
                            dr("Price") = drs(0)("Price")
                        End If
                        If cboClient.SelectedIndex <> -1 Then
                            Dim drv As DataRowView = cboClient.SelectedItem
                            If drv("Discount") <> 0 Then
                                dr("Price") = dr("Price") - dr("Price") * drv("Discount") / 100
                            End If
                        End If
                    Else
                        dr("Price") = 0
                    End If

                    dr("Discount") = 0
                    dr("Quantity") = 1
                    dr("PriceUnitID") = drs(0)("PriceUnitID")
                    dr("Del") = 0
                    dr("Total") = dr("Quantity") * (dr("Price") + dr("VatAmount") - dr("Discount"))
                    dr("TotalCurr2") = GetExchangeValue(cboCurrency.SelectedValue, CurrID2, dtpInvoiceDate.Value, dr("Total"), txtRate.Text)
                    dsdata.Tables("vwInvoiceDetail").Rows.Add(dr)
                    dsdata.Tables("vwInvoiceDetail").DefaultView.AllowNew = False
                    checkValues()
                    If grdInvoiceDetail.Rows.Count > 0 Then
                        btnRemoveService.Enabled = True
                        cboCategory.Enabled = False
                    End If

                End If

            End If
        Next
        CalculateTotal()

        'SaveDetail()
    End Sub

	Private Sub frmPassword_OnOkClick(ByVal pBlnPassed As Boolean, ByVal pIntUserID As Integer, ByVal pIntUserLevel As Integer) Handles mClsFrmLogin.OnOkClick
		If pBlnPassed = True Then
			gIntUserID = pIntUserID
			mblnLoginSucces = True
			gUserLevel = CType(pIntUserLevel, enmUserLevel)	'pIntUserLevel 'CType(pIntUserLevel, enmUserLevel)
		End If
	End Sub

	Private Sub UpdateClientBalance()
		Dim TotalCharge As Decimal
		Dim AcctCurrID As Integer = GetAcctCurrency(cboClient.SelectedValue)

		If GetOperation(cboCurrency.SelectedValue, AcctCurrID, dtpInvoiceDate.Value) = "/" Then

			TotalCharge = Decimal.Parse(txtTotal.Text) / GetRate(cboCurrency.SelectedValue, AcctCurrID, dtpInvoiceDate.Value)
		Else
			If txtTotal.Text <> String.Empty Then
				TotalCharge = Decimal.Parse(txtTotal.Text) * GetRate(cboCurrency.SelectedValue, AcctCurrID, dtpInvoiceDate.Value)
			End If
		End If

		'Return TotalCharge

		Dim command As New SqlClient.SqlCommand
		command.CommandText = "SpUpdateClientBalance"

		Try
			command.Connection = conSql
			command.CommandType = CommandType.StoredProcedure
			''
			If cboStatus.SelectedValue = 2 Then	''close --> add balance
				command.Parameters.AddWithValue("@balance", TotalCharge)
			Else
				If cboStatus.SelectedValue = 3 Then
					command.Parameters.AddWithValue("@balance", -TotalCharge)
				End If
			End If
			''
			If mCorrectInvoice Then
				command.Parameters.AddWithValue("@balance", -TotalCharge)
			End If
			''
			command.Parameters.AddWithValue("@ClientID", cboClient.SelectedValue)
			conSql.Open()
			command.ExecuteNonQuery()
			conSql.Close()
		Catch ex As Exception
			conSql.Close()
		End Try


	End Sub

	Private Sub Column_Changed(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)

		Dim blnNoRepeat As Boolean = False

		If grdInvoiceDetail.Rows.Count = 0 Then Exit Sub

		If (grdInvoiceDetail.CurrentRow) Is Nothing Then
			Exit Sub
		End If

		Dim dgvr As DataGridViewRow

		dgvr = grdInvoiceDetail.Rows(grdInvoiceDetail.CurrentRow.Index)
        ''
		If e.Column.ColumnName = "Discount" Or e.Column.ColumnName = "Price" Or e.Column.ColumnName = "VATAmount" Or e.Column.ColumnName = "Quantity" Or e.Column.ColumnName = "Note" Then
            ''
            If blnNoRepeat Then Exit Sub
            ''
			blnNoRepeat = True
            ''
			If dgvr.Cells("Discount").Value Is DBNull.Value Then
				dgvr.Cells("Discount").Value = 0
			End If
			If dgvr.Cells("Price").Value Is DBNull.Value Then
				dgvr.Cells("Price").Value = 0
			End If
			If dgvr.Cells("VatAmount").Value Is DBNull.Value Then
				dgvr.Cells("VatAmount").Value = 0
			End If
			If dgvr.Cells("Quantity").Value Is DBNull.Value Then
				dgvr.Cells("Quantity").Value = 1
			End If
			''
			'Total = Quantity * (Price + VatAmount - Discount )

            Dim dv As DataView = dsdata.Tables("ServiceChoosen").DefaultView
            ''
            If cboCategory.SelectedValue = 3 Then
                dgvr.Cells("Total").Value = (dgvr.Cells("Price").Value + dgvr.Cells("VatAmount").Value - dgvr.Cells("Discount").Value)
            Else
                dgvr.Cells("Total").Value = dgvr.Cells("Quantity").Value * (dgvr.Cells("Price").Value + dgvr.Cells("VatAmount").Value - dgvr.Cells("Discount").Value)
            End If
			dgvr.Cells("TotalCurr2").Value = GetExchangeValue(cboCurrency.SelectedValue, CurrID2, dtpInvoiceDate.Value, dgvr.Cells("Total").Value, txtRate.Text)
            ''
			CalculateTotal()
			''
			blnNoRepeat = False
		Else
			If e.Column.ColumnName = "ServiceID" Then
				If blnNoRepeat Then Exit Sub
				blnNoRepeat = True
				dsdata.Tables("ServiceChoosen").Rows.Clear()
				clsMr.BuildSqlAdapter("SELECT ServiceID,ServiceName,Price,PriceUnitID,Vat FROM tblService WHERE Del=0 AND ServiceID=" & grdInvoiceDetail.Item("ServiceID", grdInvoiceDetail.CurrentRow.Index).Value, "ServiceChoosen")

				Dim dv As DataView = dsdata.Tables("ServiceChoosen").DefaultView

				If dv.Count <> 0 Then

					If cboCurrency.SelectedValue <> gIntCompanyCurrID Then
						dgvr.Cells("Price").Value = GetExchangeValue(gIntCompanyCurrID, cboCurrency.SelectedValue, dtpInvoiceDate.Value, dv(0)("Price"))
						dgvr.Cells("VatAmount").Value = GetExchangeValue(gIntCompanyCurrID, cboCurrency.SelectedValue, dtpInvoiceDate.Value, dv(0)("Vat"))

					Else
						dgvr.Cells("Price").Value = dv(0)("Price")
						dgvr.Cells("VatAmount").Value = dv(0)("Vat")
					End If

					If cboClient.SelectedIndex <> -1 Then
						Dim drv As DataRowView = cboClient.SelectedItem
						If drv("Discount") <> 0 Then
							dgvr.Cells("Price").Value = dgvr.Cells("Price").Value - dgvr.Cells("Price").Value * drv("Discount") / 100
						End If
					End If
					dgvr.Cells("PriceUnitID").Value = dv(0)("PriceUnitID")
				End If
				blnNoRepeat = False
			End If

		End If
			checkValues()
	End Sub

    Private Function GetVatByServiceID(ByVal pServiceID As Integer) As Decimal
        ''
        Dim Vat As Decimal
        ''
        Try
            Dim cmd As New SqlCommand("SELECT VAT FROM tblService WHERE ServiceID=" & pServiceID, conSql)
            ''
            conSql.Open()
            Vat = cmd.ExecuteScalar
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try
        ''
        Return Vat
    End Function

    Private Sub CalculateTotal()
        If blnLoading Then Exit Sub

        Dim dv As DataView = dsdata.Tables("vwInvoiceDetail").DefaultView
        Dim drv As DataRowView
        Dim gt As Double
        Dim gtCurr2 As Double

        ''
        For Each drv In dv
            If IsDBNull(drv("Total")) Then
                drv("Total") = 0
            End If
            ''
            If IsDBNull(drv("Price")) Then
                drv("Price") = 0
            End If
            ''
            If IsDBNull(drv("TotalCurr2")) Then
                drv("TotalCurr2") = 0
            End If
            ''
            If cboCategory.SelectedValue = 3 Then
                ''
                gt += drv("Price")
            Else

                gt += drv("Total")

            End If
            'gt += drv("Price")
            gtCurr2 += drv("TotalCurr2")
        Next

        ''
        '' Format Totals'
        ''
        ''
        If gt Mod 1000 > 0 Then
            gt = (gt - (gt Mod 1000)) + 1000
        Else
            gt = gt
        End If
        ''
        ' If gtCurr2 Mod 1 > 0 Then
        ''
        gtCurr2 = gt / 1500
        'End If
        ''
        txtTotal.Text = gt.ToString("#,###0.##")
        txtTotalCurr2.Text = gtCurr2.ToString("#,###0.##")

        ''
        '' Try using Rounding Methods...
        ''
        'txtTotal.Text = Math.Round(CDbl(gt), 3)

        ''
        '' Rounding Totals

        'If (txtTotal.Text.Length >= 3) And (Strings.Right(txtTotal.Text, 3) > 0) Then
        '    Dim j As Integer = txtTotal.Text.Length - 3
        '    Dim tot As Double = Double.Parse(txtTotal.Text) + 1000 - Double.Parse(txtTotal.Text.Substring(j, 3))
        '    txtTotal.Text = tot
        'End If
        ''

    End Sub

    Private Sub FilterDetail()
        blnLoading = True

        dsdata.Tables("tblInvoiceDetail").Rows.Clear()
        dsdata.Tables("vwInvoiceDetail").Rows.Clear()
        ''
        If mCorrectInvoice Then
            daInvoiceDetail = clsMr.BuildSqlAdapter("SELECT *  FROM tblInvoiceDetail WHERE Del =0 AND InvoiceID=" & InvoiceID, "tblInvoiceDetail")
            clsMr.BuildSqlAdapter("SELECT *  FROM vwInvoiceDetail WHERE Del =0 AND InvoiceID=" & InvoiceID, "vwInvoiceDetail")
            blnLoading = False
            Exit Sub
        End If
        ''
        'daInvoiceDetail = clsMr.BuildSqlAdapter("SELECT *  FROM tblInvoiceDetail WHERE Del =0 AND InvoiceID=" & txtInvoiceID.Text, "tblInvoiceDetail")
        'clsMr.BuildSqlAdapter("SELECT *  FROM vwInvoiceDetail WHERE Del =0 AND InvoiceID=" & txtInvoiceID.Text, "vwInvoiceDetail")
        daInvoiceDetail = clsMr.BuildSqlAdapter("SELECT *  FROM tblInvoiceDetail WHERE Del =0 AND InvoiceID=" & mInvoiceID, "tblInvoiceDetail")
        clsMr.BuildSqlAdapter("SELECT *  FROM vwInvoiceDetail WHERE Del =0 AND InvoiceID=" & mInvoiceID, "vwInvoiceDetail")

        blnLoading = False
    End Sub

    Private Sub SaveDetail()
        ''

        ''Save detail

        'Dim lngMaxInvoiceDetailID As Long
        ' ''
        'lngMaxInvoiceDetailID = clsMr.GetMaxNumber("SELECT MAX(InvoiceDetailID) FROM tblInvoiceDetail ") + 1
        'clsMr.SetAutoNumber("tblInvoiceDetail", "InvoiceDetailID", lngMaxInvoiceDetailID)
        ''
        Dim intCounter As Integer
        Dim drAdd As DataRow
        Dim drDelete() As DataRow
        Dim drUpdate() As DataRow
        Dim dt As DataTable
        ''
        dsdata.Tables("tblInvoiceDetail").Rows.Clear()
        daInvoiceDetail = clsMr.BuildSqlAdapter("SELECT *  FROM tblInvoiceDetail WHERE Del =0 AND InvoiceID=" & txtInvoiceID.Text, "tblInvoiceDetail")


        dt = dsdata.Tables("vwInvoiceDetail").GetChanges(DataRowState.Added)
        ''
        If Not (dt Is Nothing) Then
            For intCounter = 0 To dt.Rows.Count - 1
                ''
                drAdd = dsdata.Tables("tblInvoiceDetail").NewRow()
                ''
                drAdd("InvoiceID") = txtInvoiceID.Text  'dt.Rows(intCounter)("InvoiceID")
                drAdd("ServiceID") = dt.Rows(intCounter)("ServiceID")
                drAdd("Price") = dt.Rows(intCounter)("Price")
                drAdd("PriceUnitID") = dt.Rows(intCounter)("PriceUnitID")
                drAdd("Discount") = dt.Rows(intCounter)("Discount")
                drAdd("VATAmount") = dt.Rows(intCounter)("VATAmount")
                drAdd("Quantity") = dt.Rows(intCounter)("Quantity")
                If Not IsDBNull(dt.Rows(intCounter)("Note")) Then
                    drUpdate(0)("Note") = dt.Rows(intCounter)("Note")
                End If
                drAdd("TotalCurr2") = dt.Rows(intCounter)("TotalCurr2")
                drAdd("Del") = dt.Rows(intCounter)("Del")
                ''
                dsdata.Tables("tblInvoiceDetail").Rows.Add(drAdd)
                ''
            Next

        End If

        dt = dsdata.Tables("vwInvoiceDetail").GetChanges(DataRowState.Modified)

        If Not (dt Is Nothing) Then

            For intCounter = 0 To dt.Rows.Count - 1
                drUpdate = dsdata.Tables("tblInvoiceDetail").Select("InvoiceDetailID=" & dt.Rows(intCounter)("InvoiceDetailID"))
                drUpdate(0).BeginEdit()
                drUpdate(0)("InvoiceID") = txtInvoiceID.Text    'dt.Rows(intCounter)("InvoiceID")
                drUpdate(0)("ServiceID") = dt.Rows(intCounter)("ServiceID")
                drUpdate(0)("Price") = dt.Rows(intCounter)("Price")
                drUpdate(0)("Quantity") = dt.Rows(intCounter)("Quantity")
                drUpdate(0)("PriceUnitID") = dt.Rows(intCounter)("PriceUnitID")
                drUpdate(0)("Discount") = dt.Rows(intCounter)("Discount")
                drUpdate(0)("VATAmount") = dt.Rows(intCounter)("VATAmount")
                drUpdate(0)("TotalCurr2") = dt.Rows(intCounter)("TotalCurr2")
                drUpdate(0)("Note") = dt.Rows(intCounter)("Note")
                drUpdate(0)("Del") = dt.Rows(intCounter)("Del")
                ''
                drUpdate(0).EndEdit()
            Next
        End If

        dt = dsdata.Tables("vwInvoiceDetail").GetChanges(DataRowState.Deleted)

        If Not (dt Is Nothing) Then
            dt.RejectChanges()
            For intCounter = 0 To dt.Rows.Count - 1
                drDelete = dsdata.Tables("tblInvoiceDetail").Select("InvoiceDetailID=" & dt.Rows(intCounter)("InvoiceDetailID"))
                drDelete(0).Delete()
            Next
        End If

        Dim Index As Integer
        dt = dsdata.Tables("tblInvoiceDetail").GetChanges

        'Nav.EndCurrentEdit()

        'clsMr.Update(daInvoice, "tblInvoice")
        If Not (dt Is Nothing) Then
            daInvoiceDetail.Update(dt)
            dsdata.Tables("tblInvoiceDetail").AcceptChanges()
            blnLoading = True
            dsdata.Tables("vwInvoiceDetail").AcceptChanges()
            blnLoading = False
        End If

    End Sub

    Private Sub AddComboBoxColumns1()

        'Dim comboboxColumnPriceUnit As New DataGridViewComboBoxColumn()
        Dim comboboxColumnService As New DataGridViewComboBoxColumn()

        'comboboxColumnPriceUnit = CreateComboBoxColumn("PriceUnitID", "PriceUnitID")
        comboboxColumnService = CreateComboBoxColumn("ServiceID", "ServiceID")

        'SetDataSource(comboboxColumnPriceUnit, dsdata.Tables("PriceUnit"), "PriceUnitID", "PriceUnit")
        SetDataSource(comboboxColumnService, dsdata.Tables("tblService"), "ServiceID", "ServiceName")

        'comboboxColumnPriceUnit.HeaderText = "Price Unit"
        'comboboxColumnPriceUnit.Name = "PriceUnitID"
        comboboxColumnService.HeaderText = "Service"
        comboboxColumnService.Name = "ServiceID"

        grdInvoiceDetail.Columns.Insert(0, comboboxColumnService)
        'grdInvoiceDetail.Columns.Insert(2, comboboxColumnPriceUnit)

        'grdInvoiceDetail.Columns(2).Width = 120
        grdInvoiceDetail.Columns(0).Width = 120

        'comboboxColumnPriceUnit.HeaderCell.SortGlyphDirection = SortOrder.None
        comboboxColumnService.HeaderCell.SortGlyphDirection = 0

    End Sub

    Private Sub AddComboBoxColumns2()

        'Dim comboboxColumnPriceUnit As New DataGridViewComboBoxColumn()
        Dim comboboxColumnService As New DataGridViewComboBoxColumn()

        'comboboxColumnPriceUnit = CreateComboBoxColumn("PriceUnitID", "PriceUnitID")
        comboboxColumnService = CreateComboBoxColumn("CatID", "CatID")
        'CatID,CatType
        'SetDataSource(comboboxColumnPriceUnit, dsdata.Tables("PriceUnit"), "PriceUnitID", "PriceUnit")
        SetDataSource(comboboxColumnService, dsdata.Tables("tblServiceCategory"), "CatID", "CatType")

        'comboboxColumnPriceUnit.HeaderText = "Price Unit"
        'comboboxColumnPriceUnit.Name = "PriceUnitID"
        comboboxColumnService.HeaderText = "CatType"
        comboboxColumnService.Name = "CatID"

        grdInvoiceDetail.Columns.Insert(0, comboboxColumnService)
        'grdInvoiceDetail.Columns.Insert(2, comboboxColumnPriceUnit)

        'grdInvoiceDetail.Columns(2).Width = 120
        grdInvoiceDetail.Columns(0).Width = 120

        'comboboxColumnPriceUnit.HeaderCell.SortGlyphDirection = SortOrder.None
        comboboxColumnService.HeaderCell.SortGlyphDirection = 0

    End Sub

    Private Function CreateComboBoxColumn(ByRef pDataPropertyName As String, ByRef pHeaderText As String) _
      As DataGridViewComboBoxColumn
        Dim column As New DataGridViewComboBoxColumn()

        With column
            .DataPropertyName = pDataPropertyName 'ColumnName.RefID.ToString()
            .HeaderText = pHeaderText 'ColumnName.RefID.ToString()
            .DropDownWidth = 120
            .Width = 90
            '.MaxDropDownItems = 3
            .FlatStyle = FlatStyle.Standard

        End With
        Return column

    End Function

    Private Sub SetDataSource(ByRef comboboxColumn As DataGridViewComboBoxColumn, ByRef pdt As DataTable, ByVal pStrValueMember As String, ByVal pStrDisplayMember As String)

        With comboboxColumn
            ' Dim dt As DataTable = pdt
            .DataSource = pdt
            .ValueMember = pStrValueMember '"ComplexityLevelID"
            .DisplayMember = pStrDisplayMember '"ComplexityLevelCode" '.ValueMember
        End With
    End Sub

    Public Function GetRowIndex(ByVal pInvoiceID As Long) As Integer

        Dim i As Integer

        For i = 0 To dsdata.Tables("tblInvoice").DefaultView.Count - 1
            If dsdata.Tables("tblInvoice").DefaultView.Item(i)("InvoiceID") = pInvoiceID Then
                Return i
            End If
        Next

        Return -1

    End Function

    Public Function GetInvoiceID(ByVal pInvoiceNum As Long) As Integer



        'For i = 0 To dsdata.Tables("tblInvoice").DefaultView.Count - 1
        '	If dsdata.Tables("tblInvoice").DefaultView.Item(i)("InvoiceNumber") = pInvoiceNum Then
        '		Return i
        '	End If
        'Next

        'Return -1
        Try
            Dim cmd As New SqlCommand("SELECT InvoiceID FROM tblInvoice WHERE InvoiceNumber=" & pInvoiceNum, conSql)
            ''
            conSql.Open()
            InvoiceID = cmd.ExecuteScalar
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try
        Return InvoiceID
    End Function

    Private Sub SetPeriod()
        If AddMode Then
            Select Case mPeriod

                Case 0
                    dtpInvoiceDateTo.Value = dtpInvoiceDateFrom.Value.AddMonths(1)
                    dtpInvoiceDateTo.Value = dtpInvoiceDateTo.Value.AddDays(-1)

                Case 1
                    dtpInvoiceDateTo.Value = dtpInvoiceDateFrom.Value.AddMonths(3)
                    dtpInvoiceDateTo.Value = dtpInvoiceDateTo.Value.AddDays(-1)

                Case 2
                    dtpInvoiceDateTo.Value = dtpInvoiceDateFrom.Value.AddMonths(6)
                    dtpInvoiceDateTo.Value = dtpInvoiceDateTo.Value.AddDays(-1)

                Case 3
                    dtpInvoiceDateTo.Value = dtpInvoiceDateFrom.Value.AddMonths(12)
                    dtpInvoiceDateTo.Value = dtpInvoiceDateTo.Value.AddDays(-1)
            End Select
        End If
    End Sub

    Private Sub NewRecord()
        ''
        Nav.AddNew()
        ''
        If mCorrectInvoice Then
            ''
            Dim drInvoice As DataRow
            ''
            clsMr.BuildSqlAdapter("SELECT * FROM tblInvoice WHERE Del=0 and BranchID=" & gIntBranchID & " AND InvoiceID=" & mOldInvoiceID, "tblInvoiceInitial")
            clsMr.BuildSqlAdapter("SELECT *  FROM vwInvoiceDetail WHERE Del =0 AND InvoiceID=" & mOldInvoiceID, "vwInvoiceDetailInitial")
            '	dsdata.Tables("vwInvoiceDetail").Rows.Clear()
            ''
            drInvoice = dsdata.Tables("tblInvoiceInitial").Rows(0)
            ''
            If IsDBNull(drInvoice("Description")) Then
                drInvoice("Description") = String.Empty
            End If
            txtDescription.Text = drInvoice("Description")
            txtInvoiceYY.Text = drInvoice("InvoiceYY")
            cboCategory.SelectedValue = drInvoice("CatID")
            dtpInvoiceDateFrom.Value = drInvoice("InvoiceFrom")
            dtpInvoiceDateTo.Value = drInvoice("InvoiceTo")
            cboClient.SelectedValue = drInvoice("ClientID")
            cboEmployee.SelectedValue = drInvoice("EmployeeID")
            cboDG.SelectedValue = drInvoice("DGID")
            cboCurrency.SelectedValue = drInvoice("CurrencyID")
            cboStatus.SelectedValue = 1
            dtpBilledDate.Value = drInvoice("BilledDate")
            txtTotal.Text = drInvoice("Total")
            txtRate.Text = drInvoice("Rate")
            txtTotalCurr2.Text = drInvoice("TotalCurr2")
            txtRefID.Text = mOldInvoiceNum
            ''
            'Try
            '	Dim cmd As New SqlCommand("UPDATE tblInvoice SET StatusID = 5 , RefIDTo=" & txtInvoiceNum.Text & " WHERE InvoiceID=" & mOldInvoiceID, conSql)
            '	conSql.Open()
            '	cmd.ExecuteNonQuery()
            '	conSql.Close()
            'Catch ex As Exception
            '	conSql.Close()
            'End Try
            ''
            Dim dv As DataView = dsdata.Tables("vwInvoiceDetailInitial").DefaultView
            Dim drv As DataRowView
            Dim drAdd As DataRow
            ''
            For Each drv In dv
                ''
                drAdd = dsdata.Tables("vwInvoiceDetail").NewRow()
                ''
                drAdd("invoiceID") = drv("InvoiceID") 'txtInvoiceID.Text
                drAdd("Price") = drv("Price")
                drAdd("Discount") = drv("Discount")
                drAdd("VATAmount") = drv("VATAmount")
                drAdd("Quantity") = drv("Quantity")
                drAdd("Total") = drv("Total")
                drAdd("TotalCurr2") = drv("TotalCurr2")
                drAdd("Note") = drv("Note")
                drAdd("PriceUnitID") = drv("PriceUnitID")
                drAdd("Del") = drv("Del")
                drAdd("ServiceID") = drv("ServiceID")
                ''
                dsdata.Tables("vwInvoiceDetail").Rows.Add(drAdd)
                ''
            Next
            ''
            CalculateTotal()
            setState("EDIT")
            checkValues()
            ''
            'Update Balance
            UpdateClientBalance()
            Exit Sub
        End If
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        cboClient.SelectedIndex = -1
        cboCategory.SelectedIndex = -1
        '	cboCurrency.SelectedValue = GetAcctCurrency(cboClient.SelectedValue)
        txtInvoiceYY.Text = Now.Date.Year
        txtInvoiceYY.Text = txtInvoiceYY.Text.Substring(2, 2)
        dsdata.Tables("tblInvoice").DefaultView.Item(Nav.CurrentPosition)("InvoiceYY") = txtInvoiceYY.Text
        Dim intDGID As Integer = GetBranchBillingInfo()
        If intDGID <> 0 Then
            cboDG.SelectedValue = intDGID
        End If
        txtRate.Text = GetRate(cboCurrency.SelectedValue, CurrID2, dtpInvoiceDate.Text)
        setState("NEW")
        SetPeriod()
        checkValues()
        FilterDetail()
        cboCategory.Focus()
        ''
        ' not appear type "Contract" in Category
        dsdata.Tables("tblServiceCategory").Clear()
        clsMr.BuildSqlAdapter("SELECT CatID,CatType  FROM tblServiceCategory WHERE Del =0 AND CatID <> 5", "tblServiceCategory")
        ''
        cboCategory.SelectedIndex = -1
    End Sub

    Private Sub Save()
        ''
        If AddMode Or mCorrectInvoice Then
            ''
            Dim lngMaxInvoiceID As Long
            Dim lngMaxInvoiceNum As Long
            ''
            lngMaxInvoiceID = clsMr.GetMaxNumber("SELECT MAX(InvoiceID) FROM tblInvoice ") + 1
            lngMaxInvoiceNum = clsMr.GetMaxNumber("SELECT MAX(InvoiceNumber) FROM tblInvoice ") + 1
            ''
            txtInvoiceID.Text = lngMaxInvoiceID
            txtInvoiceNum.Text = lngMaxInvoiceNum
        End If
        ''
        If dataChange Then
            ''Update Invoice
            Nav.EndCurrentEdit()
            daInvoice.Update(dsdata, "tblInvoice")
            ''Save detail
            SaveDetail()
            dataChange = False
            ''
        End If
    End Sub

    Private Sub setState(ByRef pStrMode As String)
        ''
        mStrCurrentState = UCase(pStrMode)
        '' 
        Select Case mStrCurrentState
            ''
            Case Is = "NEW"
                Me.btnSave.Enabled = False
                Me.btnCancel.Enabled = True
                Me.btnNew.Enabled = False
                btnGetService.Enabled = True
                btnRemoveService.Enabled = False
                grpInvoiceInfo.Enabled = True
                With grdInvoiceDetail
                    .ReadOnly = False
                    .Columns("Total").ReadOnly = True
                    .Columns("TotalCurr2").ReadOnly = True
                End With
                btnSave.Text = "S a v e"
                cboCategory.SelectedIndex = -1
                AddMode = True

            Case Is = "EDIT"
                ''
                Me.btnSave.Enabled = False
                Me.btnCancel.Enabled = True
                Me.btnNew.Enabled = False
                btnGetService.Enabled = True
                btnRemoveService.Enabled = True
                grpInvoiceInfo.Enabled = True
                ''
                With grdInvoiceDetail
                    .ReadOnly = False
                    .Columns("VATAmount").ReadOnly = True
                    .Columns("Total").ReadOnly = True
                    .Columns("TotalCurr2").ReadOnly = True
                    'If cboCategory.SelectedValue = 2 Or cboCategory.SelectedValue = 3 Then
                    '    ''
                    '    .Columns("Quantity").ReadOnly = True
                    'End If
                End With
                ''
                btnSave.Text = "S a v e"

            Case Is = "SAVE"
                ''
                Me.btnSave.Enabled = True
                Me.btnCancel.Enabled = False
                Me.btnNew.Enabled = True
                btnSave.Text = "E d i t"
                btnGetService.Enabled = False
                btnRemoveService.Enabled = False
                grpInvoiceInfo.Enabled = False
                grdInvoiceDetail.ReadOnly = True
                AddMode = False

            Case Is = "BROWSE"
                ''
                Me.btnSave.Enabled = True
                Me.btnCancel.Enabled = False
                Me.btnNew.Enabled = True
                btnSave.Text = "E d i t"
                btnGetService.Enabled = False
                btnRemoveService.Enabled = False
                grpInvoiceInfo.Enabled = False
                grdInvoiceDetail.ReadOnly = True
                ''
                If cboStatus.SelectedValue = 4 Then
                    btnPost.Enabled = False
                End If

            Case Is = "POST"
                ''
                Me.btnSave.Enabled = False
                Me.btnCancel.Enabled = False
                Me.btnNew.Enabled = False
                btnGetService.Enabled = False
                btnRemoveService.Enabled = False
                grpInvoiceInfo.Enabled = False
                grdInvoiceDetail.ReadOnly = True
                btnSave.Text = "E d i t"
                btnPost.Text = "U n p o s t"

            Case Is = "UNPOST"
                Me.btnSave.Enabled = False
                Me.btnCancel.Enabled = True
                Me.btnNew.Enabled = True
                btnGetService.Enabled = True
                btnRemoveService.Enabled = True
                grpInvoiceInfo.Enabled = True
                With grdInvoiceDetail
                    .ReadOnly = False
                    .Columns("Total").ReadOnly = True
                    .Columns("TotalCurr2").ReadOnly = True
                End With
                btnSave.Text = "S a v e"
                btnPost.Text = "P o s t"

            Case Is = "CORRECTED"
                btnSave.Enabled = False
                btnPost.Enabled = False
                btnPreview.Enabled = False
                btnCancel.Enabled = False
                btnGetService.Enabled = False
                btnRemoveService.Enabled = False
        End Select
        ''
        DGCA.LoadPermissionsSetState(Me, Me.Name)
    End Sub

#End Region


#Region "GrdSetUp..............."

    Private Sub DrawGrid()
        ''
        grdInvoiceDetail.DataSource = dsdata.Tables("vwInvoiceDetail").DefaultView
        grdInvoiceDetail.AllowUserToAddRows = False
        grdInvoiceDetail.Columns.Remove("ServiceID")
        ''
        AddComboBoxColumns1()
        ''
        LoadProfile(mStrSubKeyName, Me.grdInvoiceDetail)
        ''
        With grdInvoiceDetail
            ''
            .Columns("InvoiceDetailID").Visible = False
            .Columns("PriceUnitID").Visible = False
            .Columns("InvoiceID").Visible = False
            .Columns("Del").Visible = False
            .Columns("Total").ReadOnly = True
            .Columns("TotalCurr2").ReadOnly = True
            .Columns("VATAmount").ReadOnly = True
            ''
            .Columns("VATAmount").HeaderText = "VAT Amount"
            .Columns("Discount").HeaderText = "Disc. Amount"
            .ColumnHeadersHeight = btnShowCol.Height + 2
            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
            ''
            .Columns("Price").DefaultCellStyle.Format = "#,###.##"
            .Columns("Discount").DefaultCellStyle.Format = "#0#"
            .Columns("Total").DefaultCellStyle.Format = "#,###.##"
            .Columns("VatAmount").DefaultCellStyle.Format = "#0#"
            .Columns("TotalCurr2").DefaultCellStyle.Format = "#,###0.##"
            .Columns("Discount").DefaultCellStyle.ForeColor = System.Drawing.Color.Red

            .Columns("Total").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            .Columns("Total").HeaderText = "Total " & GetCompanyCurrencySymbol()
            .Columns("TotalCurr2").HeaderText = "Total " & GetCompanyCurrencySymbol2()

            ''
            If cboCategory.SelectedValue = 2 Or cboCategory.SelectedValue = 3 Or cboCategory.SelectedValue = 5 Then
                ''
                .Columns("Total").Visible = False
                chkLstGridCol.Items.Remove("Total")
                Exit Sub
            End If
        End With
        ''
        AddHandler dsdata.Tables("vwInvoiceDetail").ColumnChanged, AddressOf Column_Changed
    End Sub

    Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()
            mstrCurrentGridName = "Invoice"
            ''
            '' populate list with grid's dataSource fields...
            ''

            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdInvoiceDetail.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next
            chkLstGridCol.Items.Remove("PriceUnitID")
            chkLstGridCol.Items.Remove("ServiceID")
            chkLstGridCol.Items.Remove("InvoiceDetailID")
            chkLstGridCol.Items.Remove("InvoiceID")
            chkLstGridCol.Items.Remove("Del")

        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If
    End Sub

    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
        Dim i As Integer

        For i = 0 To Me.chkLstGridCol.Items.Count - 1
            Me.grdInvoiceDetail.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
        Next

        ''
        Me.grpShowHideColumns.Visible = False

    End Sub

    Private Sub frmInvoice_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        SaveProfile(mStrSubKeyName, Me.grdInvoiceDetail)
    End Sub

    Private Sub cboCategory_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboCategory.KeyPress
        AutoComplete(cboCategory, e)
    End Sub

    Private Sub cboCategory_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCategory.Leave
        AddNewValueToCbo(clsMr, Me.cboCategory, "tblServiceCategory", "CatID", "CatType")
    End Sub

#End Region


#Region "Form-CheckValues......."

    Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
        ''
        '' Show/Hide error list...
        If lstDataErr.Visible = True Then
            lstDataErr.Visible = False
        Else
            lstDataErr.Visible = True
            lstDataErr.Height = 100
            lstDataErr.BringToFront()
        End If

    End Sub

    Private Sub checkValues()
        ''
        If blnLoading = True Then Exit Sub
        ''
        dataChange = True
        'btnCancel.Enabled = True
        ''
        '' clear entir list & start fresh check...
        ''
        lstDataErr.Items.Clear()
        Dim intErrCount As Int16 = 0

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' check Error - Mandatory Data Objects...
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''
        If Me.cboClient.SelectedIndex = -1 Then
            lstDataErr.Items.Add("Error: Missing Client Name")
            intErrCount += 1
        End If
        If grdInvoiceDetail.Rows.Count = 0 Then
            lstDataErr.Items.Add("Error: Enter Invoice Details")
            intErrCount += 1
        End If
        If Me.cboCurrency.SelectedIndex = -1 Then
            lstDataErr.Items.Add("Error: Missing Invoice Currency")
            intErrCount += 1
        End If

        If Me.cboCategory.SelectedIndex = -1 Then
            lstDataErr.Items.Add("Error: Missing Invoice Category")
            intErrCount += 1
        End If
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' Set appropriate controls based on errors check results...
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If lstDataErr.Items.Count = 0 Then
            lstDataErr.Visible = False
            btnDataErr.Visible = False
            'lblHelpErr.Visible = False
        Else
            btnDataErr.Visible = True
            'lblHelpErr.Visible = True
        End If
        ''
        If dataChange And intErrCount = 0 Then
            btnSave.Enabled = True
            btnPost.Enabled = True

        Else
            btnSave.Enabled = False
            btnPost.Enabled = False
        End If
    End Sub

    Private Sub cboDG_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboDG.KeyUp
        checkValues()
    End Sub

    Private Sub cboDG_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDG.SelectedIndexChanged
        checkValues()
    End Sub

    Private Sub txtType_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        checkValues()
    End Sub

    Private Sub txtInvoiceYY_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInvoiceYY.TextChanged
        checkValues()
    End Sub

    Private Sub dtpInvoiceDate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpInvoiceDate.ValueChanged
        checkValues()
    End Sub

    Private Sub txtDescription_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDescription.TextChanged
        checkValues()
    End Sub

    Private Sub dtpInvoiceDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpInvoiceDateFrom.ValueChanged
        If blnLoading Then Exit Sub
        SetPeriod()
        checkValues()

    End Sub

    Private Sub dtpInvoiceDateTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpInvoiceDateTo.ValueChanged
        checkValues()
    End Sub

    Private Sub cboCurrency_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCurrency.SelectedIndexChanged
        If blnLoading Then Exit Sub

        checkValues()
        'If cboCurrency.SelectedIndex <> -1 Then

        '	If cboCurrency.SelectedValue = gIntCompanyCurrID Then
        '		txtRate.Text = 1
        '	Else
        txtRate.Text = GetRate(gIntCompanyCurrID, CurrID2, dtpInvoiceDate.Value)
        '	End If
        'End If

    End Sub

    Private Sub cboEmployee_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboEmployee.KeyUp
        checkValues()
    End Sub

    Private Sub cboEmployee_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboEmployee.SelectedIndexChanged
        checkValues()
    End Sub

    Private Sub cboCategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCategory.SelectedIndexChanged
        ''
        If blnLoading Then Exit Sub
        ''
        checkValues()
        ' ''
        'If cboCategory.SelectedValue = 2 Or cboCategory.SelectedValue = 3 Then
        '    ''
        '    grdInvoiceDetail.Columns("Quantity").ReadOnly = True
        'End If
    End Sub

    Private Sub dtpBilledDate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpBilledDate.ValueChanged
        checkValues()
    End Sub

#End Region


End Class