Imports BITSConn

Public Class frmClientList

#Region "Form-Declaration"
   ''
   Dim dsdata As New DataSet
   Dim ClsMr As ClsMain
   Dim mStrTableName As String = "tblClient"
   Dim StrSql As String = "SELECT * From tblClient where Del =0"
   Dim daClient As New SqlClient.SqlDataAdapter
	Private mStrSubKeyName As String = "Software\BIT Solutions\PDS\Settings\ClientList"
	Private blnLoading As Boolean = True

#End Region

#Region "Form- Initialization"

   Private Sub frmClientList_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		blnLoading = True
		ClsMr = New ClsMain(conSql)
      MakeDataAdapter()
		DrawGrid()
		blnLoading = False

   End Sub

   Private Sub frmClientList_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
      SaveProfile(mStrSubKeyName, grdClientList)
   End Sub

   Enum eFormType
      A
      B
      C
      D
   End Enum

#End Region

#Region "Form _Functions"
  
   Private Sub MakeDataAdapter()
      ClsMr.BuildSqlAdapter("SELECT ClientNum,ClientName,Del,ClientID From tblClient where Del =0", "Client")
      dsdata = ClsMr.getDataSet
   End Sub

   Private Sub DrawGrid()

      With grdClientList
         .DataSource = dsdata.Tables("Client").DefaultView
         .Columns("Del").Visible = False
         .Columns("ClientID").Visible = False

         .Columns("ClientNum").HeaderText = "Number"
         .Columns("ClientName").HeaderText = "Name"

         ''
         .ReadOnly = True
         .ColumnHeadersHeight = btnShowCol.Height + 2
         .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
      End With
      LoadProfile(mStrSubKeyName, Me.grdClientList)
   End Sub

   Private Sub RemoveNonVisibleField()
      chkLstGridCol.Items.Remove("Del")
      chkLstGridCol.Items.Remove("ClientID")
      chkLstGridCol.Items.Remove("ClientClassID")

   End Sub

#End Region

#Region " Form - Grid Settings..."

   Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
      If Me.grpShowHideColumns.Visible = False Then
         Me.grpShowHideColumns.Visible = True
         Me.grpShowHideColumns.BringToFront()

         '' populate list with grid's dataSource fields...
         ''

         Dim col As Windows.Forms.DataGridViewColumn
         ''
         Me.chkLstGridCol.Items.Clear()
         For Each col In grdClientList.Columns
            Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
         Next
         RemoveNonVisibleField()
      Else
         Me.grpShowHideColumns.Visible = False
         Me.grpShowHideColumns.SendToBack()
      End If

   End Sub

   Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
      Dim i As Integer

      For i = 0 To Me.chkLstGridCol.Items.Count - 1
         Me.grdClientList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
      Next

      ''
      Me.grpShowHideColumns.Visible = False
   End Sub
   Public Sub RefreshForm(ByVal Sender As Object, ByVal e As System.EventArgs)
      dsdata.Tables("Client").Rows.Clear()
      ClsMr.BuildSqlAdapter("SELECT ClientID,ClientName,ClientNum  From tblClient where Del =0", "Client")
   End Sub
#End Region

#Region "Form-UIControls"
   Private Sub btnNewClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewClient.Click
      Dim frm As New frmClient_V1(0)
      AppMain.addTabPage(frm, frmApplicationMain.eFormType.Client)
      AddHandler frm.Closed, AddressOf RefreshForm

   End Sub
   Private Sub btnEditClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditClient.Click
      If grdClientList.Rows.Count > 0 Then
         Dim dr As DataRow = dsdata.Tables("Client").DefaultView.Item(grdClientList.CurrentRow.Index).Row
         Dim frm As New frmClient_V1(dr("ClientID"))
         AppMain.addTabPage(frm, frmApplicationMain.eFormType.Client)
         AddHandler frm.Closed, AddressOf RefreshForm
      End If
   End Sub


   Private Sub btnEmployeeList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmployeeList.Click
      Dim dr As DataRow = dsdata.Tables("Client").DefaultView.Item(grdClientList.CurrentRow.Index).Row
      Dim frm As New frmClEmployeeList(dr("ClientID"))
      'MsgBox(dr("ClientID"))
      AppMain.addTabPage(frm, frmApplicationMain.eFormType.ClEmployee)
      'MsgBox(dr("ClientID"))
      'AddHandler frm.Closed, AddressOf RefreshForm

   End Sub
   Private Sub btnCloseList_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCloseList.Click
      ''Close
      Me.Close()
   End Sub
   Public Sub New()

      ' This call is required by the Windows Form Designer.
      InitializeComponent()

      ' Add any initialization after the InitializeComponent() call.

   End Sub
#End Region

#Region " TabPage Functions la a7la Mirna . . . "

   Public Function addTabPage(ByVal frm As Form, ByVal frmType As eFormType) As Boolean
      '' set mousePointer to wait...
      Windows.Forms.Cursor.Current = Cursors.WaitCursor
      ''
      Dim title As String = ""
      addTabPage = False
      ''
      Select Case frmType
         ''
         ''Accounts
         ''
         Case eFormType.A
            AddHandler CType(frm, frmClient_V1).Closed, AddressOf closeModelTabPage
            title = "Client"

         Case eFormType.B
            AddHandler CType(frm, frmClEmployeeList).Closed, AddressOf closeModelTabPage
            title = " Client Employee List "

            'Case eFormType.C
            '   AddHandler CType(frm, frmPatientMedicalHistory).Closed, AddressOf closeModelTabPage
            '   title = " Patient Medical History "

      End Select
      ''
      '' if item is open, already exit...

      Dim i As Integer
      For i = 0 To tcMain.Controls.Count - 1
         If tcMain.TabPages.Item(i).Text Is title Then
            tcMain.SelectedTab = tcMain.TabPages.Item(i)
            Exit Function
         End If
      Next

      '' go open item in a new tab...
      Dim tp As New TabPage
      ''tp = New TabPage
      tp.Text = title
      tcMain.TabPages.Add(tp)
      ''
      frm.TopLevel = False
      frm.FormBorderStyle = Windows.Forms.FormBorderStyle.None
      frm.Dock = DockStyle.Fill
      frm.Visible = True
      ''
      '' add it to main tab control...
      tp.Controls.Add(frm)
      tcMain.SelectedTab = tp
      ''
      '' set defaults...
      Windows.Forms.Cursor.Current = Cursors.Default
      addTabPage = True
   End Function

   Private Sub CloseTabPage(ByVal sender As Object, ByVal e As System.EventArgs)
      ''
      Dim tp As TabPage
      ''
      tp = CType(sender, Form).Parent
      tcMain.TabPages.Remove(tp)
   End Sub

   Private Sub closeModelTabPage(ByVal sender As Object, ByVal e As System.EventArgs)
      ''
      Dim tp As TabPage
      ''
      tp = CType(sender, Form).Parent
      tcMain.TabPages.Remove(tp)

      '' enable all tabs + navigation menu + menubar
      For Each tp In tcMain.TabPages
         tp.Enabled = True
      Next
   End Sub

#End Region

	Private Sub txtFiltByNum_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFiltByNum.KeyPress
		Integers_KeyPress(txtFiltByNum, e)
	End Sub


	Private Sub txtFiltByNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFiltByNum.TextChanged
		FilterGrid()
	End Sub

	Private Sub txtFiltByName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFiltByName.TextChanged
		FilterGrid()
	End Sub

	Private Sub FilterGrid()
		If blnLoading = True Then Exit Sub

		Dim s As String = " True"
	
		If txtFiltByNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtFiltByNum.Text)
				s = s & " AND  (ClientNum = " & tn & ")"
			Catch ex As Exception
				txtFiltByNum.Text = ""
			End Try
		End If
		If txtFiltByName.Text <> "" Then
         s = s & " AND  ClientName  LIKE '*" & txtFiltByName.Text & "*'"
		End If
		dsdata.Tables("Client").DefaultView.RowFilter = s

	End Sub

    Private Sub grdClientList_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grdClientList.DoubleClick
        If grdClientList.Rows.Count > 0 Then
            Dim dr As DataRow = dsdata.Tables("Client").DefaultView.Item(grdClientList.CurrentRow.Index).Row
            Dim frm As New frmClient_V1(dr("ClientID"))
            appMain.addTabPage(frm, frmApplicationMain.eFormType.Client)
            AddHandler frm.Closed, AddressOf RefreshForm
        End If
    End Sub
End Class