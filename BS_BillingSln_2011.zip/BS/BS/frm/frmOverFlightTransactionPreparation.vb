Imports BITSConn
Imports System.Data.SqlClient

Public Class frmOverFlightTransactionPreparation


#Region "F o r m  -  D e c l a r a t i o n s . . ."

	Private dsdata As DataSet
	Private clsMr As ClsMain
	Private WithEvents Nav As BitsNav
	Private blnLoading As Boolean
	Private mstrCurrentGridName As String
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\OverFlightPrepare\Settings"
	Private daOverFlight As SqlDataAdapter
	Private daClientItem As SqlDataAdapter
	Private daInvoice As SqlDataAdapter
	Private daInvoiceDetail As SqlDataAdapter
	Private CurrID2 As Integer
	Private s As String = ""
	Private dblInvoiceTotal As Double = 0

#End Region


#Region "F o r m  -  L o a d . . ."

	Private Sub frmOverFlightTransactionPreparation_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		''
		SaveProfile(mStrSubKeyName, Me.grdOverFlightList)
    End Sub

    Private Sub frmOverFlightTransactionPreparation_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

	Private Sub frmOverFlightTransactionPreparation_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		''
		clsMr = New ClsMain(conSql)
		Nav = New BitsNav
		''
		blnLoading = True
		MakeDataAdapter()
		SetAutoNumber()
		SetCurrency()
		FillComboBox()
		DrawGrid()
		''
		blnLoading = False
		''
		cboClient.SelectedIndex = -1
		GetCompanyCurrencies()
		txtCount.Text = grdOverFlightList.Rows.Count
		btnAutoGenerateInvoice.Enabled = False
	End Sub

	Private Sub MakeDataAdapter()
		''
		daInvoice = clsMr.BuildSqlAdapter("SELECT * FROM tblInvoice WHERE InvoiceID=0 ", "tblInvoice")
		daInvoiceDetail = clsMr.BuildSqlAdapter("SELECT * FROM tblInvoiceDetail WHERE InvoiceID=0 ", "tblInvoiceDetail")
		clsMr.BuildSqlAdapter("SELECT ClientID,ClientName FROM tblClient Where Del=0 ORDER BY ClientName ", "ClientName")
		daClientItem = clsMr.BuildSqlAdapter("SELECT ClientItemID,ClientID,RegCode,weight FROM tblClientItem Where Del=0 ", "tblClientItem")
        daOverFlight = clsMr.BuildSqlAdapter("SELECT OverFlightID,OvFl_date, OvFl_time, Reg_serial, Co_Code, Ap_orig, Ap_dest, modificationDate,Aircraft_weight,Aircraft_type FROM tblOverFlight", "tblOverFlight")
		clsMr.BuildSqlAdapter("SELECT * FROM vwOverFlightList", "vwOverFlight")
		clsMr.BuildSqlAdapter("SELECT * FROM vwOverFlightSum", "vwOverFlightSum")
        clsMr.BuildSqlAdapter("SELECT OvFl_date, OvFl_time, Reg_serial, Co_Code, Ap_orig, Ap_dest, modificationDate,Aircraft_weight FROM OverFlight", "OverFlight")

		dsdata = clsMr.getDataSet
		''
	End Sub

	Private Sub FillComboBox()
		''
		clsMr.FillComboBox("ClientName", cboClient, "ClientName", "ClientID")
	End Sub

#End Region


#Region "F o r m - I n i t i a l i s a t i o n . . . "

	Public Sub SetAutoNumber()
		''
		Dim lngMax As Long
		lngMax = clsMr.GetMaxNumber("SELECT MAX(OverFlightID) FROM tblOverFlight ") + 1
		clsMr.SetAutoNumber("tblOverFlight", "OverFlightID", lngMax)
	End Sub

	Public Sub SetCurrency()
		''
		Nav.SetCurrency(Me, dsdata, "tblOverFlight")
	End Sub

	Private Sub FilterGrid()
		''
		If blnLoading = True Then Exit Sub
		Windows.Forms.Cursor.Current = Cursors.WaitCursor
		If chkInvoiced.Checked = True Then
			s = " InvoiceID IS NOT NULL "
		Else
			s = " InvoiceID IS Null "
		End If
		''
		's = " InvoiceID IS Null "
		''
		s = s & " AND (OvFl_date Between '" & dtpDateFrom.Value.ToString("yyyy-M-d") & "' AND '" & dtpDateTo.Value.ToString("yyyy-M-d") & "') "

		If cboClient.SelectedIndex <> -1 Then
			s = s & " AND (ClientID = " & cboClient.SelectedValue & ")"
		Else
			If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
				s = s & " AND (ClientID = " & -1 & ")"
			End If
		End If
		''
		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				s = s & " AND  (InvoiceNumber = " & tn & ")"
			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		dsdata.Tables("vwOverFlight").Rows.Clear()
		clsMr.BuildSqlAdapter("SELECT * FROM vwOverFlightList  WHERE " & s, "vwOverFlight")
		''
		SetNumber()
		txtCount.Text = grdOverFlightList.Rows.Count
		''
		Windows.Forms.Cursor.Current = Cursors.Default
	End Sub

	Private Sub DrawGrid()
		''
		grdOverFlightList.DataSource = dsdata.Tables("vwOverFlight").DefaultView
		''
		dsdata.Tables("vwOverFlight").DefaultView.AllowNew = False
		''
		With grdOverFlightList
			''
			.ColumnHeadersHeight = btnShowCol.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
			''
			Dim dgvc As New DataGridViewTextBoxColumn

			dgvc.DataPropertyName = "Number"
			dgvc.HeaderText = "Number"
			dgvc.Name = "Number"
			dgvc.DefaultCellStyle.ForeColor = Color.Maroon
			.Columns.Insert(0, dgvc)
			''
			'.Columns("ICAO").ReadOnly = True
			.Columns("ClientName").ReadOnly = True
            '.Columns("Co_Code").ReadOnly = True
			.Columns("Reg_serial").ReadOnly = True
			.Columns("OvFl_date").ReadOnly = True
			.Columns("OvFl_time").ReadOnly = True
			.Columns("Ap_orig").ReadOnly = True
			.Columns("Ap_dest").ReadOnly = True
			.Columns("modificationDate").ReadOnly = True
			.Columns("TotalOverFlight").ReadOnly = True
			'.Columns("weight").ReadOnly = True
			''
			.Columns("OvFl_date").HeaderText = "Date"
			.Columns("OvFl_time").HeaderText = "Time"
			.Columns("ClientName").HeaderText = "Client Name"
			.Columns("TotalOverFlight").HeaderText = "Total Over Flight"
			''
			.Columns("TotalOverFlight").DefaultCellStyle.Format = "#,###.##"
			''
			.Columns("ClientID").Visible = False
			.Columns("InvoiceID").Visible = False
			.Columns("OverFlightID").Visible = False
			'.Columns("Ovfl_ID").Visible = False
		End With
		''
		LoadProfile(mStrSubKeyName, Me.grdOverFlightList)
		AddHandler dsdata.Tables("vwOverFlight").ColumnChanged, AddressOf Column_Changed
		''
		btnsStatus()
	End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

    End Sub

#End Region


#Region "C u s t o m   C o l u m n s . . ."

	Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
		''
		If Me.grpShowHideColumns.Visible = False Then
			Me.grpShowHideColumns.Visible = True
			Me.grpShowHideColumns.BringToFront()
			mstrCurrentGridName = "OverFlight"
			''
			'' populate list with grid's dataSource fields...
			''
			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridCol.Items.Clear()
			For Each col In grdOverFlightList.Columns
				Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
			Next
			''
			chkLstGridCol.Items.Remove("ClientID")
			chkLstGridCol.Items.Remove("InvoiceID")
			chkLstGridCol.Items.Remove("OverFlightID")
			'chkLstGridCol.Items.Remove("Ovfl_ID")
		Else
			Me.grpShowHideColumns.Visible = False
			Me.grpShowHideColumns.SendToBack()
		End If
		''
	End Sub

	Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
		Dim i As Integer

		For i = 0 To Me.chkLstGridCol.Items.Count - 1
			Me.grdOverFlightList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
		Next

		''
		Me.grpShowHideColumns.Visible = False
	End Sub

#End Region


#Region "F o r m  -  F u n c t i o n s . . ."

	Private Function CopyNewOverFlightIntoOverFlight() As Boolean
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' RUN spInsertOverFlightFromCommonDB
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		Dim command As New SqlClient.SqlCommand
		command.CommandText = "spInsertOverFlightFromCommonDB"
		Try
			command.Connection = conSql
			command.CommandType = CommandType.StoredProcedure
			conSql.Open()
			command.ExecuteNonQuery()
			conSql.Close()
		Catch ex As Exception
			conSql.Close()
		End Try
	End Function

	Private Function InsertIntotblOverFlight() As Boolean
		''
		dsdata.Tables("OverFlight").Rows.Clear()
		clsMr.BuildSqlAdapter("SELECT OvFl_date, OvFl_time, Reg_serial, Co_Code, Ap_orig, Ap_dest, modificationDate,Aircraft_weight FROM OverFlight", "OverFlight")

		Dim dvOverFlight As DataView = dsdata.Tables("OverFlight").DefaultView
		Dim drtblOverFlight As DataRow
		Dim drOverFlight As DataRowView
		Dim i As Integer

		For Each drOverFlight In dvOverFlight
			drtblOverFlight = dsdata.Tables("tblOverFlight").NewRow
			drtblOverFlight("Reg_serial") = drOverFlight("Reg_serial")
			drtblOverFlight("OvFl_date") = drOverFlight("OvFl_date")
			drtblOverFlight("OvFl_time") = drOverFlight("OvFl_time")
			drtblOverFlight("Co_Code") = drOverFlight("Co_Code")
			drtblOverFlight("Ap_orig") = drOverFlight("Ap_orig")
			drtblOverFlight("Ap_dest") = drOverFlight("Ap_dest")
			drtblOverFlight("modificationDate") = drOverFlight("modificationDate")
			drtblOverFlight("Aircraft_weight") = drOverFlight("Aircraft_weight")
			dsdata.Tables("tblOverFlight").Rows.Add(drtblOverFlight)
		Next

		daOverFlight.Update(dsdata, "tblOverFlight")
	End Function

	Private Function GetBranchBillingInfo()
		''
		Dim intDGID As Integer

		Try
			Dim cmd As New SqlClient.SqlCommand("SELECT DGID FROM tblBranchBillingInfo WHERE BranchID=" & gIntBranchID, conSql)
			conSql.Open()
			intDGID = cmd.ExecuteScalar()
			conSql.Close()
			Return intDGID
		Catch ex As Exception
			conSql.Close()
			Return 0
		End Try
	End Function

	Private Sub UpdateInvoiceDetail(ByVal pInvoiceID As Integer, ByVal pTotal As Double, ByVal pServiceID As Integer, ByVal pQty As Integer) ', Optional ByVal pQty As Integer = 1)
		''
		Dim drInvoiceDetail As DataRow = dsdata.Tables("tblInvoiceDetail").NewRow
		drInvoiceDetail("InvoiceID") = pInvoiceID
		drInvoiceDetail("InvoiceDetailID") = clsMr.GetMaxNumber("InvoiceDetailID", "tblInvoiceDetail") + 1
		drInvoiceDetail("ServiceID") = pServiceID
		drInvoiceDetail("Price") = pTotal
		dblInvoiceTotal += drInvoiceDetail("Price")
		drInvoiceDetail("Discount") = 0
		drInvoiceDetail("VATAmount") = 0
		drInvoiceDetail("Del") = 0
		drInvoiceDetail("Quantity") = pQty
		drInvoiceDetail("PriceUnitID") = 1
		drInvoiceDetail("TotalCurr2") = GetExchangeValue(gIntCompanyCurrID, CurrID2, Now.Date, pTotal)
		dsdata.Tables("tblInvoiceDetail").Rows.Add(drInvoiceDetail)
		daInvoiceDetail.Update(dsdata, "tblInvoiceDetail")
	End Sub

	Private Function GetServicePrice(ByVal intServiceID As Integer) As Double
		''
		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand

		''
		Dim dblPrice As Double
		''
		strSQL = "select Price,AdditionalCharge   FROM  dbo.tblService  WHERE dbo.tblService.ServiceID=  " & intServiceID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text

		conSql.Open()
		dRdr = cmdX.ExecuteReader()

		If dRdr.Read Then
			dblPrice = dRdr("Price")

		End If

		dRdr.Close()
		conSql.Close()
		Return dblPrice
		''
	End Function

	Private Function GetServiceAdditionalCharge(ByVal intServiceID As Integer) As Double
		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand

		''
		Dim dblAddCharge As Double
		''
		strSQL = "select AdditionalCharge   FROM  dbo.tblService  WHERE dbo.tblService.ServiceID=  " & intServiceID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text

		conSql.Open()
		dRdr = cmdX.ExecuteReader()

		If dRdr.Read Then


			If Not dRdr("AdditionalCharge") Is DBNull.Value Then
				dblAddCharge = dRdr("AdditionalCharge")
			End If

		End If

		dRdr.Close()
		conSql.Close()
		Return dblAddCharge
	End Function

	Private Sub RefreshGrid()
		''
		dsdata.Tables("vwOverFlight").Rows.Clear()
		clsMr.BuildSqlAdapter("SELECT * FROM vwOverFlightList", "vwOverFlight")
	End Sub

	Private Sub updateClient()
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		Try
			Dim cmd As New SqlCommand("Update tblOverFlight set ClientID = tblClient.ClientID FROM tblClient INNER JOIN tblOverFlight ON tblOverFlight.Co_Code = tblClient.ICAO WHERE tblOverFlight.InvoiceID is Null", conSql)

			conSql.Open()
			cmd.ExecuteNonQuery()
			conSql.Close()

		Catch ex As Exception
			Windows.Forms.Cursor.Current = Cursors.Default()
			conSql.Close()
		End Try
		Windows.Forms.Cursor.Current = Cursors.Default()
		FilterGrid()
		' btnUpdateHours.Enabled = True
		'btnUpdatePrice.Enabled = False
		'btnUpdateClient.Enabled = False
	End Sub

	Private Sub GetCompanyCurrencies()
		''
		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand
		''
		strSQL = "select * FROM  dbo.tblCompany  WHERE dbo.tblCompany.companyID=  " & gIntCompanyID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text
		''
		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			CurrID2 = dRdr("CurrID2")
		End If
		dRdr.Close()
		conSql.Close()
	End Sub

	Private Sub btnsStatus()
		''
		If grdOverFlightList.Rows.Count = 0 Then
			btnAutoGenerateInvoice.Enabled = False
			'btnUpdateClient.Enabled = False
			btnUpdatePrice.Enabled = False
            'btnCopyData.Enabled = True
		Else
			'If btnSave.Enabled = False Then
			'btnAutoGenerateInvoice.Enabled = True
			'btnSave.Enabled = False
			'btnUpdateClient.Enabled = True
			'***********************************************************************************************************'
			'btnUpdatePrice.Enabled = True
			'btnUpdateHours.Enabled = True
			'btnUpdatePrice.Enabled = False
            'btnCopyData.Enabled = True
		End If
	End Sub

	Private Sub Column_Changed(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
		''
		If blnLoading Then Exit Sub
		''
		If grdOverFlightList.Rows.Count = 0 Then Exit Sub
		If (grdOverFlightList.CurrentRow) Is Nothing Then
			Exit Sub
		End If

		'If e.Column.ColumnName = "weight" Then

		'	'Dim dv As DataView = dsdata.Tables("vwTransaction").DefaultView
		'	Dim dr As DataRow = dsdata.Tables("vwOverFlight").DefaultView.Item(grdOverFlightList.CurrentRow.Index).Row

		'	'	For Each drv In dv

		'	If dr("Weight") Is DBNull.Value Then
		'		dr("Reg_Weight") = 0
		'	End If
		'	''
		'	If dr("Reg_Weight") <= 75 Then
		'		dr("TotalOverFlight") = 75000

		'	Else
		'		dr("TotalOverFlight") = 150000
		'	End If
		'End If
		''
		If e.Column.ColumnName = "Aircraft_weight" Or e.Column.ColumnName = "Aircraft_type" Or e.Column.ColumnName = "Co_Code" Then 'e.Column.ColumnName = "Weight" Or
			''
			btnSave.Enabled = True
		End If
		''
		'If e.Column.ColumnName = "ClientID" And Not IsDBNull(grdMessageList.Item("InvoiceID", grdMessageList.CurrentRow.Index).Value) Then
		'	''
		'	'grdMessageList.Item("InvoiceNumber", grdMessageList.CurrentRow.Index).Value = Nothing
		'	''
		'	'''''''''''''''''''''''''''''''''''
		'	'Remove InvoiceID For This Message 
		'	'''''''''''''''''''''''''''''''''''
		'	''
		'	Try
		'		Dim cmd As New SqlCommand("Update tblMessage SET InvoiceID = NULL, ClientID = " & grdMessageList.Item("ClientID", grdMessageList.CurrentRow.Index).Value & "  WHERE MessageID = " & grdMessageList.Item("MessageID", grdMessageList.CurrentRow.Index).Value, conSql)
		'		conSql.Open()
		'		cmd.ExecuteNonQuery()
		'		conSql.Close()
		'	Catch ex As Exception
		'		conSql.Close()
		'	End Try
		''

		If e.Column.ColumnName = "ICAO" Then 'And Not IsDBNull(grdOverFlightList.Item("InvoiceID", grdOverFlightList.CurrentRow.Index).Value) Then
			''
			Dim dRdr As SqlClient.SqlDataReader
			''
			Dim cmd As New SqlCommand("SELECT ClientID, ClientName FROM tblClient WHERE ICAO= '" & grdOverFlightList.Item("ICAO", grdOverFlightList.CurrentRow.Index).Value & "'", conSql)
			conSql.Open()
			dRdr = cmd.ExecuteReader()
			If dRdr.Read Then
				grdOverFlightList.Item("ClientID", grdOverFlightList.CurrentRow.Index).Value = dRdr("ClientID")
				grdOverFlightList.Item("ClientName", grdOverFlightList.CurrentRow.Index).Value = dRdr("ClientName")
			End If
			dRdr.Close()
			conSql.Close()
			''
			Try
				Dim cmdUpdate As New SqlCommand("Update tblOverFlight SET InvoiceID = NULL, ClientID = " & grdOverFlightList.Item("ClientID", grdOverFlightList.CurrentRow.Index).Value & "  WHERE OverFlightID = " & grdOverFlightList.Item("OverFlightID", grdOverFlightList.CurrentRow.Index).Value, conSql)
				conSql.Open()
				cmdUpdate.ExecuteNonQuery()
				conSql.Close()
			Catch ex As Exception
				conSql.Close()
			End Try
			'UpdateClient()
			FilterGrid()
			'btnSave.Enabled = True
			'btnUpdatePrice.Enabled = False
            'btnUpdateClient.Enabled = True
		End If

	End Sub

	Private Function InvoiceFilterString()
		''
		If blnLoading Then Exit Function
		''
		Dim strfilter As String = ""
		''
		If chkInvoiced.Checked = True Then
			strfilter = " NOT ISNULL({vwOverFlight.InvoiceID}) "
		Else
			strfilter = " ISNULL({vwOverFlight.InvoiceID}) "
		End If
		''
		'strfilter = " ISNULL({vwOverFlight.InvoiceID}) "
		''
		strfilter = strfilter & " AND ({vwOverFlight.OvFl_date} >= #" & dtpDateFrom.Value.ToString("MM/dd/yyyy") & "#)  AND ({vwOverFlight.OvFl_date} <= #" & dtpDateTo.Value.ToString("MM/dd/yyyy") & "#)"

		If cboClient.SelectedIndex <> -1 Then
			strfilter = strfilter & " AND ({vwOverFlight.ClientID} = " & cboClient.SelectedValue & ")"
		Else
			If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
				strfilter = strfilter & " AND ({vwOverFlight.ClientID} = " & -1 & ")"
			End If
		End If
		''
		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				If strfilter = "" Then
					strfilter &= "   ({vwOverFlight.InvoiceNumber} = " & tn & ")"
				Else
					strfilter &= " AND  ({vwOverFlight.InvoiceNumber} = " & tn & ")"
				End If

			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		Return strfilter
		''
	End Function

    'Private Function CheckUserGenInvoice() As Integer
    '	''
    '	Dim IntUserGenInvoice As Integer
    '	''
    '	Dim cmd As New SqlCommand("Select UserGenInvoiceID from tblUserGenInvoice ", conSql)
    '	Try
    '		conSql.Open()
    '		IntUserGenInvoice = cmd.ExecuteScalar
    '		conSql.Close()
    '	Catch ex As Exception
    '		conSql.Close()
    '	End Try
    '	''
    '	If IntUserGenInvoice > 0 Then
    '		Return IntUserGenInvoice
    '	Else
    '		Return -1
    '	End If
    '	''
    'End Function

    'Private Sub SetUserGenInvoice()
    '	''
    '	Dim strUserName As String
    '	''
    '	Dim cmd As New SqlCommand("SELECT UserName FROM vwUsers WHERE EmployeeID=" & gIntUserID, conSql)
    '	Try
    '		conSql.Open()
    '		strUserName = cmd.ExecuteScalar
    '		conSql.Close()
    '	Catch ex As Exception
    '		conSql.Close()
    '		''
    '	End Try
    '	''
    '	Dim cmdInsert As New SqlCommand("INSERT INTO tblUserGenInvoice(UserGenInvoiceID, UserGenInvoiceName, Del)VALUES(" & gIntUserID & " ,'" & strUserName & "',1)", conSql)
    '	Try
    '		conSql.Open()
    '		cmdInsert.ExecuteScalar()
    '		conSql.Close()
    '	Catch ex As Exception
    '		conSql.Close()
    '	End Try
    '	''
    'End Sub

	Private Sub SetNumber()
		''
		Dim i As Integer
		''
		For i = 0 To grdOverFlightList.Rows.Count - 1
			''
			grdOverFlightList.Rows(i).Cells("Number").Value = i + 1
		Next
		''
	End Sub

	Private Sub txt_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
		''
		Select Case grdOverFlightList.Columns(grdOverFlightList.CurrentCell.ColumnIndex).Name
			''
			Case "Aircraft_weight"
				''
				IntDecimal_KeyPress(sender, e)

		End Select
	End Sub

#End Region


#Region "G r i d  -  F i l t e r . . ."


#End Region


#Region "F o r m - U I / M e t h o d s . . . "

    Private Sub btnCopyData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' COPY Data FROM OverFlight in CommonDB TO OverFlight IN Billing...
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        CopyNewOverFlightIntoOverFlight()
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' COPY Data - INTO Billing - FROM OverFlight TO tblOverFlight...
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        InsertIntotblOverFlight()
        ''
        Try
            Dim cmd As New SqlClient.SqlCommand("DELETE FROM [OverFlight]", conSql)
            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try

        updateClient()
        'RefreshGrid()
        FilterGrid()
        'btnCopyData.Enabled = False
        'btnUpdatePrice.Enabled = True
        'btnAutoGenerateInvoice.Enabled = False
    End Sub

	Private Sub btnAutoGenerateInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAutoGenerateInvoice.Click
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ''
        Dim strMsg As String = "Are you sure you want to Generate "
        Dim strComputerName As String = ""
        ''
        If grdOverFlightList.Rows.Count > 1 Then
            ''
            strMsg &= "these " & grdOverFlightList.Rows.Count & " Transactions "
        Else
            strMsg &= "this Transaction"
        End If
        ''
        ''
        If MsgBox(strMsg & "?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            If CheckUserGenInvoice() <> -1 And CheckDate() Then
                strComputerName = GetComputerName()
                MsgBox("You Cannot Generate an Invoice At this Time ,Another User Generate Invoice At Computer: <" & strComputerName & ">", , "Try Again Later")
                Exit Sub
            Else
                DeleteUserGenInvoice()
                SetUserGenInvoice()
            End If
            ''
            Dim strSql As String = ""
            Dim strsqlSort As String = ""
            ''
            strSql = "Select ClientID,Count(OverFlightID) as Count,SUM(TotalOverFlight) AS TotalOverFlight From tblOverFlight WHERE InvoiceID IS Null AND (OvFl_date  Between '" & dtpDateFrom.Value.ToString("MM/dd/yyyy") & "' AND '" & dtpDateTo.Value.ToString("MM/dd/yyyy") & "')"
            ''
            strsqlSort = "SELECT TOP 100 PERCENT dbo.tblOverFlight.ClientID, Count(OverFlightID) as Count, SUM(dbo.tblOverFlight.TotalOverFlight) AS TotalOverFlight, dbo.tblClient.ClientName"
            strsqlSort &= " FROM dbo.tblOverFlight LEFT OUTER JOIN  dbo.tblClient ON dbo.tblOverFlight.ClientID = dbo.tblClient.ClientID"
            strsqlSort &= " WHERE (dbo.tblOverFlight.InvoiceID Is NULL) AND (OvFl_date  Between '" & dtpDateFrom.Value.ToString("MM/dd/yyyy") & "' AND '" & dtpDateTo.Value.ToString("MM/dd/yyyy") & "')"

            ''
            dsdata.Tables("vwOverFlightSum").Rows.Clear()
            ''
            'If cboClient.SelectedIndex <> -1 Then
            'clsMr.BuildSqlAdapter("Select ClientID,Count(OverFlightID) as Count,SUM(TotalOverFlight) AS TotalOverFlight From tblOverFlight WHERE ClientID=" & cboClient.SelectedValue & " AND InvoiceID IS Null AND (OvFl_date >= '" & dtpDateFrom.Value.ToShortDateString() & "')" & "   Group BY ClientID", "vwOverFlightSum")	' AND (OvFl_date <= '" & dtpDateTo.Value.ToShortDateString() & "')
            '   Else
            'clsMr.BuildSqlAdapter("Select ClientID,Count(OverFlightID) as Count,SUM(TotalOverFlight) AS TotalOverFlight From tblOverFlight WHERE InvoiceID IS Null AND (OvFl_date >= '" & dtpDateFrom.Value.ToShortDateString() & "')" & "  Group BY ClientID", "vwOverFlightSum") 'AND (OvFl_date <= '" & dtpDateTo.Value.ToShortDateString() & "') 
            '   End If
            If cboClient.SelectedIndex <> -1 Then
                strSql &= " AND dbo.tblOverFlight.ClientID=" & cboClient.SelectedValue
                strsqlSort &= " AND dbo.tblOverFlight.ClientID=" & cboClient.SelectedValue

            End If

            'Dim str As String = "Select ClientID,Count(OverFlightID) as Count,SUM(TotalOverFlight) AS TotalOverFlight From tblOverFlight WHERE ClientID=" & cboClient.SelectedValue & " AND InvoiceID IS Null AND (OvFl_date Between '" & dtpDateFrom.Value.ToString("MM/dd/yyyy") & "' AND '" & dtpDateTo.Value.ToString("MM/dd/yyyy") & "')   Group BY ClientID"
            ''
            strsqlSort &= " GROUP BY dbo.tblOverFlight.ClientID, dbo.tblClient.ClientName"
            strsqlSort &= " HAVING(dbo.tblOverFlight.ClientID Is Not NULL)"
            strsqlSort &= " ORDER BY dbo.tblClient.ClientName"
            strSql &= " Group BY dbo.tblOverFlight.ClientID"
            ''
            clsMr.BuildSqlAdapter(strsqlSort, "vwOverFlightSum")
            Dim dv As DataView = dsdata.Tables("vwOverFlightSum").DefaultView
            Dim drv As DataRowView
            For Each drv In dv
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                ''Create Invoice
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                Dim drInvoice As DataRow = dsdata.Tables("tblInvoice").NewRow
                dblInvoiceTotal = 0
                drInvoice("InvoiceID") = clsMr.GetMaxNumber("InvoiceID", "tblInvoice") + 1
                drInvoice("CatID") = 2
                drInvoice("InvoiceNumber") = clsMr.GetMaxNumber("InvoiceNumber", "tblInvoice") + 1
                drInvoice("InvoiceFrom") = dtpDateFrom.Value
                ''
                Dim strYear As String = Now.Date.Year
                strYear = strYear.Substring(2, 2)
                drInvoice("InvoiceYY") = strYear
                Dim intDG As Integer = GetBranchBillingInfo()
                If intDG <> 0 Then
                    drInvoice("DGID") = intDG
                End If

                drInvoice("InvoiceTo") = dtpDateTo.Value
                drInvoice("InvoiceDate") = Now.Date
                drInvoice("CurrencyID") = gIntCompanyCurrID
                drInvoice("Rate") = GetRate(gIntCompanyCurrID, CurrID2, Now.Date)
                drInvoice("StatusID") = 1
                drInvoice("BilledDate") = Now.Date
                drInvoice("EmployeeID") = gIntUserID
                drInvoice("BranchID") = gIntBranchID
                drInvoice("Del") = 0
                'drInvoice("Description") = "Auto Generated Invoice Number:" & drInvoice("InvoiceNumber")
                drInvoice("Description") = "Over Flight for " & dtpDateFrom.Value.ToString("MMMM") & " " & dtpDateFrom.Value.Year

                drInvoice("CreateByID") = gIntUserID
                drInvoice("CreateDate") = Now.Date
                drInvoice("AutoGel") = 1
                drInvoice("ClientID") = drv("ClientID")
                dsdata.Tables("tblInvoice").Rows.Add(drInvoice)
                daInvoice.Update(dsdata, "tblInvoice")
                ''
                Dim dvOvF As DataView = dsdata.Tables("vwOverFlight").DefaultView
                '.Select("ClientID=" & drv("ClientID") & " AND (Dat_orig >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (Dat_orig <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "'")
                Dim drvOvF As DataRowView
                For Each drvOvF In dvOvF
                    drvOvF("InvoiceID") = drInvoice("InvoiceID")

                    'Dim cmd As New SqlCommand("Update tblOverFlight set InvoiceID =" & drInvoice("InvoiceID") & " WHERE  tblOverFlight.OverFlightID =" & drvOvF("OverFlightID"), conSql)
                    Dim cmd As New SqlCommand("Update tblOverFlight set InvoiceID =" & drInvoice("InvoiceID") & " WHERE  tblOverFlight.OverFlightID =" & drvOvF("OverFlightID") & " AND tblOverFlight.ClientID=" & drv("ClientID"), conSql)


                    conSql.Open()
                    cmd.ExecuteNonQuery()
                    conSql.Close()
                Next
                UpdateInvoiceDetail(drInvoice("InvoiceID"), drv("TotalOverFlight"), 7, drv("Count"))

                ''calculate invoice total and update to invoice

                drInvoice("Total") = dblInvoiceTotal
                drInvoice("TotalCurr2") = GetExchangeValue(gIntCompanyCurrID, CurrID2, Now.Date, drInvoice("Total"))
                daInvoice.Update(dsdata, "tblInvoice")

            Next
            FilterGrid()
            ''
            DeleteUserGenInvoice()
            MsgBox("Invoice(s) Successefully Generated")
            ''
            btnAutoGenerateInvoice.Enabled = False
        Else
            ''
        End If
        ''
        Windows.Forms.Cursor.Current = Cursors.Default

    End Sub

    Private Sub btnUpdateClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor()
        Try
            Dim cmd As New SqlCommand("Update tblOverFlight set ClientID = tblClient.ClientID FROM tblClient INNER JOIN tblOverFlight ON tblOverFlight.Co_Code = tblClient.ICAO WHERE tblOverFlight.InvoiceID is Null", conSql)

            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()

        Catch ex As Exception
            Windows.Forms.Cursor.Current = Cursors.Default()
            conSql.Close()
        End Try
        Windows.Forms.Cursor.Current = Cursors.Default()
        FilterGrid()
        ' btnUpdateHours.Enabled = True
        'btnUpdatePrice.Enabled = False
        'btnUpdateClient.Enabled = False
        'CalculateTotal()
        RefreshGrid()
    End Sub

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		Me.Close()
	End Sub

	Private Sub cboClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
		AutoComplete(cboClient, e)
	End Sub

	Private Sub cboClient_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyUp
		FilterGrid()
	End Sub

	Private Sub cboClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
		FilterGrid()
	End Sub

	Private Sub btnUpdatePrice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdatePrice.Click
		''
		If blnLoading Then Exit Sub
		''
		blnLoading = True
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		''
		Dim dv As DataView = dsdata.Tables("vwOverFlight").DefaultView
		Dim drv As DataRowView
		For Each drv In dv
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			' the service of nunber '7' is Over Flight 
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'If IsDBNull(drv("Weight")) Then
            '	drv("Weight") = 0
            'End If

            'If drv("Weight") >= 0 And drv("Weight") <= 70 Then
            '	''
            '	drv("TotalOverFlight") = GetServicePrice(7)		 '75000 
            '	''
            'Else
            '	''
            '	drv("TotalOverFlight") = GetServiceAdditionalCharge(7)  ''150 000
            '	''
            'End If

            If IsDBNull(drv("Aircraft_Weight")) Then
                drv("Aircraft_Weight") = 0
            End If

            If drv("Aircraft_Weight") >= 0 And drv("Aircraft_Weight") <= 70 Then
                ''
                drv("TotalOverFlight") = GetServicePrice(7)      '75000 
                ''
            Else
                ''
                drv("TotalOverFlight") = GetServiceAdditionalCharge(7)  ''150 000
                ''
            End If

			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			''update command to update tblOverFlight
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

			Dim cmd As New SqlCommand("UPDATE tblOverFlight SET TotalOverFlight=" & drv("TotalOverFlight") & " WHERE OverFlightID=" & drv("OverFlightID"), conSql)
			conSql.Open()
			cmd.ExecuteNonQuery()
			conSql.Close()
		Next
		btnUpdatePrice.Enabled = False
		btnAutoGenerateInvoice.Enabled = True
		blnLoading = False
	End Sub

	Private Sub dtpDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateFrom.ValueChanged
		FilterGrid()
	End Sub

	Private Sub dtpDateTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateTo.ValueChanged
		FilterGrid()
	End Sub

	Private Sub chkInvoiced_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkInvoiced.CheckedChanged
		''
		FilterGrid()
		''
		If chkInvoiced.Checked = True Then
			btnUpdatePrice.Enabled = False
			btnAutoGenerateInvoice.Enabled = False
            'btnCopyData.Enabled = False
		Else
			btnUpdatePrice.Enabled = True
            'btnCopyData.Enabled = True
		End If
	End Sub

	Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
		''
		If grdOverFlightList.RowCount = 0 Then Exit Sub

		Dim frm As New frmQuickReport
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		Dim rpt As New rptOverFlightList
		Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table

		Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
		''
		For Each tbCurrent In rpt.Database.Tables
			tliCurrent = tbCurrent.LogOnInfo
			''
			With tliCurrent.ConnectionInfo
				.ServerName = gStrServerName
				.DatabaseName = gStrDataBaseName
				.UserID = "" 'gStrUserName
				.Password = ""	 'gStrPassword
			End With

			tbCurrent.ApplyLogOnInfo(tliCurrent)
		Next tbCurrent

		Dim strFilter As String = InvoiceFilterString()
		frm.crvInstantViewer.SelectionFormula = strFilter
		frm.crvInstantViewer.ReportSource = rpt
		rpt.SetParameterValue("DateFrom", Format(dtpDateFrom.Value, "MMMM"))
		rpt.SetParameterValue("DateTo", Format(dtpDateTo.Value, "MMMM"))
		rpt.SetParameterValue("Year", dtpDateFrom.Value.Year)

		frm.crvInstantViewer.Refresh()
		frm.Show()

		frm.crvInstantViewer.DisplayToolbar = True
		Windows.Forms.Cursor.Current = Cursors.Default()
		''
	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		''
		Dim intCounter As Integer
		Dim drUpdate() As DataRow
		Dim dt As DataTable
		Dim strRegSerial As String
        Dim i As Integer = 0
        Dim j As Integer
		'
		dt = dsdata.Tables("vwOverFlight").GetChanges(DataRowState.Modified)
		''
		If Not (dt Is Nothing) Then
			'For intCounter = 0 To dt.Rows.Count - 1
			'	drUpdate = dsdata.Tables("tblOverFlight").Select("OverFlightID=" & dt.Rows(intCounter)("OverFlightID"))
			'	drUpdate(0).BeginEdit()
			'	drUpdate(0)("weight") = dt.Rows(intCounter)("weight")
			'	drUpdate(0).EndEdit()
			'Next
			strRegSerial = dt.Rows(intCounter)("Reg_Serial")
			For intCounter = 0 To dt.Rows.Count - 1
				'drUpdate = dsdata.Tables("tblClientItem").Select("RegCode='" & dt.Rows(intCounter)("Reg_Serial") & "'")
				drUpdate = dsdata.Tables("tblOverFlight").Select("OverFlightID='" & dt.Rows(intCounter)("OverFlightID") & "'")
                'drUpdate = dsdata.Tables("tblClientItem").Select("ClientItemID='" & dt.Rows(intCounter)("ClientItemID") & "'")
                ''
                For i = 1 To grdOverFlightList.Rows.Count
                    ''
                    If grdOverFlightList.Item("OverFlightID", i).Value = dt.Rows(intCounter)("OverFlightID") Then
                        ''
                        j = i
                        Exit For
                    End If
                Next
				''
				If drUpdate.Length > 0 Then
					drUpdate(0).BeginEdit()
					'drUpdate(0)("Weight") = dt.Rows(intCounter)("Weight")
					drUpdate(0)("Aircraft_Weight") = dt.Rows(intCounter)("Aircraft_Weight")
                    ''Co_Code
                    drUpdate(0)("Aircraft_type") = dt.Rows(intCounter)("Aircraft_type")
                    drUpdate(0)("Co_Code") = dt.Rows(intCounter)("Co_Code")

                    drUpdate(0).EndEdit()
				Else
					'If strRegSerial = dt.Rows(intCounter)("Reg_Serial") And i = 0 Then
					'	''
					'	i += 1
					'	''
					'	MsgBox("The Reg_Serial :<" & dt.Rows(intCounter)("Reg_Serial") & "> does Not Exist Into ClientItem Please Add It Then Update The Weight")
					'End If
				End If
			Next
			''
		End If
		''
		'ToDo : SAve ICAO & ClientID + Refresh GRid

		'dt = dsdata.Tables("tblClientItem").GetChanges
		dt = dsdata.Tables("tblOverFlight").GetChanges

		If Not (dt Is Nothing) Then
			'daClientItem.Update(dt)
			daOverFlight.Update(dt)

			'dsdata.Tables("tblClientItem").AcceptChanges()
			dsdata.Tables("tblOverFlight").AcceptChanges()

			dsdata.Tables("vwOverFlight").AcceptChanges()
		End If
        ''
        'Dim cr As Integer
        'cr = grdOverFlightList.FirstDisplayedScrollingRowIndex

		FilterGrid()
        'grdOverFlightList.FirstDisplayedScrollingRowIndex = cr
        grdOverFlightList.FirstDisplayedScrollingRowIndex = j
        ''
        btnSave.Enabled = False
        btnUpdatePrice.Enabled = True
        ''
        grdOverFlightList.ClearSelection()
        grdOverFlightList.Rows(j).Selected = True
        ''
        Windows.Forms.Cursor.Current = Cursors.Default()
	End Sub

	Private Sub txtInvoiceNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInvoiceNum.TextChanged
		''
		FilterGrid()
	End Sub

	Private Sub grdOverFlightList_ColumnHeaderMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdOverFlightList.ColumnHeaderMouseClick
		''
		SetNumber()
	End Sub

	Private Sub grdOverFlightList_EditingControlShowing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles grdOverFlightList.EditingControlShowing
		''
		If blnLoading Then Exit Sub
		''
		Select Case grdOverFlightList.Columns(grdOverFlightList.CurrentCell.ColumnIndex).Name
			Case "Aircraft_weight"
				Dim txt As TextBox
				txt = e.Control
				RemoveHandler txt.KeyPress, AddressOf txt_KeyPress
				AddHandler txt.KeyPress, AddressOf txt_KeyPress
		End Select
	End Sub

	Private Sub grdOverFlightList_CellLeave(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdOverFlightList.CellLeave
		''
		Select Case grdOverFlightList.Columns(grdOverFlightList.CurrentCell.ColumnIndex).Name
			''

			Case "Aircraft_type"
				Dim str As String
				str = grdOverFlightList.Item("Aircraft_type", grdOverFlightList.CurrentRow.Index).Value.ToString()
				Dim c() As Char = str.ToCharArray
				If c.Length > 10 Then
					'MsgBox("error")
					grdOverFlightList.Item("Aircraft_type", grdOverFlightList.CurrentRow.Index).Value = str.Substring(0, 9)
				End If
		End Select
	End Sub

	Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor
		RefreshGrid()
		FilterGrid()
		Windows.Forms.Cursor.Current = Cursors.Default

	End Sub

#End Region


End Class