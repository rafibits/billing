Imports BITSConn 'zedAug2007 dataService
Public Class frmCompany_old
	Inherits System.Windows.Forms.Form
	'zedAug2007 Implements clsIMain

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Friend WithEvents lblCompanyName As System.Windows.Forms.Label
	Friend WithEvents lblCurrID As System.Windows.Forms.Label
	Friend WithEvents lblNote As System.Windows.Forms.Label
	Friend WithEvents txtNote As System.Windows.Forms.TextBox
	Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
	Friend WithEvents btnSave As BHBut.BouncingHoverButton
	Friend WithEvents lblTo As System.Windows.Forms.Label
	Friend WithEvents grdBranch As System.Windows.Forms.DataGrid
	Friend WithEvents txtCompanyName As System.Windows.Forms.TextBox
	Friend WithEvents btnEditBranchAcct As BHBut.BouncingHoverButton
	Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker
	Friend WithEvents dtpDateTo As System.Windows.Forms.DateTimePicker
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents btnNew As BHBut.BouncingHoverButton
	Friend WithEvents btnEdit As BHBut.BouncingHoverButton
	Friend WithEvents pnlCompanyInfo As System.Windows.Forms.Panel
	Friend WithEvents PicPersonnel As System.Windows.Forms.PictureBox
	Friend WithEvents btnGetPicture As System.Windows.Forms.Button
	Friend WithEvents ofdGetPhoto As System.Windows.Forms.OpenFileDialog
	Friend WithEvents fbdDataFile As System.Windows.Forms.FolderBrowserDialog
	Friend WithEvents txtLocation As System.Windows.Forms.TextBox
	Friend WithEvents tcBranches As System.Windows.Forms.TabControl
	Friend WithEvents tpBranch As System.Windows.Forms.TabPage
	Friend WithEvents tpBranchAccts As System.Windows.Forms.TabPage
	Friend WithEvents grpBranchAccounts As System.Windows.Forms.GroupBox
	Friend WithEvents grpCompanyInfo As System.Windows.Forms.GroupBox
	Friend WithEvents gpBranchName As System.Windows.Forms.GroupBox
	Friend WithEvents txtBranchName As System.Windows.Forms.TextBox
	Friend WithEvents btnOK As BHBut.BouncingHoverButton
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents txtCompanyNumber As System.Windows.Forms.TextBox
	Friend WithEvents lblCompanyNumber As System.Windows.Forms.Label
	Friend WithEvents lblCurrID1 As System.Windows.Forms.Label
	Friend WithEvents cboCurrID As System.Windows.Forms.ComboBox
	Friend WithEvents txtCurrBal As System.Windows.Forms.TextBox
	Friend WithEvents lblCurrBal As System.Windows.Forms.Label
	Friend WithEvents btnDataErr As System.Windows.Forms.Button
	Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
	Friend WithEvents btnCancelMain As BHBut.BouncingHoverButton
	Friend WithEvents lblCurrency2 As System.Windows.Forms.Label
	Friend WithEvents cboCurrency2 As System.Windows.Forms.ComboBox
	Friend WithEvents btnCancel As BHBut.BouncingHoverButton
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCompany_old))
		Me.lblCompanyName = New System.Windows.Forms.Label
		Me.lblTo = New System.Windows.Forms.Label
		Me.lblNote = New System.Windows.Forms.Label
		Me.txtNote = New System.Windows.Forms.TextBox
		Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker
		Me.dtpDateTo = New System.Windows.Forms.DateTimePicker
		Me.GroupBox1 = New System.Windows.Forms.GroupBox
		Me.btnCancelMain = New BHBut.BouncingHoverButton
		Me.btnClose = New BHBut.BouncingHoverButton
		Me.btnEditBranchAcct = New BHBut.BouncingHoverButton
		Me.btnSave = New BHBut.BouncingHoverButton
		Me.tcBranches = New System.Windows.Forms.TabControl
		Me.tpBranch = New System.Windows.Forms.TabPage
		Me.tpBranchAccts = New System.Windows.Forms.TabPage
		Me.btnEdit = New BHBut.BouncingHoverButton
		Me.btnNew = New BHBut.BouncingHoverButton
		Me.grdBranch = New System.Windows.Forms.DataGrid
		Me.txtCompanyName = New System.Windows.Forms.TextBox
		Me.Label1 = New System.Windows.Forms.Label
		Me.pnlCompanyInfo = New System.Windows.Forms.Panel
		Me.grpCompanyInfo = New System.Windows.Forms.GroupBox
		Me.txtCurrBal = New System.Windows.Forms.TextBox
		Me.lblCurrBal = New System.Windows.Forms.Label
		Me.lblCurrID1 = New System.Windows.Forms.Label
		Me.cboCurrID = New System.Windows.Forms.ComboBox
		Me.txtCompanyNumber = New System.Windows.Forms.TextBox
		Me.lblCompanyNumber = New System.Windows.Forms.Label
		Me.PicPersonnel = New System.Windows.Forms.PictureBox
		Me.txtLocation = New System.Windows.Forms.TextBox
		Me.btnGetPicture = New System.Windows.Forms.Button
		Me.grpBranchAccounts = New System.Windows.Forms.GroupBox
		Me.gpBranchName = New System.Windows.Forms.GroupBox
		Me.txtBranchName = New System.Windows.Forms.TextBox
		Me.btnOK = New BHBut.BouncingHoverButton
		Me.btnCancel = New BHBut.BouncingHoverButton
		Me.ofdGetPhoto = New System.Windows.Forms.OpenFileDialog
		Me.fbdDataFile = New System.Windows.Forms.FolderBrowserDialog
		Me.Panel1 = New System.Windows.Forms.Panel
		Me.lblfrmTitle = New System.Windows.Forms.Label
		Me.btnDataErr = New System.Windows.Forms.Button
		Me.lstDataErr = New System.Windows.Forms.ListBox
		Me.lblCurrency2 = New System.Windows.Forms.Label
		Me.cboCurrency2 = New System.Windows.Forms.ComboBox
		Me.GroupBox1.SuspendLayout()
		Me.tcBranches.SuspendLayout()
		CType(Me.grdBranch, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.pnlCompanyInfo.SuspendLayout()
		Me.grpCompanyInfo.SuspendLayout()
		CType(Me.PicPersonnel, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.grpBranchAccounts.SuspendLayout()
		Me.gpBranchName.SuspendLayout()
		Me.SuspendLayout()
		'
		'lblCompanyName
		'
		resources.ApplyResources(Me.lblCompanyName, "lblCompanyName")
		Me.lblCompanyName.ForeColor = System.Drawing.Color.Crimson
		Me.lblCompanyName.Name = "lblCompanyName"
		'
		'lblTo
		'
		resources.ApplyResources(Me.lblTo, "lblTo")
		Me.lblTo.ForeColor = System.Drawing.Color.Navy
		Me.lblTo.Name = "lblTo"
		'
		'lblNote
		'
		resources.ApplyResources(Me.lblNote, "lblNote")
		Me.lblNote.ForeColor = System.Drawing.Color.Red
		Me.lblNote.Name = "lblNote"
		'
		'txtNote
		'
		resources.ApplyResources(Me.txtNote, "txtNote")
		Me.txtNote.Name = "txtNote"
		Me.txtNote.ReadOnly = True
		'
		'dtpDateFrom
		'
		resources.ApplyResources(Me.dtpDateFrom, "dtpDateFrom")
		Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
		Me.dtpDateFrom.Name = "dtpDateFrom"
		'
		'dtpDateTo
		'
		resources.ApplyResources(Me.dtpDateTo, "dtpDateTo")
		Me.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
		Me.dtpDateTo.Name = "dtpDateTo"
		'
		'GroupBox1
		'
		resources.ApplyResources(Me.GroupBox1, "GroupBox1")
		Me.GroupBox1.Controls.Add(Me.btnCancelMain)
		Me.GroupBox1.Controls.Add(Me.btnClose)
		Me.GroupBox1.Controls.Add(Me.btnEditBranchAcct)
		Me.GroupBox1.Controls.Add(Me.btnSave)
		Me.GroupBox1.Controls.Add(Me.tcBranches)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.TabStop = False
		'
		'btnCancelMain
		'
		Me.btnCancelMain.AlternativeGroup = Nothing
		resources.ApplyResources(Me.btnCancelMain, "btnCancelMain")
		Me.btnCancelMain.BackColor = System.Drawing.Color.LightSteelBlue
		Me.btnCancelMain.BackColor1 = System.Drawing.Color.White
		Me.btnCancelMain.BackColor2 = System.Drawing.Color.LightSteelBlue
		Me.btnCancelMain.BorderHover = True
		Me.btnCancelMain.BorderHoverColor = System.Drawing.SystemColors.Highlight
		Me.btnCancelMain.BorderNormalColor = System.Drawing.SystemColors.ControlDark
		Me.btnCancelMain.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
		Me.btnCancelMain.ClickColor1 = System.Drawing.SystemColors.Highlight
		Me.btnCancelMain.ClickColor2 = System.Drawing.SystemColors.Window
		Me.btnCancelMain.DrawBorder = True
		Me.btnCancelMain.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
		Me.btnCancelMain.ForeColor = System.Drawing.Color.Navy
		Me.btnCancelMain.HoverColor1 = System.Drawing.Color.RoyalBlue
		Me.btnCancelMain.HoverColor2 = System.Drawing.Color.White
		Me.btnCancelMain.HoverForeColor = System.Drawing.SystemColors.ControlText
		Me.btnCancelMain.Name = "btnCancelMain"
		Me.btnCancelMain.SelectedColor1 = System.Drawing.Color.RoyalBlue
		Me.btnCancelMain.SelectedColor2 = System.Drawing.Color.WhiteSmoke
		Me.btnCancelMain.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.btnCancelMain.SelectedHoverColor1 = System.Drawing.Color.White
		Me.btnCancelMain.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
		Me.btnCancelMain.SelectedText = Nothing
		Me.btnCancelMain.UseVisualStyleBackColor = False
		'
		'btnClose
		'
		Me.btnClose.AlternativeGroup = Nothing
		resources.ApplyResources(Me.btnClose, "btnClose")
		Me.btnClose.BackColor = System.Drawing.Color.Orange
		Me.btnClose.BackColor1 = System.Drawing.Color.White
		Me.btnClose.BackColor2 = System.Drawing.Color.Orange
		Me.btnClose.BorderHover = True
		Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
		Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
		Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
		Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
		Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
		Me.btnClose.DrawBorder = True
		Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
		Me.btnClose.ForeColor = System.Drawing.Color.Navy
		Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
		Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
		Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
		Me.btnClose.Name = "btnClose"
		Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
		Me.btnClose.SelectedColor2 = System.Drawing.Color.White
		Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
		Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
		Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
		Me.btnClose.SelectedText = Nothing
		Me.btnClose.UseVisualStyleBackColor = False
		'
		'btnEditBranchAcct
		'
		Me.btnEditBranchAcct.AlternativeGroup = Nothing
		resources.ApplyResources(Me.btnEditBranchAcct, "btnEditBranchAcct")
		Me.btnEditBranchAcct.BackColor = System.Drawing.Color.LightSteelBlue
		Me.btnEditBranchAcct.BackColor1 = System.Drawing.Color.White
		Me.btnEditBranchAcct.BackColor2 = System.Drawing.Color.LightSteelBlue
		Me.btnEditBranchAcct.BorderHover = True
		Me.btnEditBranchAcct.BorderHoverColor = System.Drawing.SystemColors.Highlight
		Me.btnEditBranchAcct.BorderNormalColor = System.Drawing.SystemColors.ControlDark
		Me.btnEditBranchAcct.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
		Me.btnEditBranchAcct.ClickColor1 = System.Drawing.SystemColors.Highlight
		Me.btnEditBranchAcct.ClickColor2 = System.Drawing.SystemColors.Window
		Me.btnEditBranchAcct.DrawBorder = True
		Me.btnEditBranchAcct.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
		Me.btnEditBranchAcct.ForeColor = System.Drawing.Color.Navy
		Me.btnEditBranchAcct.HoverColor1 = System.Drawing.Color.RoyalBlue
		Me.btnEditBranchAcct.HoverColor2 = System.Drawing.Color.White
		Me.btnEditBranchAcct.HoverForeColor = System.Drawing.SystemColors.ControlText
		Me.btnEditBranchAcct.Name = "btnEditBranchAcct"
		Me.btnEditBranchAcct.SelectedColor1 = System.Drawing.Color.RoyalBlue
		Me.btnEditBranchAcct.SelectedColor2 = System.Drawing.Color.WhiteSmoke
		Me.btnEditBranchAcct.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.btnEditBranchAcct.SelectedHoverColor1 = System.Drawing.Color.White
		Me.btnEditBranchAcct.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
		Me.btnEditBranchAcct.SelectedText = Nothing
		Me.btnEditBranchAcct.UseVisualStyleBackColor = False
		'
		'btnSave
		'
		Me.btnSave.AlternativeGroup = Nothing
		resources.ApplyResources(Me.btnSave, "btnSave")
		Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
		Me.btnSave.BackColor1 = System.Drawing.Color.White
		Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
		Me.btnSave.BorderHover = True
		Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
		Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
		Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
		Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
		Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
		Me.btnSave.DrawBorder = True
		Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
		Me.btnSave.ForeColor = System.Drawing.Color.Navy
		Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
		Me.btnSave.HoverColor2 = System.Drawing.Color.White
		Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
		Me.btnSave.Name = "btnSave"
		Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
		Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
		Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
		Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
		Me.btnSave.SelectedText = Nothing
		Me.btnSave.UseVisualStyleBackColor = False
		'
		'tcBranches
		'
		resources.ApplyResources(Me.tcBranches, "tcBranches")
		Me.tcBranches.Controls.Add(Me.tpBranch)
		Me.tcBranches.Controls.Add(Me.tpBranchAccts)
		Me.tcBranches.Name = "tcBranches"
		Me.tcBranches.SelectedIndex = 0
		'
		'tpBranch
		'
		resources.ApplyResources(Me.tpBranch, "tpBranch")
		Me.tpBranch.Name = "tpBranch"
		'
		'tpBranchAccts
		'
		resources.ApplyResources(Me.tpBranchAccts, "tpBranchAccts")
		Me.tpBranchAccts.Name = "tpBranchAccts"
		'
		'btnEdit
		'
		Me.btnEdit.AlternativeGroup = Nothing
		resources.ApplyResources(Me.btnEdit, "btnEdit")
		Me.btnEdit.BackColor = System.Drawing.Color.LightSteelBlue
		Me.btnEdit.BackColor1 = System.Drawing.Color.White
		Me.btnEdit.BackColor2 = System.Drawing.Color.LightSteelBlue
		Me.btnEdit.BorderHover = True
		Me.btnEdit.BorderHoverColor = System.Drawing.SystemColors.Highlight
		Me.btnEdit.BorderNormalColor = System.Drawing.SystemColors.ControlDark
		Me.btnEdit.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
		Me.btnEdit.ClickColor1 = System.Drawing.SystemColors.Highlight
		Me.btnEdit.ClickColor2 = System.Drawing.SystemColors.Window
		Me.btnEdit.DrawBorder = True
		Me.btnEdit.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
		Me.btnEdit.ForeColor = System.Drawing.Color.Navy
		Me.btnEdit.HoverColor1 = System.Drawing.Color.RoyalBlue
		Me.btnEdit.HoverColor2 = System.Drawing.Color.White
		Me.btnEdit.HoverForeColor = System.Drawing.SystemColors.ControlText
		Me.btnEdit.Name = "btnEdit"
		Me.btnEdit.SelectedColor1 = System.Drawing.Color.RoyalBlue
		Me.btnEdit.SelectedColor2 = System.Drawing.Color.WhiteSmoke
		Me.btnEdit.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.btnEdit.SelectedHoverColor1 = System.Drawing.Color.White
		Me.btnEdit.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
		Me.btnEdit.SelectedText = Nothing
		Me.btnEdit.UseVisualStyleBackColor = False
		'
		'btnNew
		'
		Me.btnNew.AlternativeGroup = Nothing
		resources.ApplyResources(Me.btnNew, "btnNew")
		Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
		Me.btnNew.BackColor1 = System.Drawing.Color.White
		Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
		Me.btnNew.BorderHover = True
		Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
		Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
		Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
		Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
		Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
		Me.btnNew.DrawBorder = True
		Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
		Me.btnNew.ForeColor = System.Drawing.Color.Navy
		Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
		Me.btnNew.HoverColor2 = System.Drawing.Color.White
		Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
		Me.btnNew.Name = "btnNew"
		Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
		Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
		Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
		Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
		Me.btnNew.SelectedText = Nothing
		Me.btnNew.UseVisualStyleBackColor = False
		'
		'grdBranch
		'
		resources.ApplyResources(Me.grdBranch, "grdBranch")
		Me.grdBranch.BackgroundColor = System.Drawing.SystemColors.InactiveCaptionText
		Me.grdBranch.CaptionBackColor = System.Drawing.SystemColors.Highlight
		Me.grdBranch.DataMember = ""
		Me.grdBranch.HeaderForeColor = System.Drawing.SystemColors.ControlText
		Me.grdBranch.Name = "grdBranch"
		'
		'txtCompanyName
		'
		resources.ApplyResources(Me.txtCompanyName, "txtCompanyName")
		Me.txtCompanyName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.txtCompanyName.Name = "txtCompanyName"
		'
		'Label1
		'
		resources.ApplyResources(Me.Label1, "Label1")
		Me.Label1.ForeColor = System.Drawing.Color.Navy
		Me.Label1.Name = "Label1"
		'
		'pnlCompanyInfo
		'
		Me.pnlCompanyInfo.AllowDrop = True
		resources.ApplyResources(Me.pnlCompanyInfo, "pnlCompanyInfo")
		Me.pnlCompanyInfo.BackColor = System.Drawing.SystemColors.Control
		Me.pnlCompanyInfo.Controls.Add(Me.grpCompanyInfo)
		Me.pnlCompanyInfo.Controls.Add(Me.GroupBox1)
		Me.pnlCompanyInfo.Controls.Add(Me.grpBranchAccounts)
		Me.pnlCompanyInfo.Name = "pnlCompanyInfo"
		'
		'grpCompanyInfo
		'
		Me.grpCompanyInfo.Controls.Add(Me.lblCurrency2)
		Me.grpCompanyInfo.Controls.Add(Me.cboCurrency2)
		Me.grpCompanyInfo.Controls.Add(Me.txtCurrBal)
		Me.grpCompanyInfo.Controls.Add(Me.lblCurrBal)
		Me.grpCompanyInfo.Controls.Add(Me.lblCurrID1)
		Me.grpCompanyInfo.Controls.Add(Me.cboCurrID)
		Me.grpCompanyInfo.Controls.Add(Me.txtCompanyNumber)
		Me.grpCompanyInfo.Controls.Add(Me.lblCompanyNumber)
		Me.grpCompanyInfo.Controls.Add(Me.dtpDateFrom)
		Me.grpCompanyInfo.Controls.Add(Me.Label1)
		Me.grpCompanyInfo.Controls.Add(Me.lblNote)
		Me.grpCompanyInfo.Controls.Add(Me.lblCompanyName)
		Me.grpCompanyInfo.Controls.Add(Me.txtNote)
		Me.grpCompanyInfo.Controls.Add(Me.txtCompanyName)
		Me.grpCompanyInfo.Controls.Add(Me.PicPersonnel)
		Me.grpCompanyInfo.Controls.Add(Me.txtLocation)
		Me.grpCompanyInfo.Controls.Add(Me.btnGetPicture)
		Me.grpCompanyInfo.Controls.Add(Me.lblTo)
		Me.grpCompanyInfo.Controls.Add(Me.dtpDateTo)
		resources.ApplyResources(Me.grpCompanyInfo, "grpCompanyInfo")
		Me.grpCompanyInfo.Name = "grpCompanyInfo"
		Me.grpCompanyInfo.TabStop = False
		'
		'txtCurrBal
		'
		resources.ApplyResources(Me.txtCurrBal, "txtCurrBal")
		Me.txtCurrBal.Name = "txtCurrBal"
		Me.txtCurrBal.ReadOnly = True
		Me.txtCurrBal.TabStop = False
		'
		'lblCurrBal
		'
		resources.ApplyResources(Me.lblCurrBal, "lblCurrBal")
		Me.lblCurrBal.ForeColor = System.Drawing.Color.Maroon
		Me.lblCurrBal.Name = "lblCurrBal"
		'
		'lblCurrID1
		'
		resources.ApplyResources(Me.lblCurrID1, "lblCurrID1")
		Me.lblCurrID1.ForeColor = System.Drawing.Color.Crimson
		Me.lblCurrID1.Name = "lblCurrID1"
		'
		'cboCurrID
		'
		resources.ApplyResources(Me.cboCurrID, "cboCurrID")
		Me.cboCurrID.Name = "cboCurrID"
		'
		'txtCompanyNumber
		'
		resources.ApplyResources(Me.txtCompanyNumber, "txtCompanyNumber")
		Me.txtCompanyNumber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.txtCompanyNumber.Name = "txtCompanyNumber"
		Me.txtCompanyNumber.ReadOnly = True
		Me.txtCompanyNumber.TabStop = False
		'
		'lblCompanyNumber
		'
		resources.ApplyResources(Me.lblCompanyNumber, "lblCompanyNumber")
		Me.lblCompanyNumber.ForeColor = System.Drawing.Color.Crimson
		Me.lblCompanyNumber.Name = "lblCompanyNumber"
		'
		'PicPersonnel
		'
		Me.PicPersonnel.BackColor = System.Drawing.Color.SandyBrown
		Me.PicPersonnel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		resources.ApplyResources(Me.PicPersonnel, "PicPersonnel")
		Me.PicPersonnel.Name = "PicPersonnel"
		Me.PicPersonnel.TabStop = False
		'
		'txtLocation
		'
		resources.ApplyResources(Me.txtLocation, "txtLocation")
		Me.txtLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtLocation.Name = "txtLocation"
		'
		'btnGetPicture
		'
		Me.btnGetPicture.BackColor = System.Drawing.SystemColors.ControlLightLight
		resources.ApplyResources(Me.btnGetPicture, "btnGetPicture")
		Me.btnGetPicture.Name = "btnGetPicture"
		Me.btnGetPicture.UseCompatibleTextRendering = True
		Me.btnGetPicture.UseVisualStyleBackColor = False
		'
		'grpBranchAccounts
		'
		resources.ApplyResources(Me.grpBranchAccounts, "grpBranchAccounts")
		Me.grpBranchAccounts.Controls.Add(Me.grdBranch)
		Me.grpBranchAccounts.Controls.Add(Me.btnNew)
		Me.grpBranchAccounts.Controls.Add(Me.btnEdit)
		Me.grpBranchAccounts.FlatStyle = System.Windows.Forms.FlatStyle.System
		Me.grpBranchAccounts.Name = "grpBranchAccounts"
		Me.grpBranchAccounts.TabStop = False
		'
		'gpBranchName
		'
		Me.gpBranchName.Controls.Add(Me.txtBranchName)
		Me.gpBranchName.Controls.Add(Me.btnOK)
		Me.gpBranchName.Controls.Add(Me.btnCancel)
		resources.ApplyResources(Me.gpBranchName, "gpBranchName")
		Me.gpBranchName.Name = "gpBranchName"
		Me.gpBranchName.TabStop = False
		'
		'txtBranchName
		'
		resources.ApplyResources(Me.txtBranchName, "txtBranchName")
		Me.txtBranchName.Name = "txtBranchName"
		'
		'btnOK
		'
		Me.btnOK.AlternativeGroup = Nothing
		resources.ApplyResources(Me.btnOK, "btnOK")
		Me.btnOK.BackColor = System.Drawing.Color.LightSteelBlue
		Me.btnOK.BackColor1 = System.Drawing.Color.White
		Me.btnOK.BackColor2 = System.Drawing.Color.LightSteelBlue
		Me.btnOK.BorderHover = True
		Me.btnOK.BorderHoverColor = System.Drawing.SystemColors.Highlight
		Me.btnOK.BorderNormalColor = System.Drawing.SystemColors.ControlDark
		Me.btnOK.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
		Me.btnOK.ClickColor1 = System.Drawing.SystemColors.Highlight
		Me.btnOK.ClickColor2 = System.Drawing.SystemColors.Window
		Me.btnOK.DrawBorder = True
		Me.btnOK.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
		Me.btnOK.ForeColor = System.Drawing.Color.Navy
		Me.btnOK.HoverColor1 = System.Drawing.Color.RoyalBlue
		Me.btnOK.HoverColor2 = System.Drawing.Color.White
		Me.btnOK.HoverForeColor = System.Drawing.SystemColors.ControlText
		Me.btnOK.Name = "btnOK"
		Me.btnOK.SelectedColor1 = System.Drawing.Color.RoyalBlue
		Me.btnOK.SelectedColor2 = System.Drawing.Color.WhiteSmoke
		Me.btnOK.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.btnOK.SelectedHoverColor1 = System.Drawing.Color.White
		Me.btnOK.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
		Me.btnOK.SelectedText = Nothing
		Me.btnOK.UseVisualStyleBackColor = False
		'
		'btnCancel
		'
		Me.btnCancel.AlternativeGroup = Nothing
		resources.ApplyResources(Me.btnCancel, "btnCancel")
		Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
		Me.btnCancel.BackColor1 = System.Drawing.Color.White
		Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
		Me.btnCancel.BorderHover = True
		Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
		Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
		Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
		Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
		Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
		Me.btnCancel.DrawBorder = True
		Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
		Me.btnCancel.ForeColor = System.Drawing.Color.Navy
		Me.btnCancel.HoverColor1 = System.Drawing.Color.RoyalBlue
		Me.btnCancel.HoverColor2 = System.Drawing.Color.White
		Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
		Me.btnCancel.Name = "btnCancel"
		Me.btnCancel.SelectedColor1 = System.Drawing.Color.RoyalBlue
		Me.btnCancel.SelectedColor2 = System.Drawing.Color.WhiteSmoke
		Me.btnCancel.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.White
		Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
		Me.btnCancel.SelectedText = Nothing
		Me.btnCancel.UseVisualStyleBackColor = False
		'
		'Panel1
		'
		Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
		resources.ApplyResources(Me.Panel1, "Panel1")
		Me.Panel1.ForeColor = System.Drawing.SystemColors.HotTrack
		Me.Panel1.Name = "Panel1"
		'
		'lblfrmTitle
		'
		Me.lblfrmTitle.AutoEllipsis = True
		Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
		resources.ApplyResources(Me.lblfrmTitle, "lblfrmTitle")
		Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.lblfrmTitle.Name = "lblfrmTitle"
		'
		'btnDataErr
		'
		resources.ApplyResources(Me.btnDataErr, "btnDataErr")
		Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
		Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
		Me.btnDataErr.ForeColor = System.Drawing.Color.Red
		Me.btnDataErr.Name = "btnDataErr"
		Me.btnDataErr.TabStop = False
		Me.btnDataErr.UseVisualStyleBackColor = False
		'
		'lstDataErr
		'
		resources.ApplyResources(Me.lstDataErr, "lstDataErr")
		Me.lstDataErr.FormattingEnabled = True
		Me.lstDataErr.Name = "lstDataErr"
		'
		'lblCurrency2
		'
		resources.ApplyResources(Me.lblCurrency2, "lblCurrency2")
		Me.lblCurrency2.ForeColor = System.Drawing.Color.CornflowerBlue
		Me.lblCurrency2.Name = "lblCurrency2"
		'
		'cboCurrency2
		'
		resources.ApplyResources(Me.cboCurrency2, "cboCurrency2")
		Me.cboCurrency2.Name = "cboCurrency2"
		'
		'frmCompany
		'
		resources.ApplyResources(Me, "$this")
		Me.Controls.Add(Me.btnDataErr)
		Me.Controls.Add(Me.lstDataErr)
		Me.Controls.Add(Me.Panel1)
		Me.Controls.Add(Me.lblfrmTitle)
		Me.Controls.Add(Me.gpBranchName)
		Me.Controls.Add(Me.pnlCompanyInfo)
		Me.Name = "frmCompany"
		Me.GroupBox1.ResumeLayout(False)
		Me.tcBranches.ResumeLayout(False)
		CType(Me.grdBranch, System.ComponentModel.ISupportInitialize).EndInit()
		Me.pnlCompanyInfo.ResumeLayout(False)
		Me.grpCompanyInfo.ResumeLayout(False)
		Me.grpCompanyInfo.PerformLayout()
		CType(Me.PicPersonnel, System.ComponentModel.ISupportInitialize).EndInit()
		Me.grpBranchAccounts.ResumeLayout(False)
		Me.gpBranchName.ResumeLayout(False)
		Me.gpBranchName.PerformLayout()
		Me.ResumeLayout(False)

	End Sub

#End Region
	Dim clsMr As ClsMain
	Dim dsData As New DataSet

	Dim mstrTableName As String = "tblCompany"
	Dim daCompany As SqlClient.SqlDataAdapter
	Dim dgStyle As New DataGridTableStyle
	Dim dabranch As SqlClient.SqlDataAdapter
	Dim daAccount As SqlClient.SqlDataAdapter
	Private mStrCurrentState As String
	Private blncbo As Boolean = True
	Dim blnPic As Boolean = False	' Pic Boolean 
	Dim mStrPicSource As String '' Pic source path 
	Private WithEvents Nav As BitsNav
	Dim ifSave As Boolean = False

	Private Sub frmCompany_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

		' bug fix:
		' If Me.Parent.Parent Is Nothing Then Return

		clsMr = New ClsMain(conSql)

		Nav = New BitsNav()
		MakeDataAdapter()
		FillComboBox()
		SetDataBinding()
		SetAutoNumber()
		SetCurrencyManager()
		SetDefaultValue()

		''
		Dim dv As DataView

		dv = dsData.Tables("tblBranch").DefaultView()
		dv.AllowNew = False
		dv.AllowEdit = False
		grdBranch.DataSource = dv
		dgStyle.MappingName = "tblBranch"
		grdBranch.TableStyles.Add(dgStyle)

		'' Set columns width...
		dgStyle.GridColumnStyles("BranchID").Width = 0
		dgStyle.GridColumnStyles("CompanyID").Width = 0
		dgStyle.GridColumnStyles("BranchName").Width = 150
		dgStyle.GridColumnStyles("CreateBy").Width = 0
		dgStyle.GridColumnStyles("Del").Width = 0

		formatDecimal()
		'  DisableCompanyName()
		' BringPicFromDataBase()
		blncbo = False

		'Disabled()
		dtpDateFrom.Enabled = False
		dtpDateTo.Enabled = False
		' BringPicFromDataBase()
		DrawGrid()
		filterGrid()
		setState("BROWSE")

	End Sub

	Private Sub formatDecimal()
		'txtCurrBal.Text = Convert.ToDecimal(txtCurrBal.Text).ToString("#0.00")
	End Sub
	'Private Sub Disabled()
	'    txtCompanyID.Enabled = False
	'    txtCompanyNumber.Enabled = False
	'    txtCompanyNumber.Enabled = False
	'    cboCurrID.Enabled = False
	'    txtCurrBal.Enabled = False
	'    dtDateFrom.Enabled = False
	'    dtDateTo.Enabled = False
	'    txtNote.Enabled = False
	'End Sub

	'Private Sub Enabled1()
	'    txtCompanyID.Enabled = True
	'    txtCompanyNumber.Enabled = True
	'    txtCompanyName.Enabled = True
	'    cboCurrID.Enabled = True
	'    txtCurrBal.Enabled = True
	'    dtDateFrom.Enabled = True
	'    dtDateTo.Enabled = True
	'    txtNote.Enabled = True

	'End Sub


	Public Sub FillComboBox() 'zedAug2007  Implements dataService.clsIMain.FillComboBox
		'zedAug2007 clsMr.SetCM(Me.BindingContext)
		clsMr.FillComboBox("CurrID", cboCurrID, "Symbol", "CurrID")
		clsMr.FillComboBox("CurrID2", cboCurrency2, "Symbol", "CurrID")
	End Sub
	Public Sub MakeDataAdapter() 'zedAug2007  Implements dataService.clsIMain.MakeDataAdapter
		strSQL = "SELECT * FROM tblCompany WHERE CompanyID=" & gIntCompanyID
		daCompany = clsMr.BuildSqlAdapter(strSQL, mstrTableName)
		clsMr.BuildSqlAdapter("SELECT CurrID, Symbol FROM tblCurrency WHERE del = 0", "CurrID")
		clsMr.BuildSqlAdapter("SELECT CurrID, Symbol FROM tblCurrency WHERE del = 0", "CurrID2")
		dabranch = clsMr.BuildSqlAdapter("SELECT * FROM tblBranch WHERE del=0 AND CompanyID=" & gIntCompanyID, "tblBranch")
		'daAccount = clsMr.BuildSqlAdapter("SELECT * FROM tblAccount WHERE del=0 AND AcctID=-1", "tblAccount")

		'clsMr.BuildSqlAdapter("SELECT AcctTypeID, BranchID FROM tblAccount WHERE del=0", "AcctID")
		'clsMr.BuildSqlAdapter("SELECT  dbo.tblBranch.BranchID, dbo.tblAccount.AcctTypeID  FROM        dbo.tblBranch INNER JOIN   dbo.tblAccount ON dbo.tblBranch.BranchID = dbo.tblAccount.BranchID", "tblBranchAccount")

		'' populate main form's da...

		' clsMr.BuildSqlAdapter("SELECT * FROM vwAccountBrAndType where AcctTypeID IN(4,7,9)", "vwAccountBrAndType")


		'' populate da's for combos on form...
		' clsMr.BuildSqlAdapter("SELECT * FROM tblBranch WHERE Del= 0 ORDER BY BranchName", "Branch")
		' clsMr.BuildSqlAdapter("SELECT * FROM tblAcctType WHERE (Del=0) AND (AcctTypeID IN (4,7,9)) ORDER BY AcctType", "AcctType")

		dsData = clsMr.getDataSet
		'dsRpt1 = clsMr.getDataSet
	End Sub

	Public Sub SetAutoNumber()	'zedAug2007  Implements dataService.clsIMain.SetAutoNumber
		clsMr.SetAutoNumber(mstrTableName, "CompanyID")
		clsMr.SetAutoNumber("tblBranch", "BranchID")
		'  clsMr.SetAutoNumber("tblAccount", "AcctID")
	End Sub

	Public Sub SetCurrencyManager() 'zedAug2007  Implements dataService.clsIMain.SetCurrencyManager
		Nav.SetCurrency(Me, dsData, mstrTableName)
	End Sub

	Public Sub SetDataBinding() 'zedAug2007  Implements dataService.clsIMain.SetDataBinding

		clsMr.BindDateTimePicker(dtpDateFrom, mstrTableName, "DateFrom")
		clsMr.BindDateTimePicker(dtpDateTo, mstrTableName, "DateTo")
		clsMr.BindTextBox(txtCompanyName, mstrTableName, "CompanyName")
		clsMr.BindTextBox(txtNote, mstrTableName, "Note")
		clsMr.BindTextBox(txtCompanyNumber, mstrTableName, "CompanyNumber")
		clsMr.BindTextBox(txtCurrBal, mstrTableName, "CurrBal")
		clsMr.BindComboBox(cboCurrID, mstrTableName, "CurrID")
		clsMr.BindComboBox(cboCurrency2, mstrTableName, "CurrID2")
	End Sub

	Public Sub SetDefaultValue() 'zedAug2007  Implements dataService.clsIMain.SetDefaultValue
		clsMr.SetDefaults(mstrTableName, "Del", 0)
		clsMr.SetDefaults(mstrTableName, "CreateBy", gIntUserID)
		clsMr.SetDefaults("tblbranch", "CreateBy", gIntUserID)
		clsMr.SetDefaults(mstrTableName, "CreateDate", Now())
		clsMr.SetDefaults("tblBranch", "CompanyID", gIntCompanyID, "Del", 0)
		clsMr.SetDefaults(mstrTableName, "CurrBal", 0)
		'  clsMr.SetDefaults("tblAccount", "CreateBy", gIntUserID)
		'clsMr.SetDefaults("tblAccount", "CreateDate", Now())
		'clsMr.SetDefaults("tblAccount", "Del", 0)

	End Sub

	Private Function ChkCompanyName()
		ChkCompanyName = True
	End Function

	'Private Sub Filter()
	'   If blncbo = True Then
	'      Exit Sub
	'   End If
	'   blncbo = True
	'   Dim s As String

	'   Dim vw As DataView
	'   If txtCompanyID.Text = String.Empty Then
	'      txtCompanyID.Text = -1
	'   End If
	'   'If txtID.Text <> "" Then
	'   vw = dsData.Tables("tblBranch").DefaultView
	'   vw.RowFilter = "CompanyID=" & txtCompanyID.Text & " and del=0"
	'   'End If

	'End Sub

	'Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
	'   btnSave.Text = "Save"
	'   Nav.AddNew()
	'   'Enabled1()
	'End Sub

	'Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
	'   'If btnSave.Text = "Save" Then
	'   '    btnSave.Text = "Edit"
	'   Nav.EndCurrentEdit()
	'   clsMr.Update(daCompany, mstrTableName)
	'   'Else
	'   '    btnSave.Text = "Save"
	'   'End If
	'   If txtCompanyName.Text = "" Then MsgBox("Please Enter Company Name", MsgBoxStyle.Critical, "Warning")
	'   Exit Sub

	'End Sub

	'Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
	'   Me.Close()
	'End Sub

	'Private Sub Nav_AfterLast() Handles Nav.AfterLast
	'   'Disabled()
	'End Sub

	'Private Sub Nav_AfterFirst() Handles Nav.AfterFirst
	'   'Disabled()
	'End Sub

	'Private Sub Nav_AfterNext() Handles Nav.AfterNext
	'   'Disabled()
	'End Sub

	'Private Sub Nav_AfterPrevious() Handles Nav.AfterPrevious
	'   'Disabled()
	'End Sub


	'Private Sub btnNew_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
	'   Nav.AddNew()
	'End Sub

	'Private Sub btnSave_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
	'   Nav.EndCurrentEdit()
	'   clsMr.Update(daCompany, mstrTableName)

	'   'If cboCompanyName.SelectedValue = "" Then MsgBox("Please insert CompanyName  ", MsgBoxStyle.Critical, "Warning") : Exit Sub
	'   If cboCurrID.Text = "" Then MsgBox("Please Choose CurrID", MsgBoxStyle.Critical, "Warning") : Exit Sub
	'End Sub

	Private Sub txtCompanyNumber_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
		'Integers_KeyPress(txtCompanyNumber, e)
	End Sub

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		'   If ifSave = True Then
		'      Dim res As MsgBoxResult
		'res = MsgBox("Do you want to save the changes", MsgBoxStyle.Question + MsgBoxStyle.YesNoCancel, "BitSolution")
		'      If res = MsgBoxResult.Yes Then
		'         save()
		'      End If
		'   End If
		'   Me.Close()

		If ifSave Then
			Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
				Case MsgBoxResult.Yes
					'' call save...
					If lstDataErr.Items.Count <> 0 Then
						MsgBox("Cannot save.Please check error list")
						Exit Sub
					Else
						btnSave.PerformClick()
						Me.Close()
					End If
				Case MsgBoxResult.No
					'' ignore changes...

					Try
						Nav.CancelCurrentEdit()
					Catch ex As Exception

					End Try
					Me.Close()
				Case MsgBoxResult.Cancel
					'' ignore close press..
					'' do nothing...

			End Select
		Else
			Me.Close()
		End If
	End Sub


	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		If btnSave.Text = "E d i t" Then
			setState("EDIT")
			Exit Sub
		End If
		save()
	End Sub

	Private Sub save()
		'Try
		If txtCompanyName.ReadOnly = False Then
			dsData.Tables(mstrTableName).DefaultView.Item(0).EndEdit()
			clsMr.Update(daCompany, mstrTableName)

			'If blnPic Then SavePicToDB()
		End If

		Dim al As ArrayList
		Dim dv As DataView
		Dim drv As DataRowView
		Dim i As Integer

		al = New ArrayList
		dv = dsData.Tables("tblBranch").DefaultView
		For i = 0 To dv.Count - 1
			drv = dv.Item(i)
			If drv.Row.RowState = DataRowState.Added Then
				al.Add(drv)
			End If
		Next

		clsMr.Update(dabranch, "tblBranch")

		' create accounts for new branches
		For Each drv In al
			' AcctTypeID 5 = Branch Stock
			'CreateAccount(drv("BranchId"), drv("BranchName"), 5)
			' AcctTypeID 6 = Branch Cash Sales
			'CreateAccount(drv("BranchId"), drv("BranchName"), 6)
		Next
		ifSave = False
		btnSave.Enabled = False
		'Catch ex As Exception
		'   MsgBox(ex.Message)
		'End Try
		'clsMr.Update(dabranch, "tblBranch")

		'Dim dr1 As DataRow
		'dr1 = dsData.Tables("tblBranch").NewRow()
		'dr1("CompanyID") = grdBranch.Item(grdBranch.CurrentRowIndex, 1)

		'dr1("BranchID") = grdBranch.Item(grdBranch.CurrentRowIndex, 0)
		'dr1("BranchName") = grdBranch.Item(grdBranch.CurrentRowIndex, 2)

		'dsData.Tables("tblBranch").Rows.Add(dr1)
		'clsMr.Update(dabranch, "tblBranch")
		'dabranch.Update(dsData, "tblBranch")
		setState("SAVE")
	End Sub

	Private Sub CreateAccount(ByVal BranchID As Integer, ByVal BranchName As String, ByVal AcctTypeID As Integer)

		Dim dvAcct As DataView
		Dim drvAcct As DataRowView
		Dim dvCompany As DataView
		Dim drvCompany As DataRowView

		dvCompany = dsData.Tables(mstrTableName).DefaultView
		drvCompany = dvCompany.Item(0)

		dvAcct = dsData.Tables("tblAccount").DefaultView

		Dim lngMax As Integer

		drvAcct = dvAcct.AddNew()
		' auto
		'drv("AcctID") =  
		drvAcct("BranchID") = BranchID
		drvAcct("AcctTypeID") = AcctTypeID
		lngMax = clsMr.GetMaxNumber("select case when max(AcctNumber) is null then 0 else max(AcctNumber) end from tblAccount where branchid=" & BranchID) + 1
		drvAcct("AcctNumber") = lngMax
		Select Case AcctTypeID
			Case 5
				drvAcct("ClientName") = BranchName & " Stock Account"

			Case 6
				drvAcct("ClientName") = BranchName & " Cash Sales Account"
		End Select
		drvAcct("Balance") = 0
		drvAcct("CurrencyID") = drvCompany("CurrID")
		'drv("ContactName") =  
		'drv("Tel") =  
		'drv("fax") =  
		'drv("Ext") =  
		'drv("Cell") =  
		'drv("Email") =  
		'drv("StreetID") =  
		'drv("CityID") =  
		'drv("Bldg") =  
		'drv("Office") =  
		'drv("Zipcode") =  
		'drv("Note") =  
		' auto
		'drv("createBy") =  
		'drv("createDate") =  
		'drv("Del") =  
		drvAcct.EndEdit()

		daAccount.Update(dsData.Tables("tblAccount"))

	End Sub

	Private Sub btnEditBranchAcct_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditBranchAcct.Click
		'Dim frmX As New FrmAccount(grdBranch.CurrentCell.ColumnNumber("BranchID"))
		'Dim frmX As New FrmAccount(-2, Me.grdBranch.Item(grdBranch.CurrentRowIndex, 0))
		'Dim frmX As New FrmAccount(0, "")

		'' ALI one line below
		''Dim frmX As New FrmBranchAccountMaintenance(Me.grdBranch.Item(grdBranch.CurrentRowIndex, 0))
		'frmX.AcctTypeID = 6
		'frmX.d()

		'' Ali
		'MainForm.addModelTabPage(frmX, frmApplicationMain.eFormType.BranchAccounts)

	End Sub

	'Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
	'   Dim frm As frmCompany
	'   frm = New frmCompany

	'   'MainForm.AddTabPage(frm, frmApplicationMain.eFormType.Purchase)
	'   'frm.ShowDialog()

	'   dsData.Tables("tblBranch").Rows.Clear()
	'   daCompany.Fill(dsData.Tables("tblBranch"))
	'End Sub
	'Private Sub btnEditBranchAcct_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditBranchAcct.Click
	'   Dim frmX As New FrmAccount(Me.grdBranch.Item(grdBranch.CurrentRowIndex, 0))
	'   frmX.AcctTypeID = 6
	'   ''''
	'   MainForm.AddModelTabPage(frmX, frmApplicationMain.eFormType.Customer)
	'End Sub


	Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click

		If txtBranchName.Text.Trim = String.Empty Then
			MsgBox("Please Enter Branch Name")
			txtBranchName.Focus()
			Exit Sub
		End If

		Dim dv As DataView
		Dim drv As DataRowView

		dv = dsData.Tables("tblBranch").DefaultView

		If gpBranchName.Tag = "New" Then
			dv.AllowNew = True
			drv = dv.AddNew()
			drv("BranchName") = txtBranchName.Text
			drv.EndEdit()
			dv.AllowNew = False
		Else
			dv.AllowEdit = True
			drv = dv.Item(grdBranch.CurrentRowIndex)
			drv("BranchName") = txtBranchName.Text
			drv.EndEdit()
			dv.AllowEdit = False
		End If

		'daCompany.Fill(dsData.Tables("tblBranch"))
		btnCancel.PerformClick()

		ifSave = True
		btnSave.Enabled = True
		SaveBranch()
	End Sub

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

		pnlCompanyInfo.Enabled = True
		pnlCompanyInfo.BackColor = System.Drawing.SystemColors.Control
		txtCompanyName.BackColor = System.Drawing.SystemColors.Control
		txtNote.BackColor = System.Drawing.SystemColors.Control
		gpBranchName.Visible = False

	End Sub

	Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
		txtBranchName.Text = ""
		AddEditBranchName("New")
	End Sub

	Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
		If grdBranch.CurrentRowIndex = -1 Then
			Exit Sub
		End If

		Dim dv As DataView
		Dim drv As DataRowView

		dv = dsData.Tables("tblBranch").DefaultView
		drv = dv.Item(grdBranch.CurrentRowIndex)
		txtBranchName.Text = drv("BranchName")
		AddEditBranchName("Edit")
	End Sub

	Private Sub AddEditBranchName(ByVal Mode As String)

		pnlCompanyInfo.Enabled = False
		pnlCompanyInfo.BackColor = System.Drawing.SystemColors.ControlDarkDark
		txtCompanyName.BackColor = System.Drawing.SystemColors.ControlDarkDark

		txtNote.BackColor = System.Drawing.SystemColors.ControlDarkDark

		gpBranchName.Left = pnlCompanyInfo.Left + (pnlCompanyInfo.Width - gpBranchName.Width) / 2
		gpBranchName.Top = (pnlCompanyInfo.Height - gpBranchName.Height) / 2
		gpBranchName.Visible = True
		gpBranchName.BringToFront()
		gpBranchName.Tag = Mode
		'  gpBranchName.Enabled = True
		txtBranchName.Focus()

	End Sub
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	''enable changing company when there are no transactions and vouchers...
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Private Sub DisableCompanyName()
		'If dsData.Tables(mstrTableName).DefaultView.Count = 0 Then
		'   'txtCompanyName.ReadOnly = False
		'   Exit Sub
		'End If

		'Dim TrxCount As Integer
		'Dim TrxVoucher As Integer
		'Try

		'   Dim cmdTrx As New SqlClient.SqlCommand("Select count (dbo.tblTransaction.TrxID)   FROM dbo.tblTransaction WHERE (dbo.tblTransaction.TrxTypeID <> 5) AND (BranchID=" & gIntBranchID & ")", conSql)
		'   conSql.Open()
		'   TrxCount = cmdTrx.ExecuteScalar()
		'   conSql.Close()

		'   Dim cmdVoucher As New SqlClient.SqlCommand("Select count (dbo.tblVoucher.VoucherID)   FROM dbo.tblVoucher WHERE BranchID=" & gIntBranchID, conSql)
		'   conSql.Open()
		'   TrxVoucher = cmdVoucher.ExecuteScalar()
		'   conSql.Close()

		'   If TrxCount <> 0 Or TrxVoucher <> 0 Then
		'      txtCompanyName.ReadOnly = True
		'          '  btnGetPicture.Enabled = False
		'   End If
		'Catch ex As Exception
		'   conSql.Close()
		'End Try


	End Sub
	'Private Sub BringPicFromDataBase()

	'   'Bring picture from data base 

	'   ' ask if there is any records in the db 
	'   If dsData.Tables(mstrTableName).Rows.Count = 0 Then Exit Sub

	'   ' ask if the field Photo is null in the database 
	'   If IsDBNull(dsData.Tables(mstrTableName).Rows(GetRowIndex())("CompanyLogo")) Then PicPersonnel.Image = Nothing : Exit Sub
	'   Dim arrPicture() As Byte = _
	' CType(dsData.Tables(mstrTableName).Rows(GetRowIndex())("CompanyLogo"), Byte())
	'   Dim ms As New System.IO.MemoryStream(arrPicture)

	'   ''' Appear pic for user 
	'   With PicPersonnel
	'      .Image = Image.FromStream(ms)
	'      .SizeMode = PictureBoxSizeMode.StretchImage
	'      .BorderStyle = BorderStyle.Fixed3D
	'   End With
	'   ''''''''''
	'End Sub
	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' This function gets the row index of the current record
	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Public Function GetRowIndex() As Integer
		Dim i As Integer
		For i = 0 To dsData.Tables(mstrTableName).DefaultView.Count - 1
			If dsData.Tables(mstrTableName).DefaultView.Item(i)("CompanyID") = gIntCompanyID Then
				Return i
			End If
		Next
		Return -1
	End Function

#Region "frmPhotoNew"
	Private Sub btnGetPicture_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetPicture.Click
		blnPic = True
		ofdGetPhoto.Filter = "jpg (*.jpg)|*.jpg|bmp (*.bmp)|*.bmp|All files (*.*)|*.*"
		ofdGetPhoto.FilterIndex = 1
		ofdGetPhoto.RestoreDirectory = True
		ofdGetPhoto.ShowDialog()
		txtLocation.Text = ofdGetPhoto.FileName
		mStrPicSource = ofdGetPhoto.FileName
		'txtLocation.Text = mStrPicSource
		If Not mStrPicSource = "" Then PicPersonnel.Image = Image.FromFile(txtLocation.Text)
	End Sub
	Private Sub SavePicToDB() ''''''' Save Picture to data base 

		If mStrPicSource = "" Then Exit Sub
		Dim ms As New System.IO.MemoryStream

		'' read Picture and convert to bytes 
		PicPersonnel.Image.Save(ms, PicPersonnel.Image.RawFormat)
		Dim arrImage() As Byte = ms.GetBuffer

		' Close the stream object to release the resource.
		ms.Close()

		'''' Update record 

		''Dim strSQL As String = _
		''                   "update  tblCompany  set  CompanyLogo = @Picture where CompanyID = " & txtCompanyID.Text
		'Dim cmd As New SqlClient.SqlCommand
		''With cmd
		''   .Parameters.Add(New SqlClient.SqlParameter("@Picture", _
		''       SqlDbType.Image)).Value = arrImage
		''End With
		''Dim cmd As New SqlClient.SqlCommand(strSQL, conSql)
		'cmd.Connection = conSql
		'cmd.CommandText = "spUpdateLogo"
		'cmd.CommandType = CommandType.StoredProcedure

		'cmd.Parameters.AddWithValue("@Picture", arrImage)
		'cmd.Parameters.AddWithValue("@CompanyID", txtCompanyID.Text)
		'conSql.Open()
		'cmd.ExecuteNonQuery()
		'conSql.Close()

		Dim strSQL As String = _
										"update  tblCompany  set  CompanyLogo = @Picture where CompanyID = " & gIntCompanyID

		Dim cmd As New SqlClient.SqlCommand(strSQL, conSql)
		With cmd
			.Parameters.Add(New SqlClient.SqlParameter("@Picture", _
				 SqlDbType.Image)).Value = arrImage
		End With
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()

		' MsgBox("Picture Changes will appear next time you Login to Form")


		blnPic = False	 '' Convert Boolean to false 
	End Sub
	'Private Sub BringPicFromDataBase()

	'   'Bring picture from data base 

	'   ' ask if there is any records in the db 
	'   If dsData.Tables(mstrTableName).Rows.Count = 0 Then Exit Sub

	'   ' ask if the field Photo is null in the database 
	'   If IsDBNull(dsData.Tables(mstrTableName).Rows(navComp.CurrentPosition)("CompanyLogo")) Then PicPersonnel.Image = Nothing : Exit Sub
	'   Dim arrPicture() As Byte = _
	' CType(dsData.Tables(mstrTableName).Rows(navComp.CurrentPosition)("CompanyLogo"), Byte())
	'   Dim ms As New System.IO.MemoryStream(arrPicture)

	'   ''' Appear pic for user 
	'   With PicPersonnel
	'      .Image = Image.FromStream(ms)
	'      .SizeMode = PictureBoxSizeMode.StretchImage
	'      .BorderStyle = BorderStyle.Fixed3D
	'   End With
	'   ''''''''''
	'End Sub
	Private Sub txtDataFile_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)
		ofdGetPhoto.Filter = "All files (*.*)|*.*"
		'ofdGetPhoto.InitialDirectory = txtDataFile.Text
		ofdGetPhoto.ShowDialog()
	End Sub

	'Private Sub btnDataLocation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataLocation.Click
	'   fbdDataFile.ShowDialog()
	'   txtDataFile.Text = fbdDataFile.SelectedPath
	'End Sub

#End Region

#Region "frmBranchAccounts"
	Private Sub CboAcctType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)


		If blncbo = True Then
			Return
		End If
		''


		''
		filterGrid()
	End Sub
	Private Sub filterGrid()
		''
		If blncbo = True Then
			Exit Sub
		End If
		''
		If grdBranch.CurrentRowIndex = -1 Then Exit Sub
		strSQL = "( True "
		'' Filter for BranchID Filter...
		'If cboBranch.SelectedIndex <> -1 Then
		Dim drRowToEdit As DataRow

		drRowToEdit = dsData.Tables("tblBranch").DefaultView.Item(grdBranch.CurrentRowIndex).Row

		strSQL = strSQL & " AND (BranchID=" & drRowToEdit("BranchID") & ")"
		'End If

		'' Filter On Selected AcctType...

		strSQL = strSQL & ")"

		''
		'  dsData.Tables("vwAccountBrAndType").DefaultView.RowFilter = strSQL
		blncbo = False

	End Sub

	Private Sub AccountSaved(ByVal sender As Object, ByVal e As EventArgs)
		dsData.Tables("vwAccountBrAndType").Rows.Clear()
		strSQL = "SELECT * FROM vwAccountBrAndType"
		daAccount = clsMr.BuildSqlAdapter(strSQL, "vwAccountBrAndType")
	End Sub


	Private Sub DrawGrid()
		Dim dgStyle As New DataGridTableStyle
		'Disabled()
		dgStyle.MappingName = "vwAccountBrAndType"
		''
		''
		If gStrLang = "ar" Then
			dgStyle.GridColumnStyles("BranchName").HeaderText = "��� �����"
			dgStyle.GridColumnStyles("AcctType").HeaderText = "��� ������"
			dgStyle.GridColumnStyles("AcctNumber").HeaderText = "��� ������"
			dgStyle.GridColumnStyles("ClientName").HeaderText = "��� ������"
			dgStyle.GridColumnStyles("Balance").HeaderText = "������"
			dgStyle.GridColumnStyles("Symbol").HeaderText = "������"
			dgStyle.GridColumnStyles("LedgerNumber").HeaderText = "ledger"
		Else
			'dgStyle.GridColumnStyles("BranchName").HeaderText = "Branch Name"
			'dgStyle.GridColumnStyles("AcctType").HeaderText = "Account Type"
			'dgStyle.GridColumnStyles("AcctNumber").HeaderText = "Account Num"
			'dgStyle.GridColumnStyles("ClientName").HeaderText = "Account Name"
			'dgStyle.GridColumnStyles("Balance").HeaderText = "Balance"
			' dgStyle.GridColumnStyles("Symbol").HeaderText = "Curr"
			'dgStyle.GridColumnStyles("LedgerNumber").HeaderText = "Ledger"
		End If
		'dgStyle.GridColumnStyles("BranchID").Width = 0
		'dgStyle.GridColumnStyles("BranchName").Width = 0
		'dgStyle.GridColumnStyles("AcctTypeID").Width = 0
		'dgStyle.GridColumnStyles("AcctType").Width = 120
		'dgStyle.GridColumnStyles("AcctID").Width = 0
		'dgStyle.GridColumnStyles("AcctNumber").Width = 80
		'dgStyle.GridColumnStyles("ClientName").Width = 120
		' ''
		'dgStyle.GridColumnStyles("Symbol").Width = 35
		''dgStyle.GridColumnStyles("Symbol").HeaderText = "Curr"
		'dgStyle.GridColumnStyles("Balance").Width = 100
		' ''
		'dgStyle.GridColumnStyles("Contactname").Width = 0
		'dgStyle.GridColumnStyles("Tel").Width = 0
		'dgStyle.GridColumnStyles("Ext").Width = 0
		'dgStyle.GridColumnStyles("cell").Width = 0
		'dgStyle.GridColumnStyles("Email").Width = 0
		' ''
		'dgStyle.GridColumnStyles("Bldg").Width = 0
		'dgStyle.GridColumnStyles("Office").Width = 0
		''dgStyle.GridColumnStyles("StreetID").Width = 0
		''dgStyle.GridColumnStyles("CityID").Width = 0
		'dgStyle.GridColumnStyles("Zipcode").Width = 0
		'dgStyle.GridColumnStyles("Note").Width = 0
		'dgStyle.GridColumnStyles("Del").Width = 0
		'dgStyle.GridColumnStyles("CreateBy").Width = 0
		'dgStyle.GridColumnStyles("CreateDate").Width = 0
		'dgStyle.PreferredColumnWidth = cboBranch.Height + 2
		'' put column header 
		'cboBranch.SelectedIndex = -1

		'If Mid() > 0 Then
		'   cboBranch.SelectedValue = Mid()
		'End If
	End Sub


	Private Sub btnNewBranchMaintenance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		' Select Case (CboAcctType.SelectedValue)
		'Case (6)
		'   Dim frm As New FrmAccount(0, "")
		'   frm.AcctTypeID = 6
		'   frm.Text = "BranchSales"
		'   MainForm.AddModelTabPage(frm, frmApplicationMain.eFormType.BranchSales)
		'   AddHandler frm.Closed, AddressOf AccountSaved

		'Case (7)
		'    Dim frm As New frmAccountNew(0, "")
		'    frm.AcctTypeID = 7
		'    'frm.cboLedger.SelectedValue = 549
		'    frm.Text = "BranchAccount"
		'    'frm.initControl()
		'    'MainForm.addModelTabPage(frm, frmApplicationMain.eFormType.BranchAccounts)
		'    ''frmApplicationMain.addModelTabPage(frm, frmApplicationMain.eFormType.BranchAccounts)
		'    frm.Show()
		'    AddHandler frm.Closed, AddressOf AccountSaved
		'Case (8)
		'    Dim frm As New frmAccountNew(0, "")
		'    frm.AcctTypeID = 8
		'    'frm.cboLedger.SelectedValue = 549
		'    frm.Text = "PurchaseExpense"
		'    'frm.initControl()
		'    frm.Show()
		'    'MainForm.addModelTabPage(frm, frmApplicationMain.eFormType.PurchaseExpenses)
		'    AddHandler frm.Closed, AddressOf AccountSaved

		' End Select
	End Sub

	Private Sub tcBranches_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tcBranches.SelectedIndexChanged
		If tcBranches.SelectedTab Is tpBranchAccts Then

			filterGrid()

			'   Dim drRowToEdit As DataRow
			'   drRowToEdit = dsData.Tables("tblBranch").DefaultView.Item(grdBranch.CurrentRowIndex).Row

			'   If drRowToEdit("BranchID") <> gIntBranchID Then
			'      grpBtns.Visible = False
			'      btnAcctStatement.Visible = False
			'   Else
			'      grpBtns.Visible = True
			'      btnAcctStatement.Visible = True
			'   End If

		End If

	End Sub
	Private Sub CboAcctType_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
		filterGrid()
	End Sub
	Private Sub grdBranch_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdBranch.CurrentCellChanged
		filterGrid()



	End Sub
	Private Sub SaveBranch()
		Dim al As ArrayList
		Dim dv As DataView
		Dim drv As DataRowView
		Dim i As Integer

		al = New ArrayList
		dv = dsData.Tables("tblBranch").DefaultView
		For i = 0 To dv.Count - 1
			drv = dv.Item(i)
			If drv.Row.RowState = DataRowState.Added Then
				al.Add(drv)
			End If
		Next

		clsMr.Update(dabranch, "tblBranch")

		' create accounts for new branches
		For Each drv In al
			' AcctTypeID 5 = Branch Stock
			'CreateAccount(drv("BranchId"), drv("BranchName"), 5)
			' AcctTypeID 6 = Branch Cash Sales
			'CreateAccount(drv("BranchId"), drv("BranchName"), 6)
		Next
		ifSave = False
		btnSave.Enabled = False
	End Sub
#End Region
	Private Sub setState(ByRef pStrMode As String)
		''
		mStrCurrentState = UCase(pStrMode)
		'' 
		Select Case mStrCurrentState
			Case Is = "NEW"

				Me.btnSave.Enabled = False
				Me.btnCancelMain.Enabled = True
				Me.btnNew.Enabled = False
				grpCompanyInfo.Enabled = True
				grpBranchAccounts.Enabled = True


				btnSave.Text = "S a v e"

			Case Is = "EDIT"

				Me.btnSave.Enabled = False
				Me.btnCancelMain.Enabled = True
				Me.btnNew.Enabled = False
				grpCompanyInfo.Enabled = True
				grpBranchAccounts.Enabled = True

				btnSave.Text = "S a v e"

			Case Is = "SAVE"

				Me.btnSave.Enabled = True
				Me.btnCancelMain.Enabled = False
				Me.btnNew.Enabled = True
				btnSave.Text = "E d i t"
				grpCompanyInfo.Enabled = False
				grpBranchAccounts.Enabled = False


			Case Is = "BROWSE"

				Me.btnSave.Enabled = True
				Me.btnCancelMain.Enabled = False
				Me.btnNew.Enabled = True
				btnSave.Text = "E d i t"
				grpCompanyInfo.Enabled = False
				grpBranchAccounts.Enabled = False


		End Select
	End Sub
	Private Sub dtpDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateFrom.ValueChanged
		checkValues()
	End Sub

	Private Sub dtpDateTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateTo.ValueChanged
		checkValues()
	End Sub

	Private Sub txtNote_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNote.TextChanged
		checkValues()
	End Sub

	Private Sub txtCompanyName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCompanyName.TextChanged
		checkValues()
	End Sub

	Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
		''
		'' Show/Hide error list...
		If lstDataErr.Visible = True Then
			lstDataErr.Visible = False
		Else
			lstDataErr.Visible = True
			lstDataErr.Height = 251
			lstDataErr.BringToFront()
		End If
	End Sub
	Private Sub checkValues()
		''
		If blncbo = True Then Exit Sub
		''
		ifSave = True
		'btnCancel.Enabled = True
		''
		'' clear entir list & start fresh check...
		''
		lstDataErr.Items.Clear()
		Dim intErrCount As Int16 = 0

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' check Error - Mandatory Data Objects...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''

		If Me.txtCompanyName.Text = "" Then
			lstDataErr.Items.Add("Error: Missing Company Name")
			intErrCount += 1
		End If
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' Set appropriate controls based on errors check results...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		If lstDataErr.Items.Count = 0 Then
			lstDataErr.Visible = False
			btnDataErr.Visible = False
			'lblHelpErr.Visible = False
		Else
			btnDataErr.Visible = True
			'lblHelpErr.Visible = True
		End If
		''
		If ifSave And intErrCount = 0 Then
			btnSave.Enabled = True


		Else
			btnSave.Enabled = False

		End If
	End Sub

	Private Sub btnCancelMain_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelMain.Click
		If ifSave Then
			If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

				Try
					Nav.CancelCurrentEdit()
				Catch ex As Exception

				End Try

				ifSave = False

				setState("BROWSE")
			End If
		Else
			setState("BROWSE")
			'AddMode = False
		End If
	End Sub
End Class
