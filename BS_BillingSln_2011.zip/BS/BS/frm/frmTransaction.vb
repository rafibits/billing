Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmTransaction

#Region " Form Declaration  .  .  . "
    ''
    Dim clsMr As ClsMain
    'Dim clsMrCommonDB As ClsMain

    Dim dsData As New DataSet
    'Dim dsCommonDB As New DataSet
    'Dim daBitsMArt As New SqlDataAdapter
    Dim datblTransaction As New SqlDataAdapter
    Dim datblTransactionParking As New SqlDataAdapter
    Private WithEvents Nav As BitsNav
    Dim blnLoading As Boolean = True
    Dim blnCountMdf As Boolean = False

    Private mStrSubKeyName As String = "Software\BIT Solutions\BS\NewTransactions\Settings"
    Private mStrSubKeyName2 As String = "Software\BIT Solutions\BS\ModifiedTransactions\Settings"

    Private mstrCurrentGridName As String

    ''
#End Region


#Region " Form Initialization . . . "

    Private Sub frmTransaction_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        ''
        SaveProfile(mStrSubKeyName, grdNewTransactions)
        SaveProfile(mStrSubKeyName2, grdModifiedTransactions)
    End Sub

    Private Sub frmTransaction_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmTransaction_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav
        ''
        blnLoading = True
        ''
        MakeDataAdapter()
        SetAutoNumber()
        SetCurrency()
        DrawGrid()
        ChangeColor()
        Renumbering(grdNewTransactions)
        ''
        btnDelete.Enabled = False
        btnCopyData.Enabled = True
        btnUpdateTransactions.Enabled = False
        btnUpdateHours.Enabled = False
        blnLoading = False
        ''
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

    End Sub

#End Region


#Region " Form Functions   .   .   ."

    Private Sub MakeDataAdapter()
        ''
        datblTransactionParking = clsMr.BuildSqlAdapter(" SELECT TransactionParkingID, seq_ID, ParkingAreaID, ParkingCode,DtIn, DtOut, TotalHours, TotalChargeableHours,Del FROM tblTransactionParking", "tblTransactionParking")
        clsMr.BuildSqlAdapter("SELECT  madarej_hangar, madarej_datein, madarej_timein, madarej_dateout, madarej_timeout,  seq_ID FROM madarej", "madarej")
        clsMr.BuildSqlAdapter("SELECT seq_ID, Reg_serial, Operatr, Callsign_orig, Ap_orig, dat_orig, time_orig, light_orig, gate, Callsign_dest, Ap_dest, dat_dest,time_dest, light_dest, confArr, confDep, counters, creationDate, modificationDate, gates_invFinger, reg_weight, Aircraft_type FROM [BitsMart].[dbo].[Transaction]", "Transaction")
        datblTransaction = clsMr.BuildSqlAdapter("SELECT TransactionID,Seq_ID, Reg_serial, Operatr, Callsign_orig, Ap_orig, dat_orig, time_orig, rwy_orig, light_orig, gate, Callsign_dest, Ap_dest, dat_dest, time_dest, light_dest, confArr, confDep, counters, creationDate, modificationDate, gates_invFinger, reg_weight, rwy_dest, transp_tc, houboutInv, iklaaInv, iwaaTotPaid, iwaaDaysPaid, iwaaLastDate, creationUser_counters, creationDate_counters, modificationUser_counters, modificationDate_counters, fids_desc, op_representative, remark_orig, remark_dest, modificationUser, creationUser, Aircraft_type FROM [tblTransaction] WHERE InvoiceID IS NULL", "tblTransaction")
        clsMr.BuildSqlAdapter("SELECT TransactionID, seq_ID, reg_weight, gates_invFinger, modificationDate, creationDate, counters, confDep, confArr, light_dest, time_dest, dat_dest, Callsign_dest, Ap_dest, gate, light_orig, time_orig, dat_orig, Ap_orig, Callsign_orig, Operatr, Reg_serial, Aircraft_type FROM [BitsMart].[dbo].[vwFilterGrid]", "NewTransactions")
        ''
        clsMr.BuildSqlAdapter("SELECT     TransactionID,seq_ID, Reg_serial, Operatr, Callsign_orig, Ap_orig, dat_orig," & _
         "time_orig, rwy_orig, light_orig, gate, Callsign_dest, Ap_dest, dat_dest, time_dest," & _
         "rwy_dest, light_dest, confArr, confDep, counters, transp_tc, houboutInv, " & _
         "iklaaInv, iwaaTotPaid, iwaaDaysPaid, iwaaLastDate, creationUser, " & _
         "creationDate, modificationUser, modificationDate, creationUser_counters, " & _
        "creationDate_counters, modificationUser_counters, " & _
        "modificationDate_counters, fids_desc, gates_invFinger, reg_weight, op_representative, remark_orig, remark_dest, Aircraft_type" & _
        " FROM dbo.[tblTransaction] WHERE(seq_ID IN(SELECT [seq_ID] FROM [TRANSACTION]))", "ModifiedTransactions")
        ''
        clsMr.BuildSqlAdapter("SELECT TransactionID FROM [BitsMart].[dbo].[vwFilterGrid]", "NewTrxByIDs")
        dsData = clsMr.getDataSet
    End Sub

    Private Sub DrawGrid()
        ''
        dsData.Tables("NewTransactions").DefaultView.AllowNew = False
        dsData.Tables("ModifiedTransactions").DefaultView.AllowNew = False
        ''
        With grdNewTransactions
            ''
            Dim dgvc As New DataGridViewTextBoxColumn
            ''
            dgvc.DataPropertyName = "Line"
            dgvc.HeaderText = "Line"
            dgvc.Name = "Line"
            dgvc.Width = 47
            .Columns.Insert(0, dgvc)
            ''
            .AllowUserToDeleteRows = False
            .DataSource = dsData.Tables("NewTransactions").DefaultView
            .ReadOnly = True
            .Columns("TransactionID").Visible = False
            .ColumnHeadersHeight = btnShowCol.Height + 2
            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        End With
        ''
        RemoveGrdListItems()
        LoadProfile(mStrSubKeyName, grdNewTransactions)
        ''
        With grdModifiedTransactions
            .DataSource = dsData.Tables("ModifiedTransactions").DefaultView
            .AllowUserToDeleteRows = False
            .Columns("TransactionID").Visible = False
            .Columns("TransactionID").ReadOnly = True
            .Columns("seq_ID").ReadOnly = True
            '.Columns("Reg_serial").ReadOnly = True
            .Columns("dat_orig").ReadOnly = True
            .Columns("time_orig").ReadOnly = True
            .Columns("rwy_orig").ReadOnly = True
            .Columns("time_dest").ReadOnly = True
            .Columns("dat_dest").ReadOnly = True
            .Columns("gates_invFinger").ReadOnly = True
            .Columns("light_orig").ReadOnly = True
            .Columns("gate").ReadOnly = True
            '.Columns("reg_weight").ReadOnly = True
            ''
            .ColumnHeadersHeight = btnShowCol.Height + 2
            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
            .Columns("TransactionID").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            .Columns("seq_ID").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            '.Columns("Reg_serial").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            .Columns("dat_orig").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            .Columns("time_orig").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            .Columns("rwy_orig").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            .Columns("dat_dest").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            .Columns("gates_invFinger").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            .Columns("light_orig").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            .Columns("gate").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            '.Columns("reg_weight").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            .Columns("time_dest").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
            ''
        End With
        ''
        LoadProfile(mStrSubKeyName2, grdModifiedTransactions)
        ''
        AddHandler dsData.Tables("ModifiedTransactions").ColumnChanged, AddressOf Column_Changed
    End Sub

    Private Sub ChangeColor()
        ''
        ''change color for Modified Transactions ..........
        ''
        '   Dim i As Integer
        '   ' Dim intStatus As Integer
        '   If grdNewTransactions.Rows.Count <> 0 Then
        'For i = 0 To dsData.Tables("NewTransactions").DefaultView.Count - 1
        '	If Not IsDBNull(dsData.Tables("newTransactions").DefaultView.Item(i)("TransactionID")) Then
        '		grdNewTransactions.Rows(i).DefaultCellStyle.BackColor = Color.LightSteelBlue
        '	End If
        'Next
        '   End If
        '***************************************************************
        ''
        Dim i As Integer
        If grdNewTransactions.Rows.Count <> 0 Then
            For i = 0 To dsData.Tables("NewTransactions").DefaultView.Count - 1
                Dim Seq As Integer
                Try
                    Dim cmd As New SqlClient.SqlCommand("SELECT seq_id FROM tbltransaction WHERE seq_ID=" & dsData.Tables("newTransactions").DefaultView.Item(i)("Seq_ID"), conSql)

                    conSql.Open()
                    Seq = cmd.ExecuteScalar
                    conSql.Close()
                    If Seq <> 0 Then
                        grdNewTransactions.Rows(i).DefaultCellStyle.BackColor = Color.LightSteelBlue
                    End If
                Catch ex As Exception
                    conSql.Close()
                End Try
            Next
        End If
    End Sub

    Private Sub RemoveGrdListItems()
        ''
        chkLstGridCol.Items.Remove("TransactionID")
    End Sub

    Private Sub SetAutoNumber()
        ''
        Dim lngMax As Long
        lngMax = clsMr.GetMaxNumber("SELECT MAX(TransactionID) FROM tblTransaction ") + 1
        clsMr.SetAutoNumber("tblTransaction", "TransactionID", lngMax)
        Dim lngMaxPar As Long
        lngMaxPar = clsMr.GetMaxNumber("SELECT MAX(TransactionParkingID) FROM tblTransactionParking ") + 1
        clsMr.SetAutoNumber("tblTransactionParking", "TransactionParkingID", lngMaxPar)
    End Sub

    Private Sub setDefaultValue()
        ''
        clsMr.SetDefaults("tblTransactionParking", "CreateByID", gIntUserID, "CreateDate", Now.Date, "Del", 0)
    End Sub

    Public Sub SetCurrency()
        ''
        Nav.SetCurrency(Me, dsData, "tblTransaction")
    End Sub

    Private Function CopyNewTrxIntoTrx() As Boolean
        ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' RUN spInsertTrxFromCommonDB
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim command As New SqlClient.SqlCommand
        command.CommandText = "spInsertTrxFromCommonDB"
        Try
            command.Connection = conSql
            command.CommandType = CommandType.StoredProcedure
            conSql.Open()
            command.ExecuteNonQuery()
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try
        ''
    End Function

    Private Function CopyNewMadarejIntoMadarej() As Boolean
        ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' RUN spInsertMadarejFromCommonDB
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        Dim command As New SqlClient.SqlCommand
        command.CommandText = "spInsertMadarejFromCommonDB"
        Try
            command.Connection = conSql
            command.CommandType = CommandType.StoredProcedure
            conSql.Open()
            command.ExecuteNonQuery()
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try
        ''
    End Function

    Private Function CopyTrxIntotblTrx() As Boolean
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '---------------- COPY Data - INTO BitsMArt - FROM Transaction TO tblTransaction --------------------------
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''
        Dim dvTransaction As DataView = dsData.Tables("NewTransactions").DefaultView
        Dim drtblTransaction As DataRow
        Dim drTransaction As DataRowView
        Dim i As Integer
        For Each drTransaction In dvTransaction
            drtblTransaction = dsData.Tables("tbltransaction").NewRow
            'drtblTransaction("TransactionID") = clsMr.GetMaxNumber("TransactionID", "tblTransaction") + 1
            drtblTransaction("seq_ID") = drTransaction("seq_ID")
            drtblTransaction("Reg_serial") = drTransaction("Reg_serial")
            drtblTransaction("Operatr") = drTransaction("Operatr")
            drtblTransaction("Callsign_orig") = drTransaction("Callsign_orig")
            drtblTransaction("Ap_orig") = drTransaction("Ap_orig")
            drtblTransaction("dat_orig") = drTransaction("dat_orig")
            drtblTransaction("time_orig") = drTransaction("time_orig")
            'drtblTransaction("rwy_orig") = drTransaction("rwy_orig")
            drtblTransaction("light_orig") = drTransaction("light_orig")
            drtblTransaction("gate") = drTransaction("gate")
            drtblTransaction("Callsign_dest") = drTransaction("Callsign_dest")
            drtblTransaction("Ap_dest") = drTransaction("Ap_dest")
            drtblTransaction("dat_dest") = drTransaction("dat_dest")
            drtblTransaction("time_dest") = drTransaction("time_dest")
            drtblTransaction("light_dest") = drTransaction("light_dest")
            drtblTransaction("confArr") = drTransaction("confArr")
            drtblTransaction("confDep") = drTransaction("confDep")
            drtblTransaction("counters") = drTransaction("counters")
            drtblTransaction("creationDate") = drTransaction("creationDate")
            drtblTransaction("modificationDate") = drTransaction("modificationDate")
            drtblTransaction("gates_invFinger") = drTransaction("gates_invFinger")
            drtblTransaction("reg_weight") = drTransaction("reg_weight")
            drtblTransaction("Aircraft_type") = drTransaction("Aircraft_type")
            'If drTransaction("transp_tc") Is DBNull.Value Then
            '   drtblTransaction("transp_tc") = 0
            'Else
            '   drtblTransaction("transp_tc") = drTransaction("transp_tc")
            'End If
            ' drtblTransaction("houboutInv") = drTransaction("houboutInv")
            'drtblTransaction("iklaaInv") = drTransaction("iklaaInv")
            'drtblTransaction("iwaaTotPaid") = drTransaction("iwaaTotPaid")
            'drtblTransaction("iwaaDaysPaid") = drTransaction("iwaaDaysPaid")
            'drtblTransaction("iwaaLastDate") = drTransaction("iwaaLastDate")
            'drtblTransaction("creationUser_counters") = drTransaction("creationUser_counters")
            'drtblTransaction("creationDate_counters") = drTransaction("creationDate_counters")
            'drtblTransaction("modificationUser_counters") = drTransaction("modificationUser_counters")
            'drtblTransaction("modificationDate_counters") = drTransaction("modificationDate_counters")
            'drtblTransaction("fids_desc") = drTransaction("fids_desc")
            'drtblTransaction("op_representative") = drTransaction("op_representative")
            'drtblTransaction("remark_orig") = drTransaction("remark_orig")
            'drtblTransaction("remark_dest") = drTransaction("remark_dest")
            'drtblTransaction("modificationUser") = drTransaction("modificationUser")
            'drtblTransaction("creationUser") = drTransaction("creationUser")
            Dim seqID As Integer
            Try
                Dim cmd As New SqlClient.SqlCommand("SELECT seq_id FROM tbltransaction WHERE seq_ID=" & drTransaction("seq_ID"), conSql)
                conSql.Open()
                seqID = cmd.ExecuteScalar()
                conSql.Close()
            Catch ex As Exception
                conSql.Close()
            End Try
            If seqID = 0 Then
                dsData.Tables("tblTransaction").Rows.Add(drtblTransaction)
                Try
                    Dim cmd As New SqlClient.SqlCommand("DELETE FROM [Transaction] where seq_ID =" & drTransaction("seq_ID"), conSql)
                    conSql.Open()
                    cmd.ExecuteNonQuery()
                    conSql.Close()
                Catch ex As Exception
                    conSql.Close()
                End Try
            End If
        Next
        datblTransaction.Update(dsData, "tblTransaction")
        ''
    End Function

    Private Function CopyMadarejIntotblTrxParking() As Boolean
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '---------------- COPY Data - INTO BitsMart - FROM Madarej TO tblTransactionParking --------------------------
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        dsData.Tables("Madarej").Rows.Clear()
        clsMr.BuildSqlAdapter("SELECT  madarej_hangar, madarej_datein , madarej_timein, madarej_dateout, madarej_timeout, seq_ID FROM madarej WHERE madarej_datein IS NOT NULL AND madarej_timein IS NOT NULL AND madarej_dateout IS NOT NULL AND madarej_timeout IS NOT NULL AND Seq_ID NOT IN ( SELECT Seq_ID FROM tblTransactionParking)", "madarej")
        ''
        Dim dvMadarej As DataView = dsData.Tables("Madarej").DefaultView
        Dim drtblTransactionParking As DataRow
        Dim drMadarej As DataRowView
        Dim i As Integer
        Dim madarej_datein As Date, madarej_timein As Date
        Dim madarej_dateout As Date, madarej_timeout As Date

        Dim DateIn As Date
        Dim DateOut As Date
        ''
        For Each drMadarej In dvMadarej
            'TODO : if drMadarej("madarej_datein") OR drMadarej("madarej_timein") OR drMadarej("madarej_dateout") OR drMadarej("madarej_timeout")is Null 
            madarej_datein = drMadarej("madarej_datein")
            madarej_timein = drMadarej("madarej_timein")
            DateIn = New Date(madarej_datein.Year, madarej_datein.Month, madarej_datein.Day, madarej_timein.Hour, madarej_timein.Minute, madarej_timein.Second, madarej_timein.Millisecond)

            madarej_dateout = drMadarej("madarej_dateout")
            madarej_timeout = drMadarej("madarej_timeout")
            DateOut = New Date(madarej_dateout.Year, madarej_dateout.Month, madarej_dateout.Day, madarej_timeout.Hour, madarej_timeout.Minute, madarej_timeout.Second, madarej_timeout.Millisecond)

            drtblTransactionParking = dsData.Tables("tbltransactionParking").NewRow
            drtblTransactionParking("seq_ID") = drMadarej("seq_ID")
            drtblTransactionParking("ParkingCode") = drMadarej("madarej_hangar")
            drtblTransactionParking("DtIn") = DateIn
            drtblTransactionParking("DtOut") = DateOut
            drtblTransactionParking("Del") = 0
            'drtblTransactionParking("CreateBy") = gIntUserID
            'drtblTransactionParking("CreateDate") = Now.Date

            'clsMr.SetDefaults("tblTransactionParking", "CreateByID", gIntUserID, "CreateDate", Now.Date, "Del", 0)

            dsData.Tables("tblTransactionParking").Rows.Add(drtblTransactionParking)

            'Try
            '	Dim cmd As New SqlClient.SqlCommand("DELETE FROM [Madarej] where seq_ID =" & drMadarej("seq_ID"), conSql)
            '	conSql.Open()
            '	cmd.ExecuteNonQuery()
            '	conSql.Close()
            '	'RefreshGrids()
            'Catch ex As Exception
            '	conSql.Close()
            'End Try
        Next
        ''
        Try
            Dim cmd As New SqlClient.SqlCommand("DELETE FROM [Madarej]", conSql)
            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try
        ''
        datblTransactionParking.Update(dsData, "tblTransactionParking")

    End Function

    Private Sub Column_Changed(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
        ''
        If blnLoading Then Exit Sub
        ''
        If grdModifiedTransactions.Rows.Count = 0 Then Exit Sub
        ''
        If (grdModifiedTransactions.CurrentRow) Is Nothing Then
            Exit Sub
        End If
        ''
        If e.Column.ColumnName = "Operatr" Or e.Column.ColumnName = "Callsign_orig" Or e.Column.ColumnName = "Ap_orig" Or e.Column.ColumnName = "Callsign_dest" Or e.Column.ColumnName = "Ap_dest" Or e.Column.ColumnName = "light_dest" Or e.Column.ColumnName = "confArr" Or e.Column.ColumnName = "confDep" Or e.Column.ColumnName = "counters" Or e.Column.ColumnName = "creationDate" Or e.Column.ColumnName = "modificationDate" Or e.Column.ColumnName = "rwy_dest" Or e.Column.ColumnName = "transp_tc" Or e.Column.ColumnName = "houboutInv" Or e.Column.ColumnName = "iklaaInv" Or e.Column.ColumnName = "iwaaTotPaid" Or e.Column.ColumnName = "iwaaDaysPaid" Or e.Column.ColumnName = "iwaaLastDate" Or e.Column.ColumnName = "creationUser_counters" Or e.Column.ColumnName = "creationDate_counters" Or e.Column.ColumnName = " modificationUser_counters" Or e.Column.ColumnName = "modificationDate_counters" Or e.Column.ColumnName = "fids_desc" Or e.Column.ColumnName = "op_representative" Or e.Column.ColumnName = "remark_orig" Or e.Column.ColumnName = "remark_dest" Or e.Column.ColumnName = "modificationUser" Or e.Column.ColumnName = "creationUser" Or e.Column.ColumnName = "reg_weight" Or e.Column.ColumnName = "Reg_serial" Then
            ''
            btnSave.Enabled = True
        End If
    End Sub

    Private Sub filterGrid()
        ''
        If blnLoading Then Exit Sub
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor

        If rdbAllTransactions.Checked = True Then
            dsData.Tables("NewTransactions").DefaultView.RowFilter = ""
        ElseIf rdbNewTransactions.Checked = True Then
            dsData.Tables("NewTransactions").DefaultView.RowFilter = "TransactionID IS  NULL"
        Else
            dsData.Tables("NewTransactions").DefaultView.RowFilter = "TransactionID IS NOT NULL"
        End If
        ''
        Renumbering(grdNewTransactions)
        ChangeColor()
        Windows.Forms.Cursor.Current = Cursors.Default

    End Sub

    Private Sub RefreshGrids()
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''Refresh Grid grdNewtransactions
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        dsData.Tables("NewTransactions").Rows.Clear()
        clsMr.BuildSqlAdapter("SELECT TransactionID, reg_weight, gates_invFinger, modificationDate, creationDate, counters, confDep, confArr, light_dest, time_dest, dat_dest, Callsign_dest, Ap_dest, gate, light_orig, time_orig, dat_orig, Ap_orig, Callsign_orig, Operatr, Reg_serial, seq_ID, Aircraft_type FROM [BitsMart].[dbo].[vwFilterGrid]", "NewTransactions")

        ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''Refresh Grid  grdModifiedtransactions
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        dsData.Tables("ModifiedTransactions").Rows.Clear()
        clsMr.BuildSqlAdapter("SELECT     TransactionID,seq_ID, Reg_serial, Operatr, Callsign_orig, Ap_orig, dat_orig," & _
         "time_orig, rwy_orig, light_orig, gate, Callsign_dest, Ap_dest, dat_dest, time_dest," & _
         "rwy_dest, light_dest, confArr, confDep, counters, transp_tc, houboutInv, " & _
         "iklaaInv, iwaaTotPaid, iwaaDaysPaid, iwaaLastDate, creationUser, " & _
         "creationDate, modificationUser, modificationDate, creationUser_counters, " & _
          "creationDate_counters, modificationUser_counters, " & _
          "modificationDate_counters, fids_desc, gates_invFinger, reg_weight, op_representative, remark_orig, remark_dest, Aircraft_type" & _
          " FROM dbo.[tblTransaction] WHERE(seq_ID IN(SELECT [seq_ID] FROM [BitsMArt].[dbo].[TRANSACTION]))", "ModifiedTransactions")
        ''
        ChangeColor()
    End Sub

    Private Sub UpdateClient()
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ' UPDATE Client INTO Table tblTransaction 
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''
        Try
            Dim cmd As New SqlCommand("UPDATE tblTransaction SET ClientID = tblClient.ClientID FROM tblClient INNER JOIN tblTransaction ON tblTransaction.Operatr = tblClient.ICAO WHERE tblTransaction.InvoiceID IS NULL", conSql)
            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()
        Catch ex As Exception
            Windows.Forms.Cursor.Current = Cursors.Default()
            conSql.Close()
        End Try
    End Sub

    Private Sub DeleteTransactions()
        '
        Try
            Dim cmd As New SqlClient.SqlCommand("DELETE FROM [Transaction]", conSql)
            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()
            RefreshGrids()
        Catch ex As Exception
            conSql.Close()
        End Try
    End Sub

    Private Sub ChekModified()
        ''
        If dsData.Tables("ModifiedTransactions").Rows.Count <> 0 Then
            btnDelete.Enabled = True
        Else
            btnDelete.Enabled = False
        End If
    End Sub

#End Region


#Region "UI-Events . . . . . . . .  "

    Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
        ''
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()
            mstrCurrentGridName = "ImportTransactions"
            ''
            '' populate list with grid's dataSource fields...
            ''
            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdNewTransactions.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next
            RemoveGrdListItems()
        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If

        ''
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        ''
        Me.Close()
    End Sub

    Private Sub btnGrdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGrdClose.Click
        ''
        pnlModified.Visible = False
        Me.grdNewTransactions.Height += 114
    End Sub

    Private Sub btnUpdateHours_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateHours.Click
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ''
        'MsgBox("Start")
        Try
            Dim i As Integer
            Dim dv As DataView
            'Dim dvNewTrxIDs As DataView
            ''
            dv = dsData.Tables("tblTransaction").DefaultView
            'dvNewTrxIDs = dsData.Tables("NewTrxByIDs").DefaultView
            ''
            For i = 0 To dv.Count - 1
                ''
                strSQL = "UPDATE tbltransaction "
                strSQL &= "SET tbltransaction.Hours =( "
                strSQL &= "SELECT SUM(tblTransactionParking.TotalChargeableHours) "
                strSQL &= "FROM tblTransactionParking "
                strSQL &= "WHERE tblTransactionParking.Seq_ID = " & dv(i)("Seq_ID") & ")"
                strSQL &= "WHERE tblTransaction.Seq_ID = " & dv(i)("Seq_ID")
                'strSQL &= " AND tblTransaction.TransactionID IN ("
                'strSQL &= "SELECT TransactionID FROM [BitsMart].[dbo].[vwFilterGrid])"
                ''
                Dim cmd As New SqlCommand(strSQL, conSql)
                conSql.Open()
                cmd.ExecuteNonQuery()
                conSql.Close()
            Next
        Catch ex As Exception
            Windows.Forms.Cursor.Current = Cursors.Default()
            conSql.Close()
        End Try
        ''
        btnUpdateHours.Enabled = False
        ChekModified()
        ''
        Renumbering(grdNewTransactions)
        'MsgBox("Finish")
        Windows.Forms.Cursor.Current = Cursors.Default
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor()
        Dim intCounter As Integer


        Dim drUpdate() As DataRow
        Dim dt As DataTable

        dt = dsData.Tables("ModifiedTransactions").GetChanges(DataRowState.Modified)

        If Not (dt Is Nothing) Then
            'dsData.Tables("tblTransaction").Rows.Clear()

            'datblTransaction = clsMr.BuildSqlAdapter("SELECT TransactionID,Operatr, Callsign_orig, Ap_orig, Callsign_dest, Ap_dest, light_dest, confArr, confDep, counters, creationDate, modificationDate,rwy_dest, transp_tc, houboutInv, iklaaInv, iwaaTotPaid, iwaaDaysPaid, iwaaLastDate, creationUser_counters, creationDate_counters, modificationUser_counters, modificationDate_counters, fids_desc, op_representative, remark_orig, remark_dest, modificationUser, creationUser FROM tblTransaction", "tblTransaction")

            For intCounter = 0 To dt.Rows.Count - 1
                drUpdate = dsData.Tables("tblTransaction").Select("TransactionID=" & grdModifiedTransactions.Item("TransactionID", intCounter).Value)
                drUpdate(0).BeginEdit()
                drUpdate(0)("Operatr") = dt.Rows(intCounter)("Operatr")
                drUpdate(0)("Callsign_orig") = dt.Rows(intCounter)("Callsign_orig")
                drUpdate(0)("Ap_orig") = dt.Rows(intCounter)("Ap_orig")
                drUpdate(0)("Callsign_dest") = dt.Rows(intCounter)("Callsign_dest")
                drUpdate(0)("Ap_dest") = dt.Rows(intCounter)("Ap_dest")
                drUpdate(0)("light_dest") = dt.Rows(intCounter)("light_dest")
                drUpdate(0)("confArr") = dt.Rows(intCounter)("confArr")
                drUpdate(0)("confDep") = dt.Rows(intCounter)("confDep")
                drUpdate(0)("counters") = dt.Rows(intCounter)("counters")
                drUpdate(0)("creationDate") = dt.Rows(intCounter)("creationDate")
                drUpdate(0)("modificationDate") = dt.Rows(intCounter)("modificationDate")
                drUpdate(0)("rwy_dest") = dt.Rows(intCounter)("rwy_dest")
                drUpdate(0)("transp_tc") = dt.Rows(intCounter)("transp_tc")
                drUpdate(0)("houboutInv") = dt.Rows(intCounter)("houboutInv")
                drUpdate(0)("iklaaInv") = dt.Rows(intCounter)("iklaaInv")
                drUpdate(0)("iwaaTotPaid") = dt.Rows(intCounter)("iwaaTotPaid")
                drUpdate(0)("iwaaDaysPaid") = dt.Rows(intCounter)("iwaaDaysPaid")
                drUpdate(0)("iwaaLastDate") = dt.Rows(intCounter)("iwaaLastDate")
                drUpdate(0)("creationUser_counters") = dt.Rows(intCounter)("creationUser_counters")
                drUpdate(0)("creationDate_counters") = dt.Rows(intCounter)("creationDate_counters")
                drUpdate(0)("modificationUser_counters") = dt.Rows(intCounter)("modificationUser_counters")
                drUpdate(0)("modificationDate_counters") = dt.Rows(intCounter)("modificationDate_counters")
                drUpdate(0)("fids_desc") = dt.Rows(intCounter)("fids_desc")
                drUpdate(0)("op_representative") = dt.Rows(intCounter)("op_representative")
                drUpdate(0)("remark_orig") = dt.Rows(intCounter)("remark_orig")
                drUpdate(0)("remark_dest") = dt.Rows(intCounter)("remark_dest")
                drUpdate(0)("modificationUser") = dt.Rows(intCounter)("modificationUser")
                drUpdate(0)("creationUser") = dt.Rows(intCounter)("creationUser")
                drUpdate(0)("Aircraft_type") = dt.Rows(intCounter)("Aircraft_type")
                drUpdate(0)("Reg_serial") = dt.Rows(intCounter)("Reg_serial")
                ''
                drUpdate(0).EndEdit()
            Next
        End If

        dt = dsData.Tables("tblTransaction").GetChanges

        If Not (dt Is Nothing) Then
            datblTransaction.Update(dt)
            dsData.Tables("tblTransaction").AcceptChanges()

        End If

        btnSave.Enabled = False
        Windows.Forms.Cursor.Current = Cursors.Default()
        ''
    End Sub

    Private Sub btnCopyData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyData.Click
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        dsData.Tables("NewTransactions").Rows.Clear()
        If grdNewTransactions.Rows.Count <> 0 Then
            grdNewTransactions.AllowUserToDeleteRows = True
            grdNewTransactions.Rows.Clear()
            grdNewTransactions.ReadOnly = False
        End If
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ' Copy data from table Transaction(CommonDB) To Table Transaction(BitsMArt) 
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        CopyNewTrxIntoTrx()
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ' Copy data from table Madarej(CommonDB) To Table Madarej(BitsMArt) 
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        CopyNewMadarejIntoMadarej()
        ''
        CopyMadarejIntotblTrxParking()
        ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''-----------------------------' Update ParkingAreaID in tblTransactionParking'-------------------------'
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        Try

            Dim cmd As New SqlCommand("UPDATE tblTransactionParking SET tblTransactionParking.ParkingAreaID = tblParkingArea.ParkingAreaID FROM tblParkingArea INNER JOIN tblTransactionParking AS tblTransactionParking_1 ON tblParkingArea.ParkingAreaCode = tblTransactionParking_1.ParkingCode where tblParkingArea.ParkingAreaCode = tblTransactionParking_1.ParkingCode ", conSql)

            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()

        Catch ex As Exception
            Windows.Forms.Cursor.Current = Cursors.Default()
            conSql.Close()
        End Try
        ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '---------------------------' Update TotalHours in tblTransactionParking ----------------------------'
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        Try

            Dim cmd As New SqlCommand("Update tbltransactionParking set Totalhours= ceiling(cast(datediff(minute, (DtIn), (DtOut)) as decimal)/60)", conSql)  'ceiling(datediff(minute, (DtIn), (DtOut))/60)", conSql)
            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()

        Catch ex As Exception
            Windows.Forms.Cursor.Current = Cursors.Default()
            conSql.Close()
        End Try
        ''
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '---------------------------' Update TotalChargeableHours in tblTransactionParking--------------------
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        Try

            Dim cmdChargeable As New SqlCommand("Update tblTransactionParking set TotalChargeablehours= ceiling(Cast(datediff(minute, (DtIn), (DtOut)) as decimal)/60) FROM tblTransactionParking inner join tblParkingArea on tblTransactionParking.ParkingAreaID=tblParkingArea.ParkingAreaID WHERE tblParkingArea.Chargeable <> 0", conSql)

            conSql.Open()
            cmdChargeable.ExecuteNonQuery()
            conSql.Close()

        Catch ex As Exception
            Windows.Forms.Cursor.Current = Cursors.Default()
            conSql.Close()
        End Try

        RefreshGrids()
        ChekModified()
        Renumbering(grdNewTransactions)
        ''
        btnCopyData.Enabled = False
        btnUpdateTransactions.Enabled = True
        btnUpdateHours.Enabled = False
        Windows.Forms.Cursor.Current = Cursors.Default

    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        ''
        If grdNewTransactions.Rows.Count = 0 Then Exit Sub
        ''

        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to delete?", MsgBoxStyle.YesNo, "BitSolution")

        If response = MsgBoxResult.Yes Then

            Dim i As Integer


            Dim dv As DataGridViewSelectedRowCollection = grdNewTransactions.SelectedRows

            For i = 0 To grdNewTransactions.SelectedRows.Count - 1

                Dim cmd As New SqlClient.SqlCommand("DELETE FROM [Transaction] where seq_ID =" & dv(i).Cells("seq_ID").Value, conSql)
                Try
                    conSql.Open()
                    cmd.ExecuteNonQuery()
                    conSql.Close()
                    ''

                Catch ex As Exception
                    conSql.Close()
                End Try

            Next

        End If

        RefreshGrids()
        ChekModified()
    End Sub

    Private Sub btnUpdateTransactions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateTransactions.Click
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''Copy data In BitsMArt from table Transaction  To Table tblTransaction 
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        CopyTrxIntotblTrx()
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''Update Client in tblTransaction...
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        UpdateClient()
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''Refresh Grids
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        RefreshGrids()
        ChekModified()
        btnUpdateTransactions.Enabled = False
        btnUpdateHours.Enabled = True
        Renumbering(grdNewTransactions)
        Windows.Forms.Cursor.Current = Cursors.Default

        ''
        'If grd.Count > 0 Then
        '   '' we have a modified trx(s) - raise flag
        'End If
        ' filter()
    End Sub

    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
        ''
        Dim i As Integer

        For i = 0 To Me.chkLstGridCol.Items.Count - 1
            Me.grdNewTransactions.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
        Next
        ''
        Me.grpShowHideColumns.Visible = False
    End Sub

    Private Sub btnDeleteAllTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteAllTransaction.Click
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ' Delete data from table Transaction after Copy New Data
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        DeleteTransactions()
    End Sub

    Private Sub rdbAllTransactions_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbAllTransactions.CheckedChanged
        filterGrid()
    End Sub

    Private Sub rdbNewTransactions_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbNewTransactions.CheckedChanged
        filterGrid()
    End Sub

    Private Sub rdbModifiedTransactions_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbModifiedTransactions.CheckedChanged
        filterGrid()
    End Sub

    Private Sub grdNewTransactions_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdNewTransactions.CellDoubleClick
        ''
        If grdNewTransactions.Rows.Count <> 0 Then
            dsData.Tables("ModifiedTransactions").DefaultView.RowFilter = "Seq_ID=" & grdNewTransactions.Item("seq_ID", grdNewTransactions.CurrentRow.Index).Value
        End If
        ''
        Dim intDiff As Int16
        If pnlModified.Visible = True Then
            '' hide it...
            pnlModified.Visible = False
            intDiff = 114
        Else
            pnlModified.Visible = True
            intDiff = -114
        End If
        ''
        '' up/dwn: grd...
        ''
        Me.grdNewTransactions.Height += intDiff
    End Sub

#End Region


End Class