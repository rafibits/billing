Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmInvoicesGet

#Region " Form Declaration  .  .  ."
   ''
   Private dsdata As DataSet
   Private clsMr As ClsMain
   Private daTafkeet As SqlDataAdapter
   Private blnLoading As Boolean
   Private mstrCurrentGridName As String
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\InvoiceList\InvoicesGet\Settings"
   Private intPeriodChecked As Integer = 0
   Public arrPay(50) As Integer
	Private mClient As Integer
	Private mstrIDs As String
#End Region


#Region " Form Initialization . . ."

    Private Sub frmInvoicesGet_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmInvoicesGet_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ''
        clsMr = New ClsMain(conSql)
        ''
        blnLoading = True
        MakeDataAdapter()
        FillComboBox()
        DrawGrid()
        cboClient.SelectedValue = mClient
        blnLoading = False
        FilterGrid()
    End Sub

    Private Sub MakeDataAdapter()
        ''
        '' Get Invoice(s) that is\are related to specific client defined in frmPayment through the Me.constructor . . . . 
        If mstrIDs <> "" Then
            clsMr.BuildSqlAdapter("SELECT * FROM vwInvoiceList WHERE Del=0 AND StatusID = 2  AND InvoiceID NOT  IN (" & mstrIDs & ")", "vwInvoiceList") 'AND ClientID =" & mClient & "
        Else
            clsMr.BuildSqlAdapter("SELECT * FROM vwInvoiceList WHERE Del=0 AND StatusID = 2 ", "vwInvoiceList") 'AND ClientID =" & mClient
        End If
        clsMr.BuildSqlAdapter("SELECT ClientID,ClientName  from tblClient WHERE Del =0  ORDER BY ClientName", "ClientName")
        dsdata = clsMr.getDataSet
    End Sub

    Private Sub FillComboBox()
        clsMr.FillComboBox("ClientName", cboClient, "ClientName", "ClientID")
    End Sub

#End Region


#Region " Form Functions   .  .  . "
   ''
   Private Sub DrawGrid()
      ''
      With grdInvoiceList
			''
			.DataSource = dsdata.Tables("vwInvoiceList").DefaultView
			.ReadOnly = True
			.ColumnHeadersHeight = btnShowCol.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
			''
			.Columns("AutoGel").Visible = False
			.Columns("ClientID").Visible = False
			.Columns("statusID").Visible = False
			.Columns("InvoiceID").Visible = False
			.Columns("CatID").Visible = False
			.Columns("Del").Visible = False
            ''
            .Columns("BillStatus").HeaderText = "Bill Status"
            .Columns("InvoiceNumber").HeaderText = "Invoice #"
			.Columns("CatType").HeaderText = "Cat Type"
			.Columns("InvoiceDate").HeaderText = "Invoice Date"
			.Columns("ClientName").HeaderText = "Client Name"
			.Columns("InvoiceFrom").HeaderText = "Invoice From"
			.Columns("InvoiceTo").HeaderText = "Invoice To"

			.Columns("Total").DefaultCellStyle.Format = "#,###.##"
			''

         '' One Invoice can be selected
         '' .MultiSelect = False
         dsdata.Tables("vwInvoiceList").DefaultView.AllowNew = False
      End With

      LoadProfile(mStrSubKeyName, Me.grdInvoiceList)
      RemoveLstItems()
      ''
   End Sub

	Public Sub New(ByVal intClientID As Integer, ByVal pstrIDs As String)

		' This call is required by the Windows Form Designer.
		InitializeComponent()
		mClient = intClientID
		mstrIDs = pstrIDs
		' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

	End Sub

   Private Sub RemoveLstItems()
		''
		chkLstGridCol.Items.Remove("AutoGel")
		chkLstGridCol.Items.Remove("ClientID")
		chkLstGridCol.Items.Remove("statusID")
		chkLstGridCol.Items.Remove("InvoiceID")
		chkLstGridCol.Items.Remove("CatID")
		chkLstGridCol.Items.Remove("Del")
	End Sub

   Private Sub FilterGrid()
      ''
      If blnLoading = True Then Exit Sub
      ''
      Dim s As String '= " True"
      ''
        's = "(InvoiceDate >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (InvoiceDate <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "')"
        s = "(InvoiceDate >= '" & dtpDateFrom.Value.ToString("yyyy-M-d") & "') AND (InvoiceDate <= '" & dtpDateTo.Value.ToString("yyyy-M-d") & "')"

      If txtInvoiceNum.Text <> String.Empty Then
         Dim tn As Integer
         Try
            tn = Convert.ToInt32(txtInvoiceNum.Text)
            s = s & " AND  (InvoiceNumber = " & tn & ")"
         Catch ex As Exception
            txtInvoiceNum.Text = ""
         End Try
      End If

      If txtInvoiceType.Text <> String.Empty Then

         s = s & " AND  (InvoiceType = '" & txtInvoiceType.Text & "')"

      End If
      If cboClient.SelectedIndex <> -1 Then
         s = s & " AND (ClientID = " & cboClient.SelectedValue & ")"
      Else
         If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
            s = s & " AND (ClientID = " & -1 & ")"
         End If

      End If

      dsdata.Tables("vwInvoiceList").DefaultView.RowFilter = s

   End Sub

    Private Sub SelectInvoice()
        ''
        If grdInvoiceList.Rows.Count = 0 Then Exit Sub
        Dim i As Integer
        Dim dv As DataGridViewSelectedRowCollection = grdInvoiceList.SelectedRows
        ReDim arrPay(dv.Count)
        ''
        For i = 0 To dv.Count - 1
            Dim drv As DataGridViewRow = dv(i)
            '' Array of Invoice IDees . . .
            arrPay(i) = dv(i).Cells("InvoiceID").Value
        Next
        ''
        Me.Close()
    End Sub
#End Region


#Region " UI - Events     .  .  .  "

   Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
      Me.Close()
   End Sub

   Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        ''
        SelectInvoice()
   End Sub

   Private Sub cboClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
      ''
      FilterGrid()
   End Sub

   Private Sub txtInvoiceNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInvoiceNum.TextChanged
      ''
      FilterGrid()
   End Sub

   Private Sub dtpDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateFrom.ValueChanged
      FilterGrid()
   End Sub

   Private Sub dtpDateTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateTo.ValueChanged
      FilterGrid()
   End Sub

   Private Sub txtInvoiceType_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInvoiceType.TextChanged
      FilterGrid()
   End Sub

   Private Sub cboClient_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyUp
      FilterGrid()
   End Sub

   Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
      ''
      If Me.grpShowHideColumns.Visible = False Then
         Me.grpShowHideColumns.Visible = True
         Me.grpShowHideColumns.BringToFront()
         mstrCurrentGridName = "InvoiceList"
         ''
         '' populate list with grid's dataSource fields...
         ''

         Dim col As Windows.Forms.DataGridViewColumn
         ''
         Me.chkLstGridCol.Items.Clear()
         For Each col In grdInvoiceList.Columns
            Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
         Next
         chkLstGridCol.Items.Remove("StatusID")
         chkLstGridCol.Items.Remove("ClientID")
         chkLstGridCol.Items.Remove("InvoiceID")
         chkLstGridCol.Items.Remove("Del")

      Else
         Me.grpShowHideColumns.Visible = False
         Me.grpShowHideColumns.SendToBack()
      End If
      ''
      RemoveLstItems()
   End Sub

   Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
      ''
      Dim i As Integer

      For i = 0 To Me.chkLstGridCol.Items.Count - 1
         Me.grdInvoiceList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
      Next

      ''
      Me.grpShowHideColumns.Visible = False

   End Sub

   Private Sub frmInvoicesGet_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
      ''
      SaveProfile(mStrSubKeyName, Me.grdInvoiceList)
   End Sub

    Private Sub grdInvoiceList_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdInvoiceList.CellDoubleClick
        ''
        SelectInvoice()
    End Sub

    Private Sub cboClient_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
        ''
        AutoComplete(cboClient, e)
    End Sub

#End Region

    
End Class