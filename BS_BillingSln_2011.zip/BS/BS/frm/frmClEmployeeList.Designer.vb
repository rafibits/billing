<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmClEmployeeList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.grdClEmpList = New System.Windows.Forms.DataGridView
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.grpControls = New System.Windows.Forms.GroupBox
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnCloseList = New BHBut.BouncingHoverButton
        Me.btnEdit = New BHBut.BouncingHoverButton
        Me.tcMain = New System.Windows.Forms.TabControl
        Me.tbClEmpList = New System.Windows.Forms.TabPage
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.txtFilByLName = New System.Windows.Forms.TextBox
        Me.lblLName = New System.Windows.Forms.Label
        Me.txtFiltByMName = New System.Windows.Forms.TextBox
        Me.lblMName = New System.Windows.Forms.Label
        Me.txtFiltByFName = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtFiltByNum = New System.Windows.Forms.TextBox
        Me.lblEmployeeNum = New System.Windows.Forms.Label
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.tbNewEditEmpList = New System.Windows.Forms.TabPage
        Me.grpOthers = New System.Windows.Forms.GroupBox
        Me.txtNote = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtCel = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtFax = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtExt = New System.Windows.Forms.TextBox
        Me.lblTel = New System.Windows.Forms.Label
        Me.cboNationality = New System.Windows.Forms.ComboBox
        Me.txtHomePhone = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.lblEMail = New System.Windows.Forms.Label
        Me.txtTel = New System.Windows.Forms.TextBox
        Me.tcAddress = New System.Windows.Forms.TabControl
        Me.tpViewAddress = New System.Windows.Forms.TabPage
        Me.grpShowHideColumnsAdd = New System.Windows.Forms.GroupBox
        Me.btnSaveSettingAdd = New System.Windows.Forms.Button
        Me.chkLstGridColAdd = New System.Windows.Forms.CheckedListBox
        Me.btnShowColAddress = New System.Windows.Forms.Button
        Me.btnEditAddress = New System.Windows.Forms.Button
        Me.btnDeleteAddress = New System.Windows.Forms.Button
        Me.btnNewAddress = New System.Windows.Forms.Button
        Me.grdViewAddress = New System.Windows.Forms.DataGridView
        Me.tpNewAddress = New System.Windows.Forms.TabPage
        Me.txtAddID = New System.Windows.Forms.TextBox
        Me.btnSaveAddress = New System.Windows.Forms.Button
        Me.btnCancelAddress = New System.Windows.Forms.Button
        Me.btnNewAddress2 = New System.Windows.Forms.Button
        Me.lblAddType = New System.Windows.Forms.Label
        Me.lblStreet = New System.Windows.Forms.Label
        Me.lblCity = New System.Windows.Forms.Label
        Me.lblArea = New System.Windows.Forms.Label
        Me.lblState = New System.Windows.Forms.Label
        Me.lblAddID = New System.Windows.Forms.Label
        Me.cboState = New System.Windows.Forms.ComboBox
        Me.cboAddType = New System.Windows.Forms.ComboBox
        Me.CboCity = New System.Windows.Forms.ComboBox
        Me.cboArea = New System.Windows.Forms.ComboBox
        Me.CboStreet = New System.Windows.Forms.ComboBox
        Me.lblBNF = New System.Windows.Forms.Label
        Me.txtBNF = New System.Windows.Forms.TextBox
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnNewClientEmp = New BHBut.BouncingHoverButton
        Me.BtnClose = New BHBut.BouncingHoverButton
        Me.btnSaveClientEmp = New BHBut.BouncingHoverButton
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.grpInfo = New System.Windows.Forms.GroupBox
        Me.cboCOCen = New System.Windows.Forms.ComboBox
        Me.cboQOCen = New System.Windows.Forms.ComboBox
        Me.cboROCen = New System.Windows.Forms.ComboBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtCensNum = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.cboAOB = New System.Windows.Forms.ComboBox
        Me.cboCOB = New System.Windows.Forms.ComboBox
        Me.dtpDOB = New System.Windows.Forms.DateTimePicker
        Me.cboSOB = New System.Windows.Forms.ComboBox
        Me.lblPOB = New System.Windows.Forms.Label
        Me.lblDOB = New System.Windows.Forms.Label
        Me.grpName = New System.Windows.Forms.GroupBox
        Me.btnGetSign = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label45 = New System.Windows.Forms.Label
        Me.CboMaritalStatus = New System.Windows.Forms.ComboBox
        Me.txtSLName = New System.Windows.Forms.TextBox
        Me.txtSFName = New System.Windows.Forms.TextBox
        Me.txtDriverLicNum = New System.Windows.Forms.TextBox
        Me.picPersonnel = New System.Windows.Forms.PictureBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.txtMLName = New System.Windows.Forms.TextBox
        Me.Label41 = New System.Windows.Forms.Label
        Me.txtMFName = New System.Windows.Forms.TextBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.cboTitle = New System.Windows.Forms.ComboBox
        Me.txtLName = New System.Windows.Forms.TextBox
        Me.txtMName = New System.Windows.Forms.TextBox
        Me.txtFName = New System.Windows.Forms.TextBox
        Me.txtClEmpNum = New System.Windows.Forms.TextBox
        Me.lblTitle = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.lblMN = New System.Windows.Forms.Label
        Me.lblFN = New System.Windows.Forms.Label
        Me.lblCEmployeeID = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.Label44 = New System.Windows.Forms.Label
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.TextBox10 = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.TextBox11 = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.TextBox12 = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.TextBox13 = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.TextBox14 = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.TextBox15 = New System.Windows.Forms.TextBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.TextBox16 = New System.Windows.Forms.TextBox
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.TextBox17 = New System.Windows.Forms.TextBox
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.ComboBox9 = New System.Windows.Forms.ComboBox
        Me.ComboBox10 = New System.Windows.Forms.ComboBox
        Me.ComboBox11 = New System.Windows.Forms.ComboBox
        Me.ComboBox12 = New System.Windows.Forms.ComboBox
        Me.ComboBox13 = New System.Windows.Forms.ComboBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.TextBox18 = New System.Windows.Forms.TextBox
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.ComboBox14 = New System.Windows.Forms.ComboBox
        Me.TextBox19 = New System.Windows.Forms.TextBox
        Me.TextBox20 = New System.Windows.Forms.TextBox
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.BouncingHoverButton2 = New BHBut.BouncingHoverButton
        Me.BouncingHoverButton3 = New BHBut.BouncingHoverButton
        Me.BouncingHoverButton4 = New BHBut.BouncingHoverButton
        Me.BouncingHoverButton5 = New BHBut.BouncingHoverButton
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.ComboBox15 = New System.Windows.Forms.ComboBox
        Me.ComboBox16 = New System.Windows.Forms.ComboBox
        Me.ComboBox17 = New System.Windows.Forms.ComboBox
        Me.Label33 = New System.Windows.Forms.Label
        Me.TextBox21 = New System.Windows.Forms.TextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.ComboBox18 = New System.Windows.Forms.ComboBox
        Me.ComboBox19 = New System.Windows.Forms.ComboBox
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.ComboBox20 = New System.Windows.Forms.ComboBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.GroupBox8 = New System.Windows.Forms.GroupBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.ComboBox21 = New System.Windows.Forms.ComboBox
        Me.ComboBox22 = New System.Windows.Forms.ComboBox
        Me.TextBox22 = New System.Windows.Forms.TextBox
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.txtClEmpID = New System.Windows.Forms.TextBox
        Me.OFDGetPhoto = New System.Windows.Forms.OpenFileDialog
        Me.FbdDataFile = New System.Windows.Forms.FolderBrowserDialog
        Me.txtLocation = New System.Windows.Forms.TextBox
        Me.txtClientID = New System.Windows.Forms.TextBox
        CType(Me.grdClEmpList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpShowHideColumns.SuspendLayout()
        Me.grpControls.SuspendLayout()
        Me.tcMain.SuspendLayout()
        Me.tbClEmpList.SuspendLayout()
        Me.grpFilter.SuspendLayout()
        Me.tbNewEditEmpList.SuspendLayout()
        Me.grpOthers.SuspendLayout()
        Me.tcAddress.SuspendLayout()
        Me.tpViewAddress.SuspendLayout()
        Me.grpShowHideColumnsAdd.SuspendLayout()
        CType(Me.grdViewAddress, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpNewAddress.SuspendLayout()
        Me.grpButtons.SuspendLayout()
        Me.grpInfo.SuspendLayout()
        Me.grpName.SuspendLayout()
        CType(Me.picPersonnel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Panel1.Location = New System.Drawing.Point(0, 40)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(762, 3)
        Me.Panel1.TabIndex = 2
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(762, 40)
        Me.lblfrmTitle.TabIndex = 6
        Me.lblfrmTitle.Text = "Client Employee List "
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grdClEmpList
        '
        Me.grdClEmpList.AllowUserToAddRows = False
        Me.grdClEmpList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdClEmpList.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdClEmpList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdClEmpList.Location = New System.Drawing.Point(5, 58)
        Me.grdClEmpList.Name = "grdClEmpList"
        Me.grdClEmpList.ReadOnly = True
        Me.grdClEmpList.Size = New System.Drawing.Size(746, 463)
        Me.grdClEmpList.TabIndex = 3
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(45, 63)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(188, 389)
        Me.grpShowHideColumns.TabIndex = 4
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(6, 19)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(175, 334)
        Me.chkLstGridCol.TabIndex = 0
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 360)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(175, 27)
        Me.btnSaveSettings.TabIndex = 1
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'grpControls
        '
        Me.grpControls.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpControls.Controls.Add(Me.btnNew)
        Me.grpControls.Controls.Add(Me.btnCloseList)
        Me.grpControls.Controls.Add(Me.btnEdit)
        Me.grpControls.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.grpControls.Location = New System.Drawing.Point(3, 523)
        Me.grpControls.Name = "grpControls"
        Me.grpControls.Size = New System.Drawing.Size(748, 45)
        Me.grpControls.TabIndex = 0
        Me.grpControls.TabStop = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNew.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.Location = New System.Drawing.Point(11, 10)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(128, 28)
        Me.btnNew.TabIndex = 0
        Me.btnNew.Text = "N e w "
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnCloseList
        '
        Me.btnCloseList.AlternativeGroup = Nothing
        Me.btnCloseList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCloseList.BackColor = System.Drawing.Color.Orange
        Me.btnCloseList.BackColor1 = System.Drawing.Color.White
        Me.btnCloseList.BackColor2 = System.Drawing.Color.Orange
        Me.btnCloseList.BorderHover = True
        Me.btnCloseList.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCloseList.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCloseList.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCloseList.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCloseList.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCloseList.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCloseList.DrawBorder = True
        Me.btnCloseList.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCloseList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnCloseList.ForeColor = System.Drawing.Color.Navy
        Me.btnCloseList.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCloseList.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCloseList.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCloseList.Location = New System.Drawing.Point(634, 10)
        Me.btnCloseList.Name = "btnCloseList"
        Me.btnCloseList.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCloseList.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCloseList.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCloseList.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCloseList.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCloseList.SelectedText = Nothing
        Me.btnCloseList.Size = New System.Drawing.Size(105, 28)
        Me.btnCloseList.TabIndex = 2
        Me.btnCloseList.Text = "C l o s e"
        Me.btnCloseList.UseVisualStyleBackColor = False
        '
        'btnEdit
        '
        Me.btnEdit.AlternativeGroup = Nothing
        Me.btnEdit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnEdit.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BackColor1 = System.Drawing.Color.White
        Me.btnEdit.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BorderHover = True
        Me.btnEdit.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEdit.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEdit.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnEdit.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEdit.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEdit.DrawBorder = True
        Me.btnEdit.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnEdit.ForeColor = System.Drawing.Color.Navy
        Me.btnEdit.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnEdit.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnEdit.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEdit.Location = New System.Drawing.Point(168, 10)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnEdit.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnEdit.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEdit.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnEdit.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnEdit.SelectedText = Nothing
        Me.btnEdit.Size = New System.Drawing.Size(128, 28)
        Me.btnEdit.TabIndex = 1
        Me.btnEdit.Text = "E d i t "
        Me.btnEdit.UseVisualStyleBackColor = False
        '
        'tcMain
        '
        Me.tcMain.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tcMain.Controls.Add(Me.tbClEmpList)
        Me.tcMain.Controls.Add(Me.tbNewEditEmpList)
        Me.tcMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tcMain.Location = New System.Drawing.Point(0, 43)
        Me.tcMain.Name = "tcMain"
        Me.tcMain.SelectedIndex = 0
        Me.tcMain.Size = New System.Drawing.Size(762, 600)
        Me.tcMain.TabIndex = 0
        '
        'tbClEmpList
        '
        Me.tbClEmpList.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.tbClEmpList.Controls.Add(Me.grpFilter)
        Me.tbClEmpList.Controls.Add(Me.grpControls)
        Me.tbClEmpList.Controls.Add(Me.grpShowHideColumns)
        Me.tbClEmpList.Controls.Add(Me.btnShowCol)
        Me.tbClEmpList.Controls.Add(Me.grdClEmpList)
        Me.tbClEmpList.Location = New System.Drawing.Point(4, 25)
        Me.tbClEmpList.Name = "tbClEmpList"
        Me.tbClEmpList.Padding = New System.Windows.Forms.Padding(3)
        Me.tbClEmpList.Size = New System.Drawing.Size(754, 571)
        Me.tbClEmpList.TabIndex = 0
        Me.tbClEmpList.Text = "Client Employee List"
        '
        'grpFilter
        '
        Me.grpFilter.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Controls.Add(Me.txtFilByLName)
        Me.grpFilter.Controls.Add(Me.lblLName)
        Me.grpFilter.Controls.Add(Me.txtFiltByMName)
        Me.grpFilter.Controls.Add(Me.lblMName)
        Me.grpFilter.Controls.Add(Me.txtFiltByFName)
        Me.grpFilter.Controls.Add(Me.Label7)
        Me.grpFilter.Controls.Add(Me.txtFiltByNum)
        Me.grpFilter.Controls.Add(Me.lblEmployeeNum)
        Me.grpFilter.Dock = System.Windows.Forms.DockStyle.Top
        Me.grpFilter.Location = New System.Drawing.Point(3, 3)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(748, 45)
        Me.grpFilter.TabIndex = 1
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Filter By"
        '
        'txtFilByLName
        '
        Me.txtFilByLName.Location = New System.Drawing.Point(601, 16)
        Me.txtFilByLName.Name = "txtFilByLName"
        Me.txtFilByLName.Size = New System.Drawing.Size(134, 20)
        Me.txtFilByLName.TabIndex = 8
        '
        'lblLName
        '
        Me.lblLName.AutoSize = True
        Me.lblLName.ForeColor = System.Drawing.Color.Maroon
        Me.lblLName.Location = New System.Drawing.Point(546, 20)
        Me.lblLName.Name = "lblLName"
        Me.lblLName.Size = New System.Drawing.Size(39, 13)
        Me.lblLName.TabIndex = 7
        Me.lblLName.Text = "LName"
        '
        'txtFiltByMName
        '
        Me.txtFiltByMName.Location = New System.Drawing.Point(396, 16)
        Me.txtFiltByMName.Name = "txtFiltByMName"
        Me.txtFiltByMName.Size = New System.Drawing.Size(134, 20)
        Me.txtFiltByMName.TabIndex = 6
        '
        'lblMName
        '
        Me.lblMName.AutoSize = True
        Me.lblMName.ForeColor = System.Drawing.Color.Maroon
        Me.lblMName.Location = New System.Drawing.Point(346, 20)
        Me.lblMName.Name = "lblMName"
        Me.lblMName.Size = New System.Drawing.Size(42, 13)
        Me.lblMName.TabIndex = 5
        Me.lblMName.Text = "MName"
        '
        'txtFiltByFName
        '
        Me.txtFiltByFName.AcceptsReturn = True
        Me.txtFiltByFName.Location = New System.Drawing.Point(201, 16)
        Me.txtFiltByFName.Name = "txtFiltByFName"
        Me.txtFiltByFName.Size = New System.Drawing.Size(134, 20)
        Me.txtFiltByFName.TabIndex = 4
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Maroon
        Me.Label7.Location = New System.Drawing.Point(156, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 13)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "FName"
        '
        'txtFiltByNum
        '
        Me.txtFiltByNum.Location = New System.Drawing.Point(67, 16)
        Me.txtFiltByNum.Name = "txtFiltByNum"
        Me.txtFiltByNum.Size = New System.Drawing.Size(74, 20)
        Me.txtFiltByNum.TabIndex = 1
        '
        'lblEmployeeNum
        '
        Me.lblEmployeeNum.AutoSize = True
        Me.lblEmployeeNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblEmployeeNum.Location = New System.Drawing.Point(3, 20)
        Me.lblEmployeeNum.Name = "lblEmployeeNum"
        Me.lblEmployeeNum.Size = New System.Drawing.Size(64, 13)
        Me.lblEmployeeNum.TabIndex = 0
        Me.lblEmployeeNum.Text = "Employee #"
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(6, 59)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 2
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'tbNewEditEmpList
        '
        Me.tbNewEditEmpList.Controls.Add(Me.grpOthers)
        Me.tbNewEditEmpList.Controls.Add(Me.tcAddress)
        Me.tbNewEditEmpList.Controls.Add(Me.grpButtons)
        Me.tbNewEditEmpList.Controls.Add(Me.grpInfo)
        Me.tbNewEditEmpList.Controls.Add(Me.grpName)
        Me.tbNewEditEmpList.Location = New System.Drawing.Point(4, 25)
        Me.tbNewEditEmpList.Name = "tbNewEditEmpList"
        Me.tbNewEditEmpList.Padding = New System.Windows.Forms.Padding(3)
        Me.tbNewEditEmpList.Size = New System.Drawing.Size(754, 571)
        Me.tbNewEditEmpList.TabIndex = 1
        Me.tbNewEditEmpList.Text = "New / Edit  Employee "
        Me.tbNewEditEmpList.UseVisualStyleBackColor = True
        '
        'grpOthers
        '
        Me.grpOthers.BackColor = System.Drawing.Color.AliceBlue
        Me.grpOthers.Controls.Add(Me.txtNote)
        Me.grpOthers.Controls.Add(Me.Label3)
        Me.grpOthers.Controls.Add(Me.txtCel)
        Me.grpOthers.Controls.Add(Me.Label6)
        Me.grpOthers.Controls.Add(Me.txtFax)
        Me.grpOthers.Controls.Add(Me.Label4)
        Me.grpOthers.Controls.Add(Me.Label2)
        Me.grpOthers.Controls.Add(Me.txtExt)
        Me.grpOthers.Controls.Add(Me.lblTel)
        Me.grpOthers.Controls.Add(Me.cboNationality)
        Me.grpOthers.Controls.Add(Me.txtHomePhone)
        Me.grpOthers.Controls.Add(Me.Label9)
        Me.grpOthers.Controls.Add(Me.txtEmail)
        Me.grpOthers.Controls.Add(Me.lblEMail)
        Me.grpOthers.Controls.Add(Me.txtTel)
        Me.grpOthers.Location = New System.Drawing.Point(8, 247)
        Me.grpOthers.Name = "grpOthers"
        Me.grpOthers.Size = New System.Drawing.Size(743, 94)
        Me.grpOthers.TabIndex = 1
        Me.grpOthers.TabStop = False
        '
        'txtNote
        '
        Me.txtNote.AcceptsReturn = True
        Me.txtNote.Location = New System.Drawing.Point(73, 68)
        Me.txtNote.Name = "txtNote"
        Me.txtNote.Size = New System.Drawing.Size(655, 20)
        Me.txtNote.TabIndex = 14
        '
        'Label3
        '
        Me.Label3.ForeColor = System.Drawing.Color.Navy
        Me.Label3.Location = New System.Drawing.Point(4, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Note"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtCel
        '
        Me.txtCel.Location = New System.Drawing.Point(426, 16)
        Me.txtCel.Name = "txtCel"
        Me.txtCel.Size = New System.Drawing.Size(133, 20)
        Me.txtCel.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.ForeColor = System.Drawing.Color.Navy
        Me.Label6.Location = New System.Drawing.Point(402, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(24, 13)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Cell"
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(260, 42)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(133, 20)
        Me.txtFax.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.ForeColor = System.Drawing.Color.Navy
        Me.Label4.Location = New System.Drawing.Point(237, 46)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(25, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Fax"
        '
        'Label2
        '
        Me.Label2.ForeColor = System.Drawing.Color.Navy
        Me.Label2.Location = New System.Drawing.Point(4, 46)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "work Phone"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtExt
        '
        Me.txtExt.Location = New System.Drawing.Point(189, 42)
        Me.txtExt.Name = "txtExt"
        Me.txtExt.Size = New System.Drawing.Size(42, 20)
        Me.txtExt.TabIndex = 8
        '
        'lblTel
        '
        Me.lblTel.ForeColor = System.Drawing.Color.Navy
        Me.lblTel.Location = New System.Drawing.Point(193, 19)
        Me.lblTel.Name = "lblTel"
        Me.lblTel.Size = New System.Drawing.Size(67, 13)
        Me.lblTel.TabIndex = 2
        Me.lblTel.Text = "Home Phone"
        Me.lblTel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboNationality
        '
        Me.cboNationality.FormattingEnabled = True
        Me.cboNationality.Location = New System.Drawing.Point(73, 15)
        Me.cboNationality.Name = "cboNationality"
        Me.cboNationality.Size = New System.Drawing.Size(115, 21)
        Me.cboNationality.TabIndex = 1
        '
        'txtHomePhone
        '
        Me.txtHomePhone.Location = New System.Drawing.Point(260, 16)
        Me.txtHomePhone.Name = "txtHomePhone"
        Me.txtHomePhone.Size = New System.Drawing.Size(133, 20)
        Me.txtHomePhone.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.ForeColor = System.Drawing.Color.Navy
        Me.Label9.Location = New System.Drawing.Point(4, 19)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Nationality"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(426, 42)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(302, 20)
        Me.txtEmail.TabIndex = 12
        '
        'lblEMail
        '
        Me.lblEMail.ForeColor = System.Drawing.Color.Navy
        Me.lblEMail.Location = New System.Drawing.Point(396, 45)
        Me.lblEMail.Name = "lblEMail"
        Me.lblEMail.Size = New System.Drawing.Size(31, 15)
        Me.lblEMail.TabIndex = 11
        Me.lblEMail.Tag = " "
        Me.lblEMail.Text = "EMail"
        Me.lblEMail.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTel
        '
        Me.txtTel.Location = New System.Drawing.Point(73, 42)
        Me.txtTel.Name = "txtTel"
        Me.txtTel.Size = New System.Drawing.Size(115, 20)
        Me.txtTel.TabIndex = 7
        '
        'tcAddress
        '
        Me.tcAddress.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tcAddress.Controls.Add(Me.tpViewAddress)
        Me.tcAddress.Controls.Add(Me.tpNewAddress)
        Me.tcAddress.Location = New System.Drawing.Point(8, 347)
        Me.tcAddress.Name = "tcAddress"
        Me.tcAddress.SelectedIndex = 0
        Me.tcAddress.Size = New System.Drawing.Size(743, 164)
        Me.tcAddress.TabIndex = 2
        '
        'tpViewAddress
        '
        Me.tpViewAddress.Controls.Add(Me.grpShowHideColumnsAdd)
        Me.tpViewAddress.Controls.Add(Me.btnShowColAddress)
        Me.tpViewAddress.Controls.Add(Me.btnEditAddress)
        Me.tpViewAddress.Controls.Add(Me.btnDeleteAddress)
        Me.tpViewAddress.Controls.Add(Me.btnNewAddress)
        Me.tpViewAddress.Controls.Add(Me.grdViewAddress)
        Me.tpViewAddress.Location = New System.Drawing.Point(4, 22)
        Me.tpViewAddress.Name = "tpViewAddress"
        Me.tpViewAddress.Padding = New System.Windows.Forms.Padding(3)
        Me.tpViewAddress.Size = New System.Drawing.Size(735, 138)
        Me.tpViewAddress.TabIndex = 0
        Me.tpViewAddress.Text = "Address"
        Me.tpViewAddress.UseVisualStyleBackColor = True
        '
        'grpShowHideColumnsAdd
        '
        Me.grpShowHideColumnsAdd.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumnsAdd.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumnsAdd.Controls.Add(Me.btnSaveSettingAdd)
        Me.grpShowHideColumnsAdd.Controls.Add(Me.chkLstGridColAdd)
        Me.grpShowHideColumnsAdd.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumnsAdd.Location = New System.Drawing.Point(42, 6)
        Me.grpShowHideColumnsAdd.Name = "grpShowHideColumnsAdd"
        Me.grpShowHideColumnsAdd.Size = New System.Drawing.Size(175, 127)
        Me.grpShowHideColumnsAdd.TabIndex = 4
        Me.grpShowHideColumnsAdd.TabStop = False
        Me.grpShowHideColumnsAdd.Text = "Custom Columns"
        Me.grpShowHideColumnsAdd.Visible = False
        '
        'btnSaveSettingAdd
        '
        Me.btnSaveSettingAdd.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettingAdd.Location = New System.Drawing.Point(2, 98)
        Me.btnSaveSettingAdd.Name = "btnSaveSettingAdd"
        Me.btnSaveSettingAdd.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettingAdd.TabIndex = 1
        Me.btnSaveSettingAdd.Text = "Save Settings"
        Me.btnSaveSettingAdd.UseVisualStyleBackColor = True
        '
        'chkLstGridColAdd
        '
        Me.chkLstGridColAdd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridColAdd.CheckOnClick = True
        Me.chkLstGridColAdd.FormattingEnabled = True
        Me.chkLstGridColAdd.Location = New System.Drawing.Point(3, 15)
        Me.chkLstGridColAdd.Name = "chkLstGridColAdd"
        Me.chkLstGridColAdd.Size = New System.Drawing.Size(162, 64)
        Me.chkLstGridColAdd.TabIndex = 0
        Me.chkLstGridColAdd.ThreeDCheckBoxes = True
        '
        'btnShowColAddress
        '
        Me.btnShowColAddress.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowColAddress.BackColor = System.Drawing.Color.Linen
        Me.btnShowColAddress.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowColAddress.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowColAddress.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowColAddress.FlatAppearance.BorderSize = 2
        Me.btnShowColAddress.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColAddress.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColAddress.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowColAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowColAddress.ForeColor = System.Drawing.Color.White
        Me.btnShowColAddress.Location = New System.Drawing.Point(6, 6)
        Me.btnShowColAddress.Name = "btnShowColAddress"
        Me.btnShowColAddress.Size = New System.Drawing.Size(36, 30)
        Me.btnShowColAddress.TabIndex = 0
        Me.btnShowColAddress.UseVisualStyleBackColor = False
        '
        'btnEditAddress
        '
        Me.btnEditAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEditAddress.ForeColor = System.Drawing.Color.Navy
        Me.btnEditAddress.Location = New System.Drawing.Point(648, 62)
        Me.btnEditAddress.Name = "btnEditAddress"
        Me.btnEditAddress.Size = New System.Drawing.Size(76, 23)
        Me.btnEditAddress.TabIndex = 3
        Me.btnEditAddress.Text = "Edit "
        Me.btnEditAddress.UseVisualStyleBackColor = True
        '
        'btnDeleteAddress
        '
        Me.btnDeleteAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDeleteAddress.ForeColor = System.Drawing.Color.Navy
        Me.btnDeleteAddress.Location = New System.Drawing.Point(556, 148)
        Me.btnDeleteAddress.Name = "btnDeleteAddress"
        Me.btnDeleteAddress.Size = New System.Drawing.Size(64, 23)
        Me.btnDeleteAddress.TabIndex = 5
        Me.btnDeleteAddress.Text = "Delete "
        Me.btnDeleteAddress.UseVisualStyleBackColor = True
        '
        'btnNewAddress
        '
        Me.btnNewAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNewAddress.ForeColor = System.Drawing.Color.Navy
        Me.btnNewAddress.Location = New System.Drawing.Point(648, 24)
        Me.btnNewAddress.Name = "btnNewAddress"
        Me.btnNewAddress.Size = New System.Drawing.Size(77, 23)
        Me.btnNewAddress.TabIndex = 2
        Me.btnNewAddress.Text = "New "
        Me.btnNewAddress.UseVisualStyleBackColor = True
        '
        'grdViewAddress
        '
        Me.grdViewAddress.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdViewAddress.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdViewAddress.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdViewAddress.Location = New System.Drawing.Point(5, 6)
        Me.grdViewAddress.Name = "grdViewAddress"
        Me.grdViewAddress.Size = New System.Drawing.Size(635, 126)
        Me.grdViewAddress.TabIndex = 1
        '
        'tpNewAddress
        '
        Me.tpNewAddress.Controls.Add(Me.txtAddID)
        Me.tpNewAddress.Controls.Add(Me.btnSaveAddress)
        Me.tpNewAddress.Controls.Add(Me.btnCancelAddress)
        Me.tpNewAddress.Controls.Add(Me.btnNewAddress2)
        Me.tpNewAddress.Controls.Add(Me.lblAddType)
        Me.tpNewAddress.Controls.Add(Me.lblStreet)
        Me.tpNewAddress.Controls.Add(Me.lblCity)
        Me.tpNewAddress.Controls.Add(Me.lblArea)
        Me.tpNewAddress.Controls.Add(Me.lblState)
        Me.tpNewAddress.Controls.Add(Me.lblAddID)
        Me.tpNewAddress.Controls.Add(Me.cboState)
        Me.tpNewAddress.Controls.Add(Me.cboAddType)
        Me.tpNewAddress.Controls.Add(Me.CboCity)
        Me.tpNewAddress.Controls.Add(Me.cboArea)
        Me.tpNewAddress.Controls.Add(Me.CboStreet)
        Me.tpNewAddress.Controls.Add(Me.lblBNF)
        Me.tpNewAddress.Controls.Add(Me.txtBNF)
        Me.tpNewAddress.Location = New System.Drawing.Point(4, 22)
        Me.tpNewAddress.Name = "tpNewAddress"
        Me.tpNewAddress.Padding = New System.Windows.Forms.Padding(3)
        Me.tpNewAddress.Size = New System.Drawing.Size(735, 138)
        Me.tpNewAddress.TabIndex = 1
        Me.tpNewAddress.Text = "NewAddress"
        Me.tpNewAddress.UseVisualStyleBackColor = True
        '
        'txtAddID
        '
        Me.txtAddID.Location = New System.Drawing.Point(99, 14)
        Me.txtAddID.Name = "txtAddID"
        Me.txtAddID.ReadOnly = True
        Me.txtAddID.Size = New System.Drawing.Size(100, 20)
        Me.txtAddID.TabIndex = 8
        Me.txtAddID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnSaveAddress
        '
        Me.btnSaveAddress.Location = New System.Drawing.Point(632, 33)
        Me.btnSaveAddress.Name = "btnSaveAddress"
        Me.btnSaveAddress.Size = New System.Drawing.Size(85, 23)
        Me.btnSaveAddress.TabIndex = 5
        Me.btnSaveAddress.Text = "Save "
        Me.btnSaveAddress.UseVisualStyleBackColor = True
        '
        'btnCancelAddress
        '
        Me.btnCancelAddress.Location = New System.Drawing.Point(632, 68)
        Me.btnCancelAddress.Name = "btnCancelAddress"
        Me.btnCancelAddress.Size = New System.Drawing.Size(85, 23)
        Me.btnCancelAddress.TabIndex = 6
        Me.btnCancelAddress.Text = "Cancel "
        Me.btnCancelAddress.UseVisualStyleBackColor = True
        '
        'btnNewAddress2
        '
        Me.btnNewAddress2.Location = New System.Drawing.Point(632, 6)
        Me.btnNewAddress2.Name = "btnNewAddress2"
        Me.btnNewAddress2.Size = New System.Drawing.Size(86, 23)
        Me.btnNewAddress2.TabIndex = 4
        Me.btnNewAddress2.Text = "New "
        Me.btnNewAddress2.UseVisualStyleBackColor = True
        Me.btnNewAddress2.Visible = False
        '
        'lblAddType
        '
        Me.lblAddType.AutoSize = True
        Me.lblAddType.Location = New System.Drawing.Point(275, 17)
        Me.lblAddType.Name = "lblAddType"
        Me.lblAddType.Size = New System.Drawing.Size(73, 13)
        Me.lblAddType.TabIndex = 9
        Me.lblAddType.Text = "Address Type"
        '
        'lblStreet
        '
        Me.lblStreet.AutoSize = True
        Me.lblStreet.Location = New System.Drawing.Point(312, 79)
        Me.lblStreet.Name = "lblStreet"
        Me.lblStreet.Size = New System.Drawing.Size(37, 13)
        Me.lblStreet.TabIndex = 0
        Me.lblStreet.Text = "Street"
        '
        'lblCity
        '
        Me.lblCity.AutoSize = True
        Me.lblCity.Location = New System.Drawing.Point(62, 78)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(26, 13)
        Me.lblCity.TabIndex = 15
        Me.lblCity.Text = "City"
        '
        'lblArea
        '
        Me.lblArea.AutoSize = True
        Me.lblArea.Location = New System.Drawing.Point(318, 48)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(30, 13)
        Me.lblArea.TabIndex = 13
        Me.lblArea.Text = "Area"
        '
        'lblState
        '
        Me.lblState.AutoSize = True
        Me.lblState.Location = New System.Drawing.Point(55, 46)
        Me.lblState.Name = "lblState"
        Me.lblState.Size = New System.Drawing.Size(33, 13)
        Me.lblState.TabIndex = 11
        Me.lblState.Text = "State"
        '
        'lblAddID
        '
        Me.lblAddID.AutoSize = True
        Me.lblAddID.Location = New System.Drawing.Point(28, 16)
        Me.lblAddID.Name = "lblAddID"
        Me.lblAddID.Size = New System.Drawing.Size(60, 13)
        Me.lblAddID.TabIndex = 7
        Me.lblAddID.Text = "Address ID"
        '
        'cboState
        '
        Me.cboState.FormattingEnabled = True
        Me.cboState.Location = New System.Drawing.Point(99, 45)
        Me.cboState.Name = "cboState"
        Me.cboState.Size = New System.Drawing.Size(163, 21)
        Me.cboState.TabIndex = 12
        '
        'cboAddType
        '
        Me.cboAddType.FormattingEnabled = True
        Me.cboAddType.Location = New System.Drawing.Point(357, 14)
        Me.cboAddType.Name = "cboAddType"
        Me.cboAddType.Size = New System.Drawing.Size(163, 21)
        Me.cboAddType.TabIndex = 10
        '
        'CboCity
        '
        Me.CboCity.FormattingEnabled = True
        Me.CboCity.Location = New System.Drawing.Point(99, 75)
        Me.CboCity.Name = "CboCity"
        Me.CboCity.Size = New System.Drawing.Size(163, 21)
        Me.CboCity.TabIndex = 16
        '
        'cboArea
        '
        Me.cboArea.FormattingEnabled = True
        Me.cboArea.Location = New System.Drawing.Point(357, 45)
        Me.cboArea.Name = "cboArea"
        Me.cboArea.Size = New System.Drawing.Size(163, 21)
        Me.cboArea.TabIndex = 14
        '
        'CboStreet
        '
        Me.CboStreet.FormattingEnabled = True
        Me.CboStreet.Location = New System.Drawing.Point(357, 76)
        Me.CboStreet.Name = "CboStreet"
        Me.CboStreet.Size = New System.Drawing.Size(163, 21)
        Me.CboStreet.TabIndex = 1
        '
        'lblBNF
        '
        Me.lblBNF.AutoSize = True
        Me.lblBNF.Location = New System.Drawing.Point(3, 111)
        Me.lblBNF.Name = "lblBNF"
        Me.lblBNF.Size = New System.Drawing.Size(92, 13)
        Me.lblBNF.TabIndex = 2
        Me.lblBNF.Text = "Building And Floor"
        '
        'txtBNF
        '
        Me.txtBNF.Location = New System.Drawing.Point(99, 108)
        Me.txtBNF.Name = "txtBNF"
        Me.txtBNF.Size = New System.Drawing.Size(421, 20)
        Me.txtBNF.TabIndex = 3
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnNewClientEmp)
        Me.grpButtons.Controls.Add(Me.BtnClose)
        Me.grpButtons.Controls.Add(Me.btnSaveClientEmp)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Location = New System.Drawing.Point(8, 517)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(743, 50)
        Me.grpButtons.TabIndex = 3
        Me.grpButtons.TabStop = False
        '
        'btnNewClientEmp
        '
        Me.btnNewClientEmp.AlternativeGroup = Nothing
        Me.btnNewClientEmp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNewClientEmp.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNewClientEmp.BackColor1 = System.Drawing.Color.White
        Me.btnNewClientEmp.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNewClientEmp.BorderHover = True
        Me.btnNewClientEmp.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNewClientEmp.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNewClientEmp.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNewClientEmp.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNewClientEmp.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNewClientEmp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNewClientEmp.DrawBorder = True
        Me.btnNewClientEmp.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNewClientEmp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnNewClientEmp.ForeColor = System.Drawing.Color.Navy
        Me.btnNewClientEmp.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNewClientEmp.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNewClientEmp.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewClientEmp.Location = New System.Drawing.Point(11, 15)
        Me.btnNewClientEmp.Name = "btnNewClientEmp"
        Me.btnNewClientEmp.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNewClientEmp.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNewClientEmp.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewClientEmp.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNewClientEmp.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNewClientEmp.SelectedText = Nothing
        Me.btnNewClientEmp.Size = New System.Drawing.Size(105, 28)
        Me.btnNewClientEmp.TabIndex = 0
        Me.btnNewClientEmp.Text = "N e w"
        Me.btnNewClientEmp.UseVisualStyleBackColor = False
        '
        'BtnClose
        '
        Me.BtnClose.AlternativeGroup = Nothing
        Me.BtnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnClose.BackColor = System.Drawing.Color.Orange
        Me.BtnClose.BackColor1 = System.Drawing.Color.White
        Me.BtnClose.BackColor2 = System.Drawing.Color.Orange
        Me.BtnClose.BorderHover = True
        Me.BtnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BtnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BtnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BtnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BtnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BtnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnClose.DrawBorder = True
        Me.BtnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BtnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.BtnClose.ForeColor = System.Drawing.Color.Navy
        Me.BtnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BtnClose.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BtnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnClose.Location = New System.Drawing.Point(627, 15)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BtnClose.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BtnClose.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnClose.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BtnClose.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BtnClose.SelectedText = Nothing
        Me.BtnClose.Size = New System.Drawing.Size(105, 28)
        Me.BtnClose.TabIndex = 3
        Me.BtnClose.Text = "C l o s e"
        Me.BtnClose.UseVisualStyleBackColor = False
        '
        'btnSaveClientEmp
        '
        Me.btnSaveClientEmp.AlternativeGroup = Nothing
        Me.btnSaveClientEmp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSaveClientEmp.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSaveClientEmp.BackColor1 = System.Drawing.Color.White
        Me.btnSaveClientEmp.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSaveClientEmp.BorderHover = True
        Me.btnSaveClientEmp.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSaveClientEmp.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSaveClientEmp.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnSaveClientEmp.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSaveClientEmp.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSaveClientEmp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSaveClientEmp.DrawBorder = True
        Me.btnSaveClientEmp.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSaveClientEmp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnSaveClientEmp.ForeColor = System.Drawing.Color.Navy
        Me.btnSaveClientEmp.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnSaveClientEmp.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnSaveClientEmp.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSaveClientEmp.Location = New System.Drawing.Point(164, 15)
        Me.btnSaveClientEmp.Name = "btnSaveClientEmp"
        Me.btnSaveClientEmp.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnSaveClientEmp.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnSaveClientEmp.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSaveClientEmp.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnSaveClientEmp.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnSaveClientEmp.SelectedText = Nothing
        Me.btnSaveClientEmp.Size = New System.Drawing.Size(105, 28)
        Me.btnSaveClientEmp.TabIndex = 1
        Me.btnSaveClientEmp.Text = "Edit"
        Me.btnSaveClientEmp.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCancel.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Location = New System.Drawing.Point(317, 15)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(105, 28)
        Me.btnCancel.TabIndex = 2
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'grpInfo
        '
        Me.grpInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpInfo.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.grpInfo.Controls.Add(Me.cboCOCen)
        Me.grpInfo.Controls.Add(Me.cboQOCen)
        Me.grpInfo.Controls.Add(Me.cboROCen)
        Me.grpInfo.Controls.Add(Me.Label11)
        Me.grpInfo.Controls.Add(Me.txtCensNum)
        Me.grpInfo.Controls.Add(Me.Label10)
        Me.grpInfo.Controls.Add(Me.cboAOB)
        Me.grpInfo.Controls.Add(Me.cboCOB)
        Me.grpInfo.Controls.Add(Me.dtpDOB)
        Me.grpInfo.Controls.Add(Me.cboSOB)
        Me.grpInfo.Controls.Add(Me.lblPOB)
        Me.grpInfo.Controls.Add(Me.lblDOB)
        Me.grpInfo.Location = New System.Drawing.Point(8, 174)
        Me.grpInfo.Name = "grpInfo"
        Me.grpInfo.Size = New System.Drawing.Size(743, 67)
        Me.grpInfo.TabIndex = 0
        Me.grpInfo.TabStop = False
        '
        'cboCOCen
        '
        Me.cboCOCen.FormattingEnabled = True
        Me.cboCOCen.Location = New System.Drawing.Point(613, 41)
        Me.cboCOCen.Name = "cboCOCen"
        Me.cboCOCen.Size = New System.Drawing.Size(115, 21)
        Me.cboCOCen.TabIndex = 11
        '
        'cboQOCen
        '
        Me.cboQOCen.FormattingEnabled = True
        Me.cboQOCen.Location = New System.Drawing.Point(492, 41)
        Me.cboQOCen.Name = "cboQOCen"
        Me.cboQOCen.Size = New System.Drawing.Size(115, 21)
        Me.cboQOCen.TabIndex = 10
        '
        'cboROCen
        '
        Me.cboROCen.FormattingEnabled = True
        Me.cboROCen.Location = New System.Drawing.Point(371, 41)
        Me.cboROCen.Name = "cboROCen"
        Me.cboROCen.Size = New System.Drawing.Size(115, 21)
        Me.cboROCen.TabIndex = 9
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.AntiqueWhite
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label11.ForeColor = System.Drawing.Color.Navy
        Me.Label11.Location = New System.Drawing.Point(213, 43)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(154, 17)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Region-Qada-City Of Census"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtCensNum
        '
        Me.txtCensNum.Location = New System.Drawing.Point(73, 41)
        Me.txtCensNum.Name = "txtCensNum"
        Me.txtCensNum.Size = New System.Drawing.Size(113, 20)
        Me.txtCensNum.TabIndex = 7
        '
        'Label10
        '
        Me.Label10.ForeColor = System.Drawing.Color.Navy
        Me.Label10.Location = New System.Drawing.Point(5, 45)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(66, 13)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Census Num"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboAOB
        '
        Me.cboAOB.FormattingEnabled = True
        Me.cboAOB.Location = New System.Drawing.Point(612, 14)
        Me.cboAOB.Name = "cboAOB"
        Me.cboAOB.Size = New System.Drawing.Size(115, 21)
        Me.cboAOB.TabIndex = 5
        '
        'cboCOB
        '
        Me.cboCOB.FormattingEnabled = True
        Me.cboCOB.Location = New System.Drawing.Point(491, 14)
        Me.cboCOB.Name = "cboCOB"
        Me.cboCOB.Size = New System.Drawing.Size(115, 21)
        Me.cboCOB.TabIndex = 4
        '
        'dtpDOB
        '
        Me.dtpDOB.CustomFormat = "MMM dd, yyyy"
        Me.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDOB.Location = New System.Drawing.Point(72, 14)
        Me.dtpDOB.Name = "dtpDOB"
        Me.dtpDOB.Size = New System.Drawing.Size(113, 20)
        Me.dtpDOB.TabIndex = 1
        '
        'cboSOB
        '
        Me.cboSOB.FormattingEnabled = True
        Me.cboSOB.Location = New System.Drawing.Point(370, 14)
        Me.cboSOB.Name = "cboSOB"
        Me.cboSOB.Size = New System.Drawing.Size(115, 21)
        Me.cboSOB.TabIndex = 3
        '
        'lblPOB
        '
        Me.lblPOB.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblPOB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPOB.ForeColor = System.Drawing.Color.Navy
        Me.lblPOB.Location = New System.Drawing.Point(212, 16)
        Me.lblPOB.Name = "lblPOB"
        Me.lblPOB.Size = New System.Drawing.Size(154, 17)
        Me.lblPOB.TabIndex = 2
        Me.lblPOB.Text = "State-City-Area Of Birth"
        Me.lblPOB.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDOB
        '
        Me.lblDOB.ForeColor = System.Drawing.Color.Navy
        Me.lblDOB.Location = New System.Drawing.Point(3, 16)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(70, 17)
        Me.lblDOB.TabIndex = 0
        Me.lblDOB.Text = "Date of birth"
        Me.lblDOB.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpName
        '
        Me.grpName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpName.BackColor = System.Drawing.Color.Lavender
        Me.grpName.Controls.Add(Me.btnGetSign)
        Me.grpName.Controls.Add(Me.Label8)
        Me.grpName.Controls.Add(Me.Label45)
        Me.grpName.Controls.Add(Me.CboMaritalStatus)
        Me.grpName.Controls.Add(Me.txtSLName)
        Me.grpName.Controls.Add(Me.txtSFName)
        Me.grpName.Controls.Add(Me.txtDriverLicNum)
        Me.grpName.Controls.Add(Me.picPersonnel)
        Me.grpName.Controls.Add(Me.Label42)
        Me.grpName.Controls.Add(Me.txtMLName)
        Me.grpName.Controls.Add(Me.Label41)
        Me.grpName.Controls.Add(Me.txtMFName)
        Me.grpName.Controls.Add(Me.Label40)
        Me.grpName.Controls.Add(Me.cboTitle)
        Me.grpName.Controls.Add(Me.txtLName)
        Me.grpName.Controls.Add(Me.txtMName)
        Me.grpName.Controls.Add(Me.txtFName)
        Me.grpName.Controls.Add(Me.txtClEmpNum)
        Me.grpName.Controls.Add(Me.lblTitle)
        Me.grpName.Controls.Add(Me.Label5)
        Me.grpName.Controls.Add(Me.lblMN)
        Me.grpName.Controls.Add(Me.lblFN)
        Me.grpName.Controls.Add(Me.lblCEmployeeID)
        Me.grpName.Controls.Add(Me.Label12)
        Me.grpName.Controls.Add(Me.Label43)
        Me.grpName.Controls.Add(Me.Label44)
        Me.grpName.Location = New System.Drawing.Point(8, 6)
        Me.grpName.Name = "grpName"
        Me.grpName.Size = New System.Drawing.Size(743, 162)
        Me.grpName.TabIndex = 0
        Me.grpName.TabStop = False
        '
        'btnGetSign
        '
        Me.btnGetSign.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnGetSign.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnGetSign.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow
        Me.btnGetSign.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnGetSign.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGetSign.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetSign.ForeColor = System.Drawing.Color.Navy
        Me.btnGetSign.Location = New System.Drawing.Point(601, 102)
        Me.btnGetSign.Name = "btnGetSign"
        Me.btnGetSign.Size = New System.Drawing.Size(127, 23)
        Me.btnGetSign.TabIndex = 24
        Me.btnGetSign.Text = "Get Image"
        Me.btnGetSign.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Lavender
        Me.Label8.Location = New System.Drawing.Point(70, 96)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(30, 28)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "First"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label45
        '
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Navy
        Me.Label45.Location = New System.Drawing.Point(239, 131)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(58, 19)
        Me.Label45.TabIndex = 19
        Me.Label45.Text = "Spouse's"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CboMaritalStatus
        '
        Me.CboMaritalStatus.FormattingEnabled = True
        Me.CboMaritalStatus.Location = New System.Drawing.Point(106, 130)
        Me.CboMaritalStatus.Name = "CboMaritalStatus"
        Me.CboMaritalStatus.Size = New System.Drawing.Size(108, 21)
        Me.CboMaritalStatus.TabIndex = 18
        '
        'txtSLName
        '
        Me.txtSLName.Location = New System.Drawing.Point(514, 131)
        Me.txtSLName.Name = "txtSLName"
        Me.txtSLName.Size = New System.Drawing.Size(134, 20)
        Me.txtSLName.TabIndex = 23
        '
        'txtSFName
        '
        Me.txtSFName.AcceptsReturn = True
        Me.txtSFName.Location = New System.Drawing.Point(338, 130)
        Me.txtSFName.Name = "txtSFName"
        Me.txtSFName.Size = New System.Drawing.Size(140, 20)
        Me.txtSFName.TabIndex = 21
        '
        'txtDriverLicNum
        '
        Me.txtDriverLicNum.Location = New System.Drawing.Point(338, 67)
        Me.txtDriverLicNum.Name = "txtDriverLicNum"
        Me.txtDriverLicNum.Size = New System.Drawing.Size(140, 20)
        Me.txtDriverLicNum.TabIndex = 11
        '
        'picPersonnel
        '
        Me.picPersonnel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picPersonnel.BackColor = System.Drawing.Color.Wheat
        Me.picPersonnel.Location = New System.Drawing.Point(601, 12)
        Me.picPersonnel.Name = "picPersonnel"
        Me.picPersonnel.Size = New System.Drawing.Size(127, 91)
        Me.picPersonnel.TabIndex = 351
        Me.picPersonnel.TabStop = False
        '
        'Label42
        '
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Navy
        Me.Label42.Location = New System.Drawing.Point(223, 67)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(115, 20)
        Me.Label42.TabIndex = 10
        Me.Label42.Text = "Driver's License #"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtMLName
        '
        Me.txtMLName.Location = New System.Drawing.Point(338, 100)
        Me.txtMLName.Name = "txtMLName"
        Me.txtMLName.Size = New System.Drawing.Size(140, 20)
        Me.txtMLName.TabIndex = 16
        '
        'Label41
        '
        Me.Label41.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Lavender
        Me.Label41.Location = New System.Drawing.Point(306, 96)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(30, 28)
        Me.Label41.TabIndex = 15
        Me.Label41.Text = "Last"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtMFName
        '
        Me.txtMFName.Location = New System.Drawing.Point(106, 100)
        Me.txtMFName.Name = "txtMFName"
        Me.txtMFName.Size = New System.Drawing.Size(108, 20)
        Me.txtMFName.TabIndex = 14
        '
        'Label40
        '
        Me.Label40.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.White
        Me.Label40.Location = New System.Drawing.Point(15, 96)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(473, 29)
        Me.Label40.TabIndex = 12
        Me.Label40.Text = " Mother's"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboTitle
        '
        Me.cboTitle.FormattingEnabled = True
        Me.cboTitle.Location = New System.Drawing.Point(56, 67)
        Me.cboTitle.Name = "cboTitle"
        Me.cboTitle.Size = New System.Drawing.Size(158, 21)
        Me.cboTitle.TabIndex = 9
        '
        'txtLName
        '
        Me.txtLName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtLName.Location = New System.Drawing.Point(338, 26)
        Me.txtLName.Name = "txtLName"
        Me.txtLName.Size = New System.Drawing.Size(140, 22)
        Me.txtLName.TabIndex = 7
        '
        'txtMName
        '
        Me.txtMName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtMName.Location = New System.Drawing.Point(220, 26)
        Me.txtMName.Name = "txtMName"
        Me.txtMName.Size = New System.Drawing.Size(112, 22)
        Me.txtMName.TabIndex = 5
        '
        'txtFName
        '
        Me.txtFName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtFName.Location = New System.Drawing.Point(106, 26)
        Me.txtFName.Name = "txtFName"
        Me.txtFName.Size = New System.Drawing.Size(108, 22)
        Me.txtFName.TabIndex = 3
        '
        'txtClEmpNum
        '
        Me.txtClEmpNum.BackColor = System.Drawing.Color.DarkRed
        Me.txtClEmpNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtClEmpNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtClEmpNum.ForeColor = System.Drawing.Color.White
        Me.txtClEmpNum.Location = New System.Drawing.Point(15, 26)
        Me.txtClEmpNum.Name = "txtClEmpNum"
        Me.txtClEmpNum.ReadOnly = True
        Me.txtClEmpNum.Size = New System.Drawing.Size(81, 22)
        Me.txtClEmpNum.TabIndex = 1
        Me.txtClEmpNum.TabStop = False
        Me.txtClEmpNum.Text = "123"
        Me.txtClEmpNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblTitle
        '
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.Navy
        Me.lblTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblTitle.Location = New System.Drawing.Point(10, 71)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(40, 13)
        Me.lblTitle.TabIndex = 8
        Me.lblTitle.Text = "T i t l e"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.IndianRed
        Me.Label5.Location = New System.Drawing.Point(338, 12)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(140, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Last"
        '
        'lblMN
        '
        Me.lblMN.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMN.ForeColor = System.Drawing.Color.IndianRed
        Me.lblMN.Location = New System.Drawing.Point(220, 12)
        Me.lblMN.Name = "lblMN"
        Me.lblMN.Size = New System.Drawing.Size(92, 13)
        Me.lblMN.TabIndex = 4
        Me.lblMN.Text = "Middle"
        '
        'lblFN
        '
        Me.lblFN.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFN.ForeColor = System.Drawing.Color.IndianRed
        Me.lblFN.Location = New System.Drawing.Point(106, 12)
        Me.lblFN.Name = "lblFN"
        Me.lblFN.Size = New System.Drawing.Size(108, 13)
        Me.lblFN.TabIndex = 2
        Me.lblFN.Text = "First"
        '
        'lblCEmployeeID
        '
        Me.lblCEmployeeID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCEmployeeID.ForeColor = System.Drawing.Color.IndianRed
        Me.lblCEmployeeID.Location = New System.Drawing.Point(15, 12)
        Me.lblCEmployeeID.Name = "lblCEmployeeID"
        Me.lblCEmployeeID.Size = New System.Drawing.Size(81, 13)
        Me.lblCEmployeeID.TabIndex = 0
        Me.lblCEmployeeID.Text = "Employee #"
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Lavender
        Me.Label12.Location = New System.Drawing.Point(305, 126)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(30, 28)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "First"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label43
        '
        Me.Label43.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Lavender
        Me.Label43.Location = New System.Drawing.Point(481, 127)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(30, 28)
        Me.Label43.TabIndex = 22
        Me.Label43.Text = "Last"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label44
        '
        Me.Label44.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.White
        Me.Label44.Location = New System.Drawing.Point(15, 126)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(713, 29)
        Me.Label44.TabIndex = 17
        Me.Label44.Text = " Marital Status"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(687, 8)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(63, 25)
        Me.btnDataErr.TabIndex = 1
        Me.btnDataErr.Text = "Data Error"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(519, 12)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(171, 17)
        Me.lstDataErr.TabIndex = 2
        Me.lstDataErr.Visible = False
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(346, 26)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 2
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(234, 25)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 20)
        Me.TextBox9.TabIndex = 1
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(122, 25)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 20)
        Me.TextBox10.TabIndex = 0
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Maroon
        Me.Label13.Location = New System.Drawing.Point(347, 9)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(82, 15)
        Me.Label13.TabIndex = 3
        Me.Label13.Text = " Last Name    "
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Maroon
        Me.Label14.Location = New System.Drawing.Point(242, 8)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(45, 15)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "Middle"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Maroon
        Me.Label15.Location = New System.Drawing.Point(136, 8)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(70, 15)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "First Name "
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.TextBox11)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.TextBox12)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.TextBox13)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.ComboBox2)
        Me.GroupBox3.Controls.Add(Me.TextBox14)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.TextBox15)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.TextBox16)
        Me.GroupBox3.Location = New System.Drawing.Point(18, 178)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(688, 72)
        Me.GroupBox3.TabIndex = 350
        Me.GroupBox3.TabStop = False
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(347, 39)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(150, 20)
        Me.TextBox11.TabIndex = 358
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.Navy
        Me.Label16.Location = New System.Drawing.Point(320, 42)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(24, 13)
        Me.Label16.TabIndex = 357
        Me.Label16.Text = "Cell"
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(542, 39)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(139, 20)
        Me.TextBox12.TabIndex = 356
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ForeColor = System.Drawing.Color.Navy
        Me.Label17.Location = New System.Drawing.Point(503, 42)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(25, 13)
        Me.Label17.TabIndex = 355
        Me.Label17.Text = "Fax"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.Color.Navy
        Me.Label18.Location = New System.Drawing.Point(3, 43)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(63, 13)
        Me.Label18.TabIndex = 354
        Me.Label18.Text = "work Phone"
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(247, 40)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(65, 20)
        Me.TextBox13.TabIndex = 353
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.Color.Navy
        Me.Label19.Location = New System.Drawing.Point(471, 16)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(67, 13)
        Me.Label19.TabIndex = 90
        Me.Label19.Text = "Home Phone"
        '
        'Label20
        '
        Me.Label20.ForeColor = System.Drawing.Color.Navy
        Me.Label20.Location = New System.Drawing.Point(222, 44)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(28, 12)
        Me.Label20.TabIndex = 352
        Me.Label20.Text = "Ext"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(70, 11)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(103, 21)
        Me.ComboBox2.TabIndex = 351
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(541, 12)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(140, 20)
        Me.TextBox14.TabIndex = 3
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.Color.Navy
        Me.Label21.Location = New System.Drawing.Point(7, 13)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(58, 13)
        Me.Label21.TabIndex = 0
        Me.Label21.Text = "Nationality"
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(217, 12)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(253, 20)
        Me.TextBox15.TabIndex = 7
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.Color.Navy
        Me.Label22.Location = New System.Drawing.Point(186, 12)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(31, 13)
        Me.Label22.TabIndex = 87
        Me.Label22.Tag = " "
        Me.Label22.Text = "EMail"
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(70, 39)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(140, 20)
        Me.TextBox16.TabIndex = 8
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(8, 314)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(680, 193)
        Me.TabControl1.TabIndex = 347
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox4)
        Me.TabPage2.Controls.Add(Me.Button2)
        Me.TabPage2.Controls.Add(Me.Button3)
        Me.TabPage2.Controls.Add(Me.Button4)
        Me.TabPage2.Controls.Add(Me.Button5)
        Me.TabPage2.Controls.Add(Me.DataGridView1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(672, 167)
        Me.TabPage2.TabIndex = 0
        Me.TabPage2.Text = "Address"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.BackColor = System.Drawing.Color.LightSteelBlue
        Me.GroupBox4.Controls.Add(Me.Button1)
        Me.GroupBox4.Controls.Add(Me.CheckedListBox1)
        Me.GroupBox4.ForeColor = System.Drawing.Color.Navy
        Me.GroupBox4.Location = New System.Drawing.Point(42, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(175, 156)
        Me.GroupBox4.TabIndex = 160
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Custom Columns"
        Me.GroupBox4.Visible = False
        '
        'Button1
        '
        Me.Button1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Location = New System.Drawing.Point(7, 127)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(162, 27)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Save Settings"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CheckedListBox1.CheckOnClick = True
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(3, 15)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(162, 94)
        Me.CheckedListBox1.TabIndex = 92
        Me.CheckedListBox1.ThreeDCheckBoxes = True
        '
        'Button2
        '
        Me.Button2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button2.BackColor = System.Drawing.Color.Linen
        Me.Button2.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button2.FlatAppearance.BorderSize = 2
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(6, 6)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(36, 30)
        Me.Button2.TabIndex = 159
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.ForeColor = System.Drawing.Color.Navy
        Me.Button3.Location = New System.Drawing.Point(590, 85)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(66, 23)
        Me.Button3.TabIndex = 19
        Me.Button3.Text = "Edit "
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.Location = New System.Drawing.Point(556, 177)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(64, 23)
        Me.Button4.TabIndex = 18
        Me.Button4.Text = "Delete "
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button5.ForeColor = System.Drawing.Color.Navy
        Me.Button5.Location = New System.Drawing.Point(589, 49)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(67, 23)
        Me.Button5.TabIndex = 17
        Me.Button5.Text = "New "
        Me.Button5.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(5, 6)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(572, 155)
        Me.DataGridView1.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.TextBox17)
        Me.TabPage3.Controls.Add(Me.Button6)
        Me.TabPage3.Controls.Add(Me.Button7)
        Me.TabPage3.Controls.Add(Me.Button8)
        Me.TabPage3.Controls.Add(Me.Label23)
        Me.TabPage3.Controls.Add(Me.Label24)
        Me.TabPage3.Controls.Add(Me.Label25)
        Me.TabPage3.Controls.Add(Me.Label26)
        Me.TabPage3.Controls.Add(Me.Label27)
        Me.TabPage3.Controls.Add(Me.Label28)
        Me.TabPage3.Controls.Add(Me.ComboBox9)
        Me.TabPage3.Controls.Add(Me.ComboBox10)
        Me.TabPage3.Controls.Add(Me.ComboBox11)
        Me.TabPage3.Controls.Add(Me.ComboBox12)
        Me.TabPage3.Controls.Add(Me.ComboBox13)
        Me.TabPage3.Controls.Add(Me.Label29)
        Me.TabPage3.Controls.Add(Me.TextBox18)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(672, 167)
        Me.TabPage3.TabIndex = 1
        Me.TabPage3.Text = "NewAddress"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(99, 14)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.ReadOnly = True
        Me.TextBox17.Size = New System.Drawing.Size(100, 20)
        Me.TextBox17.TabIndex = 49
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(552, 108)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(66, 23)
        Me.Button6.TabIndex = 48
        Me.Button6.Text = "Save "
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(552, 135)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(66, 23)
        Me.Button7.TabIndex = 47
        Me.Button7.Text = "Cancel "
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(552, 81)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(67, 23)
        Me.Button8.TabIndex = 46
        Me.Button8.Text = "New "
        Me.Button8.UseVisualStyleBackColor = True
        Me.Button8.Visible = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(275, 17)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(73, 13)
        Me.Label23.TabIndex = 45
        Me.Label23.Text = "Address Type"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(312, 79)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(37, 13)
        Me.Label24.TabIndex = 44
        Me.Label24.Text = "Street"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(62, 78)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(26, 13)
        Me.Label25.TabIndex = 43
        Me.Label25.Text = "City"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(318, 48)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(30, 13)
        Me.Label26.TabIndex = 42
        Me.Label26.Text = "Area"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(55, 46)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(33, 13)
        Me.Label27.TabIndex = 39
        Me.Label27.Text = "State"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(28, 16)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(60, 13)
        Me.Label28.TabIndex = 38
        Me.Label28.Text = "Address ID"
        '
        'ComboBox9
        '
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(99, 45)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(163, 21)
        Me.ComboBox9.TabIndex = 2
        '
        'ComboBox10
        '
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Location = New System.Drawing.Point(357, 14)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(163, 21)
        Me.ComboBox10.TabIndex = 1
        '
        'ComboBox11
        '
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Location = New System.Drawing.Point(99, 75)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(163, 21)
        Me.ComboBox11.TabIndex = 5
        '
        'ComboBox12
        '
        Me.ComboBox12.FormattingEnabled = True
        Me.ComboBox12.Location = New System.Drawing.Point(357, 45)
        Me.ComboBox12.Name = "ComboBox12"
        Me.ComboBox12.Size = New System.Drawing.Size(163, 21)
        Me.ComboBox12.TabIndex = 6
        '
        'ComboBox13
        '
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Location = New System.Drawing.Point(357, 76)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(163, 21)
        Me.ComboBox13.TabIndex = 7
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(-4, 111)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(92, 13)
        Me.Label29.TabIndex = 7
        Me.Label29.Text = "Building And Floor"
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(99, 108)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(421, 20)
        Me.TextBox18.TabIndex = 8
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label30)
        Me.GroupBox5.Controls.Add(Me.Label31)
        Me.GroupBox5.Controls.Add(Me.Label32)
        Me.GroupBox5.Controls.Add(Me.ComboBox14)
        Me.GroupBox5.Controls.Add(Me.TextBox19)
        Me.GroupBox5.Controls.Add(Me.TextBox20)
        Me.GroupBox5.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox5.Location = New System.Drawing.Point(17, 253)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(689, 54)
        Me.GroupBox5.TabIndex = 346
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "LogIn Info"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.ForeColor = System.Drawing.Color.Navy
        Me.Label30.Location = New System.Drawing.Point(11, 23)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(54, 13)
        Me.Label30.TabIndex = 92
        Me.Label30.Text = "UserLevel"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.ForeColor = System.Drawing.Color.Navy
        Me.Label31.Location = New System.Drawing.Point(492, 24)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(53, 13)
        Me.Label31.TabIndex = 91
        Me.Label31.Text = "Password"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.ForeColor = System.Drawing.Color.Navy
        Me.Label32.Location = New System.Drawing.Point(248, 25)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(56, 13)
        Me.Label32.TabIndex = 90
        Me.Label32.Text = "UserName"
        '
        'ComboBox14
        '
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Location = New System.Drawing.Point(73, 20)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(164, 21)
        Me.ComboBox14.TabIndex = 10
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(545, 22)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TextBox19.Size = New System.Drawing.Size(136, 20)
        Me.TextBox19.TabIndex = 12
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(324, 20)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(164, 20)
        Me.TextBox20.TabIndex = 11
        '
        'ListBox1
        '
        Me.ListBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(519, -19)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(153, 17)
        Me.ListBox1.TabIndex = 349
        Me.ListBox1.Visible = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox6.Controls.Add(Me.BouncingHoverButton2)
        Me.GroupBox6.Controls.Add(Me.BouncingHoverButton3)
        Me.GroupBox6.Controls.Add(Me.BouncingHoverButton4)
        Me.GroupBox6.Controls.Add(Me.BouncingHoverButton5)
        Me.GroupBox6.Location = New System.Drawing.Point(7, 508)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(680, 45)
        Me.GroupBox6.TabIndex = 348
        Me.GroupBox6.TabStop = False
        '
        'BouncingHoverButton2
        '
        Me.BouncingHoverButton2.AlternativeGroup = Nothing
        Me.BouncingHoverButton2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BouncingHoverButton2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton2.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton2.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton2.BorderHover = True
        Me.BouncingHoverButton2.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton2.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton2.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton2.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton2.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BouncingHoverButton2.DrawBorder = True
        Me.BouncingHoverButton2.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.BouncingHoverButton2.ForeColor = System.Drawing.Color.Navy
        Me.BouncingHoverButton2.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton2.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton2.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton2.Location = New System.Drawing.Point(11, 10)
        Me.BouncingHoverButton2.Name = "BouncingHoverButton2"
        Me.BouncingHoverButton2.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton2.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton2.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton2.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton2.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton2.SelectedText = Nothing
        Me.BouncingHoverButton2.Size = New System.Drawing.Size(105, 28)
        Me.BouncingHoverButton2.TabIndex = 42
        Me.BouncingHoverButton2.Text = "N e w"
        Me.BouncingHoverButton2.UseVisualStyleBackColor = False
        '
        'BouncingHoverButton3
        '
        Me.BouncingHoverButton3.AlternativeGroup = Nothing
        Me.BouncingHoverButton3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BouncingHoverButton3.BackColor = System.Drawing.Color.Orange
        Me.BouncingHoverButton3.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton3.BackColor2 = System.Drawing.Color.Orange
        Me.BouncingHoverButton3.BorderHover = True
        Me.BouncingHoverButton3.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton3.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton3.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton3.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton3.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BouncingHoverButton3.DrawBorder = True
        Me.BouncingHoverButton3.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.BouncingHoverButton3.ForeColor = System.Drawing.Color.Navy
        Me.BouncingHoverButton3.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton3.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton3.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton3.Location = New System.Drawing.Point(564, 11)
        Me.BouncingHoverButton3.Name = "BouncingHoverButton3"
        Me.BouncingHoverButton3.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton3.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton3.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton3.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton3.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton3.SelectedText = Nothing
        Me.BouncingHoverButton3.Size = New System.Drawing.Size(105, 28)
        Me.BouncingHoverButton3.TabIndex = 41
        Me.BouncingHoverButton3.Text = "C l o s e"
        Me.BouncingHoverButton3.UseVisualStyleBackColor = False
        '
        'BouncingHoverButton4
        '
        Me.BouncingHoverButton4.AlternativeGroup = Nothing
        Me.BouncingHoverButton4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BouncingHoverButton4.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton4.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton4.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton4.BorderHover = True
        Me.BouncingHoverButton4.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton4.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton4.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton4.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton4.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BouncingHoverButton4.DrawBorder = True
        Me.BouncingHoverButton4.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.BouncingHoverButton4.ForeColor = System.Drawing.Color.Navy
        Me.BouncingHoverButton4.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton4.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton4.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton4.Location = New System.Drawing.Point(121, 10)
        Me.BouncingHoverButton4.Name = "BouncingHoverButton4"
        Me.BouncingHoverButton4.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton4.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton4.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton4.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton4.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton4.SelectedText = Nothing
        Me.BouncingHoverButton4.Size = New System.Drawing.Size(105, 28)
        Me.BouncingHoverButton4.TabIndex = 17
        Me.BouncingHoverButton4.Text = "S a v e"
        Me.BouncingHoverButton4.UseVisualStyleBackColor = False
        '
        'BouncingHoverButton5
        '
        Me.BouncingHoverButton5.AlternativeGroup = Nothing
        Me.BouncingHoverButton5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BouncingHoverButton5.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton5.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton5.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton5.BorderHover = True
        Me.BouncingHoverButton5.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton5.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton5.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton5.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton5.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BouncingHoverButton5.DrawBorder = True
        Me.BouncingHoverButton5.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.BouncingHoverButton5.ForeColor = System.Drawing.Color.Navy
        Me.BouncingHoverButton5.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton5.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton5.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton5.Location = New System.Drawing.Point(318, 10)
        Me.BouncingHoverButton5.Name = "BouncingHoverButton5"
        Me.BouncingHoverButton5.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton5.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton5.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton5.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton5.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton5.SelectedText = Nothing
        Me.BouncingHoverButton5.Size = New System.Drawing.Size(105, 28)
        Me.BouncingHoverButton5.TabIndex = 40
        Me.BouncingHoverButton5.Text = "C a n c e l"
        Me.BouncingHoverButton5.UseVisualStyleBackColor = False
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.ComboBox15)
        Me.GroupBox7.Controls.Add(Me.ComboBox16)
        Me.GroupBox7.Controls.Add(Me.ComboBox17)
        Me.GroupBox7.Controls.Add(Me.Label33)
        Me.GroupBox7.Controls.Add(Me.TextBox21)
        Me.GroupBox7.Controls.Add(Me.Label34)
        Me.GroupBox7.Controls.Add(Me.ComboBox18)
        Me.GroupBox7.Controls.Add(Me.ComboBox19)
        Me.GroupBox7.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox7.Controls.Add(Me.ComboBox20)
        Me.GroupBox7.Controls.Add(Me.Label35)
        Me.GroupBox7.Controls.Add(Me.Label36)
        Me.GroupBox7.Location = New System.Drawing.Point(18, 105)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(688, 72)
        Me.GroupBox7.TabIndex = 344
        Me.GroupBox7.TabStop = False
        '
        'ComboBox15
        '
        Me.ComboBox15.FormattingEnabled = True
        Me.ComboBox15.Location = New System.Drawing.Point(534, 43)
        Me.ComboBox15.Name = "ComboBox15"
        Me.ComboBox15.Size = New System.Drawing.Size(103, 21)
        Me.ComboBox15.TabIndex = 15
        '
        'ComboBox16
        '
        Me.ComboBox16.FormattingEnabled = True
        Me.ComboBox16.Location = New System.Drawing.Point(425, 43)
        Me.ComboBox16.Name = "ComboBox16"
        Me.ComboBox16.Size = New System.Drawing.Size(103, 21)
        Me.ComboBox16.TabIndex = 14
        '
        'ComboBox17
        '
        Me.ComboBox17.FormattingEnabled = True
        Me.ComboBox17.Location = New System.Drawing.Point(316, 43)
        Me.ComboBox17.Name = "ComboBox17"
        Me.ComboBox17.Size = New System.Drawing.Size(103, 21)
        Me.ComboBox17.TabIndex = 13
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.Color.Wheat
        Me.Label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label33.ForeColor = System.Drawing.Color.Navy
        Me.Label33.Location = New System.Drawing.Point(158, 46)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(154, 17)
        Me.Label33.TabIndex = 12
        Me.Label33.Text = "Region-Qada-City Of Census"
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(73, 44)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(81, 20)
        Me.TextBox21.TabIndex = 11
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.ForeColor = System.Drawing.Color.Navy
        Me.Label34.Location = New System.Drawing.Point(5, 47)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(66, 13)
        Me.Label34.TabIndex = 10
        Me.Label34.Text = "Census Num"
        '
        'ComboBox18
        '
        Me.ComboBox18.FormattingEnabled = True
        Me.ComboBox18.Location = New System.Drawing.Point(533, 17)
        Me.ComboBox18.Name = "ComboBox18"
        Me.ComboBox18.Size = New System.Drawing.Size(103, 21)
        Me.ComboBox18.TabIndex = 9
        '
        'ComboBox19
        '
        Me.ComboBox19.FormattingEnabled = True
        Me.ComboBox19.Location = New System.Drawing.Point(424, 17)
        Me.ComboBox19.Name = "ComboBox19"
        Me.ComboBox19.Size = New System.Drawing.Size(103, 21)
        Me.ComboBox19.TabIndex = 8
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CustomFormat = "MMM dd, yyyy"
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker1.Location = New System.Drawing.Point(48, 16)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(107, 20)
        Me.DateTimePicker1.TabIndex = 0
        '
        'ComboBox20
        '
        Me.ComboBox20.FormattingEnabled = True
        Me.ComboBox20.Location = New System.Drawing.Point(316, 17)
        Me.ComboBox20.Name = "ComboBox20"
        Me.ComboBox20.Size = New System.Drawing.Size(103, 21)
        Me.ComboBox20.TabIndex = 1
        '
        'Label35
        '
        Me.Label35.BackColor = System.Drawing.Color.Wheat
        Me.Label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label35.ForeColor = System.Drawing.Color.Navy
        Me.Label35.Location = New System.Drawing.Point(158, 19)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(154, 17)
        Me.Label35.TabIndex = 2
        Me.Label35.Text = "State-City-Area Of Birth"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.ForeColor = System.Drawing.Color.Navy
        Me.Label36.Location = New System.Drawing.Point(13, 18)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(28, 13)
        Me.Label36.TabIndex = 0
        Me.Label36.Text = "DOB"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Label37)
        Me.GroupBox8.Controls.Add(Me.ComboBox21)
        Me.GroupBox8.Controls.Add(Me.ComboBox22)
        Me.GroupBox8.Controls.Add(Me.TextBox8)
        Me.GroupBox8.Controls.Add(Me.TextBox9)
        Me.GroupBox8.Controls.Add(Me.TextBox10)
        Me.GroupBox8.Controls.Add(Me.TextBox22)
        Me.GroupBox8.Controls.Add(Me.Label38)
        Me.GroupBox8.Controls.Add(Me.Label13)
        Me.GroupBox8.Controls.Add(Me.Label14)
        Me.GroupBox8.Controls.Add(Me.Label15)
        Me.GroupBox8.Controls.Add(Me.Label39)
        Me.GroupBox8.Location = New System.Drawing.Point(21, 4)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(685, 95)
        Me.GroupBox8.TabIndex = 343
        Me.GroupBox8.TabStop = False
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Maroon
        Me.Label37.Location = New System.Drawing.Point(595, 10)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(72, 13)
        Me.Label37.TabIndex = 7
        Me.Label37.Text = "Department"
        '
        'ComboBox21
        '
        Me.ComboBox21.FormattingEnabled = True
        Me.ComboBox21.Location = New System.Drawing.Point(591, 26)
        Me.ComboBox21.Name = "ComboBox21"
        Me.ComboBox21.Size = New System.Drawing.Size(86, 21)
        Me.ComboBox21.TabIndex = 6
        '
        'ComboBox22
        '
        Me.ComboBox22.FormattingEnabled = True
        Me.ComboBox22.Location = New System.Drawing.Point(458, 26)
        Me.ComboBox22.Name = "ComboBox22"
        Me.ComboBox22.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox22.TabIndex = 3
        '
        'TextBox22
        '
        Me.TextBox22.BackColor = System.Drawing.Color.Maroon
        Me.TextBox22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox22.Location = New System.Drawing.Point(10, 26)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.ReadOnly = True
        Me.TextBox22.Size = New System.Drawing.Size(100, 20)
        Me.TextBox22.TabIndex = 5
        Me.TextBox22.TabStop = False
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Maroon
        Me.Label38.Location = New System.Drawing.Point(462, 12)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(32, 13)
        Me.Label38.TabIndex = 4
        Me.Label38.Text = "Title"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.Maroon
        Me.Label39.Location = New System.Drawing.Point(9, 8)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(92, 15)
        Me.Label39.TabIndex = 0
        Me.Label39.Text = "Employee Num"
        '
        'txtClEmpID
        '
        Me.txtClEmpID.BackColor = System.Drawing.Color.White
        Me.txtClEmpID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtClEmpID.Location = New System.Drawing.Point(353, 12)
        Me.txtClEmpID.Name = "txtClEmpID"
        Me.txtClEmpID.ReadOnly = True
        Me.txtClEmpID.Size = New System.Drawing.Size(81, 20)
        Me.txtClEmpID.TabIndex = 4
        Me.txtClEmpID.TabStop = False
        '
        'OFDGetPhoto
        '
        Me.OFDGetPhoto.FileName = "OpenFileDialog1"
        '
        'txtLocation
        '
        Me.txtLocation.Location = New System.Drawing.Point(386, 8)
        Me.txtLocation.Name = "txtLocation"
        Me.txtLocation.Size = New System.Drawing.Size(40, 20)
        Me.txtLocation.TabIndex = 3
        '
        'txtClientID
        '
        Me.txtClientID.Location = New System.Drawing.Point(286, 8)
        Me.txtClientID.Name = "txtClientID"
        Me.txtClientID.Size = New System.Drawing.Size(36, 20)
        Me.txtClientID.TabIndex = 5
        '
        'frmClEmployeeList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(762, 643)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.tcMain)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.txtClEmpID)
        Me.Controls.Add(Me.txtLocation)
        Me.Controls.Add(Me.txtClientID)
        Me.KeyPreview = True
        Me.Name = "frmClEmployeeList"
        Me.Text = "Client Employee List "
        CType(Me.grdClEmpList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.grpControls.ResumeLayout(False)
        Me.tcMain.ResumeLayout(False)
        Me.tbClEmpList.ResumeLayout(False)
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        Me.tbNewEditEmpList.ResumeLayout(False)
        Me.grpOthers.ResumeLayout(False)
        Me.grpOthers.PerformLayout()
        Me.tcAddress.ResumeLayout(False)
        Me.tpViewAddress.ResumeLayout(False)
        Me.grpShowHideColumnsAdd.ResumeLayout(False)
        CType(Me.grdViewAddress, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpNewAddress.ResumeLayout(False)
        Me.tpNewAddress.PerformLayout()
        Me.grpButtons.ResumeLayout(False)
        Me.grpInfo.ResumeLayout(False)
        Me.grpInfo.PerformLayout()
        Me.grpName.ResumeLayout(False)
        Me.grpName.PerformLayout()
        CType(Me.picPersonnel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents grdClEmpList As System.Windows.Forms.DataGridView
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
	Friend WithEvents btnShowCol As System.Windows.Forms.Button
	Friend WithEvents grpControls As System.Windows.Forms.GroupBox
	Friend WithEvents btnNew As BHBut.BouncingHoverButton
	Friend WithEvents btnCloseList As BHBut.BouncingHoverButton
	Friend WithEvents btnEdit As BHBut.BouncingHoverButton
	Friend WithEvents tcMain As System.Windows.Forms.TabControl
	Friend WithEvents tbClEmpList As System.Windows.Forms.TabPage
	Friend WithEvents tbNewEditEmpList As System.Windows.Forms.TabPage
	Friend WithEvents tcAddress As System.Windows.Forms.TabControl
	Friend WithEvents tpViewAddress As System.Windows.Forms.TabPage
	Friend WithEvents grpShowHideColumnsAdd As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettingAdd As System.Windows.Forms.Button
	Friend WithEvents chkLstGridColAdd As System.Windows.Forms.CheckedListBox
	Friend WithEvents btnShowColAddress As System.Windows.Forms.Button
	Friend WithEvents btnEditAddress As System.Windows.Forms.Button
	Friend WithEvents btnDeleteAddress As System.Windows.Forms.Button
	Friend WithEvents btnNewAddress As System.Windows.Forms.Button
	Friend WithEvents grdViewAddress As System.Windows.Forms.DataGridView
	Friend WithEvents tpNewAddress As System.Windows.Forms.TabPage
	Friend WithEvents txtAddID As System.Windows.Forms.TextBox
	Friend WithEvents btnSaveAddress As System.Windows.Forms.Button
	Friend WithEvents btnCancelAddress As System.Windows.Forms.Button
	Friend WithEvents btnNewAddress2 As System.Windows.Forms.Button
	Friend WithEvents lblAddType As System.Windows.Forms.Label
	Friend WithEvents lblStreet As System.Windows.Forms.Label
	Friend WithEvents lblCity As System.Windows.Forms.Label
	Friend WithEvents lblArea As System.Windows.Forms.Label
	Friend WithEvents lblState As System.Windows.Forms.Label
	Friend WithEvents lblAddID As System.Windows.Forms.Label
	Friend WithEvents cboState As System.Windows.Forms.ComboBox
	Friend WithEvents cboAddType As System.Windows.Forms.ComboBox
	Friend WithEvents CboCity As System.Windows.Forms.ComboBox
	Friend WithEvents cboArea As System.Windows.Forms.ComboBox
	Friend WithEvents CboStreet As System.Windows.Forms.ComboBox
	Friend WithEvents lblBNF As System.Windows.Forms.Label
	Friend WithEvents txtBNF As System.Windows.Forms.TextBox
	Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnNewClientEmp As BHBut.BouncingHoverButton
	Friend WithEvents BtnClose As BHBut.BouncingHoverButton
	Friend WithEvents btnSaveClientEmp As BHBut.BouncingHoverButton
	Friend WithEvents btnCancel As BHBut.BouncingHoverButton
	Friend WithEvents lblTel As System.Windows.Forms.Label
	Friend WithEvents lblEMail As System.Windows.Forms.Label
	Friend WithEvents txtTel As System.Windows.Forms.TextBox
	Friend WithEvents txtEmail As System.Windows.Forms.TextBox
	Friend WithEvents grpInfo As System.Windows.Forms.GroupBox
	Friend WithEvents dtpDOB As System.Windows.Forms.DateTimePicker
	Friend WithEvents cboSOB As System.Windows.Forms.ComboBox
	Friend WithEvents lblPOB As System.Windows.Forms.Label
	Friend WithEvents lblDOB As System.Windows.Forms.Label
	Friend WithEvents grpName As System.Windows.Forms.GroupBox
	Friend WithEvents cboTitle As System.Windows.Forms.ComboBox
	Friend WithEvents txtLName As System.Windows.Forms.TextBox
	Friend WithEvents txtMName As System.Windows.Forms.TextBox
	Friend WithEvents txtFName As System.Windows.Forms.TextBox
	Friend WithEvents txtClEmpNum As System.Windows.Forms.TextBox
	Friend WithEvents lblTitle As System.Windows.Forms.Label
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents lblMN As System.Windows.Forms.Label
	Friend WithEvents lblFN As System.Windows.Forms.Label
	Friend WithEvents lblCEmployeeID As System.Windows.Forms.Label
   Friend WithEvents grpOthers As System.Windows.Forms.GroupBox
   Friend WithEvents txtHomePhone As System.Windows.Forms.TextBox
   Friend WithEvents Label9 As System.Windows.Forms.Label
   Friend WithEvents Label11 As System.Windows.Forms.Label
   Friend WithEvents txtCensNum As System.Windows.Forms.TextBox
   Friend WithEvents Label10 As System.Windows.Forms.Label
   Friend WithEvents cboAOB As System.Windows.Forms.ComboBox
   Friend WithEvents cboCOB As System.Windows.Forms.ComboBox
   Friend WithEvents cboCOCen As System.Windows.Forms.ComboBox
   Friend WithEvents cboQOCen As System.Windows.Forms.ComboBox
   Friend WithEvents cboROCen As System.Windows.Forms.ComboBox
   Friend WithEvents cboNationality As System.Windows.Forms.ComboBox
   Friend WithEvents txtExt As System.Windows.Forms.TextBox
	Friend WithEvents txtFax As System.Windows.Forms.TextBox
   Friend WithEvents Label4 As System.Windows.Forms.Label
   Friend WithEvents Label2 As System.Windows.Forms.Label
   Friend WithEvents txtCel As System.Windows.Forms.TextBox
   Friend WithEvents Label6 As System.Windows.Forms.Label
   Friend WithEvents txtMFName As System.Windows.Forms.TextBox
   Friend WithEvents Label40 As System.Windows.Forms.Label
   Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
   Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
   Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
   Friend WithEvents Label13 As System.Windows.Forms.Label
   Friend WithEvents Label14 As System.Windows.Forms.Label
   Friend WithEvents Label15 As System.Windows.Forms.Label
   Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
   Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
   Friend WithEvents Label16 As System.Windows.Forms.Label
   Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
   Friend WithEvents Label17 As System.Windows.Forms.Label
   Friend WithEvents Label18 As System.Windows.Forms.Label
   Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
   Friend WithEvents Label19 As System.Windows.Forms.Label
   Friend WithEvents Label20 As System.Windows.Forms.Label
   Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
   Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
   Friend WithEvents Label21 As System.Windows.Forms.Label
   Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
   Friend WithEvents Label22 As System.Windows.Forms.Label
   Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
   Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
   Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
   Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
   Friend WithEvents Button1 As System.Windows.Forms.Button
   Friend WithEvents CheckedListBox1 As System.Windows.Forms.CheckedListBox
   Friend WithEvents Button2 As System.Windows.Forms.Button
   Friend WithEvents Button3 As System.Windows.Forms.Button
   Friend WithEvents Button4 As System.Windows.Forms.Button
   Friend WithEvents Button5 As System.Windows.Forms.Button
   Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
   Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
   Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
   Friend WithEvents Button6 As System.Windows.Forms.Button
   Friend WithEvents Button7 As System.Windows.Forms.Button
   Friend WithEvents Button8 As System.Windows.Forms.Button
   Friend WithEvents Label23 As System.Windows.Forms.Label
   Friend WithEvents Label24 As System.Windows.Forms.Label
   Friend WithEvents Label25 As System.Windows.Forms.Label
   Friend WithEvents Label26 As System.Windows.Forms.Label
   Friend WithEvents Label27 As System.Windows.Forms.Label
   Friend WithEvents Label28 As System.Windows.Forms.Label
   Friend WithEvents ComboBox9 As System.Windows.Forms.ComboBox
   Friend WithEvents ComboBox10 As System.Windows.Forms.ComboBox
   Friend WithEvents ComboBox11 As System.Windows.Forms.ComboBox
   Friend WithEvents ComboBox12 As System.Windows.Forms.ComboBox
   Friend WithEvents ComboBox13 As System.Windows.Forms.ComboBox
   Friend WithEvents Label29 As System.Windows.Forms.Label
   Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
   Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
   Friend WithEvents Label30 As System.Windows.Forms.Label
   Friend WithEvents Label31 As System.Windows.Forms.Label
   Friend WithEvents Label32 As System.Windows.Forms.Label
   Friend WithEvents ComboBox14 As System.Windows.Forms.ComboBox
   Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
   Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
   Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
   Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
   Friend WithEvents BouncingHoverButton2 As BHBut.BouncingHoverButton
   Friend WithEvents BouncingHoverButton3 As BHBut.BouncingHoverButton
   Friend WithEvents BouncingHoverButton4 As BHBut.BouncingHoverButton
   Friend WithEvents BouncingHoverButton5 As BHBut.BouncingHoverButton
   Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
   Friend WithEvents ComboBox15 As System.Windows.Forms.ComboBox
   Friend WithEvents ComboBox16 As System.Windows.Forms.ComboBox
   Friend WithEvents ComboBox17 As System.Windows.Forms.ComboBox
   Friend WithEvents Label33 As System.Windows.Forms.Label
   Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
   Friend WithEvents Label34 As System.Windows.Forms.Label
   Friend WithEvents ComboBox18 As System.Windows.Forms.ComboBox
   Friend WithEvents ComboBox19 As System.Windows.Forms.ComboBox
   Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
   Friend WithEvents ComboBox20 As System.Windows.Forms.ComboBox
   Friend WithEvents Label35 As System.Windows.Forms.Label
   Friend WithEvents Label36 As System.Windows.Forms.Label
   Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
   Friend WithEvents Label37 As System.Windows.Forms.Label
   Friend WithEvents ComboBox21 As System.Windows.Forms.ComboBox
   Friend WithEvents ComboBox22 As System.Windows.Forms.ComboBox
   Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
   Friend WithEvents Label38 As System.Windows.Forms.Label
   Friend WithEvents Label39 As System.Windows.Forms.Label
   Friend WithEvents txtMLName As System.Windows.Forms.TextBox
   Friend WithEvents Label41 As System.Windows.Forms.Label
   Friend WithEvents txtDriverLicNum As System.Windows.Forms.TextBox
   Friend WithEvents Label42 As System.Windows.Forms.Label
   Friend WithEvents txtSLName As System.Windows.Forms.TextBox
   Friend WithEvents txtSFName As System.Windows.Forms.TextBox
	Friend WithEvents CboMaritalStatus As System.Windows.Forms.ComboBox
   Friend WithEvents Label45 As System.Windows.Forms.Label
   Friend WithEvents btnGetSign As System.Windows.Forms.Button
   Friend WithEvents picPersonnel As System.Windows.Forms.PictureBox
   Friend WithEvents txtClEmpID As System.Windows.Forms.TextBox
   Friend WithEvents txtNote As System.Windows.Forms.TextBox
   Friend WithEvents Label3 As System.Windows.Forms.Label
   Friend WithEvents btnDataErr As System.Windows.Forms.Button
   Friend WithEvents OFDGetPhoto As System.Windows.Forms.OpenFileDialog
   Friend WithEvents FbdDataFile As System.Windows.Forms.FolderBrowserDialog
   Friend WithEvents txtLocation As System.Windows.Forms.TextBox
   Friend WithEvents txtClientID As System.Windows.Forms.TextBox
   Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
   Friend WithEvents txtFilByLName As System.Windows.Forms.TextBox
   Friend WithEvents lblLName As System.Windows.Forms.Label
   Friend WithEvents txtFiltByMName As System.Windows.Forms.TextBox
   Friend WithEvents lblMName As System.Windows.Forms.Label
   Friend WithEvents txtFiltByFName As System.Windows.Forms.TextBox
   Friend WithEvents Label7 As System.Windows.Forms.Label
   Friend WithEvents txtFiltByNum As System.Windows.Forms.TextBox
   Friend WithEvents lblEmployeeNum As System.Windows.Forms.Label
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents Label12 As System.Windows.Forms.Label
	Friend WithEvents Label43 As System.Windows.Forms.Label
	Friend WithEvents Label44 As System.Windows.Forms.Label
End Class
