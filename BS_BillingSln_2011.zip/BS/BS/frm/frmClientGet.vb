Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmClientGet


#Region "Form-Declaration..."
    ''
    Private dsdata As DataSet
    Private clsMr As ClsMain
    Private daService As SqlClient.SqlDataAdapter
    ''
    Private blnLoading As Boolean
    Private mStrSubKeyName As String = "Software\BIT Solutions\BS\ClientGet\Settings"

    Public arr(1) As Integer
    Public CboValue As Integer
    Private mstrCurrentGridName As String
#End Region


#Region "Form-Load......"

    Private Sub frmAccountGet_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        ''
        SaveProfile(mStrSubKeyName, grdClientSearch)
    End Sub

    Private Sub frmClientGet_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmGetService_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        clsMr = New ClsMain(conSql)
        ''
        blnLoading = True
        MakeDataAdapter()
        blnLoading = False

        ''
        DrawGrid()

        ''
        txtFilterNum.Text = ""
        txtFilterName.Text = ""
        txtFilterNum.Focus()

    End Sub

    Private Sub MakeDataAdapter()
        ''
        '' set connection
        ''
        clsMr = New ClsMain(conSql)

        ''
        '' set the structure of the tables in the DataSet
        ''

        clsMr.BuildSqlAdapter("SELECT  ClientNum, ClientName,ClientID FROM tblClient WHERE Del=0 ", "tblClient")
        dsdata = clsMr.getDataSet
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

#End Region


#Region "Form-UI/Methods...."
    ''
    Private Sub txtFilterNum_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFilterNum.KeyPress
        Integers_KeyPress(txtFilterNum, e)
    End Sub

    Private Sub txtFilterNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFilterNum.TextChanged
        ''
        If blnLoading = True Then Exit Sub
        ''
        If txtFilterNum.Text = "" Then
            dsdata.Tables("tblClient").DefaultView.RowFilter = " ClientName  LIKE '*" & txtFilterName.Text & "*'"
        Else
            dsdata.Tables("tblClient").DefaultView.RowFilter = "ClientNum = " & txtFilterNum.Text & " AND ClientName  LIKE '*" & txtFilterName.Text & "*'"
        End If

        '	dsdata.Tables("accountsearch").DefaultView.RowFilter = "num like '" & txtNumAcctFilter.Text & "*' and AcctName  like '*" & txtName.Text & "*'"
    End Sub

    Private Sub txtFilterNum_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtFilterNum.KeyDown
        ''
        If e.KeyCode = Keys.Delete Or e.KeyCode = Keys.Back Then
            txtFilterName.Text = ""
        Else
            If e.KeyCode = Keys.Down And grdClientSearch.Visible = True Then
                grdClientSearch.Focus()
            End If
        End If

    End Sub

    Private Sub txtFilterName_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtFilterName.KeyDown
        ''
        If e.KeyCode = Keys.Delete Or e.KeyCode = Keys.Back Then
            txtFilterNum.Text = ""
        Else
            If e.KeyCode = Keys.Down And grdClientSearch.Visible = True Then
                grdClientSearch.Focus()
            End If
        End If
    End Sub

    Private Sub txtFilterName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFilterName.TextChanged
        If txtFilterNum.Text = "" Then
            dsdata.Tables("tblClient").DefaultView.RowFilter = " ClientName  LIKE '*" & txtFilterName.Text & "*'"
        Else
            dsdata.Tables("tblClient").DefaultView.RowFilter = "ClientNum = " & txtFilterNum.Text & " AND ClientName  LIKE '*" & txtFilterName.Text & "*'"
        End If
        'dsdata.Tables("tblClient").DefaultView.RowFilter = "ClientNum LIKE '" & Integer.Parse(txtFilterNum.Text) & "*' AND ClientName like '*" & txtFilterName.Text & "*'"
        ''dsdata.Tables("tblClient").DefaultView.RowFilter = "ClientNum LIKE " & Integer.Parse(txtFilterNum.Text) & " AND ClientName like " & txtFilterName.Text
    End Sub

    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
        Dim i As Integer
        ''
        For i = 0 To chkLstGridCol.Items.Count - 1
            Me.grdClientSearch.Columns(i).Visible = chkLstGridCol.GetItemChecked(i)
        Next
        ''
        grpShowHideColumns.Visible = False
    End Sub

    Private Sub btnShowCol_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()
            mstrCurrentGridName = "ClientGet"
            ''
            '' populate list with grid's dataSource fields...
            ''

            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdClientSearch.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next

            chkLstGridCol.Items.Remove("ClientID")

        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        ''
        'If grdClientSearch.Rows.Count = 0 Then Exit Sub
        '' ''
        'Dim i As Integer
        'Dim dv As DataGridViewSelectedRowCollection = grdClientSearch.SelectedRows
        ' ''
        'ReDim arr(dv.Count)
        ''
        'For i = 0 To dv.Count - 1
        '	Dim drv As DataGridViewRow = dv(i)
        '	arr(i) = dv(i).Cells("ClientID").Value
        'Next

        CboValue = grdClientSearch.Item("ClientID", grdClientSearch.CurrentRow.Index).Value

        Me.Close()
    End Sub

    Private Sub grdClientSearch_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdClientSearch.KeyDown
        ''
        If e.KeyCode = Keys.Enter Then
            CboValue = grdClientSearch.Item("ClientID", grdClientSearch.CurrentRow.Index).Value
            Me.Close()
        End If
    End Sub

#End Region


#Region "Functions....."

    Private Sub DrawGrid()
        ''
        '' set draw grdAcctSearch
        ''
        grdClientSearch.DataSource = dsdata.Tables("tblClient")
        dsdata.Tables("tblClient").DefaultView.AllowNew = False
        'grdClientSearch.Columns("BranchID").Visible = False
        grdClientSearch.Columns("ClientID").Visible = False
        'grdClientSearch.Columns("Del").Visible = False
        'grdClientSearch.Columns("ClientName").Width = 245
        'grdClientSearch.Columns("Num").Width = 150
        'grdClientSearch.Columns("ClientName").HeaderText = "Name"
        'grdClientSearch.Columns("Num").HeaderText = "Number"
        grdClientSearch.ReadOnly = True
        grdClientSearch.Visible = True
        grdClientSearch.ColumnHeadersHeight = btnShowCol.Height + 2
        grdClientSearch.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing

    End Sub

#End Region


End Class