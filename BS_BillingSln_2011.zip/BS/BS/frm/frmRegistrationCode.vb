''
'Imports System.Management
Imports BITSSecurity

Public Class frmRegistrationCode

	Private mStrSubKeyName As String = "Software\BIT Solutions\SMS2005\Settings\BITSSecurityModel"


	Private Sub frmCHK_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		''
		'' save code into registry...
		''
		Dim clsBITSSecurity As New clsSet
		''
		txt1OK.Text = clsBITSSecurity.str1OK
		txt2OK.Text = clsBITSSecurity.str2OK
		txt3OK.Text = clsBITSSecurity.str3OK
		txt4OK.Text = clsBITSSecurity.str4OK
		txt5OK.Text = clsBITSSecurity.str5OK
		txt6OK.Text = clsBITSSecurity.str6OK

		''
		'' save code into registry...
		''
		txt1.Text = getKeyValue(mStrSubKeyName, "Code1")
		txt2.Text = getKeyValue(mStrSubKeyName, "Code2")
		txt3.Text = getKeyValue(mStrSubKeyName, "Code3")
		txt4.Text = getKeyValue(mStrSubKeyName, "Code4")
		txt5.Text = getKeyValue(mStrSubKeyName, "Code5")
		txt6.Text = getKeyValue(mStrSubKeyName, "Code6")

		''
		If chkRegCode() Then
			''
			'' set gBlnBITSSec value...
			''
			gBlnBITSSec = True

			''
			'' close form...
			''
			Me.Close()
		End If

	End Sub


#Region "textChnage"

	Private Sub txt1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt1.TextChanged
		If txt1.Text.Length > 7 Then
			txt2.Focus()
			chkRegCode()
		End If
	End Sub

	Private Sub txt2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt2.TextChanged
		If txt2.Text.Length > 7 Then
			txt3.Focus()
			chkRegCode()
		End If
	End Sub

	Private Sub txt3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt3.TextChanged
		If txt3.Text.Length > 7 Then
			txt4.Focus()
			chkRegCode()
		End If
	End Sub

	Private Sub txt4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt4.TextChanged
		If txt4.Text.Length > 7 Then
			txt5.Focus()
			chkRegCode()
		End If
	End Sub

	Private Sub txt5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt5.TextChanged
		If txt5.Text.Length > 7 Then
			txt6.Focus()
			chkRegCode()
		End If
	End Sub

	Private Sub txt6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt6.TextChanged
		If txt6.Text.Length > 7 Then
			chkRegCode()
		End If
	End Sub
#End Region


#Region "RegistrationCode..."

	Private Function chkRegCode() As Boolean
		''
		Dim colorX As New Color
		''
		'' default bad code...
		''
		colorX = Color.Red
		chkRegCode = False

		''
		'' check entered codes...
		''
		If txt1.Text = txt1OK.Text And txt2.Text = txt2OK.Text And txt3.Text = txt3OK.Text Then
			If txt4.Text = txt4OK.Text And txt5.Text = txt5OK.Text And txt6.Text = txt6OK.Text Then
				'' ok code, exit...
				chkRegCode = True
				colorX = Color.RoyalBlue
			Else
				'' bad code...
				colorX = Color.Red
				chkRegCode = False
			End If
		End If

		''
		'' react to validity...
		''
		Me.txt1.ForeColor = colorX
		Me.txt2.ForeColor = colorX
		Me.txt3.ForeColor = colorX
		Me.txt4.ForeColor = colorX
		Me.txt5.ForeColor = colorX
		Me.txt6.ForeColor = colorX
		''
		If chkRegCode Then
			lblMsg.Text = "Thank you for registering with BIT Solutions!"
			btnNext.Enabled = True
		Else
			lblMsg.Text = "Invalid BIT Solutions Registration Code, please check and try again!"
			btnNext.Enabled = False
		End If

	End Function

#End Region

	Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
		''
		'' set gBlnBITSSec value...
		''
		gBlnBITSSec = True

		''
		'' save codes into registry...
		''
		setKeyValue(mStrSubKeyName, "Code1", txt1.Text)
		setKeyValue(mStrSubKeyName, "Code2", txt2.Text)
		setKeyValue(mStrSubKeyName, "Code3", txt3.Text)
		setKeyValue(mStrSubKeyName, "Code4", txt4.Text)
		setKeyValue(mStrSubKeyName, "Code5", txt5.Text)
		setKeyValue(mStrSubKeyName, "Code6", txt6.Text)

		''
		'' close form...
		''
		Me.Close()

	End Sub

End Class