Imports System.Data.SqlClient
''
Public Class frmReport

#Region "Form-Declarations..."
	''
	Dim clsMr As BITSConn.ClsMain
	Dim dsData As New DataSet
	Dim blnLoading As Boolean
	Dim BstyleNone As BorderStyle = BorderStyle.None
	Dim Bstyle3D As BorderStyle = BorderStyle.Fixed3D
	Dim cboBoolean As Boolean = False
	Dim blnorder As Boolean = False
	Dim blnCustomer As Boolean = False
	Dim strCustomerName As String
	Dim strSqlAcctName As String
	Private daTafkeet As SqlDataAdapter
	Private strQuarter As String = ""
	''
	Private mstrCurrentGridNameInvoiceList As String
	Private mStrSubKeyNameInvoiceList As String = "Software\BIT Solutions\BS\ReportInvoiceList\Settings"
	''

#End Region


#Region "Form-Load..."

	Private Sub frmrptOptions_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

		clsMr = New BITSConn.ClsMain(conSql)
		blnLoading = True

		'' Initialize Data
		MakeDataAdapter()
		FillComboBox()
		SetAutoNumber()
		'' BuildTree
		BuildReportsTree()

		'' in case of item reports
		setObjState(False)

		DrawGrid()
		''
		FilterGrid()
		blnLoading = False
		If tabReportMain.TabPages.Contains(tabPreview) Then
			tabReportMain.TabPages.Remove(tabPreview)
		End If
		cboClient.SelectedIndex = -1
		cboCategory.SelectedIndex = -1
		cboServices.SelectedIndex = -1
		''
		lblCurrSymbol.Text = GetCompanyCurrencySymbol()
		lblCurrSymbol2.Text = GetCompanyCurrencySymbol2()
		''
		CalculateTotal()
		''
		grpFilter.Visible = False
		grpInvoiceList.Visible = False
		pnlTitle.Visible = False
	End Sub

	Public Sub MakeDataAdapter()
		''
		''Reports
		''
		clsMr.BuildSqlAdapter("select * from tblRptType WHERE RptTypeID = 2", "ReportGroup")
		clsMr.BuildSqlAdapter("select * from tblReport WHERE RptTypeID = 2", "Reports")
		''
		daTafkeet = clsMr.BuildSqlAdapter("SELECT * FROM tblTafkeet", "tblTafkeet")
		clsMr.BuildSqlAdapter("SELECT InvoiceNumber, ClientName, CatType, InvoiceDate, Status, RefID, RefIDTo , Total, TotalCurr2, ClientID, StatusID, InvoiceID, CatID, Del FROM vwInvoiceList", "vwInvoiceList")
		clsMr.BuildSqlAdapter("SELECT ClientID,ClientName  from tblClient WHERE Del =0  ORDER BY ClientName", "ClientName")
		clsMr.BuildSqlAdapter("SELECT * FROM tblService WHERE Del = 0", "tblServiceName")
		clsMr.BuildSqlAdapter("SELECT CatID,CatType  FROM tblServiceCategory WHERE Del =0 ", "tblServiceCategory")

		''
		dsData = clsMr.getDataSet
	End Sub

	Private Sub FillComboBox()
		''
		clsMr.FillComboBox("ClientName", cboClient, "ClientName", "ClientID")
		clsMr.FillComboBox("tblServiceName", cboServices, "ServiceName", "ServiceID")
		clsMr.FillComboBox("tblServiceCategory", cboCategory, "CatType", "CatID")
	End Sub

	Private Sub DrawGrid()
		''
		''InvoiceList
		''
		dsData.Tables("vwInvoiceList").DefaultView.AllowNew = False
		''
		With grdInvoiceList
			.DataSource = dsData.Tables("vwInvoiceList").DefaultView
			.ReadOnly = True
			.ColumnHeadersHeight = btnShowColInvoiceList.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
			''
			.Columns("ClientID").Visible = False
			.Columns("statusID").Visible = False
			.Columns("InvoiceID").Visible = False
			.Columns("CatID").Visible = False
			.Columns("Del").Visible = False
			''
			.Columns("InvoiceDate").HeaderText = "Invoice Date"
			.Columns("InvoiceNumber").HeaderText = "Invoice #"
			.Columns("ClientName").HeaderText = "Client Name"
			.Columns("CatType").HeaderText = "Category"
			.Columns("RefID").HeaderText = "Correction Of"
			.Columns("RefIDTo").HeaderText = "Corrected By"
			''
			.Columns("TotalCurr2").HeaderText = "Total " & GetCompanyCurrencySymbol2()
			.Columns("TotalCurr2").DefaultCellStyle.Format = "#,###0.##"
			.Columns("TotalCurr2").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			''
			.Columns("Total").DefaultCellStyle.Format = "#,###0.##"
			.Columns("Total").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
		End With
		''
		LoadProfile(mStrSubKeyNameInvoiceList, Me.grdInvoiceList)

	End Sub

	Private Sub SetAutoNumber()
		'clsMr.SetAutoNumber("tblInvoiceDetailRpt", "ID")

	End Sub

#End Region


#Region "Form-UI/Methods..."

	Private Sub PicPreview_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PicPreview.MouseMove
		PicPreview.BorderStyle = BstyleNone
	End Sub
	Private Sub PicPreview_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PicPreview.MouseLeave
		PicPreview.BorderStyle = Bstyle3D
	End Sub

	Private Sub PicPdf_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PicPdf.MouseMove
		PicPdf.BorderStyle = BstyleNone
	End Sub

	Private Sub PicPdf_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PicPdf.MouseLeave
		PicPdf.BorderStyle = Bstyle3D
	End Sub

	Private Sub PicPdf_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PicPdf.Click
		SelectReport()
		crvReport.ExportReport()
	End Sub
	Private Sub picPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picPrint.Click
		SelectReport()
		crvReport.PrintReport()
	End Sub

	Private Sub picPrint_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picPrint.MouseMove
		picPrint.BorderStyle = BstyleNone
	End Sub

	Private Sub picPrint_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles picPrint.MouseLeave
		picPrint.BorderStyle = Bstyle3D
	End Sub


	Private Sub PicPrint2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		crvReport.PrintReport()
	End Sub

	Private Sub PicNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		crvReport.ShowNextPage()
	End Sub

	Private Sub PicPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		crvReport.ShowPreviousPage()
	End Sub

	Private Sub PicPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PicPreview.Click
		SelectReport()
	End Sub
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' When selecting a node allow related controls to appear...
	Private Sub tvReports_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvReports.AfterSelect

		If e.Node.Tag Is Nothing Then
			Exit Sub
		End If

		Dim NodeType As String
		Dim NodeID As Integer

		NodeType = CType(e.Node.Tag, String).Substring(0, 1)
		NodeID = Convert.ToInt32(CType(e.Node.Tag, String).Substring(1))

		If NodeType = "G" Then

			Select Case NodeID
				Case 1
					'setObjState(False)
					'grpAccount.Visible = False

					'setObjState(False)

				Case 2
					''set autofilter of reports before choosing description''
					'grpDailyReport.Visible = True
					'grpAccount.Visible = False

					'setObjState(False)

				Case 3
					''grpAccount.Visible = True
					'dtpDtFrom.Value = Format(DateInterval.Month - 1, dtpDtTo.Value)
					'setObjState(False)

			End Select
		Else
			ShowReportOptions(NodeID)
		End If

	End Sub
	Private Sub grdPO_CellContentDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)
		SelectReport()
	End Sub
	Private Sub btnClosePreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClosePreview.Click
		''
		'' closes the active preview tab; retwrn focus to Reports tab...
		''
		If tabReportMain.TabPages.Contains(tabPreview) Then
			tabReportMain.TabPages.Remove(tabPreview)
		End If
		''
		tabReportMain.SelectedIndex = 0

	End Sub
	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		Me.Close()
	End Sub

	Private Sub cboFilterClient_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
		FiltertblClientsAndServices()
	End Sub

	Private Sub cboFilterClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
		FiltertblClientsAndServices()
	End Sub

	Private Sub cboService_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
		FiltertblClientsAndServices()
	End Sub

	Private Sub cboService_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
		FiltertblClientsAndServices()
	End Sub

	Private Sub rdbClient_Click(ByVal sender As Object, ByVal e As System.EventArgs)
		FiltertblClientsAndServices()
	End Sub

	Private Sub rdbService_Click(ByVal sender As Object, ByVal e As System.EventArgs)
		FiltertblClientsAndServices()
	End Sub

	Private Sub FiltertblClientsAndServices()

		If blnLoading Then Exit Sub
		Dim strFilter As String = True

		Dim strGroupBy As String = ""

        'strFilter = "(InvoiceDate >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (InvoiceDate <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "')"
		'      strFilter = "(InvoiceDate >= '" & dtpDateFrom.Value.ToShortDateString() & "') AND (InvoiceDate <= '" & dtpDateTo.Value.ToShortDateString() & "')"
		'      If cboService.SelectedIndex <> -1 Then
		'          strFilter = strFilter & " AND  ServiceName='" & cboService.Text & "'"
		'          strFilterRpt = "{vwClientsAndServicesRpt.ServiceName}='" & cboService.Text & "'"
		'      End If

		'If cboFilterClient.SelectedIndex <> -1 Then
		'	If strFilter = "" Then
		'		strFilter = " ClientName='" & cboFilterClient.Text & "'"
		'		strFilterRpt = "{vwClientsAndServicesRpt.ClientName}='" & cboService.Text & "'"
		'	Else
		'		strFilter = strFilter & " AND ClientName='" & cboFilterClient.Text & "'"
		'		strFilterRpt = strFilter & " AND {vwClientsAndServicesRpt.ClientName}='" & cboFilterClient.Text & "'"
		'	End If

		'End If




		dsData.Tables("vwClientsAndServicesRpt").DefaultView.RowFilter = strFilter
		ClearTable()
		dsData.Tables("tblInvoiceDetailRpt").DefaultView.RowFilter = ""
		Dim dv As DataView
		dv = dsData.Tables("vwClientsAndServicesRpt").DefaultView

		If dv.Count > 0 Then

			Dim ind As Integer
			For ind = 0 To dv.Count - 1
				'drv = dv(i)


				Dim dr As DataRow = dsData.Tables("tblInvoiceDetailRpt").NewRow
				AddDataRow(dr, dv(ind))
				dsData.Tables("tblInvoiceDetailRpt").Rows.Add(dr)
			Next
		End If
		'If rdbNone.Checked = True Then
		'	Exit Sub
		'End If


		'If rdbClient.Checked = True Then
		'	strGroupBy = " ClientName "
		'	dsData.Tables("tblInvoiceDetailRpt").Rows.Clear()
		'	clsMr.BuildSqlAdapter("SELECT Count(InvoiceNumber) as InvoiceNumber,ClientName,Sum(Total) as Total , Sum(TotalCurr2) as TotalCurr2, sum(sumQ1) as SumQ1 ,sum(sumQ2) as SumQ2 ,sum(sumQ3) as SumQ3 ,sum(sumQ4) as SumQ4  FROM  tblInvoiceDetailRpt  GROUP BY " & strGroupBy, "tblInvoiceDetailRpt")

		'Else
		'	strGroupBy = " ServiceName "
		'	dsData.Tables("tblInvoiceDetailRpt").Rows.Clear()
		'	clsMr.BuildSqlAdapter("SELECT Count(InvoiceNumber) as InvoiceNumber,ServiceName,Sum(Total) as Total , Sum(TotalCurr2) as TotalCurr2, sum(sumQ1) as SumQ1, sum(sumQ2) as SumQ2 , sum(sumQ3) as SumQ3 , sum(sumQ4) as  SumQ4 FROM  tblInvoiceDetailRpt   GROUP BY " & strGroupBy, "tblInvoiceDetailRpt")


		'End If

		''clear
		Dim cmd As New SqlClient.SqlCommand("Delete from tblInvoiceDetailRpt", conSql)
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()
		''fill with groupby
		Dim dv1 As DataView = dsData.Tables("tblInvoiceDetailRpt").DefaultView
		Dim drv1 As DataRowView

		For Each drv1 In dv1
			Dim cmdUpdate As New SqlClient.SqlCommand("Insert into tblInvoiceDetailRpt (InvoiceNumber,ClientName,ServiceName,Total,TotalCurr2,SumQ1,SumQ2,SumQ3,SumQ4) Values (" & drv1("InvoiceNumber") & ",'" & drv1("ClientName") & "','" & drv1("ServiceName") & "'," & drv1("Total") & "," & drv1("TotalCurr2") & "," & drv1("SumQ1") & "," & drv1("SumQ2") & "," & drv1("SumQ3") & "," & drv1("SumQ4") & ")", conSql)
			conSql.Open()
			cmdUpdate.ExecuteNonQuery()
			conSql.Close()
		Next
	End Sub

	Private Sub btnGoDynamics_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGoDynamics.Click
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		''
		If Not tvReports.SelectedNode Is Nothing Then
			''
			Dim s As String = tvReports.SelectedNode.Tag
			''
			'' "G" = A Group of Reports NOT an actual report... 
			If s.StartsWith("G") Then
				Exit Sub
			Else
				Select Case Convert.ToInt32(s.Substring(1))
					''
					Case 1
						''
						FilterGrid()
						SetColumnsGrdInvoiceList()

					Case 8
						''
						FilterGrid()
						SetColumnsGrdInvoiceList()

					Case 9
						''
						FilterGrid()
						SetColumnsGrdInvoiceList()
				End Select
			End If
		End If
		''
	End Sub



	Private Sub cboClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
		AutoComplete(cboClient, e)
	End Sub

	Private Sub cboCategory_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboCategory.KeyPress
		AutoComplete(cboCategory, e)
	End Sub

	Private Sub chkQuarter1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkQuarter1.CheckedChanged
		''
		If blnLoading Then Exit Sub
		''
		If chkOther.Visible Then
			''
			Dim blnCheck As Boolean
			''
			blnCheck = chkQuarter1.Checked
			''
			If chkOther.Checked Then
				chkQuarter1.Checked = False
				Exit Sub
			Else
				chkQuarter1.Checked = blnCheck
			End If
			''
		End If
	End Sub

	Private Sub chkQuarter3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkQuarter3.CheckedChanged
		''
		''
		If blnLoading Then Exit Sub
		''
		If chkOther.Visible Then

			Dim blnCheck As Boolean
			''
			blnCheck = chkQuarter3.Checked
			''
			If chkOther.Checked Then
				chkQuarter3.Checked = False
				Exit Sub
			Else
				chkQuarter3.Checked = blnCheck
			End If
			''
		End If
	End Sub

	Private Sub chkQuarter2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkQuarter2.CheckedChanged
		''
		If blnLoading Then Exit Sub
		''
		If chkOther.Visible Then
			''
			Dim blnCheck As Boolean
			''
			blnCheck = chkQuarter2.Checked
			''
			If chkOther.Checked Then
				chkQuarter2.Checked = False
				Exit Sub
			Else
				chkQuarter2.Checked = blnCheck
			End If
		End If
	End Sub

	Private Sub chkQuarter4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkQuarter4.CheckedChanged
		''
		If blnLoading Then Exit Sub
		''
		If chkOther.Visible Then
			''
			Dim blnCheck As Boolean
			''
			blnCheck = chkQuarter4.Checked
			''
			If chkOther.Checked Then
				chkQuarter4.Checked = False
				Exit Sub
			Else
				chkQuarter4.Checked = blnCheck
			End If
		End If
	End Sub

	Private Sub chkOther_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkOther.CheckedChanged
		''
		If blnLoading Then Exit Sub
		''
		Dim blnCheck As Boolean
		''
		blnCheck = chkOther.Checked
		''
		If chkQuarter1.Checked Or chkQuarter2.Checked Or chkQuarter3.Checked Or chkQuarter4.Checked Then
			chkOther.Checked = False
			Exit Sub
		Else
			chkOther.Checked = blnCheck
		End If
		''
		If chkOther.Checked Then
			''
			setcontrols(True)
		Else
			setcontrols(False)
		End If
		''
		'FilterGrid()
	End Sub

#End Region


#Region "functions"
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' To set object state of group boxes...
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Private Sub setObjState(ByVal blnState As Boolean)

	End Sub

	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' To open the selected tab page...
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Private Sub GetNextTab()
		If Not (tabReportMain.TabPages.Contains(Me.tabPreview)) Then
			tabReportMain.TabPages.Add(tabPreview)
		End If
		Me.tabReportMain.SelectedTab = Me.tabPreview
		Me.WindowState = FormWindowState.Maximized
		'crvReport.Zoom(100)
		crvReport.Zoom(75)
		'NumericUpDown1.Value = 100

	End Sub

	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' To build tree and its nodes...
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Private Sub BuildReportsTree()
		Dim dr As DataRow
		Dim drChild As DataRow
		Dim drChilds() As DataRow

		Dim aNode As TreeNode
		Dim aNodeChild As TreeNode

		For Each dr In dsData.Tables("ReportGroup").Rows

			aNode = New TreeNode(dr("RptType"), 0, 0)
			aNode.Tag = "G" & dr("RptTypeID")

			drChilds = dsData.Tables("Reports").Select("RptTypeID = " & dr("RptTypeID"))
			For Each drChild In drChilds
				aNodeChild = New TreeNode(drChild("RptName"), 2, 2)
				aNodeChild.Tag = "R" & drChild("RptID")
				aNode.Nodes.Add(aNodeChild)
				aNodeChild.ImageIndex = 1
				aNodeChild.SelectedImageIndex = 1
			Next
			tvReports.Nodes.Add(aNode)
		Next

	End Sub

	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' view specific controls according to the chosen report name...
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Private Sub ShowReportOptions(ByVal RptId As Integer)
		''
		Dim cmd As SqlClient.SqlCommand
		''
		cmd = New SqlClient.SqlCommand("SELECT * FROM tblReport WHERE RptID=@RptID", conSql)
		cmd.Parameters.AddWithValue("@RptID", RptId)
		Dim dr As SqlClient.SqlDataReader

		If conSql.State = ConnectionState.Closed Then
			conSql.Open()
		End If

		dr = cmd.ExecuteReader()
		If dr.Read() Then
			lblReportTitle.Visible = True
			lblReportTitle.BringToFront()
			lblReportTitle.Text = dr("RptName")
			dr.Close()
			conSql.Close()
		End If
		''
		Select Case RptId
			Case 1
				grpFilter.Visible = True
				grpInvoiceList.Visible = True
				grpInvoiceList.BringToFront()
				grpInvoiceList.Dock = DockStyle.Fill
				'grpSumServiceQuarterly.Visible = False
				grpQuarter.Visible = True
				grpStatus.Visible = True

				grpDuePeriods.Visible = False
				grpStatus.Visible = True
				lblStatus.Visible = True
				lblServices.Visible = False
				cboServices.Visible = False
				lblCategory.Visible = True
				cboCategory.Visible = True
				rdbLBPAndUSD.Visible = True
				chkOther.Visible = True
				lblInvoiceNum.Visible = True
				txtInvoiceNum.Visible = True
				dtpDateFrom.Visible = True
				dtpDateTo.Visible = True
				lblDateFrom.Visible = True
				lblDateTo.Visible = True
				pnlTitle.Visible = True
				lblClient.Visible = True
				cboClient.Visible = True


			Case 8
				grpFilter.Visible = True
				grpInvoiceList.Visible = True
				grpInvoiceList.BringToFront()
				grpInvoiceList.Dock = DockStyle.Fill
				'grpSumServiceQuarterly.Visible = False
				grpDuePeriods.Visible = False
				grpStatus.Visible = True

				grpQuarter.Visible = True
				grpStatus.Visible = True
				lblStatus.Visible = True
				lblServices.Visible = False
				cboServices.Visible = False
				lblCategory.Visible = True
				cboCategory.Visible = True
				rdbLBPAndUSD.Visible = True
				chkOther.Visible = True
				lblInvoiceNum.Visible = True
				txtInvoiceNum.Visible = True
				dtpDateFrom.Visible = True
				dtpDateTo.Visible = True
				lblDateFrom.Visible = True
				lblDateTo.Visible = True
				pnlTitle.Visible = True
				lblClient.Visible = True
				cboClient.Visible = True

			Case 9
				grpFilter.Visible = True
				grpInvoiceList.Visible = True
				grpInvoiceList.BringToFront()
				grpInvoiceList.Dock = DockStyle.Fill
				'grpSumServiceQuarterly.Visible = False
				grpDuePeriods.Visible = True
				grpStatus.Visible = False
				grpQuarter.Visible = True
				grpStatus.Visible = True
				lblStatus.Visible = True
				lblServices.Visible = False
				cboServices.Visible = False
				lblCategory.Visible = True
				cboCategory.Visible = True
				rdbLBPAndUSD.Visible = True
				chkOther.Visible = True
				lblInvoiceNum.Visible = True
				txtInvoiceNum.Visible = True
				dtpDateFrom.Visible = True
				dtpDateTo.Visible = True
				lblDateFrom.Visible = True
				lblDateTo.Visible = True
				pnlTitle.Visible = True
				lblClient.Visible = True
				cboClient.Visible = True
		End Select
	End Sub

	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	'' when choosing a report from lstReport call the function required to view the report
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	Private Sub SelectReport()

		If tvReports.SelectedNode Is Nothing Then
			Exit Sub
		End If

		Dim s As String
		s = tvReports.SelectedNode.Tag

		'' what is "G"? define... 
		If s.StartsWith("G") Then
			Exit Sub
		End If

		''
		Select Case Convert.ToInt32(s.Substring(1))
			Case 1
				InvoiceList()
			Case 8
				''
				If cboCategory.SelectedIndex = -1 Then
					MsgBox(" You Should Choose a Category  ", , "Please")
					Exit Sub
				End If
				''
				Invoice()
		End Select
		GetNextTab()

	End Sub

	Public Sub ChooseReport(ByVal ReportId As Long, ByVal Status As Integer, ByVal ParamArray prms() As Object)

		Dim aNode As TreeNode
		Dim SubNode As TreeNode

		Dim found As Boolean

		found = False
		For Each aNode In tvReports.Nodes
			For Each SubNode In aNode.Nodes
				If SubNode.Tag = "R" & ReportId Then
					tvReports.SelectedNode = SubNode
					found = True
					Exit For
				End If
			Next
			If found Then
				Exit For
			End If
		Next

		If found Then
			Select Case ReportId
				Case 1
					'grpInvoice.Visible = True

				Case 2
					'grpInvoice.Visible = True

				Case 3
					'grpInvoice.Visible = True


			End Select
			''satus  1 is opened so it is order not invoice 
			If Status = 2 Then
				blnorder = True
			Else
				If Status = 1 Then
					blnorder = False
				End If
			End If
			SelectReport()
		End If
	End Sub

	'Private Sub ClientsAndServices()

	'	Windows.Forms.Cursor.Current = Cursors.WaitCursor()
	'	' If chkShowFinancialInfo.Checked = True Then
	'	Dim rpt As New rptClientsAndServices
	'	Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
	'	Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
	'	''
	'	For Each tbCurrent In rpt.Database.Tables
	'		tliCurrent = tbCurrent.LogOnInfo
	'		''
	'		With tliCurrent.ConnectionInfo
	'			.ServerName = gStrServerName
	'			.DatabaseName = gStrDataBaseName
	'			.UserID = ""
	'			.Password = ""
	'		End With
	'		tbCurrent.ApplyLogOnInfo(tliCurrent)
	'	Next tbCurrent
	'	rpt.SetParameterValue("CurrSymbol", GetCompanyCurrencySymbol())
	'	Me.crvReport.ReportSource = rpt

	'	'Me.crvReport.SelectionFormula = strFilterRpt
	'	'rpt.DataDefinition.GroupSelectionFormula = "{vwClientsAndServicesRpt.ServiceName}={vwClientsAndServicesRpt.ServiceName}"
	'	Me.crvReport.Refresh()
	'	Me.crvReport.DisplayToolbar = True

	'	'frm.tabMain.SelectedTab = frm.tabLicenseReport
	'	'' set mousePointer to default...
	'	Windows.Forms.Cursor.Current = Cursors.Default()
	'	'GetNextTab()
	'End Sub

	'Private Sub SumServicesQuarterly()
	'	Windows.Forms.Cursor.Current = Cursors.WaitCursor()
	'	' If chkShowFinancialInfo.Checked = True Then
	'	If rdbQLeb.Checked = True Then
	'		Dim rpt As New rptSumServicesQuarterly
	'		Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
	'		Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
	'		''
	'		For Each tbCurrent In rpt.Database.Tables
	'			tliCurrent = tbCurrent.LogOnInfo
	'			''
	'			With tliCurrent.ConnectionInfo
	'				.ServerName = gStrServerName
	'				.DatabaseName = gStrDataBaseName
	'				.UserID = ""
	'				.Password = ""
	'			End With
	'			tbCurrent.ApplyLogOnInfo(tliCurrent)
	'		Next tbCurrent
	'		rpt.SetParameterValue("CurrSybl", GetCompanyCurrencySymbol)
	'		Me.crvReport.ReportSource = rpt

	'		Me.crvReport.Refresh()
	'		Me.crvReport.DisplayToolbar = True

	'		'frm.tabMain.SelectedTab = frm.tabLicenseReport
	'		'' set mousePointer to default...
	'		Windows.Forms.Cursor.Current = Cursors.Default()
	'		'GetNextTab()



	'	Else
	'		If rdbQUSD.Checked = True Then
	'			Dim rpt As New rptSumServiceQuarterlyUSD
	'			Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
	'			Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
	'			''
	'			For Each tbCurrent In rpt.Database.Tables
	'				tliCurrent = tbCurrent.LogOnInfo
	'				''
	'				With tliCurrent.ConnectionInfo
	'					.ServerName = gStrServerName
	'					.DatabaseName = gStrDataBaseName
	'					.UserID = ""
	'					.Password = ""
	'				End With
	'				tbCurrent.ApplyLogOnInfo(tliCurrent)
	'			Next tbCurrent
	'			rpt.SetParameterValue("CurrSybl", GetCompanyCurrencySymbol2)
	'			Me.crvReport.ReportSource = rpt

	'			Me.crvReport.Refresh()
	'			Me.crvReport.DisplayToolbar = True

	'			'frm.tabMain.SelectedTab = frm.tabLicenseReport
	'			'' set mousePointer to default...
	'			Windows.Forms.Cursor.Current = Cursors.Default()
	'			'GetNextTab()

	'		Else
	'			Dim rpt As New rptSumServiceQuarterlyDblCurr
	'			Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
	'			Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
	'			''
	'			For Each tbCurrent In rpt.Database.Tables
	'				tliCurrent = tbCurrent.LogOnInfo
	'				''
	'				With tliCurrent.ConnectionInfo
	'					.ServerName = gStrServerName
	'					.DatabaseName = gStrDataBaseName
	'					.UserID = ""
	'					.Password = ""
	'				End With
	'				tbCurrent.ApplyLogOnInfo(tliCurrent)
	'			Next tbCurrent
	'			rpt.SetParameterValue("CurrSybl1", GetCompanyCurrencySymbol)
	'			rpt.SetParameterValue("CurrSybl2", GetCompanyCurrencySymbol2)
	'			Me.crvReport.ReportSource = rpt

	'			Me.crvReport.Refresh()
	'			Me.crvReport.DisplayToolbar = True

	'			'frm.tabMain.SelectedTab = frm.tabLicenseReport
	'			'' set mousePointer to default...
	'			Windows.Forms.Cursor.Current = Cursors.Default()
	'			'GetNextTab()
	'		End If
	'	End If

	'	End Sub

	Private Sub ClearTable()
		Dim cmd As New SqlClient.SqlCommand("Delete from tblInvoiceDetailRpt", conSql)
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()
		dsData.Tables("tblInvoiceDetailRpt").Rows.Clear()

	End Sub

	Private Sub AddDataRow(ByRef pdrToAdd As DataRow, ByRef pdrValues As DataRowView, Optional ByVal IsSum As Boolean = False)

		pdrToAdd("InvoiceNumber") = pdrValues("InvoiceNumber")
		pdrToAdd("ClientName") = pdrValues("ClientName")
		pdrToAdd("ServiceName") = pdrValues("ServiceName")

		'If IsSum Then
		'	pdrToAdd("SumQ1") = GetExchangeValue(pdrValues("CurrencyID"), gIntCompanyCurrID, pdrValues("InvoiceDate"), pdrValues("Q1Total"))
		'	pdrToAdd("SumQ2") = GetExchangeValue(pdrValues("CurrencyID"), gIntCompanyCurrID, pdrValues("InvoiceDate"), pdrValues("Q2Total"))
		'	pdrToAdd("SumQ3") = GetExchangeValue(pdrValues("CurrencyID"), gIntCompanyCurrID, pdrValues("InvoiceDate"), pdrValues("Q3Total"))
		'	pdrToAdd("SumQ4") = GetExchangeValue(pdrValues("CurrencyID"), gIntCompanyCurrID, pdrValues("InvoiceDate"), pdrValues("Q4Total"))
		'	pdrToAdd("Total") = pdrToAdd("SumQ1") + pdrToAdd("SumQ2") + pdrToAdd("SumQ3") + pdrToAdd("SumQ4")
		'Else
		If pdrValues("Total") Is DBNull.Value Then
			pdrValues("Total") = 0
		End If
		pdrToAdd("Total") = pdrValues("Total")
		pdrToAdd("TotalCurr2") = pdrValues("TotalCurr2")
		'pdrToAdd("Total") = GetExchangeValue(pdrValues("CurrencyID"), gIntCompanyCurrID, pdrValues("InvoiceDate"), pdrValues("Total"))
		pdrToAdd("SumQ1") = 0
		pdrToAdd("SumQ2") = 0
		pdrToAdd("SumQ3") = 0
		pdrToAdd("SumQ4") = 0

		'End If




		'daClientsAndServices.Update(dsData, "tblInvoiceDetailRpt")
		UpdateTable(pdrToAdd)
	End Sub

	Private Sub UpdateTable(ByRef pdrToAdd As DataRow)
		Dim cmd As New SqlClient.SqlCommand("Insert into tblInvoiceDetailRpt (InvoiceNumber,ClientName,ServiceName,Total,TotalCurr2,SumQ1,SumQ2,SumQ3,SumQ4) Values (" & pdrToAdd("InvoiceNumber") & ",'" & pdrToAdd("ClientName") & "','" & pdrToAdd("ServiceName") & "'," & pdrToAdd("Total") & "," & pdrToAdd("Total") & "," & pdrToAdd("SumQ1") & "," & pdrToAdd("SumQ2") & "," & pdrToAdd("SumQ3") & "," & pdrToAdd("SumQ4") & ")", conSql)
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()
	End Sub

	Private Sub CalculateQuartersSum()

		'If blnLoading Then Exit Sub
		'Dim dv As DataView = dsData.Tables("vwServicesQuarterlyRpt").DefaultView
		'Dim drv As DataRowView

		Dim dblSumQ1 As Double
		Dim dblSumQ2 As Double
		Dim dblSumQ3 As Double
		Dim dblSumQ4 As Double
		Dim dblQuartersTotal As Double
		Dim dblSumQ1Curr2 As Double
		Dim dblSumQ2Curr2 As Double
		Dim dblSumQ3Curr2 As Double
		Dim dblSumQ4Curr2 As Double
		Dim dblQuartersTotalCurr2 As Double
		'ClearTable()
		'For Each drv In dv
		'	Dim dr As DataRow = dsData.Tables("tblQuarterServiceSum").NewRow

		'	AddDataRow(dr, drv, True)
		'	dsData.Tables("tblQuarterServiceSum").Rows.Add(dr)

		'Next

		'dsData.Tables("tblQuarterServiceSum").Rows.Clear()
		'clsMr.BuildSqlAdapter("SELECT Count(InvoiceNumber) as InvoiceNumber,ServiceName,sum(Total) as Total, sum(SumQ1) as SumQ1,sum(SumQ2) as SumQ2 ,sum(SumQ3) as SumQ3,sum(SumQ4) as SumQ4  FROM  tblInvoiceDetailRpt   GROUP BY ServiceName", "tblQuarterServiceSum")
		' ''clear
		'Dim cmd As New SqlClient.SqlCommand("Delete from tblInvoiceDetailRpt", conSql)
		'conSql.Open()
		'cmd.ExecuteNonQuery()
		'conSql.Close()
		' ''fill with groupby
		'Dim dv1 As DataView = dsData.Tables("tblQuarterServiceSum").DefaultView
		'Dim drv1 As DataRowView

		'For Each drv1 In dv1
		'	Dim cmdUpdate As New SqlClient.SqlCommand("Insert into tblInvoiceDetailRpt (InvoiceNumber,ClientName,ServiceName,Total,SumQ1,SumQ2,SumQ3,SumQ4) Values (" & drv1("InvoiceNumber") & ",'" & drv1("ClientName") & "','" & drv1("ServiceName") & "'," & drv1("Total") & "," & drv1("SumQ1") & "," & drv1("SumQ2") & "," & drv1("SumQ3") & "," & drv1("SumQ4") & ")", conSql)
		'	conSql.Open()
		'	cmdUpdate.ExecuteNonQuery()
		'	conSql.Close()
		'Next



		'For Each drv1 In dv1
		'	dblSumQ1 += drv1("SumQ1")
		'	dblSumQ2 += drv1("SumQ2")
		'	dblSumQ3 += drv1("SumQ3")
		'	dblSumQ4 += drv1("SumQ4")
		'	dblQuartersTotal += drv1("Total")
		'Next

		'txtSumQ1.Text = Double.Parse(dblSumQ1).ToString("#0.00#")
		'txtSumQ2.Text = Double.Parse(dblSumQ2).ToString("#0.00#")
		'txtSumQ3.Text = Double.Parse(dblSumQ3).ToString("#0.00#")
		'txtSumQ4.Text = Double.Parse(dblSumQ4).ToString("#0.00#")
		'txtQuartersSum.Text = Double.Parse(dblQuartersTotal).ToString("#0.00#")

		Dim dv As DataView = dsData.Tables("vwSumServicesQuarterlyRpt").DefaultView
		Dim drv As DataRowView
		For Each drv In dv

			dblSumQ1 += drv("SumQ1")
			dblSumQ2 += drv("SumQ2")
			dblSumQ3 += drv("SumQ3")
			dblSumQ4 += drv("SumQ4")
			dblQuartersTotal += drv("SumTotal")
			dblSumQ1Curr2 += drv("SumQ1Curr2")
			dblSumQ2Curr2 += drv("SumQ2Curr2")
			dblSumQ3Curr2 += drv("SumQ3Curr2")
			dblSumQ4Curr2 += drv("SumQ4Curr2")
			dblQuartersTotalCurr2 += drv("SumTotalCurr2")
		Next
		'txtSumQ1.Text = Double.Parse(dblSumQ1).ToString("#0#")
		'txtSumQ2.Text = Double.Parse(dblSumQ2).ToString("#0#")
		'txtSumQ3.Text = Double.Parse(dblSumQ3).ToString("#0#")
		'txtSumQ4.Text = Double.Parse(dblSumQ4).ToString("#0#")
		'txtQuartersSum.Text = Double.Parse(dblQuartersTotal).ToString("#0#")

		'txtSumQ1Curr2.Text = Double.Parse(dblSumQ1Curr2).ToString("#0#")
		'txtSumQ2Curr2.Text = Double.Parse(dblSumQ2Curr2).ToString("#0#")
		'txtSumQ3Curr2.Text = Double.Parse(dblSumQ3Curr2).ToString("#0#")
		'txtSumQ4Curr2.Text = Double.Parse(dblSumQ4Curr2).ToString("#0#")
		'txtQuartersSumCurr2.Text = Double.Parse(dblQuartersTotalCurr2).ToString("#0#")
	End Sub



	Private Sub FilterGrid()
		''
		'If blnLoading = True Then Exit Sub
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor
		''
		Dim s As String = "True"
		Dim strStatus As String
		''
		If chkQuarter1.Checked Then
			''
			's &= " AND (InvoiceDate Between  '" & Date.Now.Year & "-1-1' AND '" & Date.Now.Year & "-3-31' )"
			s &= " AND ((InvoiceDate >= '" & Date.Now.Year & "-1-1') AND (InvoiceDate <='" & Date.Now.Year & "-3-31' ))"
		End If
		''
		If chkQuarter2.Checked Then
			''
			If s = "True" Then
				s &= " AND ((InvoiceDate >= '" & Date.Now.Year & "-4-1') AND (InvoiceDate <='" & Date.Now.Year & "-6-30' ))"
			Else
				s &= " OR ((InvoiceDate >= '" & Date.Now.Year & "-4-1') AND (InvoiceDate <='" & Date.Now.Year & "-6-30' ))"
			End If
		End If
		''
		If chkQuarter3.Checked Then
			''
			If s = "True" Then
				s &= " AND ((InvoiceDate >= '" & Date.Now.Year & "-7-1') AND (InvoiceDate <='" & Date.Now.Year & "-9-30' ))"
				''
			Else
				s &= " OR ((InvoiceDate >= '" & Date.Now.Year & "-7-1') AND (InvoiceDate <='" & Date.Now.Year & "-9-30' ))"
			End If
		End If
		''
		If chkQuarter4.Checked Then
			''
			If s = "True" Then
				s &= " AND ((InvoiceDate >= '" & Date.Now.Year & "-10-1') AND (InvoiceDate <='" & Date.Now.Year & "-12-31' ))"
			Else
				s &= " OR ((InvoiceDate >= '" & Date.Now.Year & "-10-1') AND (InvoiceDate <='" & Date.Now.Year & "-12-31' ))"
			End If
		End If
		''
		If chkQuarter1.Checked = False And chkQuarter2.Checked = False And chkQuarter3.Checked = False And chkQuarter4.Checked = False And chkOther.Checked Then
			s = "(InvoiceDate >= '" & dtpDateFrom.Value.ToString("yyyy-M-d") & "') AND (InvoiceDate <= '" & dtpDateTo.Value.ToString("yyyy-M-d") & "')"
		End If
		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				s = s & " AND  (InvoiceNumber = " & tn & ")"
			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		'If cboTypeOfPreparation.Text <> String.Empty Then
		'	If cboTypeOfPreparation.Text = "Manual" Then
		'		s = s & " AND  (AutoGel = 0)"
		'	Else 'If cboTypeOfPreparation.Text = "Auto Generated" Then

		'		s = s & " AND  (AutoGel = 1)"
		'	End If
		'End If
		''
		'End If
		'If txtInvoiceType.Text <> String.Empty Then

		'	s = s & " AND  (InvoiceType = '" & txtInvoiceType.Text & "')"

		'End If
		''
		If cboCategory.SelectedIndex <> -1 Then
			s = s & " AND (CatID = " & cboCategory.SelectedValue & ")"
		Else
			If cboCategory.Text <> "" And cboCategory.SelectedIndex = -1 Then
				s = s & " AND (CatID = " & -1 & ")"
			End If
		End If
		''
		'If cboTypeOfPreparation.SelectedIndex <> -1 Then
		'    s = s & " AND (AutoGel = " & cboTypeOfPreparation.SelectedValue & ")"
		'Else
		'    If cboTypeOfPreparation.Text <> "" And cboTypeOfPreparation.SelectedIndex = -1 Then
		'        s = s & " AND (AutoGel = " & -1 & ")"
		'    End If

		'End If

		If cboClient.SelectedIndex <> -1 Then
			s = s & " AND (ClientID = " & cboClient.SelectedValue & ")"
		Else
			If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
				s = s & " AND (ClientID = " & -1 & ")"
			End If
		End If

		''
		'If cboStatus.SelectedIndex <> -1 Then
		'   s = s & " AND (StatusID = " & cboStatus.SelectedValue & ")"
		'Else
		'   If cboStatus.Text <> "" And cboStatus.SelectedIndex = -1 Then
		'      s = s & " AND (StatusID = " & -1 & ")"
		'   End If
		'End If
		''

		If chkPosted.Checked = False And chkNotPosted.Checked = False And chkNew.Checked = False And chkPaid.Checked = False And chkCorrected.Checked = False Then

			' s = "0"
			s = s & " AND StatusID=0"
		Else
			''
			strStatus = " AND StatusID IN ("
			''
			If chkPosted.Checked = True Then
				strStatus = strStatus & "2"
			End If
			''
			If chkNotPosted.Checked = True Then
				If strStatus = " AND StatusID IN (" Then
					strStatus = strStatus & "3"
				Else
					strStatus = strStatus & ",3"
				End If
			End If
			''
			If chkNew.Checked = True Then
				If strStatus = " AND StatusID IN (" Then
					strStatus = strStatus & "1"
				Else
					strStatus = strStatus & ",1"
				End If
			End If
			''
			If chkPaid.Checked = True Then
				If strStatus = " AND StatusID IN (" Then
					strStatus = strStatus & "4"
				Else
					strStatus = strStatus & ",4"
				End If
			End If
			''
			If chkCorrected.Checked = True Then
				If strStatus = " AND StatusID IN (" Then
					strStatus = strStatus & "5"
				Else
					strStatus = strStatus & ",5"
				End If
			End If
			''
			strStatus = strStatus & ")"
		End If
		''

		s = s & strStatus
		''
		''
		'Dim BillStatus As String = ""
		'If chkOverDue30.Checked = False And chkOverDue60.Checked = False And chkOverDue90.Checked = False And chkOverDue120.Checked = False Then
		'	s = s & " AND BillStatus='NotFound'"
		'Else

		'	BillStatus = " AND BillStatus IN ("
		'	''
		'	'If chkDue.Checked = True Then
		'	'	If BillStatus = " AND BillStatus IN (" Then
		'	'		BillStatus = BillStatus & "'Due'"
		'	'	Else
		'	'		BillStatus = BillStatus & ",'Due'"
		'	'	End If

		'	'End If
		'	''
		'	If chkOverDue30.Checked = True Then
		'		If BillStatus = " AND BillStatus IN (" Then
		'			BillStatus = BillStatus & "'OverDue30Days'"
		'		Else
		'			BillStatus = BillStatus & ",'OverDue30Days'"
		'		End If

		'	End If
		'	''
		'	If chkOverDue60.Checked = True Then
		'		If BillStatus = " AND BillStatus IN (" Then
		'			BillStatus = BillStatus & "'OverDue60Days'"
		'		Else
		'			BillStatus = BillStatus & ",'OverDue60Days'"
		'		End If

		'	End If
		'	''
		'	If chkOverDue90.Checked = True Then
		'		If BillStatus = " AND BillStatus IN (" Then
		'			BillStatus = BillStatus & "'OverDue90Days'"
		'		Else
		'			BillStatus = BillStatus & ",'OverDue90Days'"
		'		End If

		'	End If
		'	''
		'	If chkOverDue120.Checked = True Then
		'		If BillStatus = " AND BillStatus IN (" Then
		'			BillStatus = BillStatus & "'OverDue120Days'"
		'		Else
		'			BillStatus = BillStatus & ",'OverDue120Days'"
		'		End If
		'	End If
		'	''
		'	BillStatus = BillStatus & ")"
		'End If
		' ''
		's = s & BillStatus
		''
		dsData.Tables("vwInvoiceList").DefaultView.RowFilter = s
		''
		ChangeColor()
		'SetStatus()
		CalculateTotal()
		''
		Windows.Forms.Cursor.Current = Cursors.Default
	End Sub

	Private Sub SetColumnsGrdInvoiceList()
		''
		With grdInvoiceList
			''
			If rdbLBP.Checked Then
				''
				.Columns("TotalCurr2").Visible = False
				.Columns("Total").Visible = True
				''
				.Columns("TotalCurr2").DefaultCellStyle.Format = "###,##0"
				.Columns("Total").DefaultCellStyle.Format = "###,##0"
				''
				lblCurrSymbol.Visible = True
				lblCurrSymbol2.Visible = False
				txtTotal.Visible = True
				txtTotalCurr2.Visible = False

			ElseIf rdbUSD.Checked Then
				''
				.Columns("Total").Visible = False
				.Columns("TotalCurr2").Visible = True
				''
				.Columns("TotalCurr2").DefaultCellStyle.Format = "###,##0.0"
				.Columns("Total").DefaultCellStyle.Format = "###,##0.0"
				''
				lblCurrSymbol.Visible = False
				lblCurrSymbol2.Visible = True
				txtTotal.Visible = False
				txtTotalCurr2.Visible = True

			Else
				.Columns("TotalCurr2").Visible = True
				.Columns("Total").Visible = True
				''
				.Columns("TotalCurr2").DefaultCellStyle.Format = "###,##0.0"
				.Columns("Total").DefaultCellStyle.Format = "###,##0.0"
				''
				lblCurrSymbol.Visible = True
				lblCurrSymbol2.Visible = True
				txtTotal.Visible = True
				txtTotalCurr2.Visible = True
			End If
			''
		End With
	End Sub

	Private Sub ChangeColor()
		''
		''change color of visits according to status
		''
		Dim i As Integer
		Dim intStatus As Integer
		For i = 0 To dsData.Tables("vwInvoiceList").DefaultView.Count - 1
			intStatus = dsData.Tables("vwInvoiceList").DefaultView.Item(i)("StatusID")
			''
			Select Case intStatus
				Case 1
					grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.LightYellow

				Case 2
					grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.LightSteelBlue

				Case 3
					grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.MistyRose
				Case 4
					grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.LightPink
				Case 5
					'grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.LightPink
					grdInvoiceList.Item("Status", i).Style.ForeColor = Color.Blue
					grdInvoiceList.Item("Status", i).Style.Font = New Font(grdInvoiceList.Font, FontStyle.Underline)
			End Select
			''
		Next
	End Sub

	Private Sub CalculateTotal()
		''
		If blnLoading Then Exit Sub
		Dim dv As DataView = dsData.Tables("vwInvoiceList").DefaultView
		Dim drv As DataRowView
		Dim gt As Double
		Dim gtCurr2 As Double
		''
		For Each drv In dv
			If drv("Total") Is DBNull.Value Then
				drv("Total") = 0
			End If
			If drv("TotalCurr2") Is DBNull.Value Then
				drv("TotalCurr2") = 0
			End If
			gt += drv("Total")
			gtCurr2 += drv("TotalCurr2")
		Next
		'txtTotal.Text = gt.ToString("#0.##")
		'txtTotalCurr2.Text = gtCurr2.ToString("#0.##")
		''
		If gt Mod 1000 > 0 Then
			gt = (gt - (gt Mod 1000)) + 1000
		Else
			gt = gt
		End If
		''
		txtTotal.Text = gt.ToString("#,###.##")
		txtTotalCurr2.Text = gtCurr2.ToString("#,###.##")
	End Sub

	Private Sub InvoiceList()
		''
		'If grdInvoiceList.Rows.Count = 0 Then Exit Sub
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		''
		'Dim frm As New frmQuickReport
		Dim rpt As Object
		''
		If rdbLBP.Checked Then
			''
			rpt = New rptInvoiceList2
		ElseIf rdbUSD.Checked Then
			''
			rpt = New rptInvoiceListCurr2
		Else
			''
			rpt = New rptInvoiceListTwoCurr
		End If
		''
		Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
		Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
		''
		For Each tbCurrent In rpt.Database.Tables
			tliCurrent = tbCurrent.LogOnInfo
			''
			With tliCurrent.ConnectionInfo
				.ServerName = gStrServerName
				.DatabaseName = gStrDataBaseName
				.UserID = ""
				.Password = ""
			End With
			''
			tbCurrent.ApplyLogOnInfo(tliCurrent)
		Next tbCurrent
		''
		Dim strFilter As String = InvoiceFilterStringList()
		Me.crvReport.SelectionFormula = strFilter
		''
		rpt.SetParameterValue("Quarter", strQuarter)
		rpt.SetParameterValue("DateFrom", dtpDateFrom.Value.ToString("yyyy-M-d"))
		rpt.SetParameterValue("DateTo", dtpDateTo.Value.ToString("yyyy-M-d"))
		''
		Me.crvReport.ReportSource = rpt
		Me.crvReport.Refresh()
		Me.crvReport.Show()
		''
		Me.crvReport.DisplayToolbar = True
		Windows.Forms.Cursor.Current = Cursors.Default()
	End Sub

	Private Function InvoiceFilterStringList()
		''
		If blnLoading Then
			Exit Function
		End If
		''
		Dim strStatus As String
		Dim strfilter As String = "True "
		''
		'If mblnPrintList = False Then
		'strfilter = " ({vwInvoiceList.InvoiceDate} >= {?DateFrom}) AND ({vwInvoiceList.InvoiceDate} <= {?DateTo})"
		'End If
		''
		strQuarter = ""
		''
		If chkQuarter1.Checked Then
			''
			's &= " AND (InvoiceDate Between  '" & Date.Now.Year & "-1-1' AND '" & Date.Now.Year & "-3-31' )"
			strfilter &= " AND (({vwInvoiceList.InvoiceDate} >= #" & Date.Now.Year & "-1-1#) AND ({vwInvoiceList.InvoiceDate} <=#" & Date.Now.Year & "-3-31# ))"
			strQuarter = " For First Quarter "
		End If
		''
		If chkQuarter2.Checked Then
			''
			If strfilter = "True " Then
				strfilter &= " AND (({vwInvoiceList.InvoiceDate} >= #" & Date.Now.Year & "-4-1#) AND ({vwInvoiceList.InvoiceDate} <=#" & Date.Now.Year & "-6-30# ))"
			Else
				strfilter &= " OR (({vwInvoiceList.InvoiceDate} >= #" & Date.Now.Year & "-4-1#) AND ({vwInvoiceList.InvoiceDate} <=#" & Date.Now.Year & "-6-30# ))"
			End If
			''
			If strQuarter = "" Then
				''
				strQuarter = "For "
			Else
				strQuarter &= " And "

			End If
			strQuarter &= "  Second Quarter "
		End If
		''
		If chkQuarter3.Checked Then
			''
			If strfilter = "True " Then
				strfilter &= " AND (({vwInvoiceList.InvoiceDate} >= #" & Date.Now.Year & "-7-1#) AND ({vwInvoiceList.InvoiceDate} <=#" & Date.Now.Year & "-9-30# ))"
				''
			Else
				strfilter &= " OR (({vwInvoiceList.InvoiceDate} >= #" & Date.Now.Year & "-7-1#) AND ({vwInvoiceList.InvoiceDate} <=#" & Date.Now.Year & "-9-30# ))"
			End If
			''
			If strQuarter = "" Then
				''
				strQuarter = "For "
			Else
				strQuarter &= " And "

			End If
			strQuarter &= "  Third Quarter "
		End If
		''
		If chkQuarter4.Checked Then
			''
			If strfilter = "True " Then
				strfilter &= " AND (({vwInvoiceList.InvoiceDate} >= #" & Date.Now.Year & "-10-1#) AND ({vwInvoiceList.InvoiceDate} <=#" & Date.Now.Year & "-12-31# ))"
			Else
				strfilter &= " OR (({vwInvoiceList.InvoiceDate} >= #" & Date.Now.Year & "-10-1#) AND ({vwInvoiceList.InvoiceDate} <=#" & Date.Now.Year & "-12-31# ))"
			End If
			''
			If strQuarter = "" Then
				''
				strQuarter = "For "
			Else
				strQuarter &= " And "

			End If
			strQuarter &= "  Fourth Quarter "
		End If
		''
		If chkQuarter1.Checked = False And chkQuarter2.Checked = False And chkQuarter3.Checked = False And chkQuarter4.Checked = False And chkOther.Checked Then
			strfilter = "({vwInvoiceList.InvoiceDate} >= #" & dtpDateFrom.Value.ToString("yyyy-M-d") & "#) AND ({vwInvoiceList.InvoiceDate} <= #" & dtpDateTo.Value.ToString("yyyy-M-d") & "#)"
			''
			strQuarter = "From " & dtpDateFrom.Value.ToString("d-M-yyyy") & "  To  " & dtpDateTo.Value.ToString("d-M-yyyy")
		Else
			strQuarter &= " For Year " & Now.Date.Year
		End If
		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				If strfilter = "" Then
					strfilter &= "   ({vwInvoiceList.InvoiceNumber} = " & tn & ")"
				Else
					strfilter &= " AND  ({vwInvoiceList.InvoiceNumber} = " & tn & ")"
				End If

			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		If cboClient.SelectedIndex <> -1 Then
			If strfilter = "" Then
				strfilter = "  ({vwInvoiceList.ClientID} = " & cboClient.SelectedValue & ")"
			Else
				strfilter &= " AND ({vwInvoiceList.ClientID} = " & cboClient.SelectedValue & ")"
			End If
		Else
			If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
				If strfilter = "" Then
					strfilter = "  ({vwInvoiceList.ClientID} = " & -1 & ")"
				Else
					strfilter &= " AND ({vwInvoiceList.ClientID} = " & -1 & ")"
				End If
			End If
		End If
		''
		If cboCategory.SelectedIndex <> -1 Then
			strfilter &= " AND ({vwInvoiceList.CatID }= " & cboCategory.SelectedValue & ")"
		Else
			If cboCategory.Text <> "" And cboCategory.SelectedIndex = -1 Then
				strfilter &= " AND ({vwInvoiceList.CatID }= " & -1 & ")"
			End If
		End If
		''
		'If cboTypeOfPreparation.Text <> String.Empty Then
		'	If cboTypeOfPreparation.Text = "Manual" Then
		'		strfilter = strfilter & " AND  ({vwInvoiceList.AutoGel }= false)"
		'	Else 'If cboTypeOfPreparation.Text = "Auto Generated" Then
		'		strfilter &= " AND  ({vwInvoiceList.AutoGel} = true)"
		'	End If
		'End If
		''
		''
		If chkPosted.Checked = False And chkNotPosted.Checked = False And chkNew.Checked = False And chkPaid.Checked = False And chkCorrected.Checked = False Then
			'' Do Nothing
		Else
			''
			If chkPosted.Checked = True Then
				strStatus = " ( {vwInvoiceList.StatusID}=" & 2
			End If
			''
			If chkNotPosted.Checked = True Then
				If strStatus = "" Then
					strStatus = " ( {vwInvoiceList.StatusID}=" & 3
				Else
					strStatus = strStatus & " OR {vwInvoiceList.StatusID}=" & 3
				End If
			End If
			''
			If chkNew.Checked = True Then
				If strStatus = "" Then
					strStatus = " ( {vwInvoiceList.StatusID}=" & 1
				Else
					strStatus = strStatus & " OR {vwInvoiceList.StatusID}=" & 1
				End If
			End If
			''
			If chkPaid.Checked = True Then
				If strStatus = "" Then
					strStatus = " ( {vwInvoiceList.StatusID}=" & 4
				Else
					strStatus = strStatus & " OR {vwInvoiceList.StatusID}=" & 4
				End If
			End If
			''
			If chkCorrected.Checked = True Then
				If strStatus = "" Then
					strStatus = " ( {vwInvoiceList.StatusID}=" & 5
				Else
					strStatus = strStatus & " OR {vwInvoiceList.StatusID}=" & 5
				End If
			End If
			''
			If strStatus <> "" And Not (strStatus.EndsWith(")")) Then
				strStatus = strStatus & " )"
			End If
			''
		End If
		''
		If strfilter <> "" And strStatus <> "" Then

			strfilter = strfilter & " AND" & strStatus
		Else
			strfilter = strfilter & strStatus
		End If
		''
		Return strfilter
	End Function


	Private Sub setcontrols(ByVal pblnstatus As Boolean)
		''
		lblDateFrom.Visible = pblnstatus
		lblDateTo.Visible = pblnstatus
		dtpDateFrom.Visible = pblnstatus
		dtpDateTo.Visible = pblnstatus
	End Sub

	Private Sub Invoice()
		''
		If grdInvoiceList.Rows.Count = 0 Then Exit Sub
		''
		Dim rpt As Object
		Dim intCounter As Integer
		''
		If cboCategory.Text = "����� ������" Then
			'if 
			rpt = New RptContractInvoice
		ElseIf cboCategory.Text = "��� ��� ��������" Then
			rpt = New rptInvestmentInvoice
		Else
			rpt = New rptInvoice
		End If
		''
		'For intCounter = 0 To grdInvoiceList.Rows.Count - 1
		'	If grdInvoiceList.Item("CatType", intCounter).Value = "Contract" Then
		'		rpt = New RptContractInvoice
		'		rpt.SetParameterValue("Total", grdInvoiceList.Item("Total", intCounter).Value)
		'		rpt.SetParameterValue("TotalCurr2", grdInvoiceList.Item("TotalCurr2", intCounter).Value)
		'	Else
		'		rpt = New rptInvoice
		'	End If

		'Next


		ClearTableTafkeet()
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		'Dim rpt As New rptInvoice
		Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table

		Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
		''
		For Each tbCurrent In rpt.Database.Tables
			tliCurrent = tbCurrent.LogOnInfo
			''
			With tliCurrent.ConnectionInfo
				.ServerName = gStrServerName
				.DatabaseName = gStrDataBaseName
				.UserID = "" 'gStrUserName
				.Password = ""	'gStrPassword
			End With

			tbCurrent.ApplyLogOnInfo(tliCurrent)
		Next tbCurrent
		'frm.crvInstantViewer.SelectionFormula = "{vwInvoiceRpt.ClientName}=" & cboClient.SelectedText
		rpt.SetParameterValue("InvoiceFrom", dtpDateFrom.Value)
		rpt.SetParameterValue("InvoiceTo", dtpDateTo.Value)
		rpt.SetParameterValue("CurrSybl1", GetCompanyCurrencySymbol())
		rpt.SetParameterValue("CurrSybl2", GetCompanyCurrencySymbol2())
		rpt.SetParameterValue("DateFrom", Format(dtpDateFrom.Value, "MMMM"))

		''
		Dim dv As DataView = dsData.Tables("vwInvoicelist").DefaultView
		Dim drv As DataRowView
		For Each drv In dv


			Dim dRdr As SqlClient.SqlDataReader
			Dim cmdX As SqlClient.SqlCommand
			'If cboCategory.SelectedValue = 5 Then
			'	'rpt.SetParameterValue("Total", grdInvoiceList.Item("Total", intCounter).Value)
			'	'rpt.SetParameterValue("TotalCurr2", grdInvoiceList.Item("TotalCurr2", intCounter).Value)
			'	'rpt.SetParameterValue("Total", txtTotal.Text)
			'	'rpt.SetParameterValue("TotalCurr2", txtTotalCurr2.Text)
			'	rpt.SetParameterValue("Total", grdInvoiceList.Item("Total", intCounter).Value)
			'	rpt.SetParameterValue("TotalCurr2", grdInvoiceList.Item("TotalCurr2", intCounter).Value)
			'End If
			''
			Dim strUnitName As String
			Dim strPartUnitName As String
			Dim strSymbol As String
			Dim strUnitNameEn As String
			Dim strPartUnitNameEn As String
			Dim strSymbolEn As String
			''
			strSQL = "select *   FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID
			''
			'strSQL = "select *   FROM  dbo.tblCurrency INNER JOIN dbo.tblCompany ON dbo.tblCurrency.CurrID = dbo.tblCompany.CurrID WHERE dbo.tblCompany.companyID=  " & gIntCompanyCurrID
			''
			cmdX = New SqlClient.SqlCommand(strSQL, conSql)
			cmdX.CommandType = CommandType.Text

			conSql.Open()
			dRdr = cmdX.ExecuteReader()
			If dRdr.Read Then
				strUnitName = dRdr("UnitName")
				strPartUnitName = dRdr("PartUnitName")
				strSymbol = dRdr("Symbol")
			End If
			dRdr.Close()
			conSql.Close()

			strSQL = "select *   FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID2
			''
			cmdX = New SqlClient.SqlCommand(strSQL, conSql)
			cmdX.CommandType = CommandType.Text

			conSql.Open()
			dRdr = cmdX.ExecuteReader()
			If dRdr.Read Then
				strUnitNameEn = dRdr("UnitName")
				strPartUnitNameEn = dRdr("PartUnitName")
				strSymbolEn = dRdr("Symbol")
			End If
			dRdr.Close()
			conSql.Close()

			''
			Dim strWord As String
			Dim strWordEn As String

			'strWord = ToWords(JobCards.Current()("Total"), strUnitName, strPartUnitName)
			'rpt.DataDefinition.FormulaFields.("TotalCurrSybl1", strWord)
			'rpt.DataDefinition.FormulaFields("TotalCurrSybl1", strWord)
			''
			If (drv("Total") Mod 1000) > 0 Then
				drv("Total") = (drv("Total") - (drv("Total") Mod 1000)) + 1000
			End If
			''
			strWord = ToWords(drv("Total"), strUnitName, strPartUnitName)
			' drv("TotalCurr2") = Double.Parse(drv("TotalCurr2")).ToString("#,###.##")
			''
			'If (drv("TotalCurr2") Mod 1) > 0 Then
			'	drv("TotalCurr2") = (drv("TotalCurr2") - (drv("TotalCurr2") Mod 1)) + 1
			'End If
			''
			strWordEn = ToWordsEn(drv("TotalCurr2"), strUnitNameEn, strPartUnitNameEn)
			''
			Dim drNew As DataRow = dsData.Tables("tblTafkeet").NewRow
			drNew("Tafkeet") = strWord
			drNew("TafkeetEn") = strWordEn
			drNew("InvoiceID") = drv("InvoiceID")
			dsData.Tables("tblTafkeet").Rows.Add(drNew)
			daTafkeet.Update(dsData, "tblTafkeet")
			'rpt.SetParameterValue("Words", strWord)
		Next
		Dim strFilter As String = InvoiceFilterString()
		Me.crvReport.SelectionFormula = strFilter
		''
		Me.crvReport.ReportSource = rpt
		Me.crvReport.Refresh()
		Me.crvReport.Show()
		''
		Me.crvReport.DisplayToolbar = True
		Windows.Forms.Cursor.Current = Cursors.Default()
	End Sub

	Private Sub ClearTableTafkeet()
		Dim cmd As New SqlClient.SqlCommand("Delete from tblTafkeet", conSql)
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()
		dsData.Tables("tblTafkeet").Rows.Clear()

	End Sub

	Private Function InvoiceFilterString()
		''
		If blnLoading Then
			Exit Function
		End If
		''
		Dim strStatus As String
		Dim strfilter As String = "" '""" True"
		''
		strfilter = " ({vwInvoiceRpt.InvoiceDate} >= {?InvoiceFrom}) AND ({vwInvoiceRpt.InvoiceDate} <= {?InvoiceTo})"

		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				If strfilter = "" Then
					strfilter &= "   ({vwInvoiceRpt.InvoiceNumber} = " & tn & ")"
				Else
					strfilter &= " AND  ({vwInvoiceRpt.InvoiceNumber} = " & tn & ")"
				End If

			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		If cboClient.SelectedIndex <> -1 Then
			If strfilter = "" Then
				strfilter = "  ({vwInvoiceRpt.ClientID} = " & cboClient.SelectedValue & ")"
			Else
				strfilter &= " AND ({vwInvoiceRpt.ClientID} = " & cboClient.SelectedValue & ")"
			End If
		Else
			If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
				If strfilter = "" Then
					strfilter = "  ({vwInvoiceRpt.ClientID} = " & -1 & ")"
				Else
					strfilter &= " AND ({vwInvoiceRpt.ClientID} = " & -1 & ")"
				End If
			End If
		End If
		''
		If cboCategory.SelectedIndex <> -1 Then
			strfilter &= " AND ({vwInvoiceRpt.CatID }= " & cboCategory.SelectedValue & ")"
		Else
			If cboCategory.Text <> "" And cboCategory.SelectedIndex = -1 Then
				strfilter &= " AND ({vwInvoiceRpt.CatID }= " & -1 & ")"
			End If
		End If
		''
		'If cboTypeOfPreparation.Text <> String.Empty Then
		'	If cboTypeOfPreparation.Text = "Manual" Then
		'		strfilter = strfilter & " AND  ({vwInvoiceRpt.AutoGel }= false)"
		'	Else 'If cboTypeOfPreparation.Text = "Auto Generated" Then
		'		strfilter &= " AND  ({vwInvoiceRpt.AutoGel} = true)"
		'	End If
		'End If
		''
		''
		If chkPosted.Checked = False And chkNotPosted.Checked = False And chkNew.Checked = False And chkPaid.Checked = False And chkCorrected.Checked = False Then
			'' Do Nothing
		Else
			''
			If chkPosted.Checked = True Then
				strStatus = " ( {vwInvoiceRpt.StatusID}=" & 2
			End If
			''
			If chkNotPosted.Checked = True Then
				If strStatus = "" Then
					strStatus = " ( {vwInvoiceRpt.StatusID}=" & 3
				Else
					strStatus = strStatus & " OR {vwInvoiceRpt.StatusID}=" & 3
				End If
			End If
			''
			If chkNew.Checked = True Then
				If strStatus = "" Then
					strStatus = " ( {vwInvoiceRpt.StatusID}=" & 1
				Else
					strStatus = strStatus & " OR {vwInvoiceRpt.StatusID}=" & 1
				End If
			End If
			''
			If chkPaid.Checked = True Then
				If strStatus = "" Then
					strStatus = " ( {vwInvoiceRpt.StatusID}=" & 4
				Else
					strStatus = strStatus & " OR {vwInvoiceRpt.StatusID}=" & 4
				End If
			End If
			''
			If chkCorrected.Checked = True Then
				If strStatus = "" Then
					strStatus = " ( {vwInvoiceRpt.StatusID}=" & 5
				Else
					strStatus = strStatus & " OR {vwInvoiceRpt.StatusID}=" & 5
				End If
			End If
			''
			If strStatus <> "" And Not (strStatus.EndsWith(")")) Then
				strStatus = strStatus & " )"
			End If
			''
		End If
		''
		If strfilter <> "" And strStatus <> "" Then

			strfilter = strfilter & " AND" & strStatus
		Else
			strfilter = strfilter & strStatus
		End If
		''
		Return strfilter
	End Function


#End Region


End Class