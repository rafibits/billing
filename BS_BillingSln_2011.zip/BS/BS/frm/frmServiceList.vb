Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmServiceList

#Region " Form Declaration  .  .  . "
   ''
   Dim clsMr As ClsMain
   Dim dsData As New DataSet
   Private WithEvents Nav As BitsNav
   Dim blnLoading As Boolean = False
   Dim daService As New SqlClient.SqlDataAdapter
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Sevice List\Settings"
   Private mstrCurrentGridName As String
   Private dataChange As Boolean
   ''
#End Region


#Region " Form Initialization . . . "

   Private Sub frmServiceList_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
      ''
      SaveProfile(mStrSubKeyName, Me.grdServiceList)
    End Sub

    Private Sub frmServiceList_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

   Private Sub frmServiceList_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
      ''
      clsMr = New ClsMain(conSql)
      Nav = New BitsNav
      ''
      blnLoading = True

      MakeDataAdapter()
      FillComboBox()
      ''
      DrawGrid()
      ''
      blnLoading = False

      FilterGrid()
      cboCode.SelectedIndex = -1
      cboServiceName.SelectedIndex = -1
      cboCategory.SelectedIndex = -1
      cboSubCategory.SelectedIndex = -1
      ''
   End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

#End Region


#Region " Form Functions   .   .   ."

   Private Sub MakeDataAdapter()
      ''
      clsMr.BuildSqlAdapter("SELECT * FROM vwGetService WHERE Del = 0", "vwGetService")
      clsMr.BuildSqlAdapter("SELECT * FROM tblService WHERE Del = 0", "tblServiceCode")
      clsMr.BuildSqlAdapter("SELECT * FROM tblService WHERE Del = 0", "tblServiceName")
      clsMr.BuildSqlAdapter("SELECT * FROM tblServiceCategory WHERE Del = 0", "tblServiceCategory")
      clsMr.BuildSqlAdapter("SELECT * FROM tblServiceSubCategory WHERE Del = 0", "tblServiceSubCategory")
      dsData = clsMr.getDataSet
      ''
   End Sub

   Private Sub FillComboBox()
      ''
      clsMr.FillComboBox("tblServiceCode", cboCode, "ServiceCode", "ServiceID")
      clsMr.FillComboBox("tblServiceName", cboServiceName, "ServiceName", "ServiceID")
      clsMr.FillComboBox("tblServiceCategory", cboCategory, "CatType", "CatID")
      clsMr.FillComboBox("tblServiceSubCategory", cboSubCategory, "SubCatType", "SubCatID")
      ''
   End Sub

   Private Sub setState(ByRef pStrMode As String)
      ''
      Dim mStrCurrentState As String
      mStrCurrentState = UCase(pStrMode)
      '' 
      Select Case mStrCurrentState

         Case Is = "NEW"
            grpFilter.Enabled = False
            btnNew.Enabled = False

         Case Is = "SAVE"
            grpFilter.Enabled = True
            btnNew.Enabled = True

         Case Is = "CANCEL"
            grpFilter.Enabled = True
            btnNew.Enabled = True
            cboCode.SelectedIndex = -1
            cboServiceName.SelectedIndex = -1
            cboCategory.SelectedIndex = -1
            cboSubCategory.SelectedIndex = -1
        End Select
        ''
        DGCA.LoadPermissionsSetState(Me, Me.Name)
    End Sub

   Private Sub DrawGrid()
      ''
      With grdServiceList
         .DataSource = dsData.Tables("vwGetService").DefaultView
         dsData.Tables("vwGetService").DefaultView.AllowNew = False
         .Columns("ServiceCode").HeaderText = "Code"
         .Columns("ServiceName").HeaderText = "Name"
         .Columns("CatType").HeaderText = "Category"
         .Columns("SubCatType").HeaderText = "Sub Category"
         .Columns("ServiceType").HeaderText = "Type"

         .Columns("ServiceID").Visible = False
         .Columns("CompanyID").Visible = False
         .Columns("ServiceCatID").Visible = False
         .Columns("ServiceSubCatID").Visible = False
         .Columns("ServiceTypeID").Visible = False
         .Columns("Del").Visible = False
         .ReadOnly = True
         .ColumnHeadersHeight = btnShowCol.Height + 2
         .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
      End With
      ''
      LoadProfile(mStrSubKeyName, Me.grdServiceList)
      RemoveGrdListItems()
      ''
   End Sub

   Private Sub Save()
      ''
      Nav.EndCurrentEdit()
      daService.Update(dsData, "vwGetService")
      ''
   End Sub

   Private Sub RemoveGrdListItems()
      ''
      chkLstGridCol.Items.Remove("ServiceID")
      chkLstGridCol.Items.Remove("CompanyID")
      chkLstGridCol.Items.Remove("ServiceCatID")
      chkLstGridCol.Items.Remove("ServiceSubCatID")
      chkLstGridCol.Items.Remove("ServiceTypeID")
      chkLstGridCol.Items.Remove("Del")
      ''
   End Sub

   Private Sub FilterGrid()
      ''
      If blnLoading Then Exit Sub
      Dim s As String = "True"
      ''

      If cboCode.SelectedIndex <> -1 Then
         s = s & " AND (ServiceID=" & cboCode.SelectedValue & ")"
      Else
         If cboCode.Text <> "" Then
            s = s & " AND (ServiceID= " & -1 & ")"
         End If
      End If
      ''

      ''
      If cboServiceName.SelectedIndex <> -1 Then
         s = s & " AND ServiceID = " & cboServiceName.SelectedValue
      Else
         If cboServiceName.Text <> "" Then
            s = s & " AND ServiceID=-1"
         End If
      End If
      ''

      If cboCategory.SelectedIndex <> -1 Then
         s = s & " AND ServiceCatID = " & cboCategory.SelectedValue
      Else
         If cboCategory.Text <> "" Then
            s = s & " AND ServiceCatID=-1"
         End If
      End If
      ''

      If cboSubCategory.SelectedIndex <> -1 Then
         s = s & " AND ServiceSubCatID = " & cboSubCategory.SelectedValue
      Else
         If cboSubCategory.Text <> "" Then
            s = s & " AND ServiceSubCatID=-1"
         End If
      End If
      ''
      dsData.Tables("vwGetService").DefaultView.RowFilter = s
      ''
   End Sub

   Private Sub RefreshService(ByVal sender As Object, ByVal e As System.EventArgs)
      ''
      dsData.Tables("vwGetService").Rows.Clear()
      clsMr.BuildSqlAdapter("SELECT * FROM vwGetService WHERE Del = 0", "vwGetService")
      ''
   End Sub

   Private Function ServiceUsed() As Boolean
      ''
      ' check if the service is already in use in some invoice

      Dim sqlCommand As New SqlCommand("Select ServiceID,InvoiceID, Del from tblInvoiceDetail where Del = 0 AND ServiceID=" & "'" & grdServiceList.Item("ServiceID", grdServiceList.CurrentRow.Index).Value & "'", conSql)
      Dim drRead As SqlDataReader
      ''
      Try
         conSql.Open()
         drRead = sqlCommand.ExecuteReader()

         While drRead.Read
            conSql.Close()
            drRead.Close()
            Return True
         End While

      Catch ex As Exception
      End Try
      ''
      conSql.Close()
      drRead.Close()
      Return False
      ''
   End Function

#End Region


#Region " UI - Events     .    .   ."

   Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
      ''
      If dataChange Then
         ''
         Dim res As MsgBoxResult
         res = MsgBox("Do you want to save changes?", MsgBoxStyle.YesNoCancel)
         ''
         Select Case res

            Case MsgBoxResult.Yes
               Me.Close()

            Case MsgBoxResult.No
               Nav.CancelCurrentEdit()
               Me.Close()

            Case MsgBoxResult.Cancel
               grdServiceList.ReadOnly = True
               Exit Sub

         End Select
      End If
      Me.Close()
      ''
   End Sub

   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      ''
      If dataChange = True Then
         If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Nav.CancelCurrentEdit()
            dsData.Tables("vwGetService").DefaultView.AllowNew = False
            btnEdit.Text = "Edit"
            btnNew.Enabled = True
            grdServiceList.ReadOnly = True
            dataChange = False
         End If
      End If
      ''
   End Sub

   Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
      ''
      Dim frm As New frmService(-1)
      appMain.addTabPage(frm, frmApplicationMain.eFormType.Service)
      AddHandler frm.Closed, AddressOf RefreshService
      ''
   End Sub

   Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
      ''
      If Me.grpShowHideColumns.Visible = False Then
         Me.grpShowHideColumns.Visible = True
         Me.grpShowHideColumns.BringToFront()
         mstrCurrentGridName = "ServiceList"
         ''
         '' populate list with grid's dataSource fields...
         ''
         Dim col As Windows.Forms.DataGridViewColumn
         ''
         Me.chkLstGridCol.Items.Clear()
         For Each col In grdServiceList.Columns
            Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
         Next
         RemoveGrdListItems()
      Else
         Me.grpShowHideColumns.Visible = False
         Me.grpShowHideColumns.SendToBack()
      End If

      ''
   End Sub

   Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
      ''
      Dim i As Integer

      For i = 0 To Me.chkLstGridCol.Items.Count - 1
         Me.grdServiceList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
      Next
      ''
      Me.grpShowHideColumns.Visible = False
      ''
   End Sub
  
   Private Sub cboCode_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCode.SelectedIndexChanged
      ''
      If blnLoading = True Then Exit Sub
      FilterGrid()
      ''
   End Sub

   Private Sub cboCategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCategory.SelectedIndexChanged
      ''
      If blnLoading = True Then Exit Sub
      If cboCategory.Text <> String.Empty Then
         dsData.Tables("tblServiceSubCategory").DefaultView.RowFilter = "CatID=" & cboCategory.SelectedValue
         cboSubCategory.SelectedIndex = -1
      End If

      FilterGrid()
      ''
   End Sub

   Private Sub cboSubCategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboSubCategory.SelectedIndexChanged
      ''
      If blnLoading = True Then Exit Sub
      FilterGrid()
      ''
   End Sub

   Private Sub cboServiceName_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboServiceName.SelectedIndexChanged
      ''
      If blnLoading = True Then Exit Sub
      FilterGrid()
      ''
   End Sub

   Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
      ''
      If grdServiceList.Rows.Count = 0 Then Exit Sub
      ''
      Dim frm As New frmService(grdServiceList.Item("ServiceID", grdServiceList.CurrentRow.Index).Value)
      appMain.addTabPage(frm, frmApplicationMain.eFormType.Service)
      AddHandler frm.Closed, AddressOf RefreshService
      ''
   End Sub

   Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
      ''
      If grdServiceList.Rows.Count = 0 Then Exit Sub
      ''

      Dim response As MsgBoxResult
      response = MsgBox("Are you sure you want to delete?", MsgBoxStyle.YesNo, "BitSolution")

      If response = MsgBoxResult.Yes Then
         Try
            Dim cmd As New SqlClient.SqlCommand("UPDATE tblService SET Del=1 WHERE ServiceID=" & grdServiceList.Item("ServiceID", grdServiceList.CurrentRow.Index).Value, conSql)
            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()
            grdServiceList.Item("Del", grdServiceList.CurrentRow.Index).Value = 1
            dsData.Tables("vwGetService").DefaultView(grdServiceList.CurrentRow.Index).Delete()

         Catch ex As Exception
            conSql.Close()
         End Try
      End If

      ''
   End Sub

   Private Sub cboCode_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboCode.KeyUp
      ''
      FilterGrid()
      ''
   End Sub

   Private Sub cboServiceName_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboServiceName.KeyUp
      ''
      FilterGrid()
      ''
   End Sub

   Private Sub cboCategory_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboCategory.KeyUp
      ''
      FilterGrid()
      ''
   End Sub

   Private Sub cboSubCategory_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboSubCategory.KeyUp
      ''
      FilterGrid()
      ''
   End Sub

   Private Sub cboCode_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboCode.KeyPress
      ''
      AutoComplete(cboCode, e)
      ''
   End Sub

   Private Sub cboServiceName_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboServiceName.KeyPress
      ''
      AutoComplete(cboServiceName, e)
      ''
   End Sub

   Private Sub cboCategory_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboCategory.KeyPress
      ''
      AutoComplete(cboCategory, e)
      ''
   End Sub

   Private Sub cboSubCategory_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboSubCategory.KeyPress
      ''
      AutoComplete(cboSubCategory, e)
      ''
   End Sub

   Private Sub grdServiceList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grdServiceList.Click

      If ServiceUsed() Then
         btnDelete.Enabled = False
      Else
         btnDelete.Enabled = True
      End If

   End Sub

    Private Sub grdServiceList_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdServiceList.CellDoubleClick
        ''
        If grdServiceList.Rows.Count = 0 Then Exit Sub
        ''
        Dim frm As New frmService(grdServiceList.Item("ServiceID", grdServiceList.CurrentRow.Index).Value)
        appMain.addTabPage(frm, frmApplicationMain.eFormType.Service)
        AddHandler frm.Closed, AddressOf RefreshService
    End Sub

#End Region


End Class