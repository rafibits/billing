Imports BITSConn
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Public Class frmEmployeeV1

#Region "Form-Declaration"
	Private dsdata As DataSet
	Private clsMr As ClsMain
	Private WithEvents Nav As BitsNav
   Private daEmployee As SqlDataAdapter
	Private daAddress As SqlDataAdapter
	Private blnLoading As Boolean	  '' Used to flag when loading form (T/F)...
	Private AddMode As Boolean
   Private AddressAddMode As Boolean
   Dim mStrTableName As String = "tblEmployee"
	'' Var for Registry Usage...
   Private mStrSubKeyName As String = "Software\BIT Solutions\PDS\Settings\Employee"
   Private mStrSubKeyNameAdd As String = "Software\BIT Solutions\PDS\Settings\Employee\Address"
	Private mstrCurrentGridName As String
   Private mStrCurrentState As String
   Private mstrCurrentGridNameAdd As String
	Dim dataChange As Boolean = False
	Private mDeptID As Integer = -1

#End Region

#Region "Form-Initialisation"
	Public Sub MakeDataAdapter()
		''
		'' set SQL for selecting active emp recs...
      strSQL = "SELECT * FROM tblEmployee "

      strSQL = strSQL & "WHERE ((Del=0)And(BranchID =" & gIntBranchID & ")) "

      daEmployee = clsMr.BuildSqlAdapter(strSQL, mStrTableName)

		''List Of Employees
		If mDeptID <> -1 Then

			clsMr.BuildSqlAdapter("SELECT * From vwEmployeeList where Del =0 AND DptID=" & mDeptID & " And (BranchID=" & gIntBranchID & ")", "EmployeeList")

		Else
			clsMr.BuildSqlAdapter("SELECT * From vwEmployeeList where Del =0 AND DptID=" & gIntDepartment & " And (BranchID=" & gIntBranchID & ")", "EmployeeList")

		End If

      '' List of Employee Titles...
      clsMr.BuildSqlAdapter("SELECT * FROM tblEmployeeTitle WHERE Del=0", "tblEmployeeTitle")

		''
		clsMr.BuildSqlAdapter("Select EmployeeID,(FName+' '+ISNULL(MName,N'')+' '+LName) AS FullName from tblEmployee where del =0", "FullName")

		'' List of Employee Pay Periods...
		clsMr.BuildSqlAdapter("SELECT * FROM tblEmployeePayPeriod WHERE Del=0", "tblEmployeePayPeriod")
		''
		'' List of User Levels...
		clsMr.BuildSqlAdapter("SELECT * FROM tblUserLevel WHERE Del=0", "UserLevel")
		''
		'' List of City Of Birth...
		clsMr.BuildSqlAdapter("SELECT * FROM tblAddCity WHERE del =0", "CityOfBirth")

      '' List of Streets...
      clsMr.BuildSqlAdapter("SELECT * FROM tblAddStreet WHERE del=0", "Street")
		
      ''List of Currency...
      clsMr.BuildSqlAdapter("SELECT * FROM tblCurrency WHERE del =0", "tblCurrency")

      clsMr.BuildSqlAdapter("Select * from tblDepartment where del=0", "tblDepartment")
		''
		
      ''List Of tbls Respect To Address...
      clsMr.BuildSqlAdapter("SELECT CityID,City_en,Del,StateID FROM tblAddCity WHERE del =0", "City")

      clsMr.BuildSqlAdapter("SELECT StreetID,AreaID,Street_en,Del FROM tblAddStreet WHERE del=0", "Street")
     
      clsMr.BuildSqlAdapter("SELECT CityID,AreaID,Area_en,Del FROM tblAddArea WHERE del =0", "Area")

      clsMr.BuildSqlAdapter("SELECT * FROM tblAddressType ", "AddressType")

		clsMr.BuildSqlAdapter("SELECT StateID,State_en,Del FROM tblAddState WHERE del=0", "State")

      clsMr.BuildSqlAdapter("SELECT *  FROM vwAddress WHERE del =0", "vwAddress")

		daAddress = clsMr.BuildSqlAdapter("SELECT *  FROM tblAddress WHERE del =0", "tblAddress")
		clsMr.BuildSqlAdapter("SELECT *  FROM tblEmployeeType WHERE del =0", "tblEmployeeType")
		clsMr.BuildSqlAdapter("SELECT *  FROM tblEmployeeJobGrade WHERE del =0", "tblEmployeeJobGrade")

		dsdata = clsMr.getDataSet

	End Sub

	Public Sub FillComboBox()
		'' Title...
		clsMr.FillComboBox("tblEmployeeTitle", cboTitle, "Title", "TitleID")
		'' PayPeriod...
		clsMr.FillComboBox("tblEmployeePayPeriod", cboPeriod, "PayPeriod", "PayPeriodID")
		'' UserLevel...
      clsMr.FillComboBox("UserLevel", cboUserLevel, "UserLevel", "UserLevelID")

		'' CityOfBirth...
      If gStrLang = "en" Then
         clsMr.FillComboBox("city", CboCity, "City_en", "CityID")
         clsMr.FillComboBox("Street", CboStreet, "Street_en", "StreetID")

         clsMr.FillComboBox("Area", cboArea, "Area_en", "AreaID")
         clsMr.FillComboBox("State", cboState, "State_en", "StateID")
         clsMr.FillComboBox("CityOfBirth", cboPOB, "City_en", "CityID")
      Else
         clsMr.FillComboBox("city", CboCity, "City_ar", "CityID")
         clsMr.FillComboBox("Street", CboStreet, "Street_ar", "StreetID")
       
         clsMr.FillComboBox("Area", cboArea, "Area_ar", "AreaID")
         clsMr.FillComboBox("State", cboState, "State_ar", "StateID")
         clsMr.FillComboBox("CityOfBirth", cboPOB, "City_ar", "CityID")
      End If
      clsMr.FillComboBox("tblDepartment", cboDepartment, "LongName", "DptID")
		clsMr.FillComboBox("AddressType", cboAddType, "AddType", "AddTypeID")

		''Currency
		clsMr.FillComboBox("tblCurrency", cboCurrency, "Symbol", "CurrID")
		clsMr.FillComboBox("tblEmployeeType", cboEmployeeType, "EmployeeType", "EmployeeTypeID")
		clsMr.FillComboBox("tblEmployeeJobGrade", cboJobGrade, "JobGrade", "JobGradeID")
	End Sub

	Public Sub SetAutoNumber()
      clsMr.SetAutoNumber(mStrTableName, "EmployeeID")
		Dim lngMax As Long

      lngMax = clsMr.GetMaxNumber("SELECT max(EmployeeNumber) FROM tblEmployee WHERE BranchId=" & gIntBranchID) + 1
      clsMr.SetAutoNumber(mStrTableName, "EmployeeNumber", lngMax)
	End Sub

	Public Sub SetCurrencyManager()
      Nav.SetCurrency(Me, clsMr.getDataSet(), mStrTableName)
	End Sub

	Public Sub SetDataBinding()
      clsMr.BindTextBox(txtEmpID, mStrTableName, "EmployeeID")
      clsMr.BindTextBox(txtEmpNum, mStrTableName, "EmployeeNumber")
      clsMr.BindComboBox(cboDepartment, mStrTableName, "DptID")
      clsMr.BindTextBox(txtFName, mStrTableName, "FName")
      clsMr.BindTextBox(txtMName, mStrTableName, "MName")
      clsMr.BindTextBox(txtLName, mStrTableName, "LName")
      clsMr.BindComboBox(cboTitle, mStrTableName, "TitleID")
      clsMr.BindDateTimePicker(dtpStartDate, mStrTableName, "StartDate")
      clsMr.BindDateTimePicker(dtpEndDate, mStrTableName, "EndDate")
      clsMr.BindTextBox(txtTel, mStrTableName, "Tel")
      clsMr.BindTextBox(TxtCel, mStrTableName, "Cell")
      clsMr.BindTextBox(txtEmail, mStrTableName, "Email")
      clsMr.BindDateTimePicker(dtpDOB, mStrTableName, "DOB")
      clsMr.BindComboBox(cboPOB, mStrTableName, "POBID")
      clsMr.BindComboBox(cboPeriod, mStrTableName, "PayPeriodID")
      clsMr.BindTextBox(txtSalary, mStrTableName, "SalaryPP")
      clsMr.BindTextBox(txtHours, mStrTableName, "HoursPP")
      clsMr.BindTextBox(txtUserName, mStrTableName, "UserName")
		clsMr.BindTextBox(txtPassword, mStrTableName, "Password")

      clsMr.BindComboBox(cboUserLevel, mStrTableName, "UserLevelID")
		clsMr.BindComboBox(cboEmployeeType, mStrTableName, "EmployeeTypeID")
		clsMr.BindComboBox(cboJobGrade, mStrTableName, "JobGradeID")
	End Sub

	Public Sub SetDefaultValue()
      clsMr.SetDefaults(mStrTableName, "Del", 0, "BranchID", gIntBranchID, "CreateDate", Now.Date, "CreateBy", gIntUserID, "StartDate", Now.Date, "EndDate", Now.Date, "DOB", Now.Date)
	End Sub
#End Region

#Region "Form-Load"

   Private Sub frmEmployeeV1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
      SaveProfile(mStrSubKeyName, grdEmployeeList)
      SaveProfile(mstrCurrentGridNameAdd, grdViewAddress)
   End Sub
   Private Sub frmEmployee_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      clsMr = New ClsMain(conSql)
      Nav = New BitsNav
      ''
      blnLoading = True
      MakeDataAdapter()
      FillComboBox()
      SetAutoNumber()
      SetDataBinding()

      SetCurrencyManager()
      SetDefaultValue()

      DrawGrid()
      blnLoading = False
      tbEmployee.TabPages.Remove(tbNewEmployee)
      tcAddress.TabPages.Remove(tpNewAddress)

   End Sub
#End Region

#Region "frmAddress..."

   Private Sub btnNewAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewAddress.Click
      NewAddress()
      tpNewAddress.Text = "New"
   End Sub

   Private Sub btnEditAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditAddress.Click
      EditAddress()
   End Sub

  

   Private Sub NewAddress()
      ''Add tab Page if not found
      If Not tcAddress.TabPages.Contains(tpNewAddress) Then
         tcAddress.TabPages.Add(tpNewAddress)
         'tpNewAddress.Text = "New Address"
      End If

      ' tcAddress.SelectedIndex = 1
      tcAddress.SelectedTab = tpNewAddress

      ''Get Auto Number for AddressID
      Dim AddressID As Long
      Try
         Dim cmdAddressID As New SqlClient.SqlCommand("SELECT CASE WHEN MAX(AddressID) IS NULL THEN 1 ELSE MAX(AddressID)+1 END FROM tblAddress", conSql)
         conSql.Open()
         AddressID = cmdAddressID.ExecuteScalar
         conSql.Close()
      Catch ex As Exception
         conSql.Close()
      End Try

      txtAddID.Text = AddressID

      btnSaveAddress.Enabled = True
      tpNewAddress.Visible = True

      ''clear address combos
      If cboAddType.Items.Count <> 0 Then
         cboAddType.SelectedIndex = 0
      End If

      cboArea.SelectedIndex = -1
      CboCity.SelectedIndex = -1
      CboStreet.SelectedIndex = -1

      If cboState.Items.Count <> 0 Then
         cboState.SelectedIndex = 0
      End If

   
      cboArea.Text = ""
      CboCity.Text = ""
      CboStreet.Text = ""
     
      btnSaveAddress.Enabled = True
      AddressAddMode = True
   End Sub

   Private Function CheckAddressValues() As Boolean
      strMsg = ""

      If cboAddType.Text = "" Then
         strMsg = "Please insert AddressType " & vbCrLf
      End If

      If CboCity.Text = "" Then
         strMsg = strMsg & "Please enter City  " & vbCrLf
      End If
      If CboStreet.Text = "" Then
         strMsg = strMsg & "Please enter  Street  " & vbCrLf
      End If
      If strMsg <> "" Then
         strMsg = "The following value(s) is/are not valid: " & vbCrLf & strMsg
         'MsgBox(strMsg)
         Return False
      Else
         Return True
      End If

   End Function
   Private Sub SaveAddress()
      If CheckAddressValues() = False Then Exit Sub

      If lstDataErr.Items.Count <> 0 Then
         MsgBox("Cannot save. Please check error list")
         Exit Sub
      Else
         Save()
      End If
      If AddressAddMode = True Then
         dsData.Tables("vwAddress").DefaultView.AllowNew = True
         ''adding new Address
         Dim drAddress As DataRow
         Dim drNew As DataRow

         ''add new row
         drAddress = dsdata.Tables("vwAddress").NewRow
         drNew = dsData.Tables("tblAddress").NewRow

         drAddress("EmployeeID") = txtEmpID.Text
         drNew("EmpID") = txtEmpID.Text
         ''add values to fields
         UpdateAddressDataRow(drAddress)
         UpdateAddressDataRow(drNew)

         drAddress("AddType") = cboAddType.Text
         drAddress("State_en") = cboState.Text
         ' drAddress("Region_en") = cboRegion.Text
         ' drAddress("Qadaa_en") = cboQadaa.Text
         drAddress("City_en") = CboCity.Text
         drAddress("Area_en") = cboArea.Text
         drAddress("Street_en") = CboStreet.Text

         drAddress("Del") = 0
         drNew("Del") = 0
         ''add the created row
         dsData.Tables("vwAddress").Rows.Add(drAddress)
         drAddress.EndEdit()
         dsData.Tables("tblAddress").Rows.Add(drNew)
         clsMr.Update(daAddress, "tblAddress")

         dsData.Tables("vwAddress").DefaultView.AllowNew = False

         AddressAddMode = False
         'If AddMode Then
         '   save()
         'End If

      Else
         Dim drAddress() As DataRow
         Dim drUpdate() As DataRow
         drUpdate = dsData.Tables("tblAddress").Select("AddressID = " & txtAddID.Text)
         drAddress = dsData.Tables("vwAddress").Select("AddressID = " & txtAddID.Text)

         UpdateAddressDataRow(drAddress(0))
         UpdateAddressDataRow(drUpdate(0))
         drAddress(0)("AddType") = cboAddType.Text
         drAddress(0)("State_en") = cboState.Text
         drAddress(0)("City_en") = CboCity.Text
         drAddress(0)("Area_en") = cboArea.Text
         drAddress(0)("Street_en") = CboStreet.Text
         drAddress(0).EndEdit()
         clsMr.Update(daAddress, "tblAddress")
         dsData.Tables("vwAddress").DefaultView.AllowNew = False

      End If
      btnEditAddress.Visible = True
      tcAddress.TabPages.Remove(tpNewAddress)
   End Sub
   Private Sub UpdateAddressDataRow(ByVal pDr As DataRow)
      pDr("AddressID") = txtAddID.Text

      If cboAddType.SelectedIndex = -1 Then
         pDr("AddTypeID") = DBNull.Value
      Else
         pDr("AddTypeID") = cboAddType.SelectedValue

      End If

      If cboState.SelectedIndex = -1 Then
         pDr("StateID") = DBNull.Value
      Else
         pDr("StateID") = cboState.SelectedValue

      End If


     

      If CboCity.SelectedIndex = -1 Then
         pDr("CityID") = DBNull.Value
      Else
         pDr("CityID") = CboCity.SelectedValue

      End If

      If cboArea.SelectedIndex = -1 Then
         pDr("AreaID") = DBNull.Value
      Else
         pDr("AreaID") = cboArea.SelectedValue

      End If


      If CboStreet.SelectedIndex = -1 Then
         pDr("StreetID") = DBNull.Value
      Else
         pDr("StreetID") = CboStreet.SelectedValue


      End If

      If txtBNF.Text <> "" Then
         pDr("BNF") = txtBNF.Text & ""
      End If
   End Sub
  
   Private Sub filterCity()
      If blnLoading = True Then
         Exit Sub
      End If
     
      If cboState.Text = "" Then
         cboState.SelectedIndex = -1
         dsData.Tables("city").DefaultView.RowFilter = String.Empty
      Else
         dsData.Tables("city").DefaultView.RowFilter = " StateID =" & cboState.SelectedValue
      End If
   End Sub
   Private Sub filterAreaANDStreet()
      If blnLoading = True Then
         Exit Sub
      End If
      If CboCity.Text = "" Then
         CboCity.SelectedIndex = -1
         dsData.Tables("Area").DefaultView.RowFilter = String.Empty
         dsData.Tables("Street").DefaultView.RowFilter = String.Empty
      Else
         dsData.Tables("Area").DefaultView.RowFilter = "cityID =" & CboCity.SelectedValue
         dsdata.Tables("Street").DefaultView.RowFilter = "CityID =" & cboCity.SelectedValue
      End If

   End Sub
   Private Sub filterStreet()
      If blnLoading = True Then
         Exit Sub
      End If
      If cboArea.Text = "" Then
         cboArea.SelectedIndex = -1
         dsData.Tables("Street").DefaultView.RowFilter = String.Empty
      Else

         dsData.Tables("Street").DefaultView.RowFilter = " AreaID =" & cboArea.SelectedValue

      End If
   End Sub

   Private Sub cboState_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboState.Leave
      'chkAddNewValueInCbo(clsMr, Me.cboState, "tblAddressState", "StateID", "State_en")
   End Sub
   Private Sub cboAddType_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboAddType.Leave
      ' chkAddNewValueInCbo(clsMr, Me.cboAddType, "tblAddressType", "AddTypeID", "AddType")
   End Sub
   Private Sub cboState_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboState.SelectedIndexChanged

      filterCity()
   End Sub

   

   Private Sub cboCity_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboCity.Leave

      ' chkAddNewValueInCbo1(clsMr, Me.cboCity, Me.cboState, "tblAddCity", "CityID", "City_en", "StateID")
   End Sub

   Private Sub cboCity_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboCity.SelectedIndexChanged
      ' filterArea()
      filterAreaANDStreet()
   End Sub

   Private Sub CboArea_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboArea.SelectedIndexChanged
      filterStreet()

   End Sub

   Private Sub EditAddress()
      If grdViewAddress.Rows.Count = 0 Then
         Exit Sub
      End If
      'ItemInfoStatus(False)
      If Not tcAddress.TabPages.Contains(tpNewAddress) Then
         tcAddress.TabPages.Add(tpNewAddress)
         tpNewAddress.Text = "Edit Address"
      End If
      ' tcAddress.SelectedIndex = 1
      tcAddress.SelectedTab = tpNewAddress
      Dim drAddress As DataView
      drAddress = dsData.Tables("vwAddress").DefaultView

      txtAddID.Text = drAddress(grdViewAddress.CurrentRow.Index)("AddressID") & ""
      If Not (drAddress(grdViewAddress.CurrentRow.Index)("AddTypeID") Is DBNull.Value) Then
         cboAddType.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("AddTypeID") & ""
      Else
         cboAddType.SelectedValue = DBNull.Value
         cboAddType.SelectedIndex = -1
      End If

      If Not (drAddress(grdViewAddress.CurrentRow.Index)("StateID") Is DBNull.Value) Then
         cboState.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("StateID") & ""
      Else
         cboState.SelectedValue = DBNull.Value
         cboState.SelectedIndex = -1
      End If
     
      If Not (drAddress(grdViewAddress.CurrentRow.Index)("CityID") Is DBNull.Value) Then
         CboCity.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("CityID")
      Else
         CboCity.SelectedValue = DBNull.Value
         CboCity.SelectedIndex = -1
      End If
      If Not (drAddress(grdViewAddress.CurrentRow.Index)("AreaID") Is DBNull.Value) Then
         cboArea.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("AreaID")
      Else
         cboArea.SelectedValue = DBNull.Value
         cboArea.SelectedIndex = -1
      End If

      If Not (drAddress(grdViewAddress.CurrentRow.Index)("StreetID") Is DBNull.Value) Then
         CboStreet.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("StreetID")
      Else
         CboStreet.SelectedValue = DBNull.Value
         CboStreet.SelectedIndex = -1
      End If
      If Not (drAddress(grdViewAddress.CurrentRow.Index)("BNF") Is DBNull.Value) Then
         txtBNF.Text = drAddress(grdViewAddress.CurrentRow.Index)("BNF")
      End If
   End Sub


   Private Sub btnDeleteAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteAddress.Click

      If grdViewAddress.Rows.Count = -1 Then Exit Sub

      Dim drAddress As DataView
      drAddress = dsData.Tables("vwAddress").DefaultView

      If MsgBox(" Are you sure you want to Delete? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution") = MsgBoxResult.Yes Then

         Dim drDel() As DataRow
         drDel = dsData.Tables("tblAddress").Select("AddressID = " & drAddress(grdViewAddress.CurrentRow.Index)("AddressID"))
         If drDel.Length > 0 Then
            drDel(0).Delete()
            nav.EndCurrentEdit()
            clsMr.Update(daAddress, "tblAddress")
         End If

         dsData.Tables("vwAddress").DefaultView(grdViewAddress.CurrentRow.Index).Delete()

         If grdViewAddress.Rows.Count = 0 Then
            btnDeleteAddress.Enabled = False
         End If
      End If


   End Sub

   Private Sub btnNewAddress2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewAddress2.Click
      NewAddress()
   End Sub

   Private Sub btnSaveAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveAddress.Click
      SaveAddress()

   End Sub

   Private Sub btnCancelAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAddress.Click
      tcAddress.TabPages.Remove(tpNewAddress)
      'tcAddress.SelectedIndex = 1
      tcAddress.SelectedTab = tpViewAddress
      ' ItemInfoStatus(True)
      btnNewAddress.Enabled = True
      btnNewAddress.Enabled = True
      btnSaveAddress.Enabled = True
      'If changed = False Then
      ' dataChange = False
      'btnEdit.Enabled = False
      'End If
      'dataChangedVeh = False
   End Sub

   Private Sub cboStreet_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboStreet.Leave
      If cboArea.Text = "" And cboCity.Text = "" Then Exit Sub
      'AddStreet()
   End Sub

#End Region

#Region "Form-EmployeeList"
   Private Sub FilterList()
          
      Dim strFilter As String = "True"

      If txtFiltByNum.Text <> "" Then
         strFilter = strFilter & " AND EmployeeNumber='" & txtFiltByNum.Text & "'"
      End If
      If txtFiltByFName.Text <> "" Then
         strFilter = strFilter & " AND FName LIKE '" & txtFiltByFName.Text & "%'"
      End If
      If txtFiltByMName.Text <> "" Then
         strFilter = strFilter & " AND MName LIKE '" & txtFiltByMName.Text & "%'"
      End If
      If txtFilByLName.Text <> "" Then
         strFilter = strFilter & " AND LName LIKE '" & txtFilByLName.Text & "%'"

      End If



      If strFilter <> "" Then
         dsdata.Tables("EmployeeList").DefaultView.RowFilter = strFilter

      End If
	End Sub

	Private Sub txtFiltByNum_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFiltByNum.KeyPress
		Integers_KeyPress(txtEmpNum, e)
	End Sub
   Private Sub txtFiltByNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFiltByNum.TextChanged
      FilterList()
   End Sub

   Private Sub txtFiltByMName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFiltByMName.TextChanged
      FilterList()
   End Sub

   Private Sub txtFilByLName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFilByLName.TextChanged
      FilterList()
   End Sub

   Private Sub txtFiltByFName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFiltByFName.TextChanged
      FilterList()
   End Sub

   Private Sub btnNewEmp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewEmp.Click

      If Not tbEmployee.TabPages.Contains(tbNewEmployee) Then
         tbEmployee.TabPages.Add(tbNewEmployee)
      End If
      tbEmployee.SelectedIndex = 1

      NewRecord()
     

   End Sub
#End Region

#Region "Form-UI/Methods"


   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      If dataChange Then
         If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            Try
               Nav.CancelCurrentEdit()
            Catch ex As Exception

            End Try

            dataChange = False
            AddMode = False

         End If
      Else

         'AddMode = False
      End If




      setState("BROWSE")

   End Sub
   Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
      'MsgBox(txtEmpID.Text)
      NewRecord()

   End Sub
   Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
      If btnSave.Text = "E d i t" Then
         setState("EDIT")
         Exit Sub
      End If
      Save()
      setState("SAVE")
   End Sub
   Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClose.Click
      '' check OK to close...
      If dataChange Then
         Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
            Case MsgBoxResult.Yes
               '' call save...
               If lstDataErr.Items.Count <> 0 Then
                  MsgBox("Cannot save.Please check error list")
                  Exit Sub
               Else
                  Save()
                  tbEmployee.SelectedIndex = 0
               End If
            Case MsgBoxResult.No
               '' ignore changes...

               Try
                  Nav.CancelCurrentEdit()
               Catch ex As Exception

               End Try
               tbEmployee.SelectedIndex = 0
            Case MsgBoxResult.Cancel
               '' ignore close press..
               '' do nothing...

         End Select
      Else
         tbEmployee.SelectedIndex = 0
      End If
      RefreshEmployee()
      tcAddress.TabPages.Remove(tpNewAddress)

   End Sub
#End Region

#Region "Form-Functions"
   Private Sub setState(ByRef pStrMode As String)
      ''
      mStrCurrentState = UCase(pStrMode)
      '' 
      Select Case mStrCurrentState
         Case Is = "NEW"

            Me.btnSave.Enabled = False
            Me.btnCancel.Enabled = True
            Me.btnNew.Enabled = False
            grpEmployee.Enabled = True
            btnSave.Text = "S a v e"
          AddMode = True
         Case Is = "EDIT"

            Me.btnSave.Enabled = False
            Me.btnCancel.Enabled = True
            Me.btnNew.Enabled = False
            grpEmployee.Enabled = True
            btnSave.Text = "S a v e"

         Case Is = "SAVE"

            Me.btnSave.Enabled = True
            Me.btnCancel.Enabled = False
            Me.btnNew.Enabled = True
            btnSave.Text = "E d i t"
         
            grpEmployee.Enabled = False

            AddMode = False
         Case Is = "BROWSE"

            Me.btnSave.Enabled = True
            Me.btnCancel.Enabled = False
            Me.btnNew.Enabled = True
            btnSave.Text = "E d i t"
            grpEmployee.Enabled = False
      End Select
   End Sub
	Private Sub RefreshEmployee()

		dsdata.Tables("EmployeeList").Clear()
		If mDeptID <> -1 Then

			clsMr.BuildSqlAdapter("SELECT * From vwEmployeeList where Del =0 AND DptID=" & mDeptID & " And (BranchID=" & gIntBranchID & ")", "EmployeeList")

		Else
			clsMr.BuildSqlAdapter("SELECT * From vwEmployeeList where Del =0 AND DptID=" & gIntDepartment & " And (BranchID=" & gIntBranchID & ")", "EmployeeList")

		End If
		'	clsMr.BuildSqlAdapter("Select * From vwEmployeeList where Del= 0 ", "EmployeeList")

	End Sub
   Private Sub NewRecord()
      Nav.AddNew()
      txtFName.Focus()
      btnNew.Enabled = False
      txtFName.Focus()
      SetState("New")
		cboEmployeeType.SelectedIndex = -1
		cboJobGrade.SelectedIndex = -1
		If mDeptID = -1 Then
			cboDepartment.SelectedValue = gIntDepartment
		Else
			cboDepartment.SelectedValue = mDeptID
		End If
      FilterAddress()
   End Sub
   Private Sub FilterAddress()
      If txtEmpID.Text <> "" Then
         dsdata.Tables("vwAddress").DefaultView.RowFilter = "EmployeeID= '" & txtEmpID.Text & "'"
      End If
      If grdViewAddress.Rows.Count = 0 Then
         btnDeleteAddress.Visible = False
         btnEditAddress.Visible = False
      Else
         btnEditAddress.Visible = True
         btnDeleteAddress.Visible = True
      End If

   End Sub

   Private Sub nonVisibleFields()
      With grdEmployeeList
         .Columns("EmployeeID").Visible = False
         .Columns("BranchID").Visible = False
         .Columns("UserLevelID").Visible = False
         .Columns("PayPeriodID").Visible = False
         .Columns("POBID").Visible = False
         .Columns("DptID").Visible = False
         .Columns("TitleID").Visible = False


      End With
   End Sub

   Private Sub DrawGrid()

      ''Set Properties Of EmplpoyeeListGrid

      grdEmployeeList.DataSource = dsdata.Tables("EmployeeList").DefaultView
      With grdEmployeeList
         .ReadOnly = True
         .ColumnHeadersHeight = btnShowCol.Height + 2
         .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
      End With
      nonVisibleFields()
      LoadProfile(mStrSubKeyName, grdEmployeeList)
      LoadProfile(mStrSubKeyNameAdd, grdViewAddress)
      ''Set Properties Of EmplpoyeeAddressGrid

      grdViewAddress.DataSource = dsdata.Tables("vwAddress").DefaultView
      dsdata.Tables("vwAddress").DefaultView.AllowNew = False
      grdViewAddress.ReadOnly = True

      grdViewAddress.Columns("State_en").HeaderText = "State"
      grdViewAddress.Columns("Street_en").HeaderText = "Street"
      grdViewAddress.Columns("Area_en").HeaderText = "Area"
      grdViewAddress.Columns("City_en").HeaderText = "City"


      grdViewAddress.Columns("StateID").Visible = False
      grdViewAddress.Columns("StreetID").Visible = False
      grdViewAddress.Columns("AreaID").Visible = False
      grdViewAddress.Columns("CityID").Visible = False
      grdViewAddress.Columns("EmployeeID").Visible = False
      grdViewAddress.Columns("AddTypeID").Visible = False
      grdViewAddress.Columns("Del").Visible = False
      With grdViewAddress
         .ReadOnly = True
         .ColumnHeadersHeight = btnShowColAddress.Height + 2
         .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
      End With

   End Sub


   Public Function GetRowIndex(ByVal pEmployeeID As Long) As Integer

      Dim i As Integer

      For i = 0 To dsdata.Tables(mStrTableName).DefaultView.Count - 1
         If dsdata.Tables(mStrTableName).DefaultView.Item(i)("EmployeeID") = pEmployeeID Then
            Return i
         End If
      Next

      Return -1
   End Function

   ''Save Employee
   Private Sub Save()
      If dataChange Then
         ''Update Invoice
         Nav.EndCurrentEdit()
			clsMr.Update(daEmployee, mStrTableName)
         dataChange = False

      End If


   End Sub
#End Region

   Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click


      Dim dr As DataRow = dsdata.Tables("EmployeeList").DefaultView.Item(grdEmployeeList.CurrentRow.Index).Row
      Nav.CurrentPosition = GetRowIndex(dr("EmployeeID"))
      If Not tbEmployee.TabPages.Contains(tbNewEmployee) Then
         tbEmployee.TabPages.Add(tbNewEmployee)
      End If
      tbEmployee.SelectedIndex = 1
      FilterAddress()
      setState("BROWSE")
		dataChange = False
   End Sub

   
   Private Sub btnCloseList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseList.Click
      Me.Close()

   End Sub

#Region "CustomControl Of Address"
   Private Sub btnShowColAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowColAddress.Click
      If Me.grpShowHideColumnsAdd.Visible = False Then
         Me.grpShowHideColumnsAdd.Visible = True
         Me.grpShowHideColumnsAdd.BringToFront()
         mstrCurrentGridNameAdd = "Address"
         ''
         '' populate list with grid's dataSource fields...
         ''

         Dim col As Windows.Forms.DataGridViewColumn
         ''
         Me.chkLstGridColAdd.Items.Clear()
         For Each col In grdViewAddress.Columns
            Me.chkLstGridColAdd.Items.Add(col.HeaderText, col.Visible)
         Next
         chkLstGridColAdd.Items.Remove("StateID")
         chkLstGridColAdd.Items.Remove("StreetID")
         chkLstGridColAdd.Items.Remove("AreaID")
         chkLstGridColAdd.Items.Remove("CityID")
         chkLstGridColAdd.Items.Remove("EmployeeID")
         chkLstGridColAdd.Items.Remove("AddTypeID")
         chkLstGridColAdd.Items.Remove("Del")


      Else
         Me.grpShowHideColumnsAdd.Visible = False
         Me.grpShowHideColumnsAdd.SendToBack()
      End If
   End Sub

   Private Sub btnSaveSettingAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettingAdd.Click
      Dim i As Integer

      For i = 0 To Me.chkLstGridColAdd.Items.Count - 1
         Me.grdViewAddress.Columns(i).Visible = Me.chkLstGridColAdd.GetItemChecked(i)
      Next

      ''
      Me.grpShowHideColumnsAdd.Visible = False

   End Sub
#End Region

#Region "CustomControls"
   Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
      If Me.grpShowHideColumns.Visible = False Then
         Me.grpShowHideColumns.Visible = True
         Me.grpShowHideColumns.BringToFront()
         mstrCurrentGridName = "EmployeeList"
         ''
         '' populate list with grid's dataSource fields...
         ''

         Dim col As Windows.Forms.DataGridViewColumn
         ''
         Me.chkLstGridCol.Items.Clear()
         For Each col In grdEmployeeList.Columns
            Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
         Next
         chkLstGridCol.Items.Remove("UserLevelID")
         chkLstGridCol.Items.Remove("PayPeriodID")
         chkLstGridCol.Items.Remove("POBID")
         chkLstGridCol.Items.Remove("DepID")
         chkLstGridCol.Items.Remove("TitleID")
         chkLstGridCol.Items.Remove("EmployeeID")
         chkLstGridCol.Items.Remove("BranchID")
         chkLstGridCol.Items.Remove("ImageSign")
      Else
         Me.grpShowHideColumns.Visible = False
         Me.grpShowHideColumns.SendToBack()
      End If
   End Sub

   Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
      Dim i As Integer

      For i = 0 To Me.chkLstGridCol.Items.Count - 1
         Me.grdEmployeeList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
      Next

      ''
      Me.grpShowHideColumns.Visible = False

   End Sub
#End Region

#Region "CheckValues"
   Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
      '' Show/Hide error list...
      If lstDataErr.Visible = True Then
         lstDataErr.Visible = False
      Else
         lstDataErr.Visible = True
         lstDataErr.Height = 100
         lstDataErr.BringToFront()
      End If
   End Sub
   Private Sub checkValues()
      If blnLoading = True Then Exit Sub

      lstDataErr.Items.Clear()
      Dim intErrCount As Int16 = 0
      dataChange = True
      If txtFName.Text.Trim = String.Empty Then
         lstDataErr.Items.Add("Please Enter First Name")
         intErrCount += 1
      End If


      If txtLName.Text.Trim = String.Empty Then
         lstDataErr.Items.Add("Please Enter Last Name")
         intErrCount += 1
      End If

      If txtTel.Text.Trim = String.Empty Then
         lstDataErr.Items.Add("Please Enter Telephone Number")
         intErrCount += 1
      End If

      If cboUserLevel.SelectedIndex = -1 Then
         lstDataErr.Items.Add("Please Enter UserLevel")
         intErrCount += 1
      End If
      If txtUserName.Text = String.Empty Then
         lstDataErr.Items.Add("Please Enter User Name")
         intErrCount += 1
      End If
      If txtPassword.Text = String.Empty Then
         lstDataErr.Items.Add("Please Enter Password")
         intErrCount += 1
      End If
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '' Set appropriate controls based on errors check results...
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      If lstDataErr.Items.Count = 0 Then
         lstDataErr.Visible = False
         btnDataErr.Visible = False
         btnSave.Enabled = True
      Else
         btnDataErr.Visible = True
         btnSave.Enabled = False
      End If
      ''

   End Sub
   Private Sub txtFName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFName.TextChanged
      checkValues()
   End Sub

   Private Sub txtLName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLName.TextChanged
      checkValues()
   End Sub

   Private Sub txtTel_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTel.TextChanged
      checkValues()
   End Sub
   Private Sub txtPassword_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPassword.TextChanged
      checkValues()
   End Sub
   Private Sub txtUserName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtUserName.TextChanged
      checkValues()
   End Sub
   Private Sub cboUserLevel_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboUserLevel.SelectedIndexChanged
      checkValues()
	End Sub
	Private Sub cboEmployeeType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboEmployeeType.SelectedIndexChanged
		checkValues()
	End Sub

	Private Sub cboJobGrade_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboJobGrade.SelectedIndexChanged
		checkValues()
	End Sub
#End Region

	
	
	Public Sub New(Optional ByVal pDeptID As Integer = -1)

		' This call is required by the Windows Form Designer.
		InitializeComponent()
		mDeptID = pDeptID
		' Add any initialization after the InitializeComponent() call.

	End Sub

	Private Sub TxtCel_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCel.TextChanged
		checkValues()
	End Sub

	Private Sub txtEmail_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtEmail.TextChanged
		checkValues()
	End Sub

	Private Sub txtMName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtMName.TextChanged
		checkValues()
	End Sub

	Private Sub cboTitle_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboTitle.SelectedIndexChanged
		checkValues()
	End Sub

	Private Sub dtpStartDate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpStartDate.ValueChanged
		checkValues()
	End Sub

	Private Sub dtpEndDate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpEndDate.ValueChanged
		checkValues()
	End Sub

	Private Sub txtHours_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtHours.TextChanged
		checkValues()
	End Sub

	Private Sub txtSalary_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSalary.TextChanged
		checkValues()
	End Sub

	Private Sub cboPOB_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboPOB.SelectedIndexChanged
		checkValues()
	End Sub

	Private Sub cboCurrency_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCurrency.SelectedIndexChanged
		checkValues()
	End Sub

	Private Sub dtpDOB_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDOB.ValueChanged
		checkValues()
	End Sub

	Private Sub cboPeriod_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboPeriod.SelectedIndexChanged
		checkValues()
    End Sub

#Region "Permissions.."
    ''Done by Mohamad March, 2008''

    'First Name'
    Private Sub txtFName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtFName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Middle Name'
    Private Sub txtMName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtMName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtMName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Last Name'
    Private Sub txtLName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtLName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtLName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Salary'
    Private Sub txtSalary_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSalary.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "." Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Hours'
    Private Sub txtHours_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtHours.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "." Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Email'
    Private Sub txtEmail_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEmail.Leave
        Dim Pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim EmailAddressMatch As Match = Regex.Match(txtEmail.Text, Pattern)

        If EmailAddressMatch.Success = True Then
            'Do Nothing
        Else
            MsgBox("Invalid Email Address")
            txtEmail.Text = ""
        End If
    End Sub

    'Telephone'
    Private Sub txtTel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtTel.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Cell Phone'
    Private Sub txtCel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtCel.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

#End Region
End Class