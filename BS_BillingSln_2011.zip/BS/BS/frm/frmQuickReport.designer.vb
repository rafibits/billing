<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmQuickReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.crvInstantViewer = New CrystalDecisions.Windows.Forms.CrystalReportViewer
		Me.SuspendLayout()
		'
		'crvInstantViewer
		'
		Me.crvInstantViewer.ActiveViewIndex = -1
		Me.crvInstantViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.crvInstantViewer.DisplayGroupTree = False
		Me.crvInstantViewer.Dock = System.Windows.Forms.DockStyle.Fill
		Me.crvInstantViewer.Location = New System.Drawing.Point(0, 0)
		Me.crvInstantViewer.Name = "crvInstantViewer"
		Me.crvInstantViewer.SelectionFormula = ""
		Me.crvInstantViewer.ShowGroupTreeButton = False
		Me.crvInstantViewer.Size = New System.Drawing.Size(673, 500)
		Me.crvInstantViewer.TabIndex = 0
		Me.crvInstantViewer.ViewTimeSelectionFormula = ""
		'
		'frmQuickReport
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(673, 500)
		Me.Controls.Add(Me.crvInstantViewer)
		Me.Name = "frmQuickReport"
		Me.Text = "Print Report"
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents crvInstantViewer As CrystalDecisions.Windows.Forms.CrystalReportViewer
End Class
