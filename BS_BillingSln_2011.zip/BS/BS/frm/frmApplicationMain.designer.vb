<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmApplicationMain
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing AndAlso components IsNot Nothing Then
			components.Dispose()
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmApplicationMain))
        Me.splitContainerLeftMain = New System.Windows.Forms.SplitContainer
        Me.btnRestoreNavMenu = New BHBut.BouncingHoverButton
        Me.scMnuItemNTitle = New System.Windows.Forms.SplitContainer
        Me.btnLogo = New BHBut.BouncingHoverButton
        Me.btnHideMenu = New BHBut.BouncingHoverButton
        Me.pnlMenuAllLeft = New System.Windows.Forms.Panel
        Me.tblPnlMenu_Payment = New System.Windows.Forms.TableLayoutPanel
        Me.btnTransactions_ClearCheck = New BHBut.BouncingHoverButton
        Me.btnTransactions_Payment = New BHBut.BouncingHoverButton
        Me.tblPnlMenu_Service = New System.Windows.Forms.TableLayoutPanel
        Me.btnService_Rate = New BHBut.BouncingHoverButton
        Me.btnService_Service = New BHBut.BouncingHoverButton
        Me.tblPnlMenu_Transactions = New System.Windows.Forms.TableLayoutPanel
        Me.btnTransactions_ImportOverFlight = New BHBut.BouncingHoverButton
        Me.btnMessage = New BHBut.BouncingHoverButton
        Me.btnTransactions_Bill = New BHBut.BouncingHoverButton
        Me.btnOverFlightPrep = New BHBut.BouncingHoverButton
        Me.btnTransactions_ImportTransactions = New BHBut.BouncingHoverButton
        Me.btnTransactions_Invoice = New BHBut.BouncingHoverButton
        Me.btnAutoInvPrep = New BHBut.BouncingHoverButton
        Me.btnTransactions_OverDueInvoice = New BHBut.BouncingHoverButton
        Me.tblPnlMenu_Company = New System.Windows.Forms.TableLayoutPanel
        Me.btnCompany_Department = New BHBut.BouncingHoverButton
        Me.btnCompany_Company = New BHBut.BouncingHoverButton
        Me.btnCompany_Employee = New BHBut.BouncingHoverButton
        Me.btnCompany_Area = New BHBut.BouncingHoverButton
        Me.tblPnlMenu_Client = New System.Windows.Forms.TableLayoutPanel
        Me.btnUserPreferences = New BHBut.BouncingHoverButton
        Me.btnClient_ClientList = New BHBut.BouncingHoverButton
        Me.tblPnlMenu_Main = New System.Windows.Forms.TableLayoutPanel
        Me.btnMenuMain_Applications = New BHBut.BouncingHoverButton
        Me.btnMenuMain_Clients = New BHBut.BouncingHoverButton
        Me.btnMenuMain_Reports = New BHBut.BouncingHoverButton
        Me.btnMenuMain_Company = New BHBut.BouncingHoverButton
        Me.btnMainMenu_Services = New BHBut.BouncingHoverButton
        Me.btnMenuMain_Payment = New BHBut.BouncingHoverButton
        Me.btnCloseWindows = New System.Windows.Forms.Button
        Me.tcMain = New System.Windows.Forms.TabControl
        Me.tabVer = New System.Windows.Forms.TabPage
        Me.lblVersinDate = New System.Windows.Forms.Label
        Me.lbldgca = New System.Windows.Forms.Label
        Me.pbavaitionlogo = New System.Windows.Forms.PictureBox
        Me.lblrepublic = New System.Windows.Forms.Label
        Me.lblVer = New System.Windows.Forms.Label
        Me.pblogo = New System.Windows.Forms.PictureBox
        Me.picExperiance = New System.Windows.Forms.PictureBox
        Me.Button8 = New System.Windows.Forms.Button
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.ETSMenu = New System.Windows.Forms.ToolStripMenuItem
        Me.tlSocSecRpts = New System.Windows.Forms.ToolStripMenuItem
        Me.tlTestQueue = New System.Windows.Forms.ToolStripMenuItem
        Me.msMenu = New System.Windows.Forms.MenuStrip
        Me.BranchBillingInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.tsmMainMenu = New System.Windows.Forms.ToolStripMenuItem
        Me.tsmFile = New System.Windows.Forms.ToolStripMenuItem
        Me.tsmEdit = New System.Windows.Forms.ToolStripMenuItem
        Me.tsmView = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VisitStatusQuickHelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BouncingHoverButton6 = New BHBut.BouncingHoverButton
        Me.BouncingHoverButton5 = New BHBut.BouncingHoverButton
        Me.BouncingHoverButton4 = New BHBut.BouncingHoverButton
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel
        Me.BouncingHoverButton7 = New BHBut.BouncingHoverButton
        Me.BouncingHoverButton8 = New BHBut.BouncingHoverButton
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel
        Me.BouncingHoverButton1 = New BHBut.BouncingHoverButton
        Me.BouncingHoverButton2 = New BHBut.BouncingHoverButton
        Me.BouncingHoverButton9 = New BHBut.BouncingHoverButton
        Me.BouncingHoverButton3 = New BHBut.BouncingHoverButton
        Me.splitContainerLeftMain.Panel1.SuspendLayout()
        Me.splitContainerLeftMain.Panel2.SuspendLayout()
        Me.splitContainerLeftMain.SuspendLayout()
        Me.scMnuItemNTitle.Panel1.SuspendLayout()
        Me.scMnuItemNTitle.Panel2.SuspendLayout()
        Me.scMnuItemNTitle.SuspendLayout()
        Me.pnlMenuAllLeft.SuspendLayout()
        Me.tblPnlMenu_Payment.SuspendLayout()
        Me.tblPnlMenu_Service.SuspendLayout()
        Me.tblPnlMenu_Transactions.SuspendLayout()
        Me.tblPnlMenu_Company.SuspendLayout()
        Me.tblPnlMenu_Client.SuspendLayout()
        Me.tblPnlMenu_Main.SuspendLayout()
        Me.tcMain.SuspendLayout()
        Me.tabVer.SuspendLayout()
        CType(Me.pbavaitionlogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pblogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picExperiance, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.msMenu.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'splitContainerLeftMain
        '
        Me.splitContainerLeftMain.BackColor = System.Drawing.Color.White
        Me.splitContainerLeftMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.splitContainerLeftMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.splitContainerLeftMain.ForeColor = System.Drawing.Color.Navy
        Me.splitContainerLeftMain.Location = New System.Drawing.Point(0, 24)
        Me.splitContainerLeftMain.Name = "splitContainerLeftMain"
        '
        'splitContainerLeftMain.Panel1
        '
        Me.splitContainerLeftMain.Panel1.Controls.Add(Me.btnRestoreNavMenu)
        Me.splitContainerLeftMain.Panel1.Controls.Add(Me.scMnuItemNTitle)
        Me.splitContainerLeftMain.Panel1.Controls.Add(Me.tblPnlMenu_Main)
        '
        'splitContainerLeftMain.Panel2
        '
        Me.splitContainerLeftMain.Panel2.BackColor = System.Drawing.Color.AliceBlue
        Me.splitContainerLeftMain.Panel2.Controls.Add(Me.btnCloseWindows)
        Me.splitContainerLeftMain.Panel2.Controls.Add(Me.tcMain)
        Me.splitContainerLeftMain.Size = New System.Drawing.Size(944, 722)
        Me.splitContainerLeftMain.SplitterDistance = 563
        Me.splitContainerLeftMain.SplitterWidth = 3
        Me.splitContainerLeftMain.TabIndex = 6
        '
        'btnRestoreNavMenu
        '
        Me.btnRestoreNavMenu.AlternativeGroup = Nothing
        Me.btnRestoreNavMenu.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnRestoreNavMenu.BackColor = System.Drawing.Color.White
        Me.btnRestoreNavMenu.BackColor1 = System.Drawing.Color.White
        Me.btnRestoreNavMenu.BackColor2 = System.Drawing.Color.LightBlue
        Me.btnRestoreNavMenu.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnRestoreNavMenu.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnRestoreNavMenu.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnRestoreNavMenu.ClickColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnRestoreNavMenu.ClickColor2 = System.Drawing.Color.White
        Me.btnRestoreNavMenu.DrawBorder = True
        Me.btnRestoreNavMenu.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnRestoreNavMenu.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRestoreNavMenu.ForeColor = System.Drawing.Color.Gray
        Me.btnRestoreNavMenu.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal
        Me.btnRestoreNavMenu.HoverColor1 = System.Drawing.Color.White
        Me.btnRestoreNavMenu.HoverColor2 = System.Drawing.Color.Gold
        Me.btnRestoreNavMenu.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnRestoreNavMenu.Location = New System.Drawing.Point(0, 37)
        Me.btnRestoreNavMenu.Name = "btnRestoreNavMenu"
        Me.btnRestoreNavMenu.SelectedColor1 = System.Drawing.Color.White
        Me.btnRestoreNavMenu.SelectedColor2 = System.Drawing.Color.Gold
        Me.btnRestoreNavMenu.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnRestoreNavMenu.SelectedHoverColor1 = System.Drawing.Color.Gold
        Me.btnRestoreNavMenu.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnRestoreNavMenu.SelectedText = Nothing
        Me.btnRestoreNavMenu.Size = New System.Drawing.Size(24, 686)
        Me.btnRestoreNavMenu.TabIndex = 58
        Me.btnRestoreNavMenu.Text = ">>"
        Me.btnRestoreNavMenu.UseVisualStyleBackColor = True
        Me.btnRestoreNavMenu.Visible = False
        '
        'scMnuItemNTitle
        '
        Me.scMnuItemNTitle.BackColor = System.Drawing.Color.White
        Me.scMnuItemNTitle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.scMnuItemNTitle.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.scMnuItemNTitle.IsSplitterFixed = True
        Me.scMnuItemNTitle.Location = New System.Drawing.Point(0, 0)
        Me.scMnuItemNTitle.Name = "scMnuItemNTitle"
        Me.scMnuItemNTitle.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'scMnuItemNTitle.Panel1
        '
        Me.scMnuItemNTitle.Panel1.Controls.Add(Me.btnLogo)
        Me.scMnuItemNTitle.Panel1.Controls.Add(Me.btnHideMenu)
        '
        'scMnuItemNTitle.Panel2
        '
        Me.scMnuItemNTitle.Panel2.Controls.Add(Me.pnlMenuAllLeft)
        Me.scMnuItemNTitle.Size = New System.Drawing.Size(561, 480)
        Me.scMnuItemNTitle.SplitterDistance = 37
        Me.scMnuItemNTitle.TabIndex = 57
        '
        'btnLogo
        '
        Me.btnLogo.AlternativeGroup = Nothing
        Me.btnLogo.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnLogo.BackColor = System.Drawing.Color.Navy
        Me.btnLogo.BackColor1 = System.Drawing.Color.White
        Me.btnLogo.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLogo.BorderHover = True
        Me.btnLogo.BorderHoverColor = System.Drawing.Color.Red
        Me.btnLogo.BorderNormalColor = System.Drawing.Color.Gray
        Me.btnLogo.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnLogo.ClickColor1 = System.Drawing.SystemColors.ControlDarkDark
        Me.btnLogo.ClickColor2 = System.Drawing.Color.DarkRed
        Me.btnLogo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnLogo.DrawBorder = True
        Me.btnLogo.Enabled = False
        Me.btnLogo.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnLogo.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogo.ForeColor = System.Drawing.Color.DarkBlue
        Me.btnLogo.HoverColor1 = System.Drawing.Color.Black
        Me.btnLogo.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnLogo.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnLogo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogo.Location = New System.Drawing.Point(0, 0)
        Me.btnLogo.Name = "btnLogo"
        Me.btnLogo.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnLogo.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnLogo.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnLogo.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnLogo.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnLogo.SelectedText = Nothing
        Me.btnLogo.Size = New System.Drawing.Size(537, 37)
        Me.btnLogo.TabIndex = 54
        Me.btnLogo.TabStop = False
        Me.btnLogo.Text = "Main Menu"
        Me.btnLogo.UseVisualStyleBackColor = False
        '
        'btnHideMenu
        '
        Me.btnHideMenu.AlternativeGroup = Nothing
        Me.btnHideMenu.BackColor = System.Drawing.Color.White
        Me.btnHideMenu.BackColor1 = System.Drawing.Color.White
        Me.btnHideMenu.BackColor2 = System.Drawing.Color.LightBlue
        Me.btnHideMenu.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnHideMenu.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnHideMenu.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnHideMenu.ClickColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnHideMenu.ClickColor2 = System.Drawing.Color.White
        Me.btnHideMenu.Dock = System.Windows.Forms.DockStyle.Right
        Me.btnHideMenu.DrawBorder = True
        Me.btnHideMenu.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnHideMenu.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHideMenu.ForeColor = System.Drawing.Color.Gray
        Me.btnHideMenu.HoverColor1 = System.Drawing.Color.White
        Me.btnHideMenu.HoverColor2 = System.Drawing.Color.Gold
        Me.btnHideMenu.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnHideMenu.Location = New System.Drawing.Point(537, 0)
        Me.btnHideMenu.Name = "btnHideMenu"
        Me.btnHideMenu.SelectedColor1 = System.Drawing.Color.White
        Me.btnHideMenu.SelectedColor2 = System.Drawing.Color.Gold
        Me.btnHideMenu.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnHideMenu.SelectedHoverColor1 = System.Drawing.Color.Gold
        Me.btnHideMenu.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnHideMenu.SelectedText = Nothing
        Me.btnHideMenu.Size = New System.Drawing.Size(24, 37)
        Me.btnHideMenu.TabIndex = 55
        Me.btnHideMenu.Text = "<<"
        Me.btnHideMenu.UseVisualStyleBackColor = False
        '
        'pnlMenuAllLeft
        '
        Me.pnlMenuAllLeft.AutoScroll = True
        Me.pnlMenuAllLeft.AutoScrollMargin = New System.Drawing.Size(10, 10)
        Me.pnlMenuAllLeft.AutoScrollMinSize = New System.Drawing.Size(10, 10)
        Me.pnlMenuAllLeft.BackColor = System.Drawing.Color.White
        Me.pnlMenuAllLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlMenuAllLeft.Controls.Add(Me.tblPnlMenu_Payment)
        Me.pnlMenuAllLeft.Controls.Add(Me.tblPnlMenu_Service)
        Me.pnlMenuAllLeft.Controls.Add(Me.tblPnlMenu_Transactions)
        Me.pnlMenuAllLeft.Controls.Add(Me.tblPnlMenu_Company)
        Me.pnlMenuAllLeft.Controls.Add(Me.tblPnlMenu_Client)
        Me.pnlMenuAllLeft.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMenuAllLeft.Location = New System.Drawing.Point(0, 0)
        Me.pnlMenuAllLeft.Margin = New System.Windows.Forms.Padding(8)
        Me.pnlMenuAllLeft.Name = "pnlMenuAllLeft"
        Me.pnlMenuAllLeft.Size = New System.Drawing.Size(561, 439)
        Me.pnlMenuAllLeft.TabIndex = 10
        '
        'tblPnlMenu_Payment
        '
        Me.tblPnlMenu_Payment.BackColor = System.Drawing.Color.Transparent
        Me.tblPnlMenu_Payment.ColumnCount = 1
        Me.tblPnlMenu_Payment.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tblPnlMenu_Payment.Controls.Add(Me.btnTransactions_ClearCheck, 0, 1)
        Me.tblPnlMenu_Payment.Controls.Add(Me.btnTransactions_Payment, 0, 0)
        Me.tblPnlMenu_Payment.Location = New System.Drawing.Point(360, 171)
        Me.tblPnlMenu_Payment.Margin = New System.Windows.Forms.Padding(1)
        Me.tblPnlMenu_Payment.Name = "tblPnlMenu_Payment"
        Me.tblPnlMenu_Payment.RowCount = 2
        Me.tblPnlMenu_Payment.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.tblPnlMenu_Payment.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.tblPnlMenu_Payment.Size = New System.Drawing.Size(166, 100)
        Me.tblPnlMenu_Payment.TabIndex = 12
        Me.tblPnlMenu_Payment.Tag = "Inventory"
        '
        'btnTransactions_ClearCheck
        '
        Me.btnTransactions_ClearCheck.AlternativeGroup = Nothing
        Me.btnTransactions_ClearCheck.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnTransactions_ClearCheck.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnTransactions_ClearCheck.BackColor1 = System.Drawing.Color.White
        Me.btnTransactions_ClearCheck.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnTransactions_ClearCheck.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnTransactions_ClearCheck.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnTransactions_ClearCheck.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnTransactions_ClearCheck.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnTransactions_ClearCheck.ClickColor2 = System.Drawing.Color.White
        Me.btnTransactions_ClearCheck.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnTransactions_ClearCheck.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnTransactions_ClearCheck.DrawBorder = True
        Me.btnTransactions_ClearCheck.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnTransactions_ClearCheck.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTransactions_ClearCheck.ForeColor = System.Drawing.Color.DimGray
        Me.btnTransactions_ClearCheck.HoverColor1 = System.Drawing.Color.White
        Me.btnTransactions_ClearCheck.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnTransactions_ClearCheck.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnTransactions_ClearCheck.Image = CType(resources.GetObject("btnTransactions_ClearCheck.Image"), System.Drawing.Image)
        Me.btnTransactions_ClearCheck.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_ClearCheck.Location = New System.Drawing.Point(3, 53)
        Me.btnTransactions_ClearCheck.Name = "btnTransactions_ClearCheck"
        Me.btnTransactions_ClearCheck.SelectedColor1 = System.Drawing.Color.White
        Me.btnTransactions_ClearCheck.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnTransactions_ClearCheck.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnTransactions_ClearCheck.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnTransactions_ClearCheck.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnTransactions_ClearCheck.SelectedText = Nothing
        Me.btnTransactions_ClearCheck.Size = New System.Drawing.Size(160, 44)
        Me.btnTransactions_ClearCheck.TabIndex = 10
        Me.btnTransactions_ClearCheck.Text = "    Clear Check"
        Me.btnTransactions_ClearCheck.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_ClearCheck.UseVisualStyleBackColor = False
        '
        'btnTransactions_Payment
        '
        Me.btnTransactions_Payment.AlternativeGroup = Nothing
        Me.btnTransactions_Payment.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnTransactions_Payment.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnTransactions_Payment.BackColor1 = System.Drawing.Color.White
        Me.btnTransactions_Payment.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnTransactions_Payment.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnTransactions_Payment.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnTransactions_Payment.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnTransactions_Payment.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnTransactions_Payment.ClickColor2 = System.Drawing.Color.White
        Me.btnTransactions_Payment.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnTransactions_Payment.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnTransactions_Payment.DrawBorder = True
        Me.btnTransactions_Payment.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnTransactions_Payment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTransactions_Payment.ForeColor = System.Drawing.Color.DimGray
        Me.btnTransactions_Payment.HoverColor1 = System.Drawing.Color.White
        Me.btnTransactions_Payment.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnTransactions_Payment.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnTransactions_Payment.Image = CType(resources.GetObject("btnTransactions_Payment.Image"), System.Drawing.Image)
        Me.btnTransactions_Payment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_Payment.Location = New System.Drawing.Point(3, 3)
        Me.btnTransactions_Payment.Name = "btnTransactions_Payment"
        Me.btnTransactions_Payment.SelectedColor1 = System.Drawing.Color.White
        Me.btnTransactions_Payment.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnTransactions_Payment.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnTransactions_Payment.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnTransactions_Payment.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnTransactions_Payment.SelectedText = Nothing
        Me.btnTransactions_Payment.Size = New System.Drawing.Size(160, 44)
        Me.btnTransactions_Payment.TabIndex = 4
        Me.btnTransactions_Payment.Text = "    Payment"
        Me.btnTransactions_Payment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_Payment.UseVisualStyleBackColor = False
        '
        'tblPnlMenu_Service
        '
        Me.tblPnlMenu_Service.BackColor = System.Drawing.Color.Transparent
        Me.tblPnlMenu_Service.ColumnCount = 1
        Me.tblPnlMenu_Service.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tblPnlMenu_Service.Controls.Add(Me.btnService_Rate, 0, 1)
        Me.tblPnlMenu_Service.Controls.Add(Me.btnService_Service, 0, 0)
        Me.tblPnlMenu_Service.Location = New System.Drawing.Point(359, 281)
        Me.tblPnlMenu_Service.Margin = New System.Windows.Forms.Padding(1)
        Me.tblPnlMenu_Service.Name = "tblPnlMenu_Service"
        Me.tblPnlMenu_Service.RowCount = 2
        Me.tblPnlMenu_Service.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.tblPnlMenu_Service.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.tblPnlMenu_Service.Size = New System.Drawing.Size(166, 95)
        Me.tblPnlMenu_Service.TabIndex = 11
        Me.tblPnlMenu_Service.Tag = "Inventory"
        '
        'btnService_Rate
        '
        Me.btnService_Rate.AlternativeGroup = Nothing
        Me.btnService_Rate.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnService_Rate.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnService_Rate.BackColor1 = System.Drawing.Color.White
        Me.btnService_Rate.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnService_Rate.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnService_Rate.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnService_Rate.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnService_Rate.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnService_Rate.ClickColor2 = System.Drawing.Color.White
        Me.btnService_Rate.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnService_Rate.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnService_Rate.DrawBorder = True
        Me.btnService_Rate.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnService_Rate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnService_Rate.ForeColor = System.Drawing.Color.DimGray
        Me.btnService_Rate.HoverColor1 = System.Drawing.Color.White
        Me.btnService_Rate.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnService_Rate.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnService_Rate.Image = CType(resources.GetObject("btnService_Rate.Image"), System.Drawing.Image)
        Me.btnService_Rate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnService_Rate.Location = New System.Drawing.Point(3, 50)
        Me.btnService_Rate.Name = "btnService_Rate"
        Me.btnService_Rate.SelectedColor1 = System.Drawing.Color.White
        Me.btnService_Rate.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnService_Rate.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnService_Rate.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnService_Rate.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnService_Rate.SelectedText = Nothing
        Me.btnService_Rate.Size = New System.Drawing.Size(160, 44)
        Me.btnService_Rate.TabIndex = 3
        Me.btnService_Rate.Text = "    Service Category"
        Me.btnService_Rate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnService_Rate.UseVisualStyleBackColor = False
        '
        'btnService_Service
        '
        Me.btnService_Service.AlternativeGroup = Nothing
        Me.btnService_Service.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnService_Service.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnService_Service.BackColor1 = System.Drawing.Color.White
        Me.btnService_Service.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnService_Service.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnService_Service.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnService_Service.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnService_Service.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnService_Service.ClickColor2 = System.Drawing.Color.White
        Me.btnService_Service.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnService_Service.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnService_Service.DrawBorder = True
        Me.btnService_Service.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnService_Service.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnService_Service.ForeColor = System.Drawing.Color.DimGray
        Me.btnService_Service.HoverColor1 = System.Drawing.Color.White
        Me.btnService_Service.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnService_Service.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnService_Service.Image = CType(resources.GetObject("btnService_Service.Image"), System.Drawing.Image)
        Me.btnService_Service.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnService_Service.Location = New System.Drawing.Point(3, 3)
        Me.btnService_Service.Name = "btnService_Service"
        Me.btnService_Service.SelectedColor1 = System.Drawing.Color.White
        Me.btnService_Service.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnService_Service.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnService_Service.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnService_Service.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnService_Service.SelectedText = Nothing
        Me.btnService_Service.Size = New System.Drawing.Size(160, 41)
        Me.btnService_Service.TabIndex = 2
        Me.btnService_Service.Text = "    Service"
        Me.btnService_Service.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnService_Service.UseVisualStyleBackColor = False
        '
        'tblPnlMenu_Transactions
        '
        Me.tblPnlMenu_Transactions.BackColor = System.Drawing.Color.Transparent
        Me.tblPnlMenu_Transactions.ColumnCount = 1
        Me.tblPnlMenu_Transactions.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle)
        Me.tblPnlMenu_Transactions.Controls.Add(Me.btnTransactions_ImportOverFlight, 0, 2)
        Me.tblPnlMenu_Transactions.Controls.Add(Me.btnMessage, 0, 5)
        Me.tblPnlMenu_Transactions.Controls.Add(Me.btnTransactions_Bill, 0, 7)
        Me.tblPnlMenu_Transactions.Controls.Add(Me.btnOverFlightPrep, 0, 3)
        Me.tblPnlMenu_Transactions.Controls.Add(Me.btnTransactions_ImportTransactions, 0, 0)
        Me.tblPnlMenu_Transactions.Controls.Add(Me.btnTransactions_Invoice, 0, 4)
        Me.tblPnlMenu_Transactions.Controls.Add(Me.btnAutoInvPrep, 0, 1)
        Me.tblPnlMenu_Transactions.Controls.Add(Me.btnTransactions_OverDueInvoice, 0, 6)
        Me.tblPnlMenu_Transactions.Location = New System.Drawing.Point(178, 28)
        Me.tblPnlMenu_Transactions.Margin = New System.Windows.Forms.Padding(1)
        Me.tblPnlMenu_Transactions.Name = "tblPnlMenu_Transactions"
        Me.tblPnlMenu_Transactions.RowCount = 8
        Me.tblPnlMenu_Transactions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.tblPnlMenu_Transactions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.tblPnlMenu_Transactions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.tblPnlMenu_Transactions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.tblPnlMenu_Transactions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.tblPnlMenu_Transactions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.tblPnlMenu_Transactions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.tblPnlMenu_Transactions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.tblPnlMenu_Transactions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tblPnlMenu_Transactions.Size = New System.Drawing.Size(159, 352)
        Me.tblPnlMenu_Transactions.TabIndex = 10
        Me.tblPnlMenu_Transactions.Tag = "Inventory"
        '
        'btnTransactions_ImportOverFlight
        '
        Me.btnTransactions_ImportOverFlight.AlternativeGroup = Nothing
        Me.btnTransactions_ImportOverFlight.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnTransactions_ImportOverFlight.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnTransactions_ImportOverFlight.BackColor1 = System.Drawing.Color.White
        Me.btnTransactions_ImportOverFlight.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnTransactions_ImportOverFlight.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnTransactions_ImportOverFlight.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnTransactions_ImportOverFlight.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnTransactions_ImportOverFlight.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnTransactions_ImportOverFlight.ClickColor2 = System.Drawing.Color.White
        Me.btnTransactions_ImportOverFlight.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnTransactions_ImportOverFlight.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnTransactions_ImportOverFlight.DrawBorder = True
        Me.btnTransactions_ImportOverFlight.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnTransactions_ImportOverFlight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTransactions_ImportOverFlight.ForeColor = System.Drawing.Color.DimGray
        Me.btnTransactions_ImportOverFlight.HoverColor1 = System.Drawing.Color.White
        Me.btnTransactions_ImportOverFlight.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnTransactions_ImportOverFlight.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnTransactions_ImportOverFlight.Image = CType(resources.GetObject("btnTransactions_ImportOverFlight.Image"), System.Drawing.Image)
        Me.btnTransactions_ImportOverFlight.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_ImportOverFlight.Location = New System.Drawing.Point(3, 91)
        Me.btnTransactions_ImportOverFlight.Name = "btnTransactions_ImportOverFlight"
        Me.btnTransactions_ImportOverFlight.SelectedColor1 = System.Drawing.Color.White
        Me.btnTransactions_ImportOverFlight.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnTransactions_ImportOverFlight.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnTransactions_ImportOverFlight.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnTransactions_ImportOverFlight.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnTransactions_ImportOverFlight.SelectedText = Nothing
        Me.btnTransactions_ImportOverFlight.Size = New System.Drawing.Size(153, 38)
        Me.btnTransactions_ImportOverFlight.TabIndex = 18
        Me.btnTransactions_ImportOverFlight.Text = "   Import Over Flight"
        Me.btnTransactions_ImportOverFlight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_ImportOverFlight.UseVisualStyleBackColor = False
        '
        'btnMessage
        '
        Me.btnMessage.AlternativeGroup = Nothing
        Me.btnMessage.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnMessage.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnMessage.BackColor1 = System.Drawing.Color.White
        Me.btnMessage.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnMessage.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnMessage.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnMessage.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnMessage.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnMessage.ClickColor2 = System.Drawing.Color.White
        Me.btnMessage.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnMessage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnMessage.DrawBorder = True
        Me.btnMessage.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMessage.ForeColor = System.Drawing.Color.DimGray
        Me.btnMessage.HoverColor1 = System.Drawing.Color.White
        Me.btnMessage.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnMessage.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMessage.Image = CType(resources.GetObject("btnMessage.Image"), System.Drawing.Image)
        Me.btnMessage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMessage.Location = New System.Drawing.Point(3, 223)
        Me.btnMessage.Name = "btnMessage"
        Me.btnMessage.SelectedColor1 = System.Drawing.Color.White
        Me.btnMessage.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnMessage.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnMessage.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnMessage.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnMessage.SelectedText = Nothing
        Me.btnMessage.Size = New System.Drawing.Size(153, 38)
        Me.btnMessage.TabIndex = 17
        Me.btnMessage.Text = "    Class-B Messages"
        Me.btnMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMessage.UseVisualStyleBackColor = False
        '
        'btnTransactions_Bill
        '
        Me.btnTransactions_Bill.AlternativeGroup = Nothing
        Me.btnTransactions_Bill.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnTransactions_Bill.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnTransactions_Bill.BackColor1 = System.Drawing.Color.White
        Me.btnTransactions_Bill.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnTransactions_Bill.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnTransactions_Bill.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnTransactions_Bill.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnTransactions_Bill.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnTransactions_Bill.ClickColor2 = System.Drawing.Color.White
        Me.btnTransactions_Bill.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnTransactions_Bill.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnTransactions_Bill.DrawBorder = True
        Me.btnTransactions_Bill.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnTransactions_Bill.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTransactions_Bill.ForeColor = System.Drawing.Color.DimGray
        Me.btnTransactions_Bill.HoverColor1 = System.Drawing.Color.White
        Me.btnTransactions_Bill.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnTransactions_Bill.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnTransactions_Bill.Image = CType(resources.GetObject("btnTransactions_Bill.Image"), System.Drawing.Image)
        Me.btnTransactions_Bill.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_Bill.Location = New System.Drawing.Point(3, 311)
        Me.btnTransactions_Bill.Name = "btnTransactions_Bill"
        Me.btnTransactions_Bill.SelectedColor1 = System.Drawing.Color.White
        Me.btnTransactions_Bill.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnTransactions_Bill.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnTransactions_Bill.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnTransactions_Bill.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnTransactions_Bill.SelectedText = Nothing
        Me.btnTransactions_Bill.Size = New System.Drawing.Size(153, 38)
        Me.btnTransactions_Bill.TabIndex = 16
        Me.btnTransactions_Bill.Text = "   Bill"
        Me.btnTransactions_Bill.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_Bill.UseVisualStyleBackColor = False
        '
        'btnOverFlightPrep
        '
        Me.btnOverFlightPrep.AlternativeGroup = Nothing
        Me.btnOverFlightPrep.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnOverFlightPrep.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnOverFlightPrep.BackColor1 = System.Drawing.Color.White
        Me.btnOverFlightPrep.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnOverFlightPrep.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnOverFlightPrep.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnOverFlightPrep.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnOverFlightPrep.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnOverFlightPrep.ClickColor2 = System.Drawing.Color.White
        Me.btnOverFlightPrep.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnOverFlightPrep.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnOverFlightPrep.DrawBorder = True
        Me.btnOverFlightPrep.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnOverFlightPrep.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOverFlightPrep.ForeColor = System.Drawing.Color.DimGray
        Me.btnOverFlightPrep.HoverColor1 = System.Drawing.Color.White
        Me.btnOverFlightPrep.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnOverFlightPrep.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnOverFlightPrep.Image = CType(resources.GetObject("btnOverFlightPrep.Image"), System.Drawing.Image)
        Me.btnOverFlightPrep.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnOverFlightPrep.Location = New System.Drawing.Point(3, 135)
        Me.btnOverFlightPrep.Name = "btnOverFlightPrep"
        Me.btnOverFlightPrep.SelectedColor1 = System.Drawing.Color.White
        Me.btnOverFlightPrep.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnOverFlightPrep.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnOverFlightPrep.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnOverFlightPrep.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnOverFlightPrep.SelectedText = Nothing
        Me.btnOverFlightPrep.Size = New System.Drawing.Size(153, 38)
        Me.btnOverFlightPrep.TabIndex = 15
        Me.btnOverFlightPrep.Text = "   Inv Over Flight"
        Me.btnOverFlightPrep.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnOverFlightPrep.UseVisualStyleBackColor = False
        '
        'btnTransactions_ImportTransactions
        '
        Me.btnTransactions_ImportTransactions.AlternativeGroup = Nothing
        Me.btnTransactions_ImportTransactions.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnTransactions_ImportTransactions.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnTransactions_ImportTransactions.BackColor1 = System.Drawing.Color.White
        Me.btnTransactions_ImportTransactions.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnTransactions_ImportTransactions.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnTransactions_ImportTransactions.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnTransactions_ImportTransactions.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnTransactions_ImportTransactions.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnTransactions_ImportTransactions.ClickColor2 = System.Drawing.Color.White
        Me.btnTransactions_ImportTransactions.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnTransactions_ImportTransactions.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnTransactions_ImportTransactions.DrawBorder = True
        Me.btnTransactions_ImportTransactions.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnTransactions_ImportTransactions.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTransactions_ImportTransactions.ForeColor = System.Drawing.Color.DimGray
        Me.btnTransactions_ImportTransactions.HoverColor1 = System.Drawing.Color.White
        Me.btnTransactions_ImportTransactions.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnTransactions_ImportTransactions.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnTransactions_ImportTransactions.Image = CType(resources.GetObject("btnTransactions_ImportTransactions.Image"), System.Drawing.Image)
        Me.btnTransactions_ImportTransactions.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_ImportTransactions.Location = New System.Drawing.Point(3, 3)
        Me.btnTransactions_ImportTransactions.Name = "btnTransactions_ImportTransactions"
        Me.btnTransactions_ImportTransactions.SelectedColor1 = System.Drawing.Color.White
        Me.btnTransactions_ImportTransactions.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnTransactions_ImportTransactions.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnTransactions_ImportTransactions.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnTransactions_ImportTransactions.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnTransactions_ImportTransactions.SelectedText = Nothing
        Me.btnTransactions_ImportTransactions.Size = New System.Drawing.Size(153, 38)
        Me.btnTransactions_ImportTransactions.TabIndex = 0
        Me.btnTransactions_ImportTransactions.Text = "   Import Transactions"
        Me.btnTransactions_ImportTransactions.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_ImportTransactions.UseVisualStyleBackColor = False
        '
        'btnTransactions_Invoice
        '
        Me.btnTransactions_Invoice.AlternativeGroup = Nothing
        Me.btnTransactions_Invoice.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnTransactions_Invoice.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnTransactions_Invoice.BackColor1 = System.Drawing.Color.White
        Me.btnTransactions_Invoice.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnTransactions_Invoice.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnTransactions_Invoice.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnTransactions_Invoice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnTransactions_Invoice.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnTransactions_Invoice.ClickColor2 = System.Drawing.Color.White
        Me.btnTransactions_Invoice.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnTransactions_Invoice.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnTransactions_Invoice.DrawBorder = True
        Me.btnTransactions_Invoice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnTransactions_Invoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTransactions_Invoice.ForeColor = System.Drawing.Color.DimGray
        Me.btnTransactions_Invoice.HoverColor1 = System.Drawing.Color.White
        Me.btnTransactions_Invoice.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnTransactions_Invoice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnTransactions_Invoice.Image = CType(resources.GetObject("btnTransactions_Invoice.Image"), System.Drawing.Image)
        Me.btnTransactions_Invoice.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_Invoice.Location = New System.Drawing.Point(3, 179)
        Me.btnTransactions_Invoice.Name = "btnTransactions_Invoice"
        Me.btnTransactions_Invoice.SelectedColor1 = System.Drawing.Color.White
        Me.btnTransactions_Invoice.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnTransactions_Invoice.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnTransactions_Invoice.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnTransactions_Invoice.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnTransactions_Invoice.SelectedText = Nothing
        Me.btnTransactions_Invoice.Size = New System.Drawing.Size(153, 38)
        Me.btnTransactions_Invoice.TabIndex = 2
        Me.btnTransactions_Invoice.Text = "    List of Invoices"
        Me.btnTransactions_Invoice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_Invoice.UseVisualStyleBackColor = False
        '
        'btnAutoInvPrep
        '
        Me.btnAutoInvPrep.AlternativeGroup = Nothing
        Me.btnAutoInvPrep.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnAutoInvPrep.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnAutoInvPrep.BackColor1 = System.Drawing.Color.White
        Me.btnAutoInvPrep.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnAutoInvPrep.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnAutoInvPrep.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnAutoInvPrep.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnAutoInvPrep.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnAutoInvPrep.ClickColor2 = System.Drawing.Color.White
        Me.btnAutoInvPrep.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnAutoInvPrep.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnAutoInvPrep.DrawBorder = True
        Me.btnAutoInvPrep.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnAutoInvPrep.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAutoInvPrep.ForeColor = System.Drawing.Color.DimGray
        Me.btnAutoInvPrep.HoverColor1 = System.Drawing.Color.White
        Me.btnAutoInvPrep.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnAutoInvPrep.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnAutoInvPrep.Image = CType(resources.GetObject("btnAutoInvPrep.Image"), System.Drawing.Image)
        Me.btnAutoInvPrep.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAutoInvPrep.Location = New System.Drawing.Point(3, 47)
        Me.btnAutoInvPrep.Name = "btnAutoInvPrep"
        Me.btnAutoInvPrep.SelectedColor1 = System.Drawing.Color.White
        Me.btnAutoInvPrep.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnAutoInvPrep.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnAutoInvPrep.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnAutoInvPrep.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnAutoInvPrep.SelectedText = Nothing
        Me.btnAutoInvPrep.Size = New System.Drawing.Size(153, 38)
        Me.btnAutoInvPrep.TabIndex = 4
        Me.btnAutoInvPrep.Text = "    Inv Preparation"
        Me.btnAutoInvPrep.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAutoInvPrep.UseVisualStyleBackColor = False
        '
        'btnTransactions_OverDueInvoice
        '
        Me.btnTransactions_OverDueInvoice.AlternativeGroup = Nothing
        Me.btnTransactions_OverDueInvoice.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnTransactions_OverDueInvoice.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnTransactions_OverDueInvoice.BackColor1 = System.Drawing.Color.White
        Me.btnTransactions_OverDueInvoice.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnTransactions_OverDueInvoice.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnTransactions_OverDueInvoice.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnTransactions_OverDueInvoice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnTransactions_OverDueInvoice.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnTransactions_OverDueInvoice.ClickColor2 = System.Drawing.Color.White
        Me.btnTransactions_OverDueInvoice.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnTransactions_OverDueInvoice.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnTransactions_OverDueInvoice.DrawBorder = True
        Me.btnTransactions_OverDueInvoice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnTransactions_OverDueInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTransactions_OverDueInvoice.ForeColor = System.Drawing.Color.DimGray
        Me.btnTransactions_OverDueInvoice.HoverColor1 = System.Drawing.Color.White
        Me.btnTransactions_OverDueInvoice.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnTransactions_OverDueInvoice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnTransactions_OverDueInvoice.Image = CType(resources.GetObject("btnTransactions_OverDueInvoice.Image"), System.Drawing.Image)
        Me.btnTransactions_OverDueInvoice.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_OverDueInvoice.Location = New System.Drawing.Point(3, 267)
        Me.btnTransactions_OverDueInvoice.Name = "btnTransactions_OverDueInvoice"
        Me.btnTransactions_OverDueInvoice.SelectedColor1 = System.Drawing.Color.White
        Me.btnTransactions_OverDueInvoice.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnTransactions_OverDueInvoice.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnTransactions_OverDueInvoice.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnTransactions_OverDueInvoice.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnTransactions_OverDueInvoice.SelectedText = Nothing
        Me.btnTransactions_OverDueInvoice.Size = New System.Drawing.Size(153, 38)
        Me.btnTransactions_OverDueInvoice.TabIndex = 5
        Me.btnTransactions_OverDueInvoice.Text = "    Over Due Invoices"
        Me.btnTransactions_OverDueInvoice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTransactions_OverDueInvoice.UseVisualStyleBackColor = False
        '
        'tblPnlMenu_Company
        '
        Me.tblPnlMenu_Company.BackColor = System.Drawing.Color.Transparent
        Me.tblPnlMenu_Company.ColumnCount = 1
        Me.tblPnlMenu_Company.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tblPnlMenu_Company.Controls.Add(Me.btnCompany_Department, 0, 2)
        Me.tblPnlMenu_Company.Controls.Add(Me.btnCompany_Company, 0, 0)
        Me.tblPnlMenu_Company.Controls.Add(Me.btnCompany_Employee, 0, 1)
        Me.tblPnlMenu_Company.Controls.Add(Me.btnCompany_Area, 0, 3)
        Me.tblPnlMenu_Company.Location = New System.Drawing.Point(22, 10)
        Me.tblPnlMenu_Company.Margin = New System.Windows.Forms.Padding(1)
        Me.tblPnlMenu_Company.Name = "tblPnlMenu_Company"
        Me.tblPnlMenu_Company.RowCount = 5
        Me.tblPnlMenu_Company.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblPnlMenu_Company.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblPnlMenu_Company.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblPnlMenu_Company.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblPnlMenu_Company.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.tblPnlMenu_Company.Size = New System.Drawing.Size(154, 236)
        Me.tblPnlMenu_Company.TabIndex = 5
        Me.tblPnlMenu_Company.Tag = "Company"
        '
        'btnCompany_Department
        '
        Me.btnCompany_Department.AlternativeGroup = Nothing
        Me.btnCompany_Department.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnCompany_Department.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnCompany_Department.BackColor1 = System.Drawing.Color.White
        Me.btnCompany_Department.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnCompany_Department.BorderHover = True
        Me.btnCompany_Department.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnCompany_Department.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnCompany_Department.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCompany_Department.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnCompany_Department.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCompany_Department.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.btnCompany_Department.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnCompany_Department.DrawBorder = True
        Me.btnCompany_Department.Enabled = False
        Me.btnCompany_Department.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCompany_Department.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCompany_Department.ForeColor = System.Drawing.Color.DimGray
        Me.btnCompany_Department.HoverColor1 = System.Drawing.Color.White
        Me.btnCompany_Department.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnCompany_Department.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCompany_Department.Image = CType(resources.GetObject("btnCompany_Department.Image"), System.Drawing.Image)
        Me.btnCompany_Department.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCompany_Department.Location = New System.Drawing.Point(3, 97)
        Me.btnCompany_Department.Name = "btnCompany_Department"
        Me.btnCompany_Department.SelectedColor1 = System.Drawing.Color.White
        Me.btnCompany_Department.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnCompany_Department.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnCompany_Department.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnCompany_Department.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnCompany_Department.SelectedText = Nothing
        Me.btnCompany_Department.Size = New System.Drawing.Size(148, 41)
        Me.btnCompany_Department.TabIndex = 54
        Me.btnCompany_Department.Text = "     Department"
        Me.btnCompany_Department.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCompany_Department.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btnCompany_Department.UseVisualStyleBackColor = False
        '
        'btnCompany_Company
        '
        Me.btnCompany_Company.AlternativeGroup = Nothing
        Me.btnCompany_Company.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnCompany_Company.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnCompany_Company.BackColor1 = System.Drawing.Color.White
        Me.btnCompany_Company.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnCompany_Company.BorderHover = True
        Me.btnCompany_Company.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnCompany_Company.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnCompany_Company.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCompany_Company.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnCompany_Company.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCompany_Company.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.btnCompany_Company.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnCompany_Company.DrawBorder = True
        Me.btnCompany_Company.Enabled = False
        Me.btnCompany_Company.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCompany_Company.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCompany_Company.ForeColor = System.Drawing.Color.DimGray
        Me.btnCompany_Company.HoverColor1 = System.Drawing.Color.White
        Me.btnCompany_Company.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnCompany_Company.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCompany_Company.Image = CType(resources.GetObject("btnCompany_Company.Image"), System.Drawing.Image)
        Me.btnCompany_Company.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCompany_Company.Location = New System.Drawing.Point(3, 3)
        Me.btnCompany_Company.Name = "btnCompany_Company"
        Me.btnCompany_Company.SelectedColor1 = System.Drawing.Color.White
        Me.btnCompany_Company.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnCompany_Company.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnCompany_Company.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnCompany_Company.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnCompany_Company.SelectedText = Nothing
        Me.btnCompany_Company.Size = New System.Drawing.Size(148, 41)
        Me.btnCompany_Company.TabIndex = 53
        Me.btnCompany_Company.Text = "     DGCA Account"
        Me.btnCompany_Company.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCompany_Company.UseVisualStyleBackColor = False
        '
        'btnCompany_Employee
        '
        Me.btnCompany_Employee.AlternativeGroup = Nothing
        Me.btnCompany_Employee.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnCompany_Employee.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnCompany_Employee.BackColor1 = System.Drawing.Color.White
        Me.btnCompany_Employee.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnCompany_Employee.BorderHover = True
        Me.btnCompany_Employee.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnCompany_Employee.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnCompany_Employee.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCompany_Employee.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnCompany_Employee.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCompany_Employee.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.btnCompany_Employee.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnCompany_Employee.DrawBorder = True
        Me.btnCompany_Employee.Enabled = False
        Me.btnCompany_Employee.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCompany_Employee.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCompany_Employee.ForeColor = System.Drawing.Color.DimGray
        Me.btnCompany_Employee.HoverColor1 = System.Drawing.Color.White
        Me.btnCompany_Employee.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnCompany_Employee.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCompany_Employee.Image = CType(resources.GetObject("btnCompany_Employee.Image"), System.Drawing.Image)
        Me.btnCompany_Employee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCompany_Employee.Location = New System.Drawing.Point(3, 50)
        Me.btnCompany_Employee.Name = "btnCompany_Employee"
        Me.btnCompany_Employee.SelectedColor1 = System.Drawing.Color.White
        Me.btnCompany_Employee.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnCompany_Employee.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnCompany_Employee.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnCompany_Employee.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnCompany_Employee.SelectedText = Nothing
        Me.btnCompany_Employee.Size = New System.Drawing.Size(148, 41)
        Me.btnCompany_Employee.TabIndex = 56
        Me.btnCompany_Employee.Text = "    Personnel"
        Me.btnCompany_Employee.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCompany_Employee.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btnCompany_Employee.UseVisualStyleBackColor = False
        '
        'btnCompany_Area
        '
        Me.btnCompany_Area.AlternativeGroup = Nothing
        Me.btnCompany_Area.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnCompany_Area.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnCompany_Area.BackColor1 = System.Drawing.Color.White
        Me.btnCompany_Area.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnCompany_Area.BorderHover = True
        Me.btnCompany_Area.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnCompany_Area.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnCompany_Area.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCompany_Area.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnCompany_Area.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCompany_Area.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.btnCompany_Area.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnCompany_Area.DrawBorder = True
        Me.btnCompany_Area.Enabled = False
        Me.btnCompany_Area.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCompany_Area.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCompany_Area.ForeColor = System.Drawing.Color.DimGray
        Me.btnCompany_Area.HoverColor1 = System.Drawing.Color.White
        Me.btnCompany_Area.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnCompany_Area.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCompany_Area.Image = CType(resources.GetObject("btnCompany_Area.Image"), System.Drawing.Image)
        Me.btnCompany_Area.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCompany_Area.Location = New System.Drawing.Point(3, 144)
        Me.btnCompany_Area.Name = "btnCompany_Area"
        Me.btnCompany_Area.SelectedColor1 = System.Drawing.Color.White
        Me.btnCompany_Area.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnCompany_Area.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnCompany_Area.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnCompany_Area.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnCompany_Area.SelectedText = Nothing
        Me.btnCompany_Area.Size = New System.Drawing.Size(148, 41)
        Me.btnCompany_Area.TabIndex = 55
        Me.btnCompany_Area.Text = "      Area"
        Me.btnCompany_Area.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCompany_Area.UseVisualStyleBackColor = False
        '
        'tblPnlMenu_Client
        '
        Me.tblPnlMenu_Client.BackColor = System.Drawing.Color.Transparent
        Me.tblPnlMenu_Client.ColumnCount = 1
        Me.tblPnlMenu_Client.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tblPnlMenu_Client.Controls.Add(Me.btnUserPreferences, 0, 1)
        Me.tblPnlMenu_Client.Controls.Add(Me.btnClient_ClientList, 0, 0)
        Me.tblPnlMenu_Client.Location = New System.Drawing.Point(359, 10)
        Me.tblPnlMenu_Client.Margin = New System.Windows.Forms.Padding(1)
        Me.tblPnlMenu_Client.Name = "tblPnlMenu_Client"
        Me.tblPnlMenu_Client.RowCount = 3
        Me.tblPnlMenu_Client.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.tblPnlMenu_Client.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.tblPnlMenu_Client.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8.0!))
        Me.tblPnlMenu_Client.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tblPnlMenu_Client.Size = New System.Drawing.Size(166, 147)
        Me.tblPnlMenu_Client.TabIndex = 7
        Me.tblPnlMenu_Client.Tag = "Accounting"
        '
        'btnUserPreferences
        '
        Me.btnUserPreferences.AlternativeGroup = Nothing
        Me.btnUserPreferences.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnUserPreferences.BackColor1 = System.Drawing.Color.White
        Me.btnUserPreferences.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnUserPreferences.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnUserPreferences.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnUserPreferences.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnUserPreferences.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnUserPreferences.ClickColor2 = System.Drawing.Color.White
        Me.btnUserPreferences.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnUserPreferences.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnUserPreferences.DrawBorder = True
        Me.btnUserPreferences.Enabled = False
        Me.btnUserPreferences.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnUserPreferences.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUserPreferences.ForeColor = System.Drawing.Color.DimGray
        Me.btnUserPreferences.HoverColor1 = System.Drawing.Color.White
        Me.btnUserPreferences.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnUserPreferences.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnUserPreferences.Image = CType(resources.GetObject("btnUserPreferences.Image"), System.Drawing.Image)
        Me.btnUserPreferences.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUserPreferences.Location = New System.Drawing.Point(3, 53)
        Me.btnUserPreferences.Name = "btnUserPreferences"
        Me.btnUserPreferences.SelectedColor1 = System.Drawing.Color.White
        Me.btnUserPreferences.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnUserPreferences.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnUserPreferences.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnUserPreferences.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnUserPreferences.SelectedText = Nothing
        Me.btnUserPreferences.Size = New System.Drawing.Size(160, 44)
        Me.btnUserPreferences.TabIndex = 3
        Me.btnUserPreferences.Text = "     User Preferences"
        Me.btnUserPreferences.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUserPreferences.UseVisualStyleBackColor = False
        '
        'btnClient_ClientList
        '
        Me.btnClient_ClientList.AlternativeGroup = Nothing
        Me.btnClient_ClientList.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnClient_ClientList.BackColor1 = System.Drawing.Color.White
        Me.btnClient_ClientList.BackColor2 = System.Drawing.Color.GhostWhite
        Me.btnClient_ClientList.BorderHoverColor = System.Drawing.Color.Gray
        Me.btnClient_ClientList.BorderNormalColor = System.Drawing.Color.DimGray
        Me.btnClient_ClientList.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnClient_ClientList.ClickColor1 = System.Drawing.Color.Moccasin
        Me.btnClient_ClientList.ClickColor2 = System.Drawing.Color.White
        Me.btnClient_ClientList.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnClient_ClientList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnClient_ClientList.DrawBorder = True
        Me.btnClient_ClientList.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClient_ClientList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClient_ClientList.ForeColor = System.Drawing.Color.DimGray
        Me.btnClient_ClientList.HoverColor1 = System.Drawing.Color.White
        Me.btnClient_ClientList.HoverColor2 = System.Drawing.Color.PeachPuff
        Me.btnClient_ClientList.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClient_ClientList.Image = CType(resources.GetObject("btnClient_ClientList.Image"), System.Drawing.Image)
        Me.btnClient_ClientList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClient_ClientList.Location = New System.Drawing.Point(3, 3)
        Me.btnClient_ClientList.Name = "btnClient_ClientList"
        Me.btnClient_ClientList.SelectedColor1 = System.Drawing.Color.White
        Me.btnClient_ClientList.SelectedColor2 = System.Drawing.Color.Orange
        Me.btnClient_ClientList.SelectedForeColor = System.Drawing.Color.DarkBlue
        Me.btnClient_ClientList.SelectedHoverColor1 = System.Drawing.Color.Orange
        Me.btnClient_ClientList.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnClient_ClientList.SelectedText = Nothing
        Me.btnClient_ClientList.Size = New System.Drawing.Size(160, 44)
        Me.btnClient_ClientList.TabIndex = 1
        Me.btnClient_ClientList.Text = "     Client List"
        Me.btnClient_ClientList.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClient_ClientList.UseVisualStyleBackColor = False
        '
        'tblPnlMenu_Main
        '
        Me.tblPnlMenu_Main.ColumnCount = 1
        Me.tblPnlMenu_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle)
        Me.tblPnlMenu_Main.Controls.Add(Me.btnMenuMain_Applications, 0, 1)
        Me.tblPnlMenu_Main.Controls.Add(Me.btnMenuMain_Clients, 0, 0)
        Me.tblPnlMenu_Main.Controls.Add(Me.btnMenuMain_Reports, 0, 5)
        Me.tblPnlMenu_Main.Controls.Add(Me.btnMenuMain_Company, 0, 4)
        Me.tblPnlMenu_Main.Controls.Add(Me.btnMainMenu_Services, 0, 3)
        Me.tblPnlMenu_Main.Controls.Add(Me.btnMenuMain_Payment, 0, 2)
        Me.tblPnlMenu_Main.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tblPnlMenu_Main.Location = New System.Drawing.Point(0, 480)
        Me.tblPnlMenu_Main.Margin = New System.Windows.Forms.Padding(0)
        Me.tblPnlMenu_Main.Name = "tblPnlMenu_Main"
        Me.tblPnlMenu_Main.RowCount = 6
        Me.tblPnlMenu_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.tblPnlMenu_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.tblPnlMenu_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.tblPnlMenu_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.tblPnlMenu_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.tblPnlMenu_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.tblPnlMenu_Main.Size = New System.Drawing.Size(561, 240)
        Me.tblPnlMenu_Main.TabIndex = 4
        '
        'btnMenuMain_Applications
        '
        Me.btnMenuMain_Applications.AlternativeGroup = Nothing
        Me.btnMenuMain_Applications.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnMenuMain_Applications.BackColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Applications.BackColor2 = System.Drawing.Color.LightBlue
        Me.btnMenuMain_Applications.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMenuMain_Applications.BorderHoverColor = System.Drawing.Color.DimGray
        Me.btnMenuMain_Applications.BorderNormalColor = System.Drawing.Color.Gray
        Me.btnMenuMain_Applications.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnMenuMain_Applications.ClickColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Applications.ClickColor2 = System.Drawing.Color.White
        Me.btnMenuMain_Applications.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnMenuMain_Applications.DrawBorder = True
        Me.btnMenuMain_Applications.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnMenuMain_Applications.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuMain_Applications.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnMenuMain_Applications.HoverColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Applications.HoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Applications.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMenuMain_Applications.Image = CType(resources.GetObject("btnMenuMain_Applications.Image"), System.Drawing.Image)
        Me.btnMenuMain_Applications.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuMain_Applications.Location = New System.Drawing.Point(3, 43)
        Me.btnMenuMain_Applications.Name = "btnMenuMain_Applications"
        Me.btnMenuMain_Applications.SelectedColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Applications.SelectedColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Applications.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMenuMain_Applications.SelectedHoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Applications.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnMenuMain_Applications.SelectedText = Nothing
        Me.btnMenuMain_Applications.Size = New System.Drawing.Size(555, 34)
        Me.btnMenuMain_Applications.TabIndex = 3
        Me.btnMenuMain_Applications.TabStop = False
        Me.btnMenuMain_Applications.Text = "            Transactions"
        Me.btnMenuMain_Applications.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuMain_Applications.UseVisualStyleBackColor = False
        '
        'btnMenuMain_Clients
        '
        Me.btnMenuMain_Clients.AlternativeGroup = Nothing
        Me.btnMenuMain_Clients.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnMenuMain_Clients.BackColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Clients.BackColor2 = System.Drawing.Color.LightBlue
        Me.btnMenuMain_Clients.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMenuMain_Clients.BorderHoverColor = System.Drawing.Color.DimGray
        Me.btnMenuMain_Clients.BorderNormalColor = System.Drawing.Color.Gray
        Me.btnMenuMain_Clients.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnMenuMain_Clients.ClickColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Clients.ClickColor2 = System.Drawing.Color.White
        Me.btnMenuMain_Clients.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnMenuMain_Clients.DrawBorder = True
        Me.btnMenuMain_Clients.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnMenuMain_Clients.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuMain_Clients.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnMenuMain_Clients.HoverColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Clients.HoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Clients.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMenuMain_Clients.Image = CType(resources.GetObject("btnMenuMain_Clients.Image"), System.Drawing.Image)
        Me.btnMenuMain_Clients.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuMain_Clients.Location = New System.Drawing.Point(3, 3)
        Me.btnMenuMain_Clients.Name = "btnMenuMain_Clients"
        Me.btnMenuMain_Clients.SelectedColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Clients.SelectedColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Clients.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMenuMain_Clients.SelectedHoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Clients.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnMenuMain_Clients.SelectedText = Nothing
        Me.btnMenuMain_Clients.Size = New System.Drawing.Size(555, 34)
        Me.btnMenuMain_Clients.TabIndex = 4
        Me.btnMenuMain_Clients.TabStop = False
        Me.btnMenuMain_Clients.Text = "            Client"
        Me.btnMenuMain_Clients.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuMain_Clients.UseVisualStyleBackColor = False
        '
        'btnMenuMain_Reports
        '
        Me.btnMenuMain_Reports.AlternativeGroup = Nothing
        Me.btnMenuMain_Reports.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnMenuMain_Reports.BackColor1 = System.Drawing.Color.WhiteSmoke
        Me.btnMenuMain_Reports.BackColor2 = System.Drawing.Color.LightBlue
        Me.btnMenuMain_Reports.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMenuMain_Reports.BorderHoverColor = System.Drawing.Color.DimGray
        Me.btnMenuMain_Reports.BorderNormalColor = System.Drawing.Color.Gray
        Me.btnMenuMain_Reports.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnMenuMain_Reports.ClickColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Reports.ClickColor2 = System.Drawing.Color.White
        Me.btnMenuMain_Reports.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnMenuMain_Reports.DrawBorder = True
        Me.btnMenuMain_Reports.Enabled = False
        Me.btnMenuMain_Reports.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnMenuMain_Reports.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuMain_Reports.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnMenuMain_Reports.HoverColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Reports.HoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Reports.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMenuMain_Reports.Image = CType(resources.GetObject("btnMenuMain_Reports.Image"), System.Drawing.Image)
        Me.btnMenuMain_Reports.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnMenuMain_Reports.Location = New System.Drawing.Point(3, 203)
        Me.btnMenuMain_Reports.Name = "btnMenuMain_Reports"
        Me.btnMenuMain_Reports.SelectedColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Reports.SelectedColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Reports.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMenuMain_Reports.SelectedHoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Reports.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnMenuMain_Reports.SelectedText = Nothing
        Me.btnMenuMain_Reports.Size = New System.Drawing.Size(555, 34)
        Me.btnMenuMain_Reports.TabIndex = 8
        Me.btnMenuMain_Reports.TabStop = False
        Me.btnMenuMain_Reports.Text = "            Reports"
        Me.btnMenuMain_Reports.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuMain_Reports.UseVisualStyleBackColor = False
        '
        'btnMenuMain_Company
        '
        Me.btnMenuMain_Company.AlternativeGroup = Nothing
        Me.btnMenuMain_Company.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnMenuMain_Company.BackColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Company.BackColor2 = System.Drawing.Color.LightBlue
        Me.btnMenuMain_Company.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMenuMain_Company.BorderHoverColor = System.Drawing.Color.DimGray
        Me.btnMenuMain_Company.BorderNormalColor = System.Drawing.Color.Gray
        Me.btnMenuMain_Company.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnMenuMain_Company.ClickColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Company.ClickColor2 = System.Drawing.Color.White
        Me.btnMenuMain_Company.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnMenuMain_Company.DrawBorder = True
        Me.btnMenuMain_Company.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnMenuMain_Company.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuMain_Company.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnMenuMain_Company.HoverColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Company.HoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Company.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMenuMain_Company.Image = CType(resources.GetObject("btnMenuMain_Company.Image"), System.Drawing.Image)
        Me.btnMenuMain_Company.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuMain_Company.Location = New System.Drawing.Point(3, 163)
        Me.btnMenuMain_Company.Name = "btnMenuMain_Company"
        Me.btnMenuMain_Company.SelectedColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Company.SelectedColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Company.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMenuMain_Company.SelectedHoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Company.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnMenuMain_Company.SelectedText = Nothing
        Me.btnMenuMain_Company.Size = New System.Drawing.Size(555, 34)
        Me.btnMenuMain_Company.TabIndex = 6
        Me.btnMenuMain_Company.TabStop = False
        Me.btnMenuMain_Company.Text = "            D G C A"
        Me.btnMenuMain_Company.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuMain_Company.UseVisualStyleBackColor = False
        '
        'btnMainMenu_Services
        '
        Me.btnMainMenu_Services.AlternativeGroup = Nothing
        Me.btnMainMenu_Services.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnMainMenu_Services.BackColor1 = System.Drawing.Color.WhiteSmoke
        Me.btnMainMenu_Services.BackColor2 = System.Drawing.Color.LightBlue
        Me.btnMainMenu_Services.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMainMenu_Services.BorderHoverColor = System.Drawing.Color.DimGray
        Me.btnMainMenu_Services.BorderNormalColor = System.Drawing.Color.Gray
        Me.btnMainMenu_Services.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnMainMenu_Services.ClickColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMainMenu_Services.ClickColor2 = System.Drawing.Color.White
        Me.btnMainMenu_Services.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnMainMenu_Services.DrawBorder = True
        Me.btnMainMenu_Services.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnMainMenu_Services.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMainMenu_Services.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnMainMenu_Services.HoverColor1 = System.Drawing.Color.White
        Me.btnMainMenu_Services.HoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMainMenu_Services.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMainMenu_Services.Image = CType(resources.GetObject("btnMainMenu_Services.Image"), System.Drawing.Image)
        Me.btnMainMenu_Services.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMainMenu_Services.Location = New System.Drawing.Point(3, 123)
        Me.btnMainMenu_Services.Name = "btnMainMenu_Services"
        Me.btnMainMenu_Services.SelectedColor1 = System.Drawing.Color.White
        Me.btnMainMenu_Services.SelectedColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMainMenu_Services.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMainMenu_Services.SelectedHoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMainMenu_Services.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnMainMenu_Services.SelectedText = Nothing
        Me.btnMainMenu_Services.Size = New System.Drawing.Size(555, 34)
        Me.btnMainMenu_Services.TabIndex = 9
        Me.btnMainMenu_Services.TabStop = False
        Me.btnMainMenu_Services.Text = "            Service"
        Me.btnMainMenu_Services.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMainMenu_Services.UseVisualStyleBackColor = False
        '
        'btnMenuMain_Payment
        '
        Me.btnMenuMain_Payment.AlternativeGroup = Nothing
        Me.btnMenuMain_Payment.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnMenuMain_Payment.BackColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Payment.BackColor2 = System.Drawing.Color.LightBlue
        Me.btnMenuMain_Payment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMenuMain_Payment.BorderHoverColor = System.Drawing.Color.DimGray
        Me.btnMenuMain_Payment.BorderNormalColor = System.Drawing.Color.Gray
        Me.btnMenuMain_Payment.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnMenuMain_Payment.ClickColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Payment.ClickColor2 = System.Drawing.Color.White
        Me.btnMenuMain_Payment.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnMenuMain_Payment.DrawBorder = True
        Me.btnMenuMain_Payment.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnMenuMain_Payment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuMain_Payment.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnMenuMain_Payment.HoverColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Payment.HoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Payment.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMenuMain_Payment.Image = CType(resources.GetObject("btnMenuMain_Payment.Image"), System.Drawing.Image)
        Me.btnMenuMain_Payment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuMain_Payment.Location = New System.Drawing.Point(3, 83)
        Me.btnMenuMain_Payment.Name = "btnMenuMain_Payment"
        Me.btnMenuMain_Payment.SelectedColor1 = System.Drawing.Color.White
        Me.btnMenuMain_Payment.SelectedColor2 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Payment.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnMenuMain_Payment.SelectedHoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnMenuMain_Payment.SelectedHoverColor2 = System.Drawing.Color.White
        Me.btnMenuMain_Payment.SelectedText = Nothing
        Me.btnMenuMain_Payment.Size = New System.Drawing.Size(555, 34)
        Me.btnMenuMain_Payment.TabIndex = 10
        Me.btnMenuMain_Payment.TabStop = False
        Me.btnMenuMain_Payment.Text = "            Payment"
        Me.btnMenuMain_Payment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuMain_Payment.UseVisualStyleBackColor = False
        '
        'btnCloseWindows
        '
        Me.btnCloseWindows.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCloseWindows.ForeColor = System.Drawing.Color.Navy
        Me.btnCloseWindows.Location = New System.Drawing.Point(265, 0)
        Me.btnCloseWindows.Name = "btnCloseWindows"
        Me.btnCloseWindows.Size = New System.Drawing.Size(111, 23)
        Me.btnCloseWindows.TabIndex = 19
        Me.btnCloseWindows.Text = "Close All Windows"
        Me.btnCloseWindows.UseVisualStyleBackColor = True
        '
        'tcMain
        '
        Me.tcMain.Controls.Add(Me.tabVer)
        Me.tcMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tcMain.Location = New System.Drawing.Point(0, 0)
        Me.tcMain.Margin = New System.Windows.Forms.Padding(0)
        Me.tcMain.Name = "tcMain"
        Me.tcMain.Padding = New System.Drawing.Point(0, 0)
        Me.tcMain.SelectedIndex = 0
        Me.tcMain.Size = New System.Drawing.Size(376, 720)
        Me.tcMain.TabIndex = 6
        '
        'tabVer
        '
        Me.tabVer.Controls.Add(Me.lblVersinDate)
        Me.tabVer.Controls.Add(Me.lbldgca)
        Me.tabVer.Controls.Add(Me.pbavaitionlogo)
        Me.tabVer.Controls.Add(Me.lblrepublic)
        Me.tabVer.Controls.Add(Me.lblVer)
        Me.tabVer.Controls.Add(Me.pblogo)
        Me.tabVer.Controls.Add(Me.picExperiance)
        Me.tabVer.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.tabVer.Location = New System.Drawing.Point(4, 22)
        Me.tabVer.Name = "tabVer"
        Me.tabVer.Padding = New System.Windows.Forms.Padding(3)
        Me.tabVer.Size = New System.Drawing.Size(368, 694)
        Me.tabVer.TabIndex = 0
        Me.tabVer.Text = "m a i n"
        Me.tabVer.UseVisualStyleBackColor = True
        '
        'lblVersinDate
        '
        Me.lblVersinDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblVersinDate.BackColor = System.Drawing.Color.White
        Me.lblVersinDate.Location = New System.Drawing.Point(210, 581)
        Me.lblVersinDate.Name = "lblVersinDate"
        Me.lblVersinDate.Size = New System.Drawing.Size(151, 18)
        Me.lblVersinDate.TabIndex = 18
        Me.lblVersinDate.Text = "2010 Sep 22"
        Me.lblVersinDate.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbldgca
        '
        Me.lbldgca.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbldgca.BackColor = System.Drawing.Color.White
        Me.lbldgca.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.lbldgca.ForeColor = System.Drawing.Color.Black
        Me.lbldgca.Location = New System.Drawing.Point(16, 235)
        Me.lbldgca.Name = "lbldgca"
        Me.lbldgca.Size = New System.Drawing.Size(338, 23)
        Me.lbldgca.TabIndex = 12
        Me.lbldgca.Text = "����������� �������� �������� ��������"
        Me.lbldgca.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'pbavaitionlogo
        '
        Me.pbavaitionlogo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.pbavaitionlogo.BackColor = System.Drawing.Color.White
        Me.pbavaitionlogo.Image = CType(resources.GetObject("pbavaitionlogo.Image"), System.Drawing.Image)
        Me.pbavaitionlogo.Location = New System.Drawing.Point(16, 104)
        Me.pbavaitionlogo.Name = "pbavaitionlogo"
        Me.pbavaitionlogo.Size = New System.Drawing.Size(338, 161)
        Me.pbavaitionlogo.TabIndex = 11
        Me.pbavaitionlogo.TabStop = False
        '
        'lblrepublic
        '
        Me.lblrepublic.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblrepublic.BackColor = System.Drawing.Color.White
        Me.lblrepublic.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.lblrepublic.ForeColor = System.Drawing.Color.Black
        Me.lblrepublic.Location = New System.Drawing.Point(16, 64)
        Me.lblrepublic.Name = "lblrepublic"
        Me.lblrepublic.Size = New System.Drawing.Size(338, 100)
        Me.lblrepublic.TabIndex = 10
        Me.lblrepublic.Text = "������������ �������������"
        Me.lblrepublic.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblVer
        '
        Me.lblVer.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblVer.BackColor = System.Drawing.Color.White
        Me.lblVer.Location = New System.Drawing.Point(210, 558)
        Me.lblVer.Name = "lblVer"
        Me.lblVer.Size = New System.Drawing.Size(151, 18)
        Me.lblVer.TabIndex = 9
        Me.lblVer.Text = "Version 1.0.1"
        Me.lblVer.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'pblogo
        '
        Me.pblogo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pblogo.BackColor = System.Drawing.Color.White
        Me.pblogo.Image = CType(resources.GetObject("pblogo.Image"), System.Drawing.Image)
        Me.pblogo.Location = New System.Drawing.Point(203, 608)
        Me.pblogo.Name = "pblogo"
        Me.pblogo.Size = New System.Drawing.Size(158, 68)
        Me.pblogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pblogo.TabIndex = 8
        Me.pblogo.TabStop = False
        '
        'picExperiance
        '
        Me.picExperiance.BackColor = System.Drawing.Color.White
        Me.picExperiance.Dock = System.Windows.Forms.DockStyle.Fill
        Me.picExperiance.Location = New System.Drawing.Point(3, 3)
        Me.picExperiance.Name = "picExperiance"
        Me.picExperiance.Size = New System.Drawing.Size(362, 688)
        Me.picExperiance.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.picExperiance.TabIndex = 7
        Me.picExperiance.TabStop = False
        '
        'Button8
        '
        Me.Button8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button8.Location = New System.Drawing.Point(3, 9)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(102, 1)
        Me.Button8.TabIndex = 3
        Me.Button8.Text = "Button8"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle)
        Me.TableLayoutPanel2.Controls.Add(Me.Button6, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Button7, 0, 1)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 3
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(200, 100)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Button6
        '
        Me.Button6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button6.Location = New System.Drawing.Point(3, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(194, 14)
        Me.Button6.TabIndex = 0
        Me.Button6.Text = "Button6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button7.Location = New System.Drawing.Point(3, 23)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(194, 14)
        Me.Button7.TabIndex = 2
        Me.Button7.Text = "Button7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'ETSMenu
        '
        Me.ETSMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tlSocSecRpts, Me.tlTestQueue})
        Me.ETSMenu.Name = "ETSMenu"
        Me.ETSMenu.Size = New System.Drawing.Size(37, 20)
        Me.ETSMenu.Text = "Edit"
        '
        'tlSocSecRpts
        '
        Me.tlSocSecRpts.Name = "tlSocSecRpts"
        Me.tlSocSecRpts.Size = New System.Drawing.Size(172, 22)
        Me.tlSocSecRpts.Text = "Test FrmSocSecRpts"
        '
        'tlTestQueue
        '
        Me.tlTestQueue.Name = "tlTestQueue"
        Me.tlTestQueue.Size = New System.Drawing.Size(172, 22)
        Me.tlTestQueue.Text = "Test ComBoGrid"
        '
        'msMenu
        '
        Me.msMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BranchBillingInfoToolStripMenuItem})
        Me.msMenu.Location = New System.Drawing.Point(0, 0)
        Me.msMenu.Name = "msMenu"
        Me.msMenu.Size = New System.Drawing.Size(944, 24)
        Me.msMenu.TabIndex = 0
        Me.msMenu.Text = "MenuStrip1"
        '
        'BranchBillingInfoToolStripMenuItem
        '
        Me.BranchBillingInfoToolStripMenuItem.Name = "BranchBillingInfoToolStripMenuItem"
        Me.BranchBillingInfoToolStripMenuItem.Size = New System.Drawing.Size(104, 20)
        Me.BranchBillingInfoToolStripMenuItem.Text = "Branch Billing Info"
        Me.BranchBillingInfoToolStripMenuItem.Visible = False
        '
        'tsmMainMenu
        '
        Me.tsmMainMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmFile})
        Me.tsmMainMenu.Name = "tsmMainMenu"
        Me.tsmMainMenu.Size = New System.Drawing.Size(37, 20)
        Me.tsmMainMenu.Text = "File"
        '
        'tsmFile
        '
        Me.tsmFile.Name = "tsmFile"
        Me.tsmFile.Size = New System.Drawing.Size(92, 22)
        Me.tsmFile.Text = "Exit"
        '
        'tsmEdit
        '
        Me.tsmEdit.Name = "tsmEdit"
        Me.tsmEdit.Size = New System.Drawing.Size(39, 20)
        Me.tsmEdit.Text = "Edit"
        Me.tsmEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tsmView
        '
        Me.tsmView.Name = "tsmView"
        Me.tsmView.Size = New System.Drawing.Size(44, 20)
        Me.tsmView.Text = "View"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(35, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(92, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VisitStatusQuickHelpToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'VisitStatusQuickHelpToolStripMenuItem
        '
        Me.VisitStatusQuickHelpToolStripMenuItem.Name = "VisitStatusQuickHelpToolStripMenuItem"
        Me.VisitStatusQuickHelpToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.VisitStatusQuickHelpToolStripMenuItem.Text = "Visit Status Quick Help"
        '
        'BouncingHoverButton6
        '
        Me.BouncingHoverButton6.AlternativeGroup = Nothing
        Me.BouncingHoverButton6.BackColor1 = System.Drawing.SystemColors.Control
        Me.BouncingHoverButton6.BackColor2 = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton6.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton6.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton6.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton6.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton6.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BouncingHoverButton6.FlatStyle = BHBut.BouncingHoverButton.FltStyle.Standard
        Me.BouncingHoverButton6.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton6.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton6.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton6.Location = New System.Drawing.Point(3, 11)
        Me.BouncingHoverButton6.Name = "BouncingHoverButton6"
        Me.BouncingHoverButton6.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton6.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton6.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton6.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton6.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton6.SelectedText = Nothing
        Me.BouncingHoverButton6.Size = New System.Drawing.Size(324, 1)
        Me.BouncingHoverButton6.TabIndex = 3
        Me.BouncingHoverButton6.Text = "BButton1-Textutton1-Text"
        Me.BouncingHoverButton6.UseVisualStyleBackColor = True
        '
        'BouncingHoverButton5
        '
        Me.BouncingHoverButton5.AlternativeGroup = Nothing
        Me.BouncingHoverButton5.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton5.BackColor2 = System.Drawing.SystemColors.InactiveCaptionText
        Me.BouncingHoverButton5.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton5.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton5.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton5.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton5.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BouncingHoverButton5.DrawBorder = True
        Me.BouncingHoverButton5.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton5.Font = New System.Drawing.Font("Comic Sans MS", 8.0!)
        Me.BouncingHoverButton5.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton5.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton5.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton5.Location = New System.Drawing.Point(3, 23)
        Me.BouncingHoverButton5.Name = "BouncingHoverButton5"
        Me.BouncingHoverButton5.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton5.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton5.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton5.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton5.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton5.SelectedText = Nothing
        Me.BouncingHoverButton5.Size = New System.Drawing.Size(194, 14)
        Me.BouncingHoverButton5.TabIndex = 2
        Me.BouncingHoverButton5.Text = " Button1-Text"
        Me.BouncingHoverButton5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BouncingHoverButton5.UseVisualStyleBackColor = True
        '
        'BouncingHoverButton4
        '
        Me.BouncingHoverButton4.AlternativeGroup = Nothing
        Me.BouncingHoverButton4.BackColor = System.Drawing.Color.White
        Me.BouncingHoverButton4.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton4.BackColor2 = System.Drawing.Color.Linen
        Me.BouncingHoverButton4.BorderHoverColor = System.Drawing.Color.Gray
        Me.BouncingHoverButton4.BorderNormalColor = System.Drawing.Color.Gray
        Me.BouncingHoverButton4.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.BouncingHoverButton4.ClickColor1 = System.Drawing.Color.Gold
        Me.BouncingHoverButton4.ClickColor2 = System.Drawing.Color.White
        Me.BouncingHoverButton4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BouncingHoverButton4.DrawBorder = True
        Me.BouncingHoverButton4.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton4.Font = New System.Drawing.Font("Comic Sans MS", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BouncingHoverButton4.HoverColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton4.HoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton4.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton4.Location = New System.Drawing.Point(3, 3)
        Me.BouncingHoverButton4.Name = "BouncingHoverButton4"
        Me.BouncingHoverButton4.SelectedColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton4.SelectedColor2 = System.Drawing.Color.Gold
        Me.BouncingHoverButton4.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton4.SelectedHoverColor1 = System.Drawing.Color.Gold
        Me.BouncingHoverButton4.SelectedHoverColor2 = System.Drawing.Color.White
        Me.BouncingHoverButton4.SelectedText = Nothing
        Me.BouncingHoverButton4.Size = New System.Drawing.Size(194, 14)
        Me.BouncingHoverButton4.TabIndex = 1
        Me.BouncingHoverButton4.Text = "Button1-Text"
        Me.BouncingHoverButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BouncingHoverButton4.UseVisualStyleBackColor = False
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.BouncingHoverButton4, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.BouncingHoverButton5, 0, 1)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(10, 10)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(200, 100)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 1
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.BouncingHoverButton7, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.BouncingHoverButton8, 0, 1)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(1)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 3
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(200, 100)
        Me.TableLayoutPanel3.TabIndex = 0
        '
        'BouncingHoverButton7
        '
        Me.BouncingHoverButton7.AlternativeGroup = Nothing
        Me.BouncingHoverButton7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BouncingHoverButton7.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton7.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton7.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton7.BorderHover = True
        Me.BouncingHoverButton7.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton7.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton7.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton7.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton7.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BouncingHoverButton7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BouncingHoverButton7.DrawBorder = True
        Me.BouncingHoverButton7.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BouncingHoverButton7.ForeColor = System.Drawing.Color.Navy
        Me.BouncingHoverButton7.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton7.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton7.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton7.Image = CType(resources.GetObject("BouncingHoverButton7.Image"), System.Drawing.Image)
        Me.BouncingHoverButton7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BouncingHoverButton7.Location = New System.Drawing.Point(3, 43)
        Me.BouncingHoverButton7.Name = "BouncingHoverButton7"
        Me.BouncingHoverButton7.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton7.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton7.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton7.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton7.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton7.SelectedText = Nothing
        Me.BouncingHoverButton7.Size = New System.Drawing.Size(194, 54)
        Me.BouncingHoverButton7.TabIndex = 51
        Me.BouncingHoverButton7.Text = " Appointement"
        Me.BouncingHoverButton7.UseVisualStyleBackColor = False
        '
        'BouncingHoverButton8
        '
        Me.BouncingHoverButton8.AlternativeGroup = Nothing
        Me.BouncingHoverButton8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BouncingHoverButton8.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton8.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton8.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton8.BorderHover = True
        Me.BouncingHoverButton8.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton8.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton8.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton8.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton8.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BouncingHoverButton8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BouncingHoverButton8.DrawBorder = True
        Me.BouncingHoverButton8.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BouncingHoverButton8.ForeColor = System.Drawing.Color.Navy
        Me.BouncingHoverButton8.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton8.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton8.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton8.Image = CType(resources.GetObject("BouncingHoverButton8.Image"), System.Drawing.Image)
        Me.BouncingHoverButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BouncingHoverButton8.Location = New System.Drawing.Point(3, 23)
        Me.BouncingHoverButton8.Name = "BouncingHoverButton8"
        Me.BouncingHoverButton8.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton8.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton8.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton8.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton8.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton8.SelectedText = Nothing
        Me.BouncingHoverButton8.Size = New System.Drawing.Size(194, 14)
        Me.BouncingHoverButton8.TabIndex = 46
        Me.BouncingHoverButton8.Text = " Visits"
        Me.BouncingHoverButton8.UseVisualStyleBackColor = False
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 1
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.BouncingHoverButton1, 0, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.BouncingHoverButton2, 0, 3)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(20, 20)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 5
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(200, 100)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'BouncingHoverButton1
        '
        Me.BouncingHoverButton1.AlternativeGroup = Nothing
        Me.BouncingHoverButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BouncingHoverButton1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton1.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton1.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton1.BorderHover = True
        Me.BouncingHoverButton1.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton1.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton1.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton1.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton1.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BouncingHoverButton1.DrawBorder = True
        Me.BouncingHoverButton1.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BouncingHoverButton1.ForeColor = System.Drawing.Color.Navy
        Me.BouncingHoverButton1.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton1.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton1.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton1.Image = CType(resources.GetObject("BouncingHoverButton1.Image"), System.Drawing.Image)
        Me.BouncingHoverButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BouncingHoverButton1.Location = New System.Drawing.Point(3, 83)
        Me.BouncingHoverButton1.Name = "BouncingHoverButton1"
        Me.BouncingHoverButton1.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton1.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton1.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton1.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton1.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton1.SelectedText = Nothing
        Me.BouncingHoverButton1.Size = New System.Drawing.Size(0, 0)
        Me.BouncingHoverButton1.TabIndex = 53
        Me.BouncingHoverButton1.Text = "Bill"
        Me.BouncingHoverButton1.UseVisualStyleBackColor = False
        '
        'BouncingHoverButton2
        '
        Me.BouncingHoverButton2.AlternativeGroup = Nothing
        Me.BouncingHoverButton2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BouncingHoverButton2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton2.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton2.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton2.BorderHover = True
        Me.BouncingHoverButton2.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton2.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton2.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton2.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton2.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BouncingHoverButton2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BouncingHoverButton2.DrawBorder = True
        Me.BouncingHoverButton2.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BouncingHoverButton2.ForeColor = System.Drawing.Color.Navy
        Me.BouncingHoverButton2.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton2.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton2.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BouncingHoverButton2.Location = New System.Drawing.Point(3, 63)
        Me.BouncingHoverButton2.Name = "BouncingHoverButton2"
        Me.BouncingHoverButton2.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton2.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton2.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton2.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton2.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton2.SelectedText = Nothing
        Me.BouncingHoverButton2.Size = New System.Drawing.Size(194, 14)
        Me.BouncingHoverButton2.TabIndex = 52
        Me.BouncingHoverButton2.Text = " Patient Visit"
        Me.BouncingHoverButton2.UseVisualStyleBackColor = False
        '
        'BouncingHoverButton9
        '
        Me.BouncingHoverButton9.AlternativeGroup = Nothing
        Me.BouncingHoverButton9.BackColor = System.Drawing.Color.White
        Me.BouncingHoverButton9.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton9.BackColor2 = System.Drawing.Color.Linen
        Me.BouncingHoverButton9.BorderHoverColor = System.Drawing.Color.Gray
        Me.BouncingHoverButton9.BorderNormalColor = System.Drawing.Color.Gray
        Me.BouncingHoverButton9.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.BouncingHoverButton9.ClickColor1 = System.Drawing.Color.Gold
        Me.BouncingHoverButton9.ClickColor2 = System.Drawing.Color.White
        Me.BouncingHoverButton9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BouncingHoverButton9.DrawBorder = True
        Me.BouncingHoverButton9.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton9.Font = New System.Drawing.Font("Comic Sans MS", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BouncingHoverButton9.HoverColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton9.HoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton9.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton9.Image = CType(resources.GetObject("BouncingHoverButton9.Image"), System.Drawing.Image)
        Me.BouncingHoverButton9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BouncingHoverButton9.Location = New System.Drawing.Point(3, 3)
        Me.BouncingHoverButton9.Name = "BouncingHoverButton9"
        Me.BouncingHoverButton9.SelectedColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton9.SelectedColor2 = System.Drawing.Color.Gold
        Me.BouncingHoverButton9.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton9.SelectedHoverColor1 = System.Drawing.Color.Gold
        Me.BouncingHoverButton9.SelectedHoverColor2 = System.Drawing.Color.White
        Me.BouncingHoverButton9.SelectedText = Nothing
        Me.BouncingHoverButton9.Size = New System.Drawing.Size(187, 1)
        Me.BouncingHoverButton9.TabIndex = 1
        Me.BouncingHoverButton9.Text = " Queue"
        Me.BouncingHoverButton9.UseVisualStyleBackColor = False
        '
        'BouncingHoverButton3
        '
        Me.BouncingHoverButton3.AlternativeGroup = Nothing
        Me.BouncingHoverButton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BouncingHoverButton3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton3.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton3.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton3.BorderHover = True
        Me.BouncingHoverButton3.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton3.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton3.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BouncingHoverButton3.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton3.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BouncingHoverButton3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BouncingHoverButton3.DrawBorder = True
        Me.BouncingHoverButton3.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BouncingHoverButton3.ForeColor = System.Drawing.Color.Navy
        Me.BouncingHoverButton3.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton3.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton3.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton3.Image = CType(resources.GetObject("BouncingHoverButton3.Image"), System.Drawing.Image)
        Me.BouncingHoverButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BouncingHoverButton3.Location = New System.Drawing.Point(3, 3)
        Me.BouncingHoverButton3.Name = "BouncingHoverButton3"
        Me.BouncingHoverButton3.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton3.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton3.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton3.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BouncingHoverButton3.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BouncingHoverButton3.SelectedText = Nothing
        Me.BouncingHoverButton3.Size = New System.Drawing.Size(194, 36)
        Me.BouncingHoverButton3.TabIndex = 51
        Me.BouncingHoverButton3.Text = " Appointement"
        Me.BouncingHoverButton3.UseVisualStyleBackColor = False
        '
        'frmApplicationMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(944, 746)
        Me.Controls.Add(Me.splitContainerLeftMain)
        Me.Controls.Add(Me.msMenu)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.KeyPreview = True
        Me.MainMenuStrip = Me.msMenu
        Me.Name = "frmApplicationMain"
        Me.Text = "B I L L I N G  �"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.splitContainerLeftMain.Panel1.ResumeLayout(False)
        Me.splitContainerLeftMain.Panel2.ResumeLayout(False)
        Me.splitContainerLeftMain.ResumeLayout(False)
        Me.scMnuItemNTitle.Panel1.ResumeLayout(False)
        Me.scMnuItemNTitle.Panel2.ResumeLayout(False)
        Me.scMnuItemNTitle.ResumeLayout(False)
        Me.pnlMenuAllLeft.ResumeLayout(False)
        Me.tblPnlMenu_Payment.ResumeLayout(False)
        Me.tblPnlMenu_Service.ResumeLayout(False)
        Me.tblPnlMenu_Transactions.ResumeLayout(False)
        Me.tblPnlMenu_Company.ResumeLayout(False)
        Me.tblPnlMenu_Client.ResumeLayout(False)
        Me.tblPnlMenu_Main.ResumeLayout(False)
        Me.tcMain.ResumeLayout(False)
        Me.tabVer.ResumeLayout(False)
        CType(Me.pbavaitionlogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pblogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picExperiance, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.msMenu.ResumeLayout(False)
        Me.msMenu.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
	Friend WithEvents splitContainerLeftMain As System.Windows.Forms.SplitContainer
	Friend WithEvents tblPnlMenu_Main As System.Windows.Forms.TableLayoutPanel
	Friend WithEvents btnMenuMain_Applications As BHBut.BouncingHoverButton
	Friend WithEvents Button8 As System.Windows.Forms.Button
	Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
	Friend WithEvents Button6 As System.Windows.Forms.Button
	Friend WithEvents Button7 As System.Windows.Forms.Button
	Friend WithEvents ETSMenu As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents msMenu As System.Windows.Forms.MenuStrip
	Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents BouncingHoverButton6 As BHBut.BouncingHoverButton
	Friend WithEvents BouncingHoverButton5 As BHBut.BouncingHoverButton
	Friend WithEvents BouncingHoverButton4 As BHBut.BouncingHoverButton
	Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
	Friend WithEvents btnMenuMain_Clients As BHBut.BouncingHoverButton
	Friend WithEvents btnMenuMain_Company As BHBut.BouncingHoverButton
	Friend WithEvents tblPnlMenu_Company As System.Windows.Forms.TableLayoutPanel
	Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
	Friend WithEvents BouncingHoverButton7 As BHBut.BouncingHoverButton
	Friend WithEvents BouncingHoverButton8 As BHBut.BouncingHoverButton
	Friend WithEvents BouncingHoverButton9 As BHBut.BouncingHoverButton
	Friend WithEvents tcMain As System.Windows.Forms.TabControl
	Friend WithEvents tblPnlMenu_Client As System.Windows.Forms.TableLayoutPanel
	Friend WithEvents btnClient_ClientList As BHBut.BouncingHoverButton
	Friend WithEvents pnlMenuAllLeft As System.Windows.Forms.Panel
	Friend WithEvents btnCompany_Company As BHBut.BouncingHoverButton
	Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
	Friend WithEvents BouncingHoverButton1 As BHBut.BouncingHoverButton
	Friend WithEvents BouncingHoverButton2 As BHBut.BouncingHoverButton
	Friend WithEvents BouncingHoverButton3 As BHBut.BouncingHoverButton
	Friend WithEvents VisitStatusQuickHelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents tlSocSecRpts As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents tlTestQueue As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents btnLogo As BHBut.BouncingHoverButton
	Friend WithEvents btnHideMenu As BHBut.BouncingHoverButton
	Friend WithEvents tsmMainMenu As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents tsmFile As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents tsmEdit As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents tsmView As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents tblPnlMenu_Transactions As System.Windows.Forms.TableLayoutPanel
	Friend WithEvents scMnuItemNTitle As System.Windows.Forms.SplitContainer
	Friend WithEvents btnCompany_Employee As BHBut.BouncingHoverButton
	Friend WithEvents btnMenuMain_Reports As BHBut.BouncingHoverButton
	Friend WithEvents picExperiance As System.Windows.Forms.PictureBox
	Friend WithEvents btnRestoreNavMenu As BHBut.BouncingHoverButton
	Friend WithEvents pblogo As System.Windows.Forms.PictureBox
	Friend WithEvents tabVer As System.Windows.Forms.TabPage
	Friend WithEvents lblVer As System.Windows.Forms.Label
	Friend WithEvents btnCompany_Department As BHBut.BouncingHoverButton
	Friend WithEvents btnCompany_Area As BHBut.BouncingHoverButton
	Friend WithEvents tblPnlMenu_Service As System.Windows.Forms.TableLayoutPanel
	Friend WithEvents btnService_Rate As BHBut.BouncingHoverButton
	Friend WithEvents btnService_Service As BHBut.BouncingHoverButton
	Friend WithEvents btnMainMenu_Services As BHBut.BouncingHoverButton
    Friend WithEvents BranchBillingInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnTransactions_OverDueInvoice As BHBut.BouncingHoverButton
	Friend WithEvents pbavaitionlogo As System.Windows.Forms.PictureBox
	Friend WithEvents lblrepublic As System.Windows.Forms.Label
	Friend WithEvents lbldgca As System.Windows.Forms.Label
	Friend WithEvents btnAutoInvPrep As BHBut.BouncingHoverButton
	Friend WithEvents btnTransactions_ImportTransactions As BHBut.BouncingHoverButton
	Friend WithEvents btnTransactions_Invoice As BHBut.BouncingHoverButton
	Friend WithEvents btnOverFlightPrep As BHBut.BouncingHoverButton
	Friend WithEvents btnTransactions_Bill As BHBut.BouncingHoverButton
	Friend WithEvents btnMessage As BHBut.BouncingHoverButton
	Friend WithEvents btnUserPreferences As BHBut.BouncingHoverButton
	Friend WithEvents btnMenuMain_Payment As BHBut.BouncingHoverButton
	Friend WithEvents tblPnlMenu_Payment As System.Windows.Forms.TableLayoutPanel
	Friend WithEvents btnTransactions_ClearCheck As BHBut.BouncingHoverButton
	Friend WithEvents btnTransactions_Payment As BHBut.BouncingHoverButton
    Friend WithEvents btnTransactions_ImportOverFlight As BHBut.BouncingHoverButton
    Friend WithEvents lblVersinDate As System.Windows.Forms.Label
    Friend WithEvents btnCloseWindows As System.Windows.Forms.Button
    'System.Windows.Forms.Button
End Class
