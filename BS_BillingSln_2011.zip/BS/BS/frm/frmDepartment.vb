''Imports Section
Imports BITSConn
Imports System.Text.RegularExpressions
Public Class frmDepartment
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '' VARs Declaration...
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
#Region "Declarations"

   Dim Nav As BitsNav

   Dim clsMr As ClsMain
   Dim daDepartment As SqlClient.SqlDataAdapter ''Adapter for the master Table 
   '' Form Vars...
   Private blnLoading As Boolean = True   '' Used to flag when loading form (T/F)...
   Dim mStrtableName As String = "tblDepartment" '' master Table
   Dim StrSql As String = "SELECT * from tblDepartment"
   Dim dsdata As New DataSet
   Dim DataChange As Boolean = False
   Private mStrCurrentState As String
   Private AddMode As Boolean

#End Region

    Private Sub frmDepartment_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''
        '' indicate start-of-loading...

        clsMr = New ClsMain(conSql)
        Nav = New BitsNav

        blnLoading = True
        MakeDataAdapter()
        FillComboBox()
        SetAutoNumber()
        SetDataBinding()
        SetCurrencyManager()
        blnLoading = False

    End Sub
   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
   '' COMMON SECTION - STANDARD DATA CONNECTION...
   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
   Public Sub MakeDataAdapter()

      daDepartment = clsMr.BuildSqlAdapter(StrSql, mStrtableName)
      'clsMr.BuildSqlAdapter("SELECT LocationID,DptID, Bldg,Flr,Room,MailDrop  From tblLocation", "daLocation")
      clsMr.BuildSqlAdapter("SELECT dbo.tblEmployee.EmployeeID, dbo.tblEmployee.FName + ' ' + dbo.tblEmployee.MName + ' ' + dbo.tblEmployee.LName AS Name FROM tblEmployee", "EmployeeName")
        clsMr.BuildSqlAdapter("SELECT AreaID from tblArea where Del = 0 ", "Area")
      dsdata = clsMr.getDataSet

   End Sub
   ''Fill Combobox
   Public Sub FillComboBox()
      clsMr.FillComboBox(mStrtableName, Me.lstDepartment, "LongName", "DptID")
      clsMr.FillComboBox("Area", Me.CboArea, "AreaName", "AreaID")
   End Sub
   ''Set AutoNumber
   Public Sub SetAutoNumber()
      clsMr.SetAutoNumber(mStrtableName, "DptID")
   End Sub
   ''Set CurrencyManager
   Public Sub SetCurrencyManager()
      nav.SetCurrency(Me, clsMr.getDataSet(), mStrtableName)
   End Sub
   ''SetDataBinding
   Public Sub SetDataBinding()
      clsMr.BindTextBox(txtID, mStrtableName, "DptID")
      clsMr.BindTextBox(txtShortName, mStrtableName, "ShortName")
      clsMr.BindTextBox(txtLongName, mStrtableName, "LongName")
		clsMr.BindTextBox(txtCode, mStrtableName, "DptCode")
		clsMr.BindComboBox(CboArea, mStrtableName, "AreaID")
      clsMr.BindTextBox(txtTel, mStrtableName, "Tel")
      clsMr.BindTextBox(txtExt, mStrtableName, "Ext")
      clsMr.BindTextBox(txtEmail, mStrtableName, "Email")

    End Sub

   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
   '' END OF COMMON SECTION - STANDARD DATA CONNECTION...
   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

#Region "Functions"

   Private Sub SetStatus(ByVal pBlnStatus As Boolean)
      btnNew.Enabled = Not (pBlnStatus)
      btnSave.Enabled = Not (pBlnStatus)
      btnCancel.Enabled = (pBlnStatus)
      grpList.Enabled = Not (pBlnStatus)
      grpInfo.Enabled = pBlnStatus
   End Sub
   Private Sub setState(ByRef pStrMode As String)
      ''
      mStrCurrentState = UCase(pStrMode)
      '' 
      Select Case mStrCurrentState
         Case Is = "NEW"

            Me.btnSave.Enabled = False
            Me.btnCancel.Enabled = True
            Me.btnNew.Enabled = False
            grpInfo.Enabled = True
            btnSave.Text = "S a v e"
            AddMode = True

         Case Is = "EDIT"

            Me.btnSave.Enabled = False
            Me.btnCancel.Enabled = True
            Me.btnNew.Enabled = False
            grpInfo.Enabled = True
            btnSave.Text = "S a v e"
				btnEmployee.Enabled = True
         Case Is = "SAVE"

            Me.btnSave.Enabled = True
            Me.btnCancel.Enabled = False
            Me.btnNew.Enabled = True
            btnSave.Text = "E d i t"
				btnEmployee.Enabled = False
            grpInfo.Enabled = False

            AddMode = False
         Case Is = "BROWSE"

            Me.btnSave.Enabled = True
            Me.btnCancel.Enabled = False
            Me.btnNew.Enabled = True
            btnSave.Text = "E d i t"
            grpInfo.Enabled = False
      End Select
   End Sub
#End Region

#Region "UI Methods"
   
   Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
      Nav.AddNew()
      setState("New")
      CheckValues()
      btnSave.Text = "Save"

   End Sub

   Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

      If btnSave.Text = "E d i t" Then
         setState("EDIT")
         Exit Sub
      End If
      save()
      setState("SAVE")
   End Sub
   Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
      '' check OK to close...
      If DataChange Then
         Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
            Case MsgBoxResult.Yes
               '' call save...
               If lstDataErr.Items.Count <> 0 Then
                  MsgBox("Cannot save.Please check error list")
                  Exit Sub
               Else
                  save()
                  Me.Close()
               End If
            Case MsgBoxResult.No
               '' ignore changes...

               Try
                  Nav.CancelCurrentEdit()
               Catch ex As Exception

               End Try
               Me.Close()
            Case MsgBoxResult.Cancel
               '' ignore close press..
               '' do nothing...

         End Select
      Else
         Me.Close()
      End If



   End Sub

#End Region

   Private Sub save()
      ''Save tblDepartment
   DataChange = False
      Nav.EndCurrentEdit()
      daDepartment.Update(dsdata, mStrtableName)
   End Sub

   Private Sub txtSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSearch.TextChanged

      If rdbContains.Checked = True Then
         dsdata.Tables("tblDepartment").DefaultView.RowFilter = "LongName LIKE '%" & txtSearch.Text & "%'"
      Else
         dsdata.Tables("tblDepartment").DefaultView.RowFilter = "LongName LIKE '" & txtSearch.Text & "%'"
      End If

   End Sub

#Region "CheckValues"
   Private Function checkValues() As Boolean

      If blnLoading = True Then Exit Function
      clearList()
      DataChange = True

      If txtCode.Text = String.Empty Then
         lstDataErr.Items.Add("Please write the code of the department")
      End If

      If txtLongName.Text = String.Empty Then
         lstDataErr.Items.Add("Please write the Long Name of the department")
      End If

      If txtShortName.Text = String.Empty Then
         lstDataErr.Items.Add("Please write the Short Name of the department")
      End If

      If txtTel.Text = String.Empty Then
         lstDataErr.Items.Add("Please write the Telephone Number of the department")
      End If


      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '' Set appropriate controls based on errors check results...
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      If lstDataErr.Items.Count = 0 Then
         lstDataErr.Visible = False
         btnDataErr.Visible = False
         btnSave.Enabled = True
      Else
         btnDataErr.Visible = True
         btnSave.Enabled = False
      End If
   End Function


   Private Sub clearList()
      Dim i As Integer

      For i = 0 To lstDataErr.Items.Count - 1
         lstDataErr.Items.RemoveAt(lstDataErr.Items.Count - 1)
      Next

   End Sub

   Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
      '' Show/Hide error list...
      If lstDataErr.Visible = True Then
         lstDataErr.Visible = False
      Else
         lstDataErr.Visible = True
         lstDataErr.Height = 100
         lstDataErr.BringToFront()
      End If
   End Sub
   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

      If DataChange Then
         If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            Try
               Nav.CancelCurrentEdit()
            Catch ex As Exception

            End Try

            DataChange = False
            AddMode = False

         End If
      Else

         'AddMode = False
      End If




      setState("BROWSE")

   End Sub

#End Region

   Private Sub txtLongName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLongName.TextChanged
      checkValues()
   End Sub

   Private Sub txtShortName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtShortName.TextChanged
      checkValues()
   End Sub

   Private Sub txtCode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCode.TextChanged
      checkValues()
   End Sub

   Private Sub CboEmployee_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
      checkValues()
   End Sub

   Private Sub txtTel_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtTel.TextChanged
      checkValues()

   End Sub
   Private Sub lstDepartment_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstDepartment.SelectedIndexChanged
      DataChange = False

   End Sub

   Private Sub txtExt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtExt.TextChanged
      checkValues()

   End Sub

   Private Sub txtEmail_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtEmail.TextChanged
      checkValues()

   End Sub

   Private Sub CboArea_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboArea.SelectedIndexChanged
      checkValues()

   End Sub

    Private Sub btnEmployee_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmployee.Click
        If Not lstDepartment.SelectedValue Is Nothing Then

            Dim frm As New frmEmployeeV1(lstDepartment.SelectedValue)
            frm.ShowDialog()

        End If

    End Sub

#Region "Permissions.."
    ''Done by Mohamad March, 2008''

    'Telephone'
    Private Sub txtTel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtTel.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Extension'
    Private Sub txtExt_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtExt.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Email'
    Private Sub txtEmail_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEmail.Leave
        Dim Pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim EmailAddressMatch As Match = Regex.Match(txtEmail.Text, Pattern)

        If EmailAddressMatch.Success = True Then
            'Do Nothing
        Else
            MsgBox("Invalid Email Address")
            txtEmail.Text = ""
        End If
    End Sub

#End Region

End Class


