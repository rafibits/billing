''
Public Class frmApplicationMain

#Region " Form - Declaration . . . . "
	''
	Dim dsData As DataSet
	Dim clsMr As BITSConn.ClsMain
	Dim blnLoading As Boolean
	Private mPermissionsSystemID As Integer = 2
	''

	Enum eFormType
		'' these should be first, same as in DGCA Sol
		Area
		AreaType
		Department
		Zone
		Employee
		ClEmployee
		Company
		Client
		ClientList
		ClientItem
		Investment
		ClientEmployee
		ClientEmployeeGet
		''
		category
		OverFlight
		Transactions
		BranchBillingInfo
		Service
		ServiceList
		ClientClass
		Message
		Rate
		InvoiceList
		OverDueInvoiceList
		BillList
		InvoicePrepare
		Invoice
		Payment
		ClientGet
		ServiceGet
		ContractList
		Contract
		Report
		CheckClearing
		PaymentList
		ImportOverFlight
		CorrectedInvoice
		CorrectedPayment
	End Enum

#End Region


#Region " Form Initialization . . . "

    Private Sub frmApplicationMain_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmApplicationMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ''
        appMain = Me
        ''
        activateMenuGrp(tblPnlMenu_Client, btnMenuMain_Clients)
        splitContainerLeftMain.SplitterDistance = 170
        ''
        blnLoading = True
        ''
        clsMr = New BITSConn.ClsMain(conSql)
        MakeDataAdapter()
        ''
        '' btnRestor is showing like an err...
        loadUserLevelPermission()
        ''
        lblVer.Text = "Version " & Application.ProductVersion
        ''
        AddHandler DGCA.clsShared.OpenForm, AddressOf OpenForm
        btnRestoreNavMenu.Visible = False
    End Sub

    Private Sub OpenForm(ByVal frm As Form, ByVal frmType As DGCA.clsShared.eFormType)
        appMain.addTabPage(frm, frmType)
    End Sub

    Private Sub MakeDataAdapter()
        ''
        clsMr.BuildSqlAdapter("SELECT * FROM tblPermissions WHERE UserLevelID = " & gUserLevel & " AND PermissionsSystemID = " & mPermissionsSystemID, "tblPermissions")
        ''
        dsData = clsMr.getDataSet
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

    End Sub

#End Region


#Region " Main Menu..."
	''
	Private Sub btnMenuMain_Accounts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenuMain_Clients.Click
		activateMenuGrp(tblPnlMenu_Client, btnMenuMain_Clients)
	End Sub

	Private Sub btnMenuMain_Transactions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenuMain_Applications.Click
		activateMenuGrp(tblPnlMenu_Transactions, btnMenuMain_Applications)
	End Sub

	Private Sub btnMenuMain_Company_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenuMain_Company.Click
		activateMenuGrp(tblPnlMenu_Company, btnMenuMain_Company)
	End Sub

	Private Sub btnMainMenu_Services_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMainMenu_Services.Click
		activateMenuGrp(tblPnlMenu_Service, btnMainMenu_Services)
	End Sub

#End Region


#Region " Client Menu . . ."

	Private Sub btnClient_ClientList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClient_ClientList.Click
		Dim frm As New DGCA.frmClientList
		addTabPage(frm, eFormType.ClientList)
	End Sub

#End Region


#Region " Transactions Menu..."

	Private Sub btnTransactions_Invoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransactions_Invoice.Click
		''
		Dim frm As New frmInvoiceList()
		addTabPage(frm, eFormType.InvoiceList)
		''
		resetButtons("Transactions")
		btnTransactions_Invoice.Selected = True
	End Sub

	Private Sub btnTransactions_Payment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransactions_Payment.Click

		'Dim frm As New frmPayment
		'addTabPage(frm, eFormType.Payment)
		Dim frm As New frmPaymentList
		addTabPage(frm, eFormType.PaymentList)

	End Sub

	Private Sub btnTransactions_ClearCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransactions_ClearCheck.Click

		Dim frm As New frmCheckClearing
		addTabPage(frm, eFormType.CheckClearing)

	End Sub

	Private Sub btnTransactions_OverDueInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransactions_OverDueInvoice.Click
		''
		Dim frm As New frmOverDueInvoiceList()
		addTabPage(frm, eFormType.OverDueInvoiceList)
		''
		resetButtons("Transactions")
		btnTransactions_OverDueInvoice.Selected = True

	End Sub

#End Region


#Region " Service Menu . . ."

	Private Sub btnService_Service_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnService_Service.Click
		Dim frm As New frmServiceList
		If addTabPage(frm, eFormType.ServiceList) Then
		End If
		frm.Text = "Service List"
		resetButtons("Service List")
	End Sub

	Private Sub btnService_Rate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnService_Rate.Click
		Dim frm As New frmCategory
		addTabPage(frm, eFormType.category)
	End Sub

    'Private Sub btnContractList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnContractList.Click
    '	Dim frm As New frmContractList
    '	addTabPage(frm, eFormType.ContractList)
    'End Sub

#End Region


#Region " Company . . . "

	Private Sub btnCompany_Employee_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompany_Employee.Click
		''
		Dim frm As New DGCA.frmEmployeeV1
		addTabPage(frm, eFormType.Employee)

		''
		resetButtons("Company")
		btnCompany_Employee.Selected = True
	End Sub

	Private Sub btnCompany_MakeModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		''
		'Dim frm As New frmMakeModel
		'If addTabPage(frm, eFormType.MakeModel) Then
		'	frm.Text = "Make Model"
		'End If
		' ''
		'resetButtons("Company")
		'btnCompany_MakeModel.Selected = True
		''
	End Sub

	Private Sub btnCompany_Currency_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		' ''
		'Dim frm As New frmCurrency
		'If addTabPage(frm, eFormType.Currency) Then
		'	frm.Text = "Currency"
		'End If
		' ''
		'resetButtons("Company")
		'btnCompany_Currency.Selected = True
		' ''
	End Sub


	Private Sub btnCompany_Department_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompany_Department.Click
		''
		Dim frm As New DGCA.frmDepartment
		frm.Text = "Department"
		If addTabPage(frm, eFormType.Department) Then

		End If
		' ''
		resetButtons("Company")
		'	btnCompany_Bank.Selected = True

	End Sub

	Private Sub btnCompany_Company_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompany_Company.Click
		''
		Dim frm As New DGCA.frmCompany
		If addTabPage(frm, eFormType.Company) Then
			frm.Text = "DGCA"
		End If
		''
		resetButtons("Company")
		btnCompany_Company.Selected = True
		''
	End Sub

	Private Sub btnCompany_Area_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompany_Area.Click
		'
		Dim frm As New DGCA.frmArea
		addTabPage(frm, eFormType.Area)
		frm.Text = "Area"
	End Sub

#End Region


#Region " Form Function . . . "

	Public Function addTabPage(ByVal frm As Form, ByVal frmType As eFormType) As Boolean
		'' set mousePointer to wait...
		Windows.Forms.Cursor.Current = Cursors.WaitCursor
		''
		Dim title As String = ""
		addTabPage = False
		''
		Select Case frmType
			''
			Case eFormType.Company
				AddHandler CType(frm, DGCA.frmCompany).Closed, AddressOf closeModelTabPage
				title = "DGCA"
				''
			Case eFormType.ClientEmployee
				AddHandler CType(frm, DGCA.frmClientEmployee).Closed, AddressOf closeModelTabPage
				title = "Client Employee"
				''
			Case eFormType.ClientEmployeeGet
				AddHandler CType(frm, DGCA.frmClientEmployee).Closed, AddressOf closeModelTabPage
				title = "Client Employee"
				''
			Case eFormType.Department
				AddHandler CType(frm, DGCA.frmDepartment).Closed, AddressOf closeModelTabPage
				title = "Department"

			Case eFormType.Message
				AddHandler CType(frm, frmMessage).Closed, AddressOf closeModelTabPage
				title = "Message"

			Case eFormType.Employee
				AddHandler CType(frm, DGCA.frmEmployeeV1).Closed, AddressOf closeModelTabPage
				title = "Employee"

			Case eFormType.Area
				AddHandler CType(frm, DGCA.frmArea).Closed, AddressOf closeModelTabPage
				title = "Area"

                'Case eFormType.Rate
                '	AddHandler CType(frm, frmRate).Closed, AddressOf closeModelTabPage
                '	title = "Rate"
			Case eFormType.ClientList
				AddHandler CType(frm, DGCA.frmClientList).Closed, AddressOf closeModelTabPage
				title = "Client List"

			Case eFormType.ClientItem
				AddHandler CType(frm, DGCA.frmClientItem).Closed, AddressOf closeModelTabPage
				title = "Client Item"

			Case eFormType.ServiceList
				AddHandler CType(frm, frmServiceList).Closed, AddressOf closeModelTabPage
				title = "Service List"

			Case eFormType.Service
				AddHandler CType(frm, frmService).Closed, AddressOf closeModelTabPage
				title = "Service"

			Case eFormType.Payment
				AddHandler CType(frm, frmPayment).Closed, AddressOf closeModelTabPage
				title = "Payment"

			Case eFormType.PaymentList
				AddHandler CType(frm, frmPaymentList).Closed, AddressOf closeModelTabPage
				title = "Payment List"

			Case eFormType.category
				AddHandler CType(frm, frmCategory).Closed, AddressOf closeModelTabPage
				title = "Service Category"

			Case eFormType.Invoice
				AddHandler CType(frm, frmInvoice).Closed, AddressOf closeModelTabPage
				title = "Invoice"

			Case eFormType.InvoiceList
				AddHandler CType(frm, frmInvoiceList).Closed, AddressOf closeModelTabPage
				title = "Invoice List"

			Case eFormType.OverDueInvoiceList
				AddHandler CType(frm, frmOverDueInvoiceList).Closed, AddressOf closeModelTabPage
				title = "OverDue Invoice List"

			Case eFormType.BillList
				AddHandler CType(frm, frmBillList).Closed, AddressOf closeModelTabPage
				title = "Bill List"

			Case eFormType.ClientGet
				AddHandler CType(frm, frmClientGet).Closed, AddressOf closeModelTabPage
				title = "Client List"

			Case eFormType.ServiceGet
				AddHandler CType(frm, frmServiceGet).Closed, AddressOf closeModelTabPage
				title = "Service List"

                'Case eFormType.ContractList
                '	AddHandler CType(frm, frmContractList).Closed, AddressOf closeModelTabPage
                '	title = "ContractList"
                'Case eFormType.Contract
                '	AddHandler CType(frm, frmContract).Closed, AddressOf closeModelTabPage
                '	title = "Contract"
			Case eFormType.Report
				AddHandler CType(frm, frmReport).Closed, AddressOf closeModelTabPage
				title = "Report"
			Case eFormType.Client
				AddHandler CType(frm, DGCA.frmClient_V1).Closed, AddressOf closeModelTabPage
				title = "Client"
				''
			Case eFormType.ClEmployee
				AddHandler CType(frm, DGCA.frmClEmployeeList).Closed, AddressOf closeModelTabPage
				title = "Client Employee List"
				''
			Case eFormType.InvoicePrepare
				AddHandler CType(frm, frmInvoicePrepare).Closed, AddressOf closeModelTabPage
				title = "Invoice Preparation"

			Case eFormType.BranchBillingInfo
                AddHandler CType(frm, DGCA.frmBranchBillingInfo).Closed, AddressOf closeModelTabPage
				title = "Branch Billing Information"


			Case eFormType.CheckClearing
				AddHandler CType(frm, frmCheckClearing).Closed, AddressOf closeModelTabPage
				title = "Check Clear"

			Case eFormType.Transactions
				AddHandler CType(frm, frmTransaction).Closed, AddressOf closeModelTabPage
				title = "Import Transactions"

			Case eFormType.OverFlight
				AddHandler CType(frm, frmOverFlightTransactionPreparation).Closed, AddressOf closeModelTabPage
				title = "OverFlight"
				''

			Case eFormType.ImportOverFlight
				AddHandler CType(frm, frmOverFlight).Closed, AddressOf closeModelTabPage
				title = "Import OverFlight"
				''

			Case eFormType.CorrectedInvoice
				AddHandler CType(frm, frmInvoice).Closed, AddressOf closeModelTabPage
				title = "Invoice Corrected"
				''
		End Select
		''
		'' if item is open, already exit...

		Dim i As Integer
		For i = 0 To tcMain.Controls.Count - 1
			If tcMain.TabPages.Item(i).Text Is title Then
				'tcMain.TabPages.Remove(tcMain.TabPages.Item(i))
				tcMain.SelectedTab = tcMain.TabPages.Item(i)
				Exit Function
			End If
		Next

		'' go open item in a new tab...
		Dim tp As New TabPage
		''tp = New TabPage
		tp.Text = title
		tcMain.TabPages.Add(tp)
		''
		frm.TopLevel = False
		frm.FormBorderStyle = Windows.Forms.FormBorderStyle.None
		frm.Dock = DockStyle.Fill
		frm.Visible = True
		''
		'' add it to main tab control...
		tp.Controls.Add(frm)
		tcMain.SelectedTab = tp
		''
		'' set defaults...
		''
		Windows.Forms.Cursor.Current = Cursors.Default
		addTabPage = True
	End Function

	Private Sub CloseTabPage(ByVal sender As Object, ByVal e As System.EventArgs)
		Dim tp As TabPage

		tp = CType(sender, Form).Parent
		tcMain.TabPages.Remove(tp)
	End Sub

	Public Sub addModelTabPage(ByVal frm As Form, ByVal frmType As eFormType)

		'' disable all tabs + navigation menu + menubar
		Dim tp As TabPage

		For Each tp In tcMain.TabPages
			tp.Enabled = False
		Next

		'tblPnlMenu_Accounts.Enabled = False

		Dim mi As MenuItem

		For Each mi In msMenu.Items
			mi.Enabled = False
		Next

		'' add tab
		If addTabPage(frm, frmType) Then
		End If

	End Sub

	Private Sub closeModelTabPage(ByVal sender As Object, ByVal e As System.EventArgs)
		''
		Dim tp As TabPage
		''
		tp = CType(sender, Form).Parent
		tcMain.TabPages.Remove(tp)

		'' enable all tabs + navigation menu + menubar
		For Each tp In tcMain.TabPages
			tp.Enabled = True
		Next
		''
		tblPnlMenu_Client.Enabled = True
		''
		'Dim mi as MenuItem
		Dim mi As ToolStripItem
		''
		For Each mi In msMenu.Items
			mi.Enabled = True
		Next

		tcMain.SelectedIndex = tcMain.TabCount - 1

	End Sub

	Private Sub resetGrpBtns()
		''
		'' hide Main btns... 
		Me.btnMenuMain_Clients.Selected = False
		Me.btnMenuMain_Applications.Selected = False
		Me.btnMenuMain_Company.Selected = False
		Me.btnMenuMain_Payment.Selected = False
		Me.btnMenuMain_Reports.Selected = False

		'' refresh btns.. after selection

		btnMenuMain_Clients.Refresh()
		btnMenuMain_Applications.Refresh()
		btnMenuMain_Company.Refresh()
		btnMenuMain_Payment.Refresh()
		btnMenuMain_Reports.Refresh()
	End Sub

	Private Sub resetButtons(ByVal tag As String)
		''
		'' reset the selected Color of the buttons
		'' inorder to highlight 
		'' gets the tag value of the tblPanelMenu and perform action on its buttons
		''
		Select Case (tag)
			''
			'Case ("Service")

			'   .Selected = False
			'   btnService_Service.Refresh()


			Case ("Service List")
				btnService_Service.Selected = False
				btnService_Service.Refresh()

			Case ("Client")
				btnClient_ClientList.Selected = False
				btnClient_ClientList.Refresh()
				''

			Case ("Applications")
				btnTransactions_Invoice.Selected = False


			Case ("Company")

				btnCompany_Department.Selected = False
				btnCompany_Company.Selected = False
				btnCompany_Area.Selected = False
				btnCompany_Employee.Selected = False
				''


				btnCompany_Company.Refresh()
				btnCompany_Area.Refresh()
				btnCompany_Employee.Refresh()


				''

		End Select
	End Sub

	Private Sub activateMenuGrp(ByRef pGrpName As TableLayoutPanel, ByRef pBtnName As BHBut.BouncingHoverButton)
		''
		'' hide groups... 
		''
		Me.tblPnlMenu_Client.Visible = False
		Me.tblPnlMenu_Transactions.Visible = False
		Me.tblPnlMenu_Service.Visible = False
		Me.tblPnlMenu_Company.Visible = False
		Me.tblPnlMenu_Payment.Visible = False

		''
		'' show reqstd...
		pGrpName.Visible = True
		pGrpName.Dock = DockStyle.Top
		'' 
		'' refresh :: Ligth generated after btns.. Selection
		resetGrpBtns()
		''
		pBtnName.Selected = True
	End Sub

	Private Sub showHidePanels(ByVal pGrpName As TableLayoutPanel)
		''
		If pGrpName.Width <= 24 Then
			pGrpName.Width = 195
		Else
			pGrpName.Width = 24
		End If
	End Sub

#End Region


#Region " UI-Events . . . "

	Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
		Me.Close()
	End Sub

	Private Sub btnHideMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHideMenu.Click
		Static isPanleWidth As Int16
		Static isPanleOpen As Boolean = True

		'' go smaller/wider direction...
		If isPanleOpen Then
			'pnlMenuAllLeft.Width = isPanleWidth
			Me.splitContainerLeftMain.SplitterDistance = 26
			btnHideMenu.Text = ">>"
			btnRestoreNavMenu.Visible = True
		Else
			isPanleWidth = pnlMenuAllLeft.Width
			'pnlMenuAllLeft.Width = 12
			Me.splitContainerLeftMain.SplitterDistance = 170
			btnHideMenu.Text = "<<"
			btnRestoreNavMenu.Visible = False
		End If
		' ''
		' '' switch state...
		isPanleOpen = Not isPanleOpen
	End Sub

	Private Sub tsmFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmFile.Click
		Me.Close()
	End Sub

	Private Sub btnRestoreNavMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRestoreNavMenu.Click
		Me.btnHideMenu.PerformClick()
	End Sub

	'Private Sub ContractToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ContractToolStripMenuItem.Click
	'   Dim frm As New frmContract
	'   frm.Show()

	'End Sub

	Private Sub BranchBillingInfoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BranchBillingInfoToolStripMenuItem.Click
		Dim frm As New frmBranchBillingInfo
		frm.Show()

	End Sub

	Private Sub btnMenuMain_Reports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenuMain_Reports.Click
		Dim frm As New frmReport
		addTabPage(frm, eFormType.Report)
		Me.tblPnlMenu_Client.Visible = False
		Me.tblPnlMenu_Transactions.Visible = False
		Me.tblPnlMenu_Service.Visible = False
		Me.tblPnlMenu_Company.Visible = False
	End Sub

	Private Sub btnAutoInvPrep_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAutoInvPrep.Click
        ''
        Dim frm As New frmInvoicePrepare
        appMain.addTabPage(frm, eFormType.InvoicePrepare)
    End Sub

    Private Sub btnCompany_BranchBillingInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        Dim frm As New DGCA.frmBranchBillingInfo ' frmBranchBillingInfo
        addTabPage(frm, eFormType.BranchBillingInfo)
    End Sub

	Private Sub btnTransactions_ImportTransactions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransactions_ImportTransactions.Click
		''
		Dim res As MsgBoxResult
		res = MsgBox("Are you Sure you want To Import Data?", MsgBoxStyle.YesNo)
		''
		Select Case res

			Case MsgBoxResult.Yes
				Dim frm As New frmTransaction
				addTabPage(frm, eFormType.Transactions)

			Case MsgBoxResult.No
				Exit Sub

		End Select
	End Sub

	Private Sub btnTransactions_ImportOverFlight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransactions_ImportOverFlight.Click
		''
		Dim res As MsgBoxResult
		res = MsgBox("Are you Sure you want To Import Data?", MsgBoxStyle.YesNo)
		''
		Select Case res
			''
			Case MsgBoxResult.Yes
				Dim frm As New frmOverFlight
				addTabPage(frm, eFormType.ImportOverFlight)
				''
			Case MsgBoxResult.No
				Exit Sub
		End Select
	End Sub

	Private Sub btnOverFlightPrep_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOverFlightPrep.Click

		''
		Dim frm As New frmOverFlightTransactionPreparation
		addTabPage(frm, eFormType.OverFlight)
		''
	End Sub

	Private Sub btnTransactions_Bill_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransactions_Bill.Click

		Dim frm As New frmBillList()
		addTabPage(frm, eFormType.BillList)
		''
		resetButtons("Transactions")
		btnTransactions_Invoice.Selected = True
	End Sub

	Private Sub btnMessage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMessage.Click
		Dim frm As New frmMessage
		addTabPage(frm, eFormType.Message)
	End Sub

	Private Sub btnUserPreferences_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUserPreferences.Click
		Dim frm As New frmUserPreferences
		frm.ShowDialog()
	End Sub

	Private Sub btnMenuMain_Payment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenuMain_Payment.Click
		activateMenuGrp(tblPnlMenu_Payment, btnMenuMain_Payment)

	End Sub

	Private Sub btnClient_ClientItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		''
		Dim frm As New DGCA.frmClientItem(1)
		addTabPage(frm, eFormType.ClientItem)

	End Sub

#End Region


#Region " Form - User Permissions . ."

	Private Sub loadUserLevelPermission()
		''
		If dsData.Tables("tblPermissions").Rows.Count = 0 Then
			BuildPermissions_BTN(Me)
		End If

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' get-apply Permissions...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		recursiveSetPermissions(Me)

	End Sub

	Private Sub recursiveSetPermissions(ByVal pObj As Object)
		''
		'' OBJs
		''
		Dim ctrl As Control
		''
		'' Loop through all ctrls in given object
		'' if obj has controls collection then recursIT... 
		''
		For Each ctrl In pObj.Controls
			'' IF BTNs...
			If TypeOf (ctrl) Is BHBut.BouncingHoverButton Then
				''
				'' Filter table for curr BTN + Set... 
				''
				With dsData.Tables("tblPermissions").DefaultView
					.RowFilter = "ObjectName = '" & ctrl.Name & "'"
					''
					If .Count > 0 Then
						''
						'' chk/Set Visible...
						''
						If .Item(0)("IsVisible") Then
							ctrl.Visible = True
						Else
							ctrl.Visible = False
						End If
						ctrl.Visible = .Item(0)("IsVisible")

						''
						'' chk/Set Enable...
						''
						If .Item(0)("IsEnabled") Then
							ctrl.Enabled = True
						Else
							ctrl.Enabled = False
						End If
					End If
				End With

			ElseIf ctrl.Controls.Count > 0 Then
				recursiveSetPermissions(ctrl)
			End If
		Next

	End Sub

	Private Sub BuildPermissions_BTN(ByVal pObj As Object)
		''
		'' OBJs
		''
		Dim ctrl As Control
		''
		'' Loop through all ctrls in given object
		'' if obj has controls collection then recursIT... 
		''
		For Each ctrl In pObj.Controls
			strSQL &= ":" & ctrl.Name
			''
			'' Chk If BTNs...
			''
			If TypeOf (ctrl) Is BHBut.BouncingHoverButton Then
				''
				'' Insert...
				''
				InsertNewPermission(ctrl.Name, 0)	'' 0 means Main , 1 means sub Main 

			ElseIf ctrl.Controls.Count > 0 Then
				BuildPermissions_BTN(ctrl)
			End If
		Next

	End Sub

	Private Sub BuildPermissions_MNU()
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''
		'' loop through mnu
		''
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		For Each x As Object In msMenu.Items
			'' insert main-menu item...
			InsertNewPermission(x.text, 1) '' 0 means Main , 1 means sub Main 

			For Each y As Object In x.items
				'' insert menu item...
				InsertNewPermission(y.text, 0) '' 0 means Main , 1 means sub Main 
			Next
		Next
	End Sub

	Private Sub InsertNewPermission(ByVal pObjName As String, ByVal pMain As Int16)
		''
		'' SpSetMenuPermissionTable()
		'' INSERT INTO tblPermissions VALUES (@MAXID, gUserLevel, @MenuName, 1, 1, 1, @Main)
		''
		Dim cmdSQL As New SqlClient.SqlCommand("spInsertNewPermission", conSql)
		''
		cmdSQL.CommandType = CommandType.StoredProcedure
		cmdSQL.Parameters.Add("@PermissionsSystemID", SqlDbType.SmallInt).Value = mPermissionsSystemID
		cmdSQL.Parameters.Add("@UserLevel", SqlDbType.SmallInt).Value = gUserLevel
        cmdSQL.Parameters.Add("@MenuName", SqlDbType.NVarChar).Value = pObjName
        cmdSQL.Parameters.Add("@Main", SqlDbType.Bit).Value = pMain
        cmdSQL.Parameters.Add("@FormName", SqlDbType.NVarChar).Value = "Main Form Billing"
        ''
		conSql.Open()
		cmdSQL.ExecuteNonQuery()
		conSql.Close()
	End Sub

#End Region


    
    Private Sub btnCloseWindows_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseWindows.Click
        If tcMain.Controls.Count = 1 Then Exit Sub
        ''
        Dim res As MsgBoxResult

        If gStrLang = "en" Then
            res = MsgBox("Are you sure you want to close all open forms?", MsgBoxStyle.Critical + MsgBoxStyle.YesNo, "Billing")
        Else
            res = MsgBox("�� ��� ����� �� ����� ���� ������п", MsgBoxStyle.Critical + MsgBoxStyle.YesNo, "Billing")
        End If

        If res = MsgBoxResult.Yes Then
            Dim i As Integer
            ''
            For i = 1 To tcMain.Controls.Count - 1
                tcMain.TabPages.RemoveAt(1)
            Next
        End If
    End Sub

End Class