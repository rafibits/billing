<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBranchBillingInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.txtID = New System.Windows.Forms.TextBox
        Me.txtBankName = New System.Windows.Forms.TextBox
        Me.txtSwift = New System.Windows.Forms.TextBox
        Me.txtFax = New System.Windows.Forms.TextBox
        Me.txtDGTitle = New System.Windows.Forms.TextBox
        Me.txtNr = New System.Windows.Forms.TextBox
        Me.txtNote = New System.Windows.Forms.TextBox
        Me.lblBankName = New System.Windows.Forms.Label
        Me.lblFax = New System.Windows.Forms.Label
        Me.lblSwift = New System.Windows.Forms.Label
        Me.lblAccount = New System.Windows.Forms.Label
        Me.lblNr = New System.Windows.Forms.Label
        Me.lblNote = New System.Windows.Forms.Label
        Me.lblDG = New System.Windows.Forms.Label
        Me.cboDG = New System.Windows.Forms.ComboBox
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.grpInfo = New System.Windows.Forms.GroupBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtTreasurerSubTitle = New System.Windows.Forms.TextBox
        Me.lblTreasurerSubTitle = New System.Windows.Forms.Label
        Me.txtTreasurerTitle = New System.Windows.Forms.TextBox
        Me.lblTreasurerTitle = New System.Windows.Forms.Label
        Me.cboTreasurer = New System.Windows.Forms.ComboBox
        Me.lblTreasurer = New System.Windows.Forms.Label
        Me.txtDGSubTitle = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblCurrency = New System.Windows.Forms.Label
        Me.txtControlerTitle = New System.Windows.Forms.TextBox
        Me.txtCurrency = New System.Windows.Forms.TextBox
        Me.lblControlerTitle = New System.Windows.Forms.Label
        Me.lblControler = New System.Windows.Forms.Label
        Me.txtControlerSubTitle = New System.Windows.Forms.TextBox
        Me.lblControlerSubTitle = New System.Windows.Forms.Label
        Me.cboControler = New System.Windows.Forms.ComboBox
        Me.grpPeriods = New System.Windows.Forms.GroupBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtClsBMsgSubTitle = New System.Windows.Forms.TextBox
        Me.cboClsBMsg = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.txtClsBMsgTitle = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtContractSubTitle = New System.Windows.Forms.TextBox
        Me.cboContract = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtContractTitle = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtOverFlightSubTitle = New System.Windows.Forms.TextBox
        Me.cboOverFlight = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtOverFlightTitle = New System.Windows.Forms.TextBox
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.lblIBAN = New System.Windows.Forms.Label
        Me.txtIBAN = New System.Windows.Forms.TextBox
        Me.grpReportInfo = New System.Windows.Forms.GroupBox
        Me.grpButtons.SuspendLayout()
        Me.grpInfo.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.grpPeriods.SuspendLayout()
        Me.grpReportInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(828, 3)
        Me.pnlTitle.TabIndex = 1
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(828, 40)
        Me.lblfrmTitle.TabIndex = 0
        Me.lblfrmTitle.Text = " Branch Billing Information"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.Color.Maroon
        Me.txtID.ForeColor = System.Drawing.Color.White
        Me.txtID.Location = New System.Drawing.Point(104, 19)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(31, 20)
        Me.txtID.TabIndex = 0
        '
        'txtBankName
        '
        Me.txtBankName.Location = New System.Drawing.Point(104, 45)
        Me.txtBankName.Name = "txtBankName"
        Me.txtBankName.Size = New System.Drawing.Size(237, 20)
        Me.txtBankName.TabIndex = 2
        '
        'txtSwift
        '
        Me.txtSwift.Location = New System.Drawing.Point(104, 97)
        Me.txtSwift.Name = "txtSwift"
        Me.txtSwift.Size = New System.Drawing.Size(237, 20)
        Me.txtSwift.TabIndex = 6
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(104, 71)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(237, 20)
        Me.txtFax.TabIndex = 4
        '
        'txtDGTitle
        '
        Me.txtDGTitle.Location = New System.Drawing.Point(104, 203)
        Me.txtDGTitle.Name = "txtDGTitle"
        Me.txtDGTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtDGTitle.TabIndex = 14
        '
        'txtNr
        '
        Me.txtNr.Location = New System.Drawing.Point(104, 123)
        Me.txtNr.Name = "txtNr"
        Me.txtNr.Size = New System.Drawing.Size(237, 20)
        Me.txtNr.TabIndex = 8
        '
        'txtNote
        '
        Me.txtNote.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNote.Location = New System.Drawing.Point(104, 42)
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.Size = New System.Drawing.Size(667, 43)
        Me.txtNote.TabIndex = 24
        '
        'lblBankName
        '
        Me.lblBankName.AutoSize = True
        Me.lblBankName.BackColor = System.Drawing.SystemColors.Control
        Me.lblBankName.Font = New System.Drawing.Font("Comic Sans MS", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBankName.ForeColor = System.Drawing.Color.Maroon
        Me.lblBankName.Location = New System.Drawing.Point(27, 48)
        Me.lblBankName.Name = "lblBankName"
        Me.lblBankName.Size = New System.Drawing.Size(73, 16)
        Me.lblBankName.TabIndex = 1
        Me.lblBankName.Text = "Bank Name"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.ForeColor = System.Drawing.Color.Maroon
        Me.lblFax.Location = New System.Drawing.Point(75, 74)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(25, 13)
        Me.lblFax.TabIndex = 3
        Me.lblFax.Text = "Fax"
        '
        'lblSwift
        '
        Me.lblSwift.AutoSize = True
        Me.lblSwift.ForeColor = System.Drawing.Color.Maroon
        Me.lblSwift.Location = New System.Drawing.Point(69, 104)
        Me.lblSwift.Name = "lblSwift"
        Me.lblSwift.Size = New System.Drawing.Size(31, 13)
        Me.lblSwift.TabIndex = 5
        Me.lblSwift.Text = "Swift"
        '
        'lblAccount
        '
        Me.lblAccount.AutoSize = True
        Me.lblAccount.ForeColor = System.Drawing.Color.Maroon
        Me.lblAccount.Location = New System.Drawing.Point(59, 206)
        Me.lblAccount.Name = "lblAccount"
        Me.lblAccount.Size = New System.Drawing.Size(44, 13)
        Me.lblAccount.TabIndex = 13
        Me.lblAccount.Text = "DG Title"
        '
        'lblNr
        '
        Me.lblNr.AutoSize = True
        Me.lblNr.ForeColor = System.Drawing.Color.Maroon
        Me.lblNr.Location = New System.Drawing.Point(56, 122)
        Me.lblNr.Name = "lblNr"
        Me.lblNr.Size = New System.Drawing.Size(44, 13)
        Me.lblNr.TabIndex = 7
        Me.lblNr.Text = "Number"
        '
        'lblNote
        '
        Me.lblNote.AutoSize = True
        Me.lblNote.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNote.ForeColor = System.Drawing.Color.Maroon
        Me.lblNote.Location = New System.Drawing.Point(53, 42)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(46, 13)
        Me.lblNote.TabIndex = 23
        Me.lblNote.Text = "N o t e"
        '
        'lblDG
        '
        Me.lblDG.AutoSize = True
        Me.lblDG.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDG.ForeColor = System.Drawing.Color.Maroon
        Me.lblDG.Location = New System.Drawing.Point(74, 179)
        Me.lblDG.Name = "lblDG"
        Me.lblDG.Size = New System.Drawing.Size(23, 13)
        Me.lblDG.TabIndex = 11
        Me.lblDG.Text = "DG"
        '
        'cboDG
        '
        Me.cboDG.FormattingEnabled = True
        Me.cboDG.Location = New System.Drawing.Point(102, 176)
        Me.cboDG.Name = "cboDG"
        Me.cboDG.Size = New System.Drawing.Size(121, 21)
        Me.cboDG.TabIndex = 12
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Location = New System.Drawing.Point(12, 619)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(804, 53)
        Me.grpButtons.TabIndex = 4
        Me.grpButtons.TabStop = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.HoverColor2 = System.Drawing.Color.White
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCancel.Location = New System.Drawing.Point(114, 15)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCancel.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(99, 28)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(695, 14)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(99, 28)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(9, 15)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(99, 28)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "E d i t"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.HoverColor2 = System.Drawing.Color.White
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNew.Location = New System.Drawing.Point(9, 15)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(99, 27)
        Me.btnNew.TabIndex = 156
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'grpInfo
        '
        Me.grpInfo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpInfo.Controls.Add(Me.grpReportInfo)
        Me.grpInfo.Controls.Add(Me.GroupBox1)
        Me.grpInfo.Controls.Add(Me.grpPeriods)
        Me.grpInfo.Location = New System.Drawing.Point(12, 49)
        Me.grpInfo.Name = "grpInfo"
        Me.grpInfo.Size = New System.Drawing.Size(804, 564)
        Me.grpInfo.TabIndex = 2
        Me.grpInfo.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightYellow
        Me.GroupBox1.Controls.Add(Me.txtID)
        Me.GroupBox1.Controls.Add(Me.lblFax)
        Me.GroupBox1.Controls.Add(Me.txtTreasurerSubTitle)
        Me.GroupBox1.Controls.Add(Me.lblBankName)
        Me.GroupBox1.Controls.Add(Me.lblTreasurerSubTitle)
        Me.GroupBox1.Controls.Add(Me.lblSwift)
        Me.GroupBox1.Controls.Add(Me.txtTreasurerTitle)
        Me.GroupBox1.Controls.Add(Me.txtNr)
        Me.GroupBox1.Controls.Add(Me.lblTreasurerTitle)
        Me.GroupBox1.Controls.Add(Me.lblAccount)
        Me.GroupBox1.Controls.Add(Me.cboTreasurer)
        Me.GroupBox1.Controls.Add(Me.txtDGTitle)
        Me.GroupBox1.Controls.Add(Me.lblTreasurer)
        Me.GroupBox1.Controls.Add(Me.lblNr)
        Me.GroupBox1.Controls.Add(Me.txtDGSubTitle)
        Me.GroupBox1.Controls.Add(Me.txtFax)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtSwift)
        Me.GroupBox1.Controls.Add(Me.lblCurrency)
        Me.GroupBox1.Controls.Add(Me.txtControlerTitle)
        Me.GroupBox1.Controls.Add(Me.txtCurrency)
        Me.GroupBox1.Controls.Add(Me.lblDG)
        Me.GroupBox1.Controls.Add(Me.lblControlerTitle)
        Me.GroupBox1.Controls.Add(Me.lblControler)
        Me.GroupBox1.Controls.Add(Me.txtBankName)
        Me.GroupBox1.Controls.Add(Me.txtControlerSubTitle)
        Me.GroupBox1.Controls.Add(Me.lblControlerSubTitle)
        Me.GroupBox1.Controls.Add(Me.cboDG)
        Me.GroupBox1.Controls.Add(Me.cboControler)
        Me.GroupBox1.Location = New System.Drawing.Point(10, 19)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(386, 442)
        Me.GroupBox1.TabIndex = 352
        Me.GroupBox1.TabStop = False
        '
        'txtTreasurerSubTitle
        '
        Me.txtTreasurerSubTitle.Location = New System.Drawing.Point(102, 317)
        Me.txtTreasurerSubTitle.Name = "txtTreasurerSubTitle"
        Me.txtTreasurerSubTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtTreasurerSubTitle.TabIndex = 22
        '
        'lblTreasurerSubTitle
        '
        Me.lblTreasurerSubTitle.AutoSize = True
        Me.lblTreasurerSubTitle.ForeColor = System.Drawing.Color.Maroon
        Me.lblTreasurerSubTitle.Location = New System.Drawing.Point(5, 318)
        Me.lblTreasurerSubTitle.Name = "lblTreasurerSubTitle"
        Me.lblTreasurerSubTitle.Size = New System.Drawing.Size(98, 13)
        Me.lblTreasurerSubTitle.TabIndex = 21
        Me.lblTreasurerSubTitle.Text = "Treasurer Sub Title"
        '
        'txtTreasurerTitle
        '
        Me.txtTreasurerTitle.Location = New System.Drawing.Point(102, 287)
        Me.txtTreasurerTitle.Name = "txtTreasurerTitle"
        Me.txtTreasurerTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtTreasurerTitle.TabIndex = 20
        '
        'lblTreasurerTitle
        '
        Me.lblTreasurerTitle.AutoSize = True
        Me.lblTreasurerTitle.ForeColor = System.Drawing.Color.Maroon
        Me.lblTreasurerTitle.Location = New System.Drawing.Point(26, 290)
        Me.lblTreasurerTitle.Name = "lblTreasurerTitle"
        Me.lblTreasurerTitle.Size = New System.Drawing.Size(77, 13)
        Me.lblTreasurerTitle.TabIndex = 19
        Me.lblTreasurerTitle.Text = "Treasurer Title"
        '
        'cboTreasurer
        '
        Me.cboTreasurer.FormattingEnabled = True
        Me.cboTreasurer.Location = New System.Drawing.Point(102, 260)
        Me.cboTreasurer.Name = "cboTreasurer"
        Me.cboTreasurer.Size = New System.Drawing.Size(121, 21)
        Me.cboTreasurer.TabIndex = 18
        '
        'lblTreasurer
        '
        Me.lblTreasurer.AutoSize = True
        Me.lblTreasurer.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTreasurer.ForeColor = System.Drawing.Color.Maroon
        Me.lblTreasurer.Location = New System.Drawing.Point(40, 260)
        Me.lblTreasurer.Name = "lblTreasurer"
        Me.lblTreasurer.Size = New System.Drawing.Size(63, 13)
        Me.lblTreasurer.TabIndex = 17
        Me.lblTreasurer.Text = "Treasurer"
        '
        'txtDGSubTitle
        '
        Me.txtDGSubTitle.Location = New System.Drawing.Point(104, 233)
        Me.txtDGSubTitle.Name = "txtDGSubTitle"
        Me.txtDGSubTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtDGSubTitle.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Maroon
        Me.Label1.Location = New System.Drawing.Point(41, 234)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "DG Sub Title"
        '
        'lblCurrency
        '
        Me.lblCurrency.AutoSize = True
        Me.lblCurrency.ForeColor = System.Drawing.Color.Maroon
        Me.lblCurrency.Location = New System.Drawing.Point(49, 151)
        Me.lblCurrency.Name = "lblCurrency"
        Me.lblCurrency.Size = New System.Drawing.Size(51, 13)
        Me.lblCurrency.TabIndex = 9
        Me.lblCurrency.Text = "Currency"
        '
        'txtControlerTitle
        '
        Me.txtControlerTitle.Location = New System.Drawing.Point(104, 373)
        Me.txtControlerTitle.Name = "txtControlerTitle"
        Me.txtControlerTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtControlerTitle.TabIndex = 28
        '
        'txtCurrency
        '
        Me.txtCurrency.Location = New System.Drawing.Point(104, 148)
        Me.txtCurrency.Name = "txtCurrency"
        Me.txtCurrency.Size = New System.Drawing.Size(121, 20)
        Me.txtCurrency.TabIndex = 10
        '
        'lblControlerTitle
        '
        Me.lblControlerTitle.AutoSize = True
        Me.lblControlerTitle.ForeColor = System.Drawing.Color.Maroon
        Me.lblControlerTitle.Location = New System.Drawing.Point(26, 376)
        Me.lblControlerTitle.Name = "lblControlerTitle"
        Me.lblControlerTitle.Size = New System.Drawing.Size(77, 13)
        Me.lblControlerTitle.TabIndex = 27
        Me.lblControlerTitle.Text = "Controller Title"
        '
        'lblControler
        '
        Me.lblControler.AutoSize = True
        Me.lblControler.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblControler.ForeColor = System.Drawing.Color.Maroon
        Me.lblControler.Location = New System.Drawing.Point(40, 346)
        Me.lblControler.Name = "lblControler"
        Me.lblControler.Size = New System.Drawing.Size(63, 13)
        Me.lblControler.TabIndex = 25
        Me.lblControler.Text = "Controller"
        '
        'txtControlerSubTitle
        '
        Me.txtControlerSubTitle.Location = New System.Drawing.Point(104, 403)
        Me.txtControlerSubTitle.Name = "txtControlerSubTitle"
        Me.txtControlerSubTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtControlerSubTitle.TabIndex = 30
        '
        'lblControlerSubTitle
        '
        Me.lblControlerSubTitle.AutoSize = True
        Me.lblControlerSubTitle.ForeColor = System.Drawing.Color.Maroon
        Me.lblControlerSubTitle.Location = New System.Drawing.Point(5, 404)
        Me.lblControlerSubTitle.Name = "lblControlerSubTitle"
        Me.lblControlerSubTitle.Size = New System.Drawing.Size(98, 13)
        Me.lblControlerSubTitle.TabIndex = 29
        Me.lblControlerSubTitle.Text = "Controller Sub Title"
        '
        'cboControler
        '
        Me.cboControler.FormattingEnabled = True
        Me.cboControler.Location = New System.Drawing.Point(104, 346)
        Me.cboControler.Name = "cboControler"
        Me.cboControler.Size = New System.Drawing.Size(121, 21)
        Me.cboControler.TabIndex = 26
        '
        'grpPeriods
        '
        Me.grpPeriods.BackColor = System.Drawing.Color.LightYellow
        Me.grpPeriods.Controls.Add(Me.Label8)
        Me.grpPeriods.Controls.Add(Me.txtClsBMsgSubTitle)
        Me.grpPeriods.Controls.Add(Me.cboClsBMsg)
        Me.grpPeriods.Controls.Add(Me.Label9)
        Me.grpPeriods.Controls.Add(Me.Label10)
        Me.grpPeriods.Controls.Add(Me.txtClsBMsgTitle)
        Me.grpPeriods.Controls.Add(Me.Label5)
        Me.grpPeriods.Controls.Add(Me.txtContractSubTitle)
        Me.grpPeriods.Controls.Add(Me.cboContract)
        Me.grpPeriods.Controls.Add(Me.Label6)
        Me.grpPeriods.Controls.Add(Me.Label7)
        Me.grpPeriods.Controls.Add(Me.txtContractTitle)
        Me.grpPeriods.Controls.Add(Me.Label2)
        Me.grpPeriods.Controls.Add(Me.txtOverFlightSubTitle)
        Me.grpPeriods.Controls.Add(Me.cboOverFlight)
        Me.grpPeriods.Controls.Add(Me.Label3)
        Me.grpPeriods.Controls.Add(Me.Label4)
        Me.grpPeriods.Controls.Add(Me.txtOverFlightTitle)
        Me.grpPeriods.Location = New System.Drawing.Point(408, 19)
        Me.grpPeriods.Name = "grpPeriods"
        Me.grpPeriods.Size = New System.Drawing.Size(386, 442)
        Me.grpPeriods.TabIndex = 351
        Me.grpPeriods.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Maroon
        Me.Label8.Location = New System.Drawing.Point(32, 346)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 13)
        Me.Label8.TabIndex = 43
        Me.Label8.Text = "Class-B Message"
        '
        'txtClsBMsgSubTitle
        '
        Me.txtClsBMsgSubTitle.Location = New System.Drawing.Point(136, 403)
        Me.txtClsBMsgSubTitle.Name = "txtClsBMsgSubTitle"
        Me.txtClsBMsgSubTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtClsBMsgSubTitle.TabIndex = 48
        '
        'cboClsBMsg
        '
        Me.cboClsBMsg.FormattingEnabled = True
        Me.cboClsBMsg.Location = New System.Drawing.Point(136, 346)
        Me.cboClsBMsg.Name = "cboClsBMsg"
        Me.cboClsBMsg.Size = New System.Drawing.Size(121, 21)
        Me.cboClsBMsg.TabIndex = 44
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.Maroon
        Me.Label9.Location = New System.Drawing.Point(2, 404)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(131, 13)
        Me.Label9.TabIndex = 47
        Me.Label9.Text = "Class-B Message Sub Title"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.Maroon
        Me.Label10.Location = New System.Drawing.Point(23, 376)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(110, 13)
        Me.Label10.TabIndex = 45
        Me.Label10.Text = "Class-B Message Title"
        '
        'txtClsBMsgTitle
        '
        Me.txtClsBMsgTitle.Location = New System.Drawing.Point(136, 373)
        Me.txtClsBMsgTitle.Name = "txtClsBMsgTitle"
        Me.txtClsBMsgTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtClsBMsgTitle.TabIndex = 46
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Maroon
        Me.Label5.Location = New System.Drawing.Point(77, 205)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 13)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "Contract"
        '
        'txtContractSubTitle
        '
        Me.txtContractSubTitle.Location = New System.Drawing.Point(136, 262)
        Me.txtContractSubTitle.Name = "txtContractSubTitle"
        Me.txtContractSubTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtContractSubTitle.TabIndex = 42
        '
        'cboContract
        '
        Me.cboContract.FormattingEnabled = True
        Me.cboContract.Location = New System.Drawing.Point(136, 205)
        Me.cboContract.Name = "cboContract"
        Me.cboContract.Size = New System.Drawing.Size(121, 21)
        Me.cboContract.TabIndex = 38
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Maroon
        Me.Label6.Location = New System.Drawing.Point(40, 263)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 13)
        Me.Label6.TabIndex = 41
        Me.Label6.Text = "Contract Sub Title"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Maroon
        Me.Label7.Location = New System.Drawing.Point(61, 235)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 13)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "Contract Title"
        '
        'txtContractTitle
        '
        Me.txtContractTitle.Location = New System.Drawing.Point(136, 232)
        Me.txtContractTitle.Name = "txtContractTitle"
        Me.txtContractTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtContractTitle.TabIndex = 40
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Maroon
        Me.Label2.Location = New System.Drawing.Point(65, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(68, 13)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "Over Flight"
        '
        'txtOverFlightSubTitle
        '
        Me.txtOverFlightSubTitle.Location = New System.Drawing.Point(136, 116)
        Me.txtOverFlightSubTitle.Name = "txtOverFlightSubTitle"
        Me.txtOverFlightSubTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtOverFlightSubTitle.TabIndex = 36
        '
        'cboOverFlight
        '
        Me.cboOverFlight.FormattingEnabled = True
        Me.cboOverFlight.Location = New System.Drawing.Point(136, 59)
        Me.cboOverFlight.Name = "cboOverFlight"
        Me.cboOverFlight.Size = New System.Drawing.Size(121, 21)
        Me.cboOverFlight.TabIndex = 32
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.Maroon
        Me.Label3.Location = New System.Drawing.Point(29, 117)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 13)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Over Flight Sub Title"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Maroon
        Me.Label4.Location = New System.Drawing.Point(50, 89)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 13)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "Over Flight Title"
        '
        'txtOverFlightTitle
        '
        Me.txtOverFlightTitle.Location = New System.Drawing.Point(136, 86)
        Me.txtOverFlightTitle.Name = "txtOverFlightTitle"
        Me.txtOverFlightTitle.Size = New System.Drawing.Size(237, 20)
        Me.txtOverFlightTitle.TabIndex = 34
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(764, 9)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(52, 25)
        Me.btnDataErr.TabIndex = 5
        Me.btnDataErr.TabStop = False
        Me.btnDataErr.Text = "E r r o r"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(565, 16)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(198, 17)
        Me.lstDataErr.TabIndex = 0
        Me.lstDataErr.Visible = False
        '
        'lblIBAN
        '
        Me.lblIBAN.AutoSize = True
        Me.lblIBAN.BackColor = System.Drawing.Color.Transparent
        Me.lblIBAN.Font = New System.Drawing.Font("Comic Sans MS", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIBAN.ForeColor = System.Drawing.Color.Maroon
        Me.lblIBAN.Location = New System.Drawing.Point(57, 17)
        Me.lblIBAN.Name = "lblIBAN"
        Me.lblIBAN.Size = New System.Drawing.Size(42, 16)
        Me.lblIBAN.TabIndex = 31
        Me.lblIBAN.Text = "IBAN"
        '
        'txtIBAN
        '
        Me.txtIBAN.Location = New System.Drawing.Point(104, 16)
        Me.txtIBAN.Name = "txtIBAN"
        Me.txtIBAN.Size = New System.Drawing.Size(237, 20)
        Me.txtIBAN.TabIndex = 32
        '
        'grpReportInfo
        '
        Me.grpReportInfo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpReportInfo.BackColor = System.Drawing.Color.Lavender
        Me.grpReportInfo.Controls.Add(Me.lblIBAN)
        Me.grpReportInfo.Controls.Add(Me.txtNote)
        Me.grpReportInfo.Controls.Add(Me.lblNote)
        Me.grpReportInfo.Controls.Add(Me.txtIBAN)
        Me.grpReportInfo.Location = New System.Drawing.Point(10, 464)
        Me.grpReportInfo.Name = "grpReportInfo"
        Me.grpReportInfo.Size = New System.Drawing.Size(784, 94)
        Me.grpReportInfo.TabIndex = 49
        Me.grpReportInfo.TabStop = False
        '
        'frmBranchBillingInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(828, 682)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.grpInfo)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.KeyPreview = True
        Me.Name = "frmBranchBillingInfo"
        Me.Text = "Branch Billing Info"
        Me.grpButtons.ResumeLayout(False)
        Me.grpInfo.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.grpPeriods.ResumeLayout(False)
        Me.grpPeriods.PerformLayout()
        Me.grpReportInfo.ResumeLayout(False)
        Me.grpReportInfo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents pnlTitle As System.Windows.Forms.Panel
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents txtID As System.Windows.Forms.TextBox
	Friend WithEvents txtBankName As System.Windows.Forms.TextBox
	Friend WithEvents txtSwift As System.Windows.Forms.TextBox
	Friend WithEvents txtFax As System.Windows.Forms.TextBox
	Friend WithEvents txtDGTitle As System.Windows.Forms.TextBox
	Friend WithEvents txtNr As System.Windows.Forms.TextBox
	Friend WithEvents txtNote As System.Windows.Forms.TextBox
	Friend WithEvents lblBankName As System.Windows.Forms.Label
	Friend WithEvents lblFax As System.Windows.Forms.Label
	Friend WithEvents lblSwift As System.Windows.Forms.Label
	Friend WithEvents lblAccount As System.Windows.Forms.Label
	Friend WithEvents lblNr As System.Windows.Forms.Label
	Friend WithEvents lblNote As System.Windows.Forms.Label
	Friend WithEvents lblDG As System.Windows.Forms.Label
	Friend WithEvents cboDG As System.Windows.Forms.ComboBox
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnCancel As BHBut.BouncingHoverButton
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
	Friend WithEvents btnSave As BHBut.BouncingHoverButton
	Friend WithEvents btnNew As BHBut.BouncingHoverButton
	Friend WithEvents grpInfo As System.Windows.Forms.GroupBox
	Friend WithEvents btnDataErr As System.Windows.Forms.Button
	Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
	Friend WithEvents lblCurrency As System.Windows.Forms.Label
	Friend WithEvents txtCurrency As System.Windows.Forms.TextBox
	Friend WithEvents txtDGSubTitle As System.Windows.Forms.TextBox
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents lblTreasurer As System.Windows.Forms.Label
	Friend WithEvents cboTreasurer As System.Windows.Forms.ComboBox
	Friend WithEvents txtTreasurerSubTitle As System.Windows.Forms.TextBox
	Friend WithEvents lblTreasurerSubTitle As System.Windows.Forms.Label
	Friend WithEvents txtTreasurerTitle As System.Windows.Forms.TextBox
	Friend WithEvents lblTreasurerTitle As System.Windows.Forms.Label
	Friend WithEvents txtControlerSubTitle As System.Windows.Forms.TextBox
	Friend WithEvents lblControlerSubTitle As System.Windows.Forms.Label
	Friend WithEvents txtControlerTitle As System.Windows.Forms.TextBox
	Friend WithEvents lblControlerTitle As System.Windows.Forms.Label
	Friend WithEvents cboControler As System.Windows.Forms.ComboBox
	Friend WithEvents lblControler As System.Windows.Forms.Label
	Friend WithEvents grpPeriods As System.Windows.Forms.GroupBox
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents txtClsBMsgSubTitle As System.Windows.Forms.TextBox
	Friend WithEvents cboClsBMsg As System.Windows.Forms.ComboBox
	Friend WithEvents Label9 As System.Windows.Forms.Label
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents txtClsBMsgTitle As System.Windows.Forms.TextBox
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents txtContractSubTitle As System.Windows.Forms.TextBox
	Friend WithEvents cboContract As System.Windows.Forms.ComboBox
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents txtContractTitle As System.Windows.Forms.TextBox
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents txtOverFlightSubTitle As System.Windows.Forms.TextBox
	Friend WithEvents cboOverFlight As System.Windows.Forms.ComboBox
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents txtOverFlightTitle As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents grpReportInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblIBAN As System.Windows.Forms.Label
    Friend WithEvents txtIBAN As System.Windows.Forms.TextBox
End Class
