Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmService

#Region " Form Declaration  .  .  . "
   ''
   Dim clsMr As ClsMain
   Dim dsData As New DataSet
   Private WithEvents Nav As BitsNav
   Dim blnLoading As Boolean = False
   Private blnEdit As Boolean = False
   Private AddMode As Boolean

   Private blnExitSave As Boolean
   Dim daService As New SqlClient.SqlDataAdapter
   Private dataChange As Boolean
   Dim mServiceID As Integer = -1
   ''
#End Region


#Region " Form Initialization . . . "

    Private Sub frmService_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmService_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ''
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav
        ''
        blnLoading = True
        MakeDataAdapter()
        SetDataBinding()
        FillComboBox()
        SetAutoNumber()
        SetCurrency()
        SetDefaultValue()
        ''
        grpPrice.Enabled = False
        blnLoading = False

        If mServiceID = -1 Then
            btnNew.PerformClick()
            Exit Sub
        Else
            Nav.CurrentPosition = GetRowIndex(mServiceID)
            dataChange = False
        End If
        checkListValues()
        dataChange = False
        ''
        setState("BROWSE")
    End Sub

    Public Sub New(Optional ByVal intServiceID As Integer = -1)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        mServiceID = intServiceID

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

#End Region


#Region " Form Functions   .   .   ."

   Private Sub MakeDataAdapter()
      ''
      daService = clsMr.BuildSqlAdapter("SELECT * FROM tblService WHERE Del = 0", "tblService")
      clsMr.BuildSqlAdapter("SELECT * FROM tblServiceCategory WHERE Del = 0", "tblServiceCategory")
      clsMr.BuildSqlAdapter("SELECT * FROM tblServiceSubCategory WHERE Del = 0", "tblServiceSubCategory")
      clsMr.BuildSqlAdapter("SELECT * FROM tblServiceType WHERE Del = 0", "tblServiceType")
      clsMr.BuildSqlAdapter("SELECT * FROM tblPriceUnit WHERE Del = 0", "tblPriceUnit")
      clsMr.BuildSqlAdapter("SELECT * FROM tblPriceUnit WHERE Del = 0", "tblAdditionalChargeUnit")

      dsData = clsMr.getDataSet
      ''
   End Sub

   Private Sub FillComboBox()
      ''
      clsMr.FillComboBox("tblServiceCategory", CboCategory, "CatType", "CatID")
      clsMr.FillComboBox("tblServiceSubCategory", CboSubCategory, "SubCatType", "SubCatID")
      clsMr.FillComboBox("tblServiceType", CboServiceType, "ServiceType", "ServiceTypeID")
      clsMr.FillComboBox("tblPriceUnit", CboPriceUnit, "PriceUnit", "PriceUnitID")
      clsMr.FillComboBox("tblAdditionalChargeUnit", CboAdditionalChargeUnit, "PriceUnit", "PriceUnitID")
    End Sub

   Private Sub SetDataBinding()
      ''
      clsMr.BindTextBox(txtServiceID, "tblService", "ServiceID")
      clsMr.BindTextBox(txtServiceName, "tblService", "ServiceName")
      clsMr.BindTextBox(txtCode, "tblService", "ServiceCode")
      clsMr.BindComboBox(CboCategory, "tblService", "ServiceCatID")
      clsMr.BindComboBox(CboSubCategory, "tblService", "ServiceSubCatID")
      clsMr.BindComboBox(CboServiceType, "tblService", "ServiceTypeID")
      clsMr.BindTextBox(txtPrice, "tblService", "Price")
      clsMr.BindComboBox(CboPriceUnit, "tblService", "PriceUnitID")
      clsMr.BindTextBox(txtVAT, "tblService", "VAT")
      clsMr.BindTextBox(txtAdditionalCharge, "tblService", "AdditionalCharge")
    End Sub

   Private Sub SetAutoNumber()
      ''
      clsMr.SetAutoNumber("tblService", "ServiceID")
    End Sub

   Public Sub SetDefaultValue()
      ''
      clsMr.SetDefaults("tblService", "CompanyID", gIntCompanyID)
      clsMr.SetDefaults("tblService", "CreateBy", gIntUserID)
      clsMr.SetDefaults("tblService", "CreateDate", Now.Date)
      clsMr.SetDefaults("tblService", "VAT", 0)
      clsMr.SetDefaults("tblService", "Del", 0)
    End Sub

   Private Sub SetCurrency()
      ''
      Nav.SetCurrency(Me, dsData, "tblService")
    End Sub

   Private Sub setState(ByRef pStrMode As String)
      ''
      Dim mStrCurrentState As String
      mStrCurrentState = UCase(pStrMode)
      '' 
        Select Case mStrCurrentState

            Case Is = "NEW"
                ''
                grpService.Enabled = True
                AddMode = True
                grpPrice.Enabled = True
                btnNew.Enabled = False
                btnCancel.Enabled = True
                btnSave.Text = "S a v e"

            Case Is = "EDIT"
                ''
                btnNew.Enabled = False
                btnSave.Enabled = False
                btnCancel.Enabled = True
                grpService.Enabled = True
                grpPrice.Enabled = True
                blnEdit = True
                btnSave.Text = "S a v e"

            Case Is = "BROWSE"
                ''
                grpService.Enabled = False
                grpPrice.Enabled = False
                btnNew.Enabled = True
                btnSave.Enabled = True
                btnCancel.Enabled = False
                btnSave.Text = "E d i t"

            Case Is = "SAVE"
                ''
                grpService.Enabled = False
                grpPrice.Enabled = False
                btnNew.Enabled = True
                btnCancel.Enabled = False
                AddMode = False
                btnSave.Text = "E d i t"

            Case Is = "CANCEL"
                ''
                grpService.Enabled = False
                grpPrice.Enabled = False
                btnCancel.Enabled = False
                btnDataErr.Visible = False
                lstDataErr.Visible = False
                btnNew.Enabled = True
                btnSave.Enabled = False
                AddMode = False
        End Select
        ''
        DGCA.LoadPermissionsSetState(Me, Me.Name)
   End Sub

   Private Sub Save()
      ''
      checkListValues()
      Nav.EndCurrentEdit()
      If blnEdit = False Then

         If ServiceNameExist() Then
            MsgBox("the Service Name is already exists")
            blnExitSave = True
            Exit Sub
         End If
      Else

      End If
      clsMr.Update(daService, "tblService")
      ''
   End Sub

   Private Function ServiceNameExist() As Boolean
      ''
      Dim sqlCommand As New SqlCommand("Select ServiceName, Del from tblService where Del = 0 AND ServiceName=" & "'" & txtServiceName.Text & "'", conSql)
      Dim drRead As SqlDataReader
      ''
      Try
         conSql.Open()
         drRead = sqlCommand.ExecuteReader()

         While drRead.Read
            conSql.Close()
            drRead.Close()
            Return True
         End While

      Catch ex As Exception
      End Try
      ''
      conSql.Close()
      drRead.Close()
      Return False
      ''
   End Function

   Private Sub checkListValues()
      ''
      If blnLoading = True Then Exit Sub

      ''
      dataChange = True
      btnCancel.Enabled = True

      '' clear entir list & start fresh check...
      ''
      lstDataErr.Items.Clear()
      Dim intErrCount As Int16 = 0

      If txtCode.Text = String.Empty Then
         lstDataErr.Items.Add(" - Please Enter Code")
         intErrCount += 1
      End If


      If txtServiceName.Text = String.Empty Then
         lstDataErr.Items.Add(" - Please Enter Service Name")
         intErrCount += 1
      End If

      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '' Set appropriate controls based on errors check results...
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      If lstDataErr.Items.Count = 0 Then
         lstDataErr.Visible = False
         btnDataErr.Visible = False
         btnSave.Enabled = True
      Else
         btnDataErr.Visible = True
         btnSave.Enabled = False
      End If
      ''
   End Sub

   Public Function GetRowIndex(ByVal pServiceID As Long) As Integer
      ''
      Dim i As Integer

      For i = 0 To dsData.Tables("tblService").DefaultView.Count - 1
         If dsData.Tables("tblService").DefaultView.Item(i)("ServiceID") = pServiceID Then
            Return i
         End If
      Next
      Return -1
      ''
   End Function

#End Region


#Region " UI - Events     .    .   ."

   Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
      ''
      dsData.Tables("tblService").DefaultView.AllowNew = True
      checkListValues()
      Nav.AddNew()
      CboCategory.SelectedIndex = -1
      CboSubCategory.SelectedIndex = -1
      setState("NEW")
      ''
   End Sub

   Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
      ''
      If btnSave.Text = "E d i t" Then

         setState("Edit")
      Else
         Save()

         'Exit Save function in case Service Name deja exists

         If blnExitSave Then
            setState("SAVE")

            Exit Sub
         End If
         dataChange = False
         setState("SAVE")
         dsData.Tables("tblService").DefaultView.AllowNew = False
      End If
      ''
   End Sub

   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      ''
      If dataChange Then
         If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            Try
               Nav.CancelCurrentEdit()
               If AddMode = True Then
                  Me.Close()

               End If
            Catch ex As Exception
               ''
            End Try
            dataChange = False
            AddMode = False
            setState("BROWSE")
         End If
      Else
         ''
         setState("BROWSE")
      End If
      ''
      ''
   End Sub

   Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
      ''
      If dataChange Then
         ''
         Dim res As MsgBoxResult
         res = MsgBox("Do you want to save changes?", MsgBoxStyle.YesNoCancel)
         ''
         Select Case res
            Case MsgBoxResult.Yes
               Save()
               Me.Close()

            Case MsgBoxResult.No
               Nav.CancelCurrentEdit()
               Me.Close()

            Case MsgBoxResult.Cancel

         End Select
      Else
         Me.Close()
      End If
      ''
   End Sub

   Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
      '' Show/Hide error list...
      If lstDataErr.Visible = True Then
         lstDataErr.Visible = False
      Else
         lstDataErr.Visible = True
         lstDataErr.Height = 35
         lstDataErr.BringToFront()
      End If
      ''
   End Sub

   Private Sub txtServiceName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtServiceName.TextChanged, txtAdditionalCharge.TextChanged, txtCode.TextChanged, txtPrice.TextChanged, txtServiceName.TextChanged, txtVAT.TextChanged
      ''
      If blnLoading = True Then Exit Sub
      checkListValues()
      ''
   End Sub

   Private Sub CboCategory_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles CboCategory.KeyUp, CboSubCategory.KeyUp, CboPriceUnit.KeyUp, CboServiceType.KeyUp
      ''
      checkListValues()
      ''
   End Sub

   Private Sub CboCategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboCategory.SelectedIndexChanged, CboPriceUnit.SelectedIndexChanged, CboServiceType.SelectedIndexChanged, CboSubCategory.SelectedIndexChanged
      ''
      If blnLoading = True Then Exit Sub
      checkListValues()
      ''
      'If CboCategory.Text <> String.Empty Then
      '   dsData.Tables("tblServiceSubCategory").DefaultView.RowFilter = "CatID=" & CboCategory.SelectedValue
      'End If

      ''
   End Sub

   Private Sub CboCategory_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboCategory.Leave
      ''
      AddNewValueToCbo(clsMr, CboCategory, "tblServiceCategory", "CatID", "CatType")
      ''
   End Sub

   Private Sub CboSubCategory_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboSubCategory.Leave
      ''
      AddNewValueToCbo(clsMr, CboSubCategory, "tblServiceSubCategory", "SubCatID", "SubCatType", "CatID", CboCategory.SelectedValue)
      ''
   End Sub

   Private Sub CboServiceType_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboServiceType.Leave
      ''
      AddNewValueToCbo(clsMr, CboServiceType, "tblServiceType", "ServiceTypeID", "ServiceType")
      ''
   End Sub

   Private Sub CboPriceUnit_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboPriceUnit.Leave
      ''
      AddNewValueToCbo(clsMr, CboPriceUnit, "tblPriceUnit", "PriceUnitID", "PriceUnit")
      ''
   End Sub

#End Region

End Class