Imports BITSConn
Imports System.data.SqlClient
''
Public Class frmOverDueInvoiceList

#Region "Form-Declaration..."
	''
	Private dsdata As DataSet
	Private clsMr As ClsMain
	Private daTafkeet As SqlDataAdapter
	Private blnLoading As Boolean
	Private mstrCurrentGridName As String
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\OverDueInvoiceList\Settings"
	Private intPeriodChecked As Integer = 0
	Public arrPay(1) As Integer
	''
#End Region


#Region "Form-Load..."

    Private Sub frmOverDueInvoiceList_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmOverDueInvoiceList_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''
        clsMr = New ClsMain(conSql)
        ''
        blnLoading = True
        MakeDataAdapter()
        FillComboBox()
        ''
        blnLoading = False
        DrawGrid()
        ''set defaults
        cboClient.SelectedIndex = -1
        cboStatus.SelectedIndex = -1
        cboCategory.SelectedIndex = -1
        FilterGrid()
        lblCurrSymbol.Text = GetCompanyCurrencySymbol()
        lblCurrSymbol2.Text = GetCompanyCurrencySymbol2()
        btnPreview.Enabled = False
        grpReportOptions.Visible = False
        ''
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

#End Region


#Region "Form-Initialisation..."

	Private Sub MakeDataAdapter()
		''
		'' set SQL for selecting active emp recs...
		daTafkeet = clsMr.BuildSqlAdapter("SELECT * FROM tblTafkeet", "tblTafkeet")
		clsMr.BuildSqlAdapter("SELECT [InvoiceID],[InvoiceNumber], [CatType], [InvoiceYY], [InvoiceDate], [ClientName], [InvoiceFrom], [InvoiceTo], [Description], [Status], [BilledDate], [BillStatus], [Total], [TotalCurr2], [AutoGel], [ClientID], [StatusID], [CatID], [Del], [RefID], [RefIDTo] FROM [vwInvoiceList] WHERE Del=0", "vwInvoiceList")
		clsMr.BuildSqlAdapter("SELECT ClientID,ClientName  from tblClient WHERE Del =0  ORDER BY ClientName", "ClientName")
		clsMr.BuildSqlAdapter("SELECT CatID,CatType  FROM tblServiceCategory WHERE Del =0 ", "tblServiceCategory")
		'clsMr.BuildSqlAdapter("SELECT * FROM tblInvoice WHERE Del=0 AND InvoiceID=0", "tblInvoice")
		'clsMr.BuildSqlAdapter("SELECT * FROM tblInvoiceDetail WHERE Del=0 AND InvoiceID=0", "tblInvoiceDetail")
		'clsMr.BuildSqlAdapter("SELECT *  from tblTrx WHERE Del =0  and trxid=-1", "tblTrx")
		dsdata = clsMr.getDataSet
	End Sub

	Private Sub FillComboBox()

		clsMr.FillComboBox("ClientName", cboClient, "ClientName", "ClientID")
		'clsMr.FillComboBox("tblVisitStatus", cboStatus, "status", "StatusID")
		clsMr.FillComboBox("tblServiceCategory", cboCategory, "CatType", "CatID")
	End Sub

	Private Sub SetDefaultValue()
		'clsMr.SetDefaults("tblInvoice", "CreateByID", gIntUserID, "CreateDate", Now.Date, "Del", 0, "StatusID", 1, "InvoiceDate", Now.Date, "InvoiceFrom", Now.Date, "InvoiceTo", Now.Date)
	End Sub

	Private Sub SetAutoNumber()
		'clsMr.SetAutoNumber("tblInvoice", "InvoiceID")
		'clsMr.SetAutoNumber("tblInvoice", "InvoiceNumber")
		' ''
		'clsMr.SetAutoNumber("tblInvoiceDetail", "InvoiceDetailID")
	End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

    End Sub

#End Region


#Region "Form-UI/Methods..."

	Private Sub btnPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreview.Click
        ''
        grpReportOptions.Visible = True
    End Sub

	Private Sub chkCurrent_Click(ByVal sender As Object, ByVal e As System.EventArgs)
		FilterGrid()

	End Sub

	Private Sub chkDue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkDue.Click
		FilterGrid()

	End Sub

	Private Sub chkPaid_Click(ByVal sender As Object, ByVal e As System.EventArgs)
		FilterGrid()
	End Sub

	Private Sub chkOverDue30_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkOverDue30.Click
		FilterGrid()

	End Sub

	Private Sub chkOverDue60_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkOverDue60.Click
		FilterGrid()

	End Sub

	Private Sub chkOverDue90_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkOverDue90.Click
		FilterGrid()

	End Sub

	Private Sub chkOverDue120_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkOverDue120.Click
		FilterGrid()

	End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        EditInvoice()
    End Sub


    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If grdInvoiceList.Rows.Count = 0 Then Exit Sub

        If MsgBox("Are you sure you want to delete?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub
        '' update invoiceDetail

        Dim cmd As New SqlCommand("UPDATE tblInvoiceDetail SET Del=1 WHERE InvoiceID=" & grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value, conSql)
        conSql.Open()
        cmd.ExecuteNonQuery()
        conSql.Close()

        ''update tblInvoice
        cmd.CommandText = "UPDATE tblInvoice SET Del=1 WHERE InvoiceID=" & grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value
        cmd.Connection = conSql
        conSql.Open()
        cmd.ExecuteNonQuery()
        conSql.Close()

        dsdata.Tables("vwInvoiceList").DefaultView(grdInvoiceList.CurrentRow.Index).Delete()
    End Sub

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		If grdInvoiceList.Rows.Count <> 0 Then
			arrPay(0) = grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value
		End If

		Me.Close()
	End Sub

	Private Sub grdInvoiceList_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdInvoiceList.DoubleClick
		EditInvoice()
	End Sub

	Private Sub cboClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
		AutoComplete(cboClient, e)
	End Sub

	Private Sub cboClient_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyUp
		FilterGrid()
	End Sub

	Private Sub cboClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
		FilterGrid()
	End Sub

	Private Sub dtpDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateFrom.ValueChanged
		FilterGrid()
	End Sub

	Private Sub dtpDateTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateTo.ValueChanged
		FilterGrid()
	End Sub

	Private Sub txtInvoiceNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInvoiceNum.TextChanged
		FilterGrid()
	End Sub

	Private Sub CboType_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
		FilterGrid()
	End Sub

	Private Sub CboType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
		FilterGrid()
	End Sub


	Private Sub txtInvoiceType_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
		FilterGrid()
	End Sub

	Private Sub cboCategory_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboCategory.KeyPress
		AutoComplete(cboCategory, e)
	End Sub

	Private Sub cboCategory_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboCategory.KeyUp
		FilterGrid()
	End Sub

	Private Sub cboCategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCategory.SelectedIndexChanged
		FilterGrid()
		btnPreview.Enabled = True
	End Sub

    Private Sub btnAutoGenerateInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Dim frm As New frmClientGet()
        'frm.ShowDialog()

        ' ''getchoosenClients to autogeneratevoucher
        'Dim i As Integer
        'For i = 0 To frm.arr.Length - 1
        '	If frm.arr(i) <> 0 Then

        '		dsdata.Tables("tblTrx").Rows.Clear()
        '		clsMr.BuildSqlAdapter("SELECT * FROM tblTrx WHERE Not (InvoiceID IS Null) AND ClientID= " & frm.arr(i), "tblTrx")
        '		Dim drs() As DataRow = dsdata.Tables("tblTrx").Select("ClientID=" & frm.arr(i))
        '		If drs.Length <> 0 Then
        '			''autoGenerateInvoice for Client

        '			Dim drInvoice As DataRow = dsdata.Tables("tblInvoice").NewRow

        '			drInvoice("InvoiceType") = "t"
        '			drInvoice("Description") = "AutoGenerated"
        '			dsdata.Tables("tblInvoice").Rows.Add(drInvoice)
        '			''invoice detail

        '			drInvoice("Total") = "t"
        '		End If

        '	End If
        'Next

        Dim frm As New frmInvoicePrepare
        'frm.ShowDialog()
        appMain.addTabPage(frm, frmApplicationMain.eFormType.InvoicePrepare)
        AddHandler frm.Closed, AddressOf RefreshList

    End Sub

    Private Sub rdbMonthly_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        intPeriodChecked = 0
    End Sub

    Private Sub rdbQuarterly_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        intPeriodChecked = 1
    End Sub

    Private Sub rdbBiAnnualy_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        intPeriodChecked = 2
    End Sub

    Private Sub rdbAnnualy_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        intPeriodChecked = 3
    End Sub


#End Region


#Region "Form-Functions..."

	Private Function InvoiceFilterString()
		If blnLoading Then Exit Function
		''
		Dim strStatus As String
		Dim strfilter As String = "" '""" True"
		''
		'strfilter = " ({vwInvoiceRpt.InvoiceDate} >= #" & Format(dtpDateFrom.Value, "dd /MMM / yyyy") & "#) AND ({vwInvoiceRpt.InvoiceDate} <= #" & Format(dtpDateTo.Value, "dd /MMM / yyyy") & "#)"
		'strfilter = " ({vwInvoiceRpt.InvoiceDate} >= #" & dtpDateFrom.Value.ToShortDateString() & "#) AND ({vwInvoiceRpt.InvoiceDate} <= #" & dtpDateTo.Value.ToShortDateString() & "#)"
		strfilter = " ({vwInvoiceRpt.InvoiceDate} >= #" & dtpDateFrom.Value.ToString("yyyy-M-d") & "#) AND ({vwInvoiceRpt.InvoiceDate} <= #" & dtpDateTo.Value.ToString("yyyy-M-d") & "#)"

		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				If strfilter = "" Then
					strfilter = strfilter & "   ({vwInvoiceRpt.InvoiceNumber} = " & tn & ")"
				Else
					strfilter = strfilter & " AND  ({vwInvoiceRpt.InvoiceNumber} = " & tn & ")"
				End If
			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		'If txtInvoiceType.Text <> String.Empty Then
		'	strfilter = strfilter & " AND  (vwInvoiceRpt.InvoiceType = '" & txtInvoiceType.Text & "')"
		'End If
		''
		If cboClient.SelectedIndex <> -1 Then
			If strfilter = "" Then
				strfilter = "  ({vwInvoiceRpt.ClientID} = " & cboClient.SelectedValue & ")"
			Else
				strfilter = strfilter & " AND ({vwInvoiceRpt.ClientID} = " & cboClient.SelectedValue & ")"
			End If
		Else
			''
			If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
				If strfilter = "" Then
					strfilter = "  ({vwInvoiceRpt.ClientID = " & -1 & ")"
				Else
					strfilter = strfilter & " AND ({vwInvoiceRpt.ClientID = " & -1 & ")"
				End If
			End If
		End If
		''
		If cboCategory.SelectedIndex <> -1 Then
			If strfilter = "" Then
				strfilter = "  ({vwInvoiceRpt.CatID} = " & cboCategory.SelectedValue & ")"
			Else
				strfilter = strfilter & " AND ({vwInvoiceRpt.CatID} = " & cboCategory.SelectedValue & ")"
			End If
		Else
			''
			If cboCategory.Text <> "" And cboCategory.SelectedIndex = -1 Then
				If strfilter = "" Then
					strfilter = "  ({vwInvoiceRpt.CatID = " & -1 & ")"
				Else
					strfilter = strfilter & " AND ({vwInvoiceRpt.CatID = " & -1 & ")"
				End If
			End If
		End If
		''
		'If chkPosted.Checked = False And chkNotPosted.Checked = False And chkNew.Checked = False Then
		'    '' Do Nothing
		'Else

		'    If chkPosted.Checked = True Then

		'        strStatus = " ( {vwInvoiceRpt.StatusID}=" & 2

		'    End If
		'    ''
		'    If chkNotPosted.Checked = True Then
		'        If strStatus = "" Then
		'            strStatus = " ( {vwInvoiceRpt.StatusID}=" & 3
		'        Else
		'            strStatus = strStatus & " OR {vwInvoiceRpt.StatusID}=" & 3
		'        End If

		'    End If
		'    ''
		'    If chkNew.Checked = True Then
		'        If strStatus = "" Then
		'            strStatus = " ( {vwInvoiceRpt.StatusID}=" & 1
		'        Else
		'            strStatus = strStatus & " OR {vwInvoiceRpt.StatusID}=" & 1
		'        End If

		'    End If
		'If strStatus <> "" And Not (strStatus.EndsWith(")")) Then
		'    strStatus = strStatus & " )"
		'End If
		'End If
		If strfilter <> "" And strStatus <> "" Then

			strfilter = strfilter & " AND" & strStatus
		Else
			strfilter = strfilter & strStatus
		End If
		''
		Dim BillStatus As String = ""
		''
		If chkDue.Checked = False And chkOverDue30.Checked = False And chkOverDue60.Checked = False And chkOverDue90.Checked = False And chkOverDue120.Checked = False Then
			''
			strfilter = strfilter & " AND {vwInvoiceRpt.BillStatus}='NotFound'"
			''
		Else
			''
			BillStatus = " AND {vwInvoiceRpt.BillStatus} IN ["
			''
			If chkDue.Checked = True Then
				If BillStatus = " AND {vwInvoiceRpt.BillStatus} IN [" Then
					BillStatus = BillStatus & "'Due'"
				Else
					BillStatus = BillStatus & ",'Due'"
				End If
			End If
			''
			If chkOverDue30.Checked = True Then
				If BillStatus = " AND {vwInvoiceRpt.BillStatus} IN [" Then
					BillStatus = BillStatus & "'OverDue30Days'"
				Else
					BillStatus = BillStatus & ",'OverDue30Days'"
				End If
			End If
			''
			If chkOverDue60.Checked = True Then
				If BillStatus = " AND {vwInvoiceRpt.BillStatus} IN [" Then
					BillStatus = BillStatus & "'OverDue60Days'"
				Else
					BillStatus = BillStatus & ",'OverDue60Days'"
				End If
			End If
			''
			If chkOverDue90.Checked = True Then
				If BillStatus = " AND {vwInvoiceRpt.BillStatus} IN [" Then
					BillStatus = BillStatus & "'OverDue90Days'"
				Else
					BillStatus = BillStatus & ",'OverDue90Days'"
				End If
			End If
			''
			If chkOverDue120.Checked = True Then
				If BillStatus = " AND {vwInvoiceRpt.BillStatus} IN [" Then
					BillStatus = BillStatus & "'OverDue120Days'"
				Else
					BillStatus = BillStatus & ",'OverDue120Days'"
				End If
			End If
			''
			BillStatus = BillStatus & "]"
		End If
		''
		strfilter = strfilter & BillStatus
		''
		Return strfilter
	End Function

	Private Sub ClearTable()
		Dim cmd As New SqlClient.SqlCommand("Delete from tblTafkeet", conSql)
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()
		dsdata.Tables("tblTafkeet").Rows.Clear()

	End Sub

	Private Sub DrawGrid()
		''
		grdInvoiceList.DataSource = dsdata.Tables("vwInvoiceList").DefaultView
		''
		dsdata.Tables("vwInvoiceList").DefaultView.AllowNew = False
		''
		With grdInvoiceList
			.ReadOnly = True
			.ColumnHeadersHeight = btnShowCol.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
			''
			.Columns("AutoGel").Visible = False
			.Columns("ClientID").Visible = False
			.Columns("statusID").Visible = False
			.Columns("InvoiceID").Visible = False
			.Columns("CatID").Visible = False
			.Columns("Del").Visible = False
			.Columns("RefID").Visible = False
			.Columns("RefIDTo").Visible = False
			''
			.Columns("InvoiceDate").HeaderText = "Invoice Date"
			.Columns("InvoiceNumber").HeaderText = "Invoice #"
			.Columns("InvoiceFrom").HeaderText = "Invoice From"
			.Columns("InvoiceTo").HeaderText = "Invoice To"
			''
			.Columns("ClientName").HeaderText = "Client"
			.Columns("BillStatus").HeaderText = "Bill Status"
			.Columns("CatType").HeaderText = "Category"
			'.Columns("Total").DefaultCellStyle.Format = "#0#"
			'.Columns("AutoGel").HeaderText = "Auto Generated"
			'.Columns("TotalCurr2").DefaultCellStyle.Format = "#0#"
			.Columns("TotalCurr2").HeaderText = "Total " & GetCompanyCurrencySymbol2()
			.Columns("TotalCurr2").DefaultCellStyle.Format = "#,###.##"
			''
			.Columns("Total").DefaultCellStyle.Format = "#,###.##"
			.Columns("Total").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
		End With
		'grdInvoiceList.Columns("Total").DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
		''
		LoadProfile(mStrSubKeyName, Me.grdInvoiceList)
	End Sub

	Private Sub FilterGrid()
		''
		If blnLoading = True Then Exit Sub
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor
		''
		Dim s As String
		Dim strStatus As String
		''
		s = "(InvoiceDate >= '" & dtpDateFrom.Value.ToString("yyyy-M-d") & "') AND (InvoiceDate <= '" & dtpDateTo.Value.ToString("yyyy-M-d") & "')"
		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				s = s & " AND  (InvoiceNumber = " & tn & ")"
			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		If cboCategory.SelectedIndex <> -1 Then
			s = s & " AND (CatID = " & cboCategory.SelectedValue & ")"
		Else
			If cboCategory.Text <> "" And cboCategory.SelectedIndex = -1 Then
				s = s & " AND (CatID = " & -1 & ")"
			End If
		End If
		''
		If cboClient.SelectedIndex <> -1 Then
			s = s & " AND (ClientID = " & cboClient.SelectedValue & ")"
		Else
			If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
				s = s & " AND (ClientID = " & -1 & ")"
			End If

		End If
		''
		Dim BillStatus As String = ""
		If chkDue.Checked = False And chkOverDue30.Checked = False And chkOverDue60.Checked = False And chkOverDue90.Checked = False And chkOverDue120.Checked = False Then
			s = s & " AND BillStatus='NotFound'"
		Else

			BillStatus = " AND BillStatus IN ("
			''
			'If chkDue.Checked = True Then
			'	If BillStatus = " AND BillStatus IN (" Then
			'		BillStatus = BillStatus & "'Due'"
			'	Else
			'		BillStatus = BillStatus & ",'Due'"
			'	End If

			'End If
			''
			If chkOverDue30.Checked = True Then
				If BillStatus = " AND BillStatus IN (" Then
					BillStatus = BillStatus & "'OverDue30Days'"
				Else
					BillStatus = BillStatus & ",'OverDue30Days'"
				End If

			End If
			''
			If chkOverDue60.Checked = True Then
				If BillStatus = " AND BillStatus IN (" Then
					BillStatus = BillStatus & "'OverDue60Days'"
				Else
					BillStatus = BillStatus & ",'OverDue60Days'"
				End If

			End If
			''
			If chkOverDue90.Checked = True Then
				If BillStatus = " AND BillStatus IN (" Then
					BillStatus = BillStatus & "'OverDue90Days'"
				Else
					BillStatus = BillStatus & ",'OverDue90Days'"
				End If

			End If
			''
			If chkOverDue120.Checked = True Then
				If BillStatus = " AND BillStatus IN (" Then
					BillStatus = BillStatus & "'OverDue120Days'"
				Else
					BillStatus = BillStatus & ",'OverDue120Days'"
				End If
			End If
			''
			BillStatus = BillStatus & ")"
		End If
		''
		s = s & BillStatus
		''
		dsdata.Tables("vwInvoiceList").DefaultView.RowFilter = s
		''
		ChangeColor()
        CalculateTotal()
		''
		Windows.Forms.Cursor.Current = Cursors.Default
	End Sub

	Private Sub ChangeColor()
		''change color of visits according to status
		Dim i As Integer
		Dim intStatus As Integer
		For i = 0 To dsdata.Tables("vwInvoiceList").DefaultView.Count - 1
			intStatus = dsdata.Tables("vwInvoiceList").DefaultView.Item(i)("StatusID")

			Select Case intStatus
				Case 1
					grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.LightYellow

				Case 2
					grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.LightSteelBlue

				Case 3
					grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.MistyRose

			End Select



		Next
	End Sub

	Private Sub EditInvoice()
		If grdInvoiceList.Rows.Count = 0 Then Exit Sub
		If grdInvoiceList.Item("StatusID", grdInvoiceList.CurrentRow.Index).Value = 4 Then
			MsgBox("Cannot edit a paid invoice")
			Exit Sub
		End If

		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor

		Dim frm As New frmInvoice(grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value)
		appMain.addTabPage(frm, frmApplicationMain.eFormType.Invoice)
		'frm.Show()

		Windows.Forms.Cursor.Current = Cursors.Default
		''refresh


		AddHandler frm.Closed, AddressOf RefreshList
	End Sub

	Private Sub RefreshList(ByVal sender As Object, ByVal e As System.EventArgs)
		dsdata.Tables("vwInvoiceList").Rows.Clear()
		clsMr.BuildSqlAdapter("SELECT * FROM vwInvoiceList WHERE Del=0", "vwInvoiceList")
		FilterGrid()
		'MakeDataAdapter()
	End Sub

    Private Sub CalculateTotal()
        If blnLoading Then Exit Sub
        Dim dv As DataView = dsdata.Tables("vwInvoiceList").DefaultView
        Dim drv As DataRowView
        Dim gt As Double
        Dim gtCurr2 As Double

        For Each drv In dv
            If drv("Total") Is DBNull.Value Then
                drv("Total") = 0
            End If
            If drv("TotalCurr2") Is DBNull.Value Then
                drv("TotalCurr2") = 0
            End If
            gt += drv("Total")
            gtCurr2 += drv("TotalCurr2")
        Next
        txtTotal.Text = gt.ToString("#,###")
        txtTotalCurr2.Text = gtCurr2.ToString("#,###")
    End Sub

#End Region


#Region "GrdSetUp..."

	Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
		If Me.grpShowHideColumns.Visible = False Then
			Me.grpShowHideColumns.Visible = True
			Me.grpShowHideColumns.BringToFront()
			mstrCurrentGridName = "InvoiceList"
			''
			'' populate list with grid's dataSource fields...
			''

			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridCol.Items.Clear()
			For Each col In grdInvoiceList.Columns
				Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
			Next
			chkLstGridCol.Items.Remove("AutoGel")
			chkLstGridCol.Items.Remove("ClientID")
			chkLstGridCol.Items.Remove("StatusID")
			chkLstGridCol.Items.Remove("InvoiceID")
			chkLstGridCol.Items.Remove("CatID")
			chkLstGridCol.Items.Remove("Del")
			chkLstGridCol.Items.Remove("RefID")
			chkLstGridCol.Items.Remove("RefIDTo")
		Else
			Me.grpShowHideColumns.Visible = False
			Me.grpShowHideColumns.SendToBack()
		End If
	End Sub

	Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
		Dim i As Integer

		For i = 0 To Me.chkLstGridCol.Items.Count - 1
			Me.grdInvoiceList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
		Next

		''
		Me.grpShowHideColumns.Visible = False

	End Sub

	Private Sub frmInvoiceList_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		SaveProfile(mStrSubKeyName, Me.grdInvoiceList)
	End Sub

#End Region

    Private Sub btnPreview_ar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        LoadOverDueInvoiceList()
    End Sub

    Private Sub LoadOverDueInvoiceList()
        ''
        If grdInvoiceList.Rows.Count = 0 Then Exit Sub
        ''
        Dim frm As New frmQuickReport
        ''
        Dim rpt As Object
        ''
        If rdbEnglish.Checked Then
            ''
            rpt = New rptOverDueInvoice
        ElseIf rdbArabic.Checked Then
            rpt = New rptOverDueInvoice_ar
        End If
        ''
        ClearTable()
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor()
        ''
        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
        ''
        For Each tbCurrent In rpt.Database.Tables
            tliCurrent = tbCurrent.LogOnInfo
            ''
            With tliCurrent.ConnectionInfo
                .ServerName = gStrServerName
                .DatabaseName = gStrDataBaseName
                .UserID = "" 'gStrUserName
                .Password = ""   'gStrPassword
            End With
            ''
            tbCurrent.ApplyLogOnInfo(tliCurrent)
            ''
        Next tbCurrent
        ''
        rpt.SetParameterValue("Curr1", GetCompanyCurrencySymbol())
        rpt.SetParameterValue("Curr2", GetCompanyCurrencySymbol2())
        ''
        Dim dv As DataView = dsdata.Tables("vwInvoicelist").DefaultView
        Dim drv As DataRowView
        For Each drv In dv
            ''
            Dim dRdr As SqlClient.SqlDataReader
            Dim cmdX As SqlClient.SqlCommand
            ''
            Dim strUnitName As String
            Dim strPartUnitName As String
            Dim strSymbol As String
            Dim strUnitNameEn As String
            Dim strPartUnitNameEn As String
            Dim strSymbolEn As String
            ''
            strSQL = "select *   FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID
            ''
            cmdX = New SqlClient.SqlCommand(strSQL, conSql)
            cmdX.CommandType = CommandType.Text
            ''
            conSql.Open()
            dRdr = cmdX.ExecuteReader()
            If dRdr.Read Then
                strUnitName = dRdr("UnitName")
                strPartUnitName = dRdr("PartUnitName")
                strSymbol = dRdr("Symbol")
            End If
            dRdr.Close()
            conSql.Close()
            ''
            strSQL = "select *   FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID2
            ''
            cmdX = New SqlClient.SqlCommand(strSQL, conSql)
            cmdX.CommandType = CommandType.Text
            ''
            conSql.Open()
            dRdr = cmdX.ExecuteReader()
            If dRdr.Read Then
                strUnitNameEn = dRdr("UnitName")
                strPartUnitNameEn = dRdr("PartUnitName")
                strSymbolEn = dRdr("Symbol")
            End If
            dRdr.Close()
            conSql.Close()
            ''
            Dim strWord As String
            Dim strWordEn As String
            ''
            strWord = ToWords(drv("Total"), strUnitName, strPartUnitName)
            strWordEn = ToWordsEn(drv("TotalCurr2"), strUnitNameEn, strPartUnitNameEn)
            ''
            Dim drNew As DataRow = dsdata.Tables("tblTafkeet").NewRow
            drNew("Tafkeet") = strWord
            drNew("TafkeetEn") = strWordEn
            drNew("InvoiceID") = drv("InvoiceID")
            dsdata.Tables("tblTafkeet").Rows.Add(drNew)
            daTafkeet.Update(dsdata, "tblTafkeet")
        Next
        ''
        Dim strFilter As String = InvoiceFilterString()
        frm.crvInstantViewer.SelectionFormula = strFilter
        ''
        frm.crvInstantViewer.ReportSource = rpt
        frm.crvInstantViewer.Refresh()
        frm.Show()
        ''
        frm.crvInstantViewer.DisplayToolbar = True
        grpReportOptions.Visible = False
        Windows.Forms.Cursor.Current = Cursors.Default()
    End Sub

    Private Sub btnOkPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOkPreview.Click
        ''
        LoadOverDueInvoiceList()
    End Sub

    Private Sub btnCancelPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelPreview.Click
        ''
        grpReportOptions.Visible = False
    End Sub
End Class