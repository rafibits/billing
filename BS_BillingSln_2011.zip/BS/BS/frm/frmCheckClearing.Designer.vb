<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCheckClearing
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpPmtDetailButtons = New System.Windows.Forms.GroupBox
        Me.btnClear = New BHBut.BouncingHoverButton
        Me.lblDiscount = New System.Windows.Forms.Label
        Me.btnDetailClose = New BHBut.BouncingHoverButton
        Me.btnDeleteVeh = New BHBut.BouncingHoverButton
        Me.btnEditPayment = New BHBut.BouncingHoverButton
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.cboBank = New System.Windows.Forms.ComboBox
        Me.lblBank = New System.Windows.Forms.Label
        Me.grpDate = New System.Windows.Forms.GroupBox
        Me.dtpToFilter = New System.Windows.Forms.DateTimePicker
        Me.dtpFromFilter = New System.Windows.Forms.DateTimePicker
        Me.lblTo = New System.Windows.Forms.Label
        Me.lblFrom = New System.Windows.Forms.Label
        Me.cboType = New System.Windows.Forms.ComboBox
        Me.lblType = New System.Windows.Forms.Label
        Me.txtNumber = New System.Windows.Forms.TextBox
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.lblClientFilter = New System.Windows.Forms.Label
        Me.lblPaymentNumFilter = New System.Windows.Forms.Label
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.grdPMT = New System.Windows.Forms.DataGridView
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnRefresh = New System.Windows.Forms.Button
        Me.btnShowHide = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.grpPmtDetailButtons.SuspendLayout()
        Me.grpFilter.SuspendLayout()
        Me.grpDate.SuspendLayout()
        CType(Me.grdPMT, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpShowHideColumns.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpPmtDetailButtons
        '
        Me.grpPmtDetailButtons.Controls.Add(Me.btnClear)
        Me.grpPmtDetailButtons.Controls.Add(Me.lblDiscount)
        Me.grpPmtDetailButtons.Controls.Add(Me.btnDetailClose)
        Me.grpPmtDetailButtons.Controls.Add(Me.btnDeleteVeh)
        Me.grpPmtDetailButtons.Controls.Add(Me.btnEditPayment)
        Me.grpPmtDetailButtons.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.grpPmtDetailButtons.Location = New System.Drawing.Point(0, 530)
        Me.grpPmtDetailButtons.Name = "grpPmtDetailButtons"
        Me.grpPmtDetailButtons.Size = New System.Drawing.Size(827, 54)
        Me.grpPmtDetailButtons.TabIndex = 261
        Me.grpPmtDetailButtons.TabStop = False
        '
        'btnClear
        '
        Me.btnClear.AlternativeGroup = Nothing
        Me.btnClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnClear.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnClear.BackColor1 = System.Drawing.Color.White
        Me.btnClear.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnClear.BorderHover = True
        Me.btnClear.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClear.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClear.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClear.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClear.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClear.DrawBorder = True
        Me.btnClear.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClear.ForeColor = System.Drawing.Color.Navy
        Me.btnClear.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnClear.HoverColor2 = System.Drawing.Color.White
        Me.btnClear.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClear.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClear.Location = New System.Drawing.Point(133, 14)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnClear.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnClear.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnClear.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClear.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnClear.SelectedText = Nothing
        Me.btnClear.Size = New System.Drawing.Size(105, 28)
        Me.btnClear.TabIndex = 368
        Me.btnClear.TabStop = False
        Me.btnClear.Text = "C l e a r"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'lblDiscount
        '
        Me.lblDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblDiscount.ForeColor = System.Drawing.Color.Maroon
        Me.lblDiscount.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDiscount.Location = New System.Drawing.Point(763, -89)
        Me.lblDiscount.Name = "lblDiscount"
        Me.lblDiscount.Size = New System.Drawing.Size(34, 23)
        Me.lblDiscount.TabIndex = 366
        Me.lblDiscount.Text = "Discount"
        Me.lblDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnDetailClose
        '
        Me.btnDetailClose.AlternativeGroup = Nothing
        Me.btnDetailClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDetailClose.BackColor = System.Drawing.Color.Orange
        Me.btnDetailClose.BackColor1 = System.Drawing.Color.White
        Me.btnDetailClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnDetailClose.BorderHover = True
        Me.btnDetailClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDetailClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDetailClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDetailClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDetailClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDetailClose.DrawBorder = True
        Me.btnDetailClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDetailClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.btnDetailClose.ForeColor = System.Drawing.Color.Navy
        Me.btnDetailClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnDetailClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnDetailClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDetailClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnDetailClose.Location = New System.Drawing.Point(716, 17)
        Me.btnDetailClose.Name = "btnDetailClose"
        Me.btnDetailClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnDetailClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnDetailClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnDetailClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDetailClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnDetailClose.SelectedText = Nothing
        Me.btnDetailClose.Size = New System.Drawing.Size(105, 28)
        Me.btnDetailClose.TabIndex = 9
        Me.btnDetailClose.Text = "C l o s e"
        Me.btnDetailClose.UseVisualStyleBackColor = False
        '
        'btnDeleteVeh
        '
        Me.btnDeleteVeh.AlternativeGroup = Nothing
        Me.btnDeleteVeh.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDeleteVeh.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnDeleteVeh.BackColor1 = System.Drawing.Color.White
        Me.btnDeleteVeh.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnDeleteVeh.BorderHover = True
        Me.btnDeleteVeh.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDeleteVeh.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDeleteVeh.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDeleteVeh.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDeleteVeh.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDeleteVeh.DrawBorder = True
        Me.btnDeleteVeh.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDeleteVeh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnDeleteVeh.ForeColor = System.Drawing.Color.Navy
        Me.btnDeleteVeh.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDeleteVeh.HoverColor2 = System.Drawing.Color.White
        Me.btnDeleteVeh.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDeleteVeh.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnDeleteVeh.Location = New System.Drawing.Point(146, -40)
        Me.btnDeleteVeh.Name = "btnDeleteVeh"
        Me.btnDeleteVeh.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDeleteVeh.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnDeleteVeh.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDeleteVeh.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDeleteVeh.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnDeleteVeh.SelectedText = Nothing
        Me.btnDeleteVeh.Size = New System.Drawing.Size(118, 28)
        Me.btnDeleteVeh.TabIndex = 278
        Me.btnDeleteVeh.Text = "Remove Vehicle"
        Me.btnDeleteVeh.UseVisualStyleBackColor = False
        '
        'btnEditPayment
        '
        Me.btnEditPayment.AlternativeGroup = Nothing
        Me.btnEditPayment.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnEditPayment.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEditPayment.BackColor1 = System.Drawing.Color.White
        Me.btnEditPayment.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEditPayment.BorderHover = True
        Me.btnEditPayment.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEditPayment.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEditPayment.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnEditPayment.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEditPayment.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEditPayment.DrawBorder = True
        Me.btnEditPayment.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEditPayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnEditPayment.ForeColor = System.Drawing.Color.Navy
        Me.btnEditPayment.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEditPayment.HoverColor2 = System.Drawing.Color.White
        Me.btnEditPayment.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEditPayment.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnEditPayment.Location = New System.Drawing.Point(5, 14)
        Me.btnEditPayment.Name = "btnEditPayment"
        Me.btnEditPayment.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEditPayment.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnEditPayment.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnEditPayment.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnEditPayment.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnEditPayment.SelectedText = Nothing
        Me.btnEditPayment.Size = New System.Drawing.Size(105, 28)
        Me.btnEditPayment.TabIndex = 370
        Me.btnEditPayment.TabStop = False
        Me.btnEditPayment.Text = "E d i t "
        Me.btnEditPayment.UseVisualStyleBackColor = False
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.cboBank)
        Me.grpFilter.Controls.Add(Me.lblBank)
        Me.grpFilter.Controls.Add(Me.grpDate)
        Me.grpFilter.Controls.Add(Me.cboType)
        Me.grpFilter.Controls.Add(Me.lblType)
        Me.grpFilter.Controls.Add(Me.txtNumber)
        Me.grpFilter.Controls.Add(Me.cboClient)
        Me.grpFilter.Controls.Add(Me.lblClientFilter)
        Me.grpFilter.Controls.Add(Me.lblPaymentNumFilter)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(3, 45)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(821, 82)
        Me.grpFilter.TabIndex = 262
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Data Filter"
        '
        'cboBank
        '
        Me.cboBank.BackColor = System.Drawing.SystemColors.Window
        Me.cboBank.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBank.ForeColor = System.Drawing.Color.Navy
        Me.cboBank.FormattingEnabled = True
        Me.cboBank.Location = New System.Drawing.Point(321, 49)
        Me.cboBank.Name = "cboBank"
        Me.cboBank.Size = New System.Drawing.Size(178, 24)
        Me.cboBank.TabIndex = 323
        '
        'lblBank
        '
        Me.lblBank.AutoSize = True
        Me.lblBank.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblBank.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBank.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblBank.Location = New System.Drawing.Point(273, 54)
        Me.lblBank.Name = "lblBank"
        Me.lblBank.Size = New System.Drawing.Size(39, 15)
        Me.lblBank.TabIndex = 322
        Me.lblBank.Text = "Bank"
        Me.lblBank.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpDate
        '
        Me.grpDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpDate.Controls.Add(Me.dtpToFilter)
        Me.grpDate.Controls.Add(Me.dtpFromFilter)
        Me.grpDate.Controls.Add(Me.lblTo)
        Me.grpDate.Controls.Add(Me.lblFrom)
        Me.grpDate.Location = New System.Drawing.Point(512, 11)
        Me.grpDate.Name = "grpDate"
        Me.grpDate.Size = New System.Drawing.Size(299, 61)
        Me.grpDate.TabIndex = 321
        Me.grpDate.TabStop = False
        Me.grpDate.Text = "Value Date"
        '
        'dtpToFilter
        '
        Me.dtpToFilter.CalendarForeColor = System.Drawing.Color.Navy
        Me.dtpToFilter.CustomFormat = "dd MMM yyyy"
        Me.dtpToFilter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpToFilter.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToFilter.Location = New System.Drawing.Point(181, 19)
        Me.dtpToFilter.Name = "dtpToFilter"
        Me.dtpToFilter.Size = New System.Drawing.Size(94, 21)
        Me.dtpToFilter.TabIndex = 1
        '
        'dtpFromFilter
        '
        Me.dtpFromFilter.CalendarForeColor = System.Drawing.Color.Navy
        Me.dtpFromFilter.CustomFormat = "dd MMM yyyy"
        Me.dtpFromFilter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpFromFilter.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromFilter.Location = New System.Drawing.Point(55, 19)
        Me.dtpFromFilter.Name = "dtpFromFilter"
        Me.dtpFromFilter.Size = New System.Drawing.Size(94, 21)
        Me.dtpFromFilter.TabIndex = 0
        '
        'lblTo
        '
        Me.lblTo.AutoSize = True
        Me.lblTo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTo.ForeColor = System.Drawing.Color.Navy
        Me.lblTo.Location = New System.Drawing.Point(157, 22)
        Me.lblTo.Name = "lblTo"
        Me.lblTo.Size = New System.Drawing.Size(21, 15)
        Me.lblTo.TabIndex = 3
        Me.lblTo.Text = "To"
        Me.lblTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblFrom
        '
        Me.lblFrom.AutoSize = True
        Me.lblFrom.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFrom.ForeColor = System.Drawing.Color.Navy
        Me.lblFrom.Location = New System.Drawing.Point(17, 22)
        Me.lblFrom.Name = "lblFrom"
        Me.lblFrom.Size = New System.Drawing.Size(36, 15)
        Me.lblFrom.TabIndex = 2
        Me.lblFrom.Text = "From"
        Me.lblFrom.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboType
        '
        Me.cboType.BackColor = System.Drawing.SystemColors.Window
        Me.cboType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboType.ForeColor = System.Drawing.Color.Navy
        Me.cboType.FormattingEnabled = True
        Me.cboType.Location = New System.Drawing.Point(57, 16)
        Me.cboType.Name = "cboType"
        Me.cboType.Size = New System.Drawing.Size(178, 24)
        Me.cboType.TabIndex = 320
        '
        'lblType
        '
        Me.lblType.AutoSize = True
        Me.lblType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblType.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblType.Location = New System.Drawing.Point(14, 21)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(37, 15)
        Me.lblType.TabIndex = 319
        Me.lblType.Text = "Type"
        Me.lblType.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtNumber
        '
        Me.txtNumber.AcceptsReturn = True
        Me.txtNumber.BackColor = System.Drawing.Color.White
        Me.txtNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNumber.ForeColor = System.Drawing.Color.Navy
        Me.txtNumber.Location = New System.Drawing.Point(321, 17)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.Size = New System.Drawing.Size(178, 23)
        Me.txtNumber.TabIndex = 318
        '
        'cboClient
        '
        Me.cboClient.BackColor = System.Drawing.SystemColors.Window
        Me.cboClient.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboClient.ForeColor = System.Drawing.Color.Navy
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(57, 47)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(178, 24)
        Me.cboClient.TabIndex = 5
        '
        'lblClientFilter
        '
        Me.lblClientFilter.AutoSize = True
        Me.lblClientFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblClientFilter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClientFilter.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblClientFilter.Location = New System.Drawing.Point(9, 52)
        Me.lblClientFilter.Name = "lblClientFilter"
        Me.lblClientFilter.Size = New System.Drawing.Size(44, 15)
        Me.lblClientFilter.TabIndex = 4
        Me.lblClientFilter.Text = "Client"
        Me.lblClientFilter.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPaymentNumFilter
        '
        Me.lblPaymentNumFilter.AutoSize = True
        Me.lblPaymentNumFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblPaymentNumFilter.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaymentNumFilter.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblPaymentNumFilter.Location = New System.Drawing.Point(265, 22)
        Me.lblPaymentNumFilter.Name = "lblPaymentNumFilter"
        Me.lblPaymentNumFilter.Size = New System.Drawing.Size(50, 13)
        Me.lblPaymentNumFilter.TabIndex = 11
        Me.lblPaymentNumFilter.Text = "Number"
        Me.lblPaymentNumFilter.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(827, 40)
        Me.lblfrmTitle.TabIndex = 263
        Me.lblfrmTitle.Text = " Payment Clear"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grdPMT
        '
        Me.grdPMT.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdPMT.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdPMT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdPMT.Location = New System.Drawing.Point(6, 133)
        Me.grdPMT.Name = "grdPMT"
        Me.grdPMT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdPMT.Size = New System.Drawing.Size(815, 391)
        Me.grdPMT.TabIndex = 264
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(44, 147)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 165)
        Me.grpShowHideColumns.TabIndex = 368
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Show/Hide Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(6, 135)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 94
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(6, 17)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 109)
        Me.chkLstGridCol.TabIndex = 93
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnRefresh
        '
        Me.btnRefresh.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRefresh.Image = Global.BS.My.Resources.Resources.Refresh
        Me.btnRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRefresh.Location = New System.Drawing.Point(723, 10)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(91, 20)
        Me.btnRefresh.TabIndex = 390
        Me.btnRefresh.Text = "R e f r e s h"
        Me.btnRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'btnShowHide
        '
        Me.btnShowHide.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowHide.BackColor = System.Drawing.Color.Linen
        Me.btnShowHide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowHide.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowHide.FlatAppearance.BorderSize = 2
        Me.btnShowHide.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowHide.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowHide.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowHide.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowHide.ForeColor = System.Drawing.Color.White
        Me.btnShowHide.Image = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowHide.Location = New System.Drawing.Point(9, 136)
        Me.btnShowHide.Name = "btnShowHide"
        Me.btnShowHide.Size = New System.Drawing.Size(32, 30)
        Me.btnShowHide.TabIndex = 369
        Me.btnShowHide.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.AcceptsReturn = True
        Me.TextBox1.BackColor = System.Drawing.Color.White
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.Navy
        Me.TextBox1.Location = New System.Drawing.Point(258, 10)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(178, 23)
        Me.TextBox1.TabIndex = 391
        Me.TextBox1.Visible = False
        '
        'frmCheckClearing
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(827, 584)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.grpShowHideColumns)
        Me.Controls.Add(Me.btnShowHide)
        Me.Controls.Add(Me.grdPMT)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.grpFilter)
        Me.Controls.Add(Me.grpPmtDetailButtons)
        Me.KeyPreview = True
        Me.Name = "frmCheckClearing"
        Me.Text = " Payment Clear"
        Me.grpPmtDetailButtons.ResumeLayout(False)
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        Me.grpDate.ResumeLayout(False)
        Me.grpDate.PerformLayout()
        CType(Me.grdPMT, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grpPmtDetailButtons As System.Windows.Forms.GroupBox
    Friend WithEvents btnClear As BHBut.BouncingHoverButton
    Friend WithEvents lblDiscount As System.Windows.Forms.Label
    Friend WithEvents btnDetailClose As BHBut.BouncingHoverButton
    Friend WithEvents btnDeleteVeh As BHBut.BouncingHoverButton
    Friend WithEvents btnEditPayment As BHBut.BouncingHoverButton
    Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
    Friend WithEvents dtpToFilter As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFromFilter As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtNumber As System.Windows.Forms.TextBox
    Friend WithEvents cboClient As System.Windows.Forms.ComboBox
    Friend WithEvents lblTo As System.Windows.Forms.Label
    Friend WithEvents lblFrom As System.Windows.Forms.Label
    Friend WithEvents lblClientFilter As System.Windows.Forms.Label
    Friend WithEvents lblPaymentNumFilter As System.Windows.Forms.Label
    Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
    Friend WithEvents grdPMT As System.Windows.Forms.DataGridView
    Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
    Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
    Friend WithEvents btnShowHide As System.Windows.Forms.Button
    Friend WithEvents cboType As System.Windows.Forms.ComboBox
    Friend WithEvents lblType As System.Windows.Forms.Label
    Friend WithEvents grpDate As System.Windows.Forms.GroupBox
    Friend WithEvents cboBank As System.Windows.Forms.ComboBox
    Friend WithEvents lblBank As System.Windows.Forms.Label
   Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
