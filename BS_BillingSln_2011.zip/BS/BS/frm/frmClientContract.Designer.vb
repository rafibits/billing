<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmClientContract
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tcMain = New System.Windows.Forms.TabControl
        Me.tpClientList = New System.Windows.Forms.TabPage
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grpControls = New System.Windows.Forms.GroupBox
        Me.btnEmployeeList = New BHBut.BouncingHoverButton
        Me.btnNewClient = New BHBut.BouncingHoverButton
        Me.btnCloseList = New BHBut.BouncingHoverButton
        Me.btnEditClient = New BHBut.BouncingHoverButton
        Me.grdClientList = New System.Windows.Forms.DataGridView
        Me.tcMain.SuspendLayout()
        Me.tpClientList.SuspendLayout()
        Me.grpControls.SuspendLayout()
        CType(Me.grdClientList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tcMain
        '
        Me.tcMain.Controls.Add(Me.tpClientList)
        Me.tcMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tcMain.Location = New System.Drawing.Point(0, 0)
        Me.tcMain.Name = "tcMain"
        Me.tcMain.SelectedIndex = 0
        Me.tcMain.Size = New System.Drawing.Size(693, 407)
        Me.tcMain.TabIndex = 352
        '
        'tpClientList
        '
        Me.tpClientList.Controls.Add(Me.btnShowCol)
        Me.tpClientList.Controls.Add(Me.grpControls)
        Me.tpClientList.Controls.Add(Me.grdClientList)
        Me.tpClientList.Location = New System.Drawing.Point(4, 22)
        Me.tpClientList.Name = "tpClientList"
        Me.tpClientList.Padding = New System.Windows.Forms.Padding(3)
        Me.tpClientList.Size = New System.Drawing.Size(685, 381)
        Me.tpClientList.TabIndex = 0
        Me.tpClientList.Text = "Client List"
        Me.tpClientList.UseVisualStyleBackColor = True
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(5, 4)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 349
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grpControls
        '
        Me.grpControls.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpControls.Controls.Add(Me.btnEmployeeList)
        Me.grpControls.Controls.Add(Me.btnNewClient)
        Me.grpControls.Controls.Add(Me.btnCloseList)
        Me.grpControls.Controls.Add(Me.btnEditClient)
        Me.grpControls.Location = New System.Drawing.Point(5, 328)
        Me.grpControls.Name = "grpControls"
        Me.grpControls.Size = New System.Drawing.Size(672, 45)
        Me.grpControls.TabIndex = 348
        Me.grpControls.TabStop = False
        '
        'btnEmployeeList
        '
        Me.btnEmployeeList.AlternativeGroup = Nothing
        Me.btnEmployeeList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnEmployeeList.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEmployeeList.BackColor1 = System.Drawing.Color.White
        Me.btnEmployeeList.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEmployeeList.BorderHover = True
        Me.btnEmployeeList.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEmployeeList.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEmployeeList.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnEmployeeList.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEmployeeList.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEmployeeList.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEmployeeList.DrawBorder = True
        Me.btnEmployeeList.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEmployeeList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnEmployeeList.ForeColor = System.Drawing.Color.Navy
        Me.btnEmployeeList.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnEmployeeList.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnEmployeeList.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEmployeeList.Location = New System.Drawing.Point(379, 10)
        Me.btnEmployeeList.Name = "btnEmployeeList"
        Me.btnEmployeeList.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnEmployeeList.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnEmployeeList.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEmployeeList.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnEmployeeList.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnEmployeeList.SelectedText = Nothing
        Me.btnEmployeeList.Size = New System.Drawing.Size(128, 28)
        Me.btnEmployeeList.TabIndex = 43
        Me.btnEmployeeList.Text = "Employee List"
        Me.btnEmployeeList.UseVisualStyleBackColor = False
        '
        'btnNewClient
        '
        Me.btnNewClient.AlternativeGroup = Nothing
        Me.btnNewClient.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNewClient.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNewClient.BackColor1 = System.Drawing.Color.White
        Me.btnNewClient.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNewClient.BorderHover = True
        Me.btnNewClient.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNewClient.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNewClient.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNewClient.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNewClient.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNewClient.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNewClient.DrawBorder = True
        Me.btnNewClient.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNewClient.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnNewClient.ForeColor = System.Drawing.Color.Navy
        Me.btnNewClient.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNewClient.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNewClient.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewClient.Location = New System.Drawing.Point(11, 10)
        Me.btnNewClient.Name = "btnNewClient"
        Me.btnNewClient.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNewClient.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNewClient.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewClient.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNewClient.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNewClient.SelectedText = Nothing
        Me.btnNewClient.Size = New System.Drawing.Size(128, 28)
        Me.btnNewClient.TabIndex = 42
        Me.btnNewClient.Text = "N e w  C l i e n t  "
        Me.btnNewClient.UseVisualStyleBackColor = False
        '
        'btnCloseList
        '
        Me.btnCloseList.AlternativeGroup = Nothing
        Me.btnCloseList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCloseList.BackColor = System.Drawing.Color.Orange
        Me.btnCloseList.BackColor1 = System.Drawing.Color.White
        Me.btnCloseList.BackColor2 = System.Drawing.Color.Orange
        Me.btnCloseList.BorderHover = True
        Me.btnCloseList.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCloseList.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCloseList.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCloseList.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCloseList.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCloseList.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCloseList.DrawBorder = True
        Me.btnCloseList.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCloseList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnCloseList.ForeColor = System.Drawing.Color.Navy
        Me.btnCloseList.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCloseList.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCloseList.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCloseList.Location = New System.Drawing.Point(556, 11)
        Me.btnCloseList.Name = "btnCloseList"
        Me.btnCloseList.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCloseList.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCloseList.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCloseList.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCloseList.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCloseList.SelectedText = Nothing
        Me.btnCloseList.Size = New System.Drawing.Size(105, 28)
        Me.btnCloseList.TabIndex = 41
        Me.btnCloseList.Text = "C l o s e"
        Me.btnCloseList.UseVisualStyleBackColor = False
        '
        'btnEditClient
        '
        Me.btnEditClient.AlternativeGroup = Nothing
        Me.btnEditClient.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnEditClient.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEditClient.BackColor1 = System.Drawing.Color.White
        Me.btnEditClient.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEditClient.BorderHover = True
        Me.btnEditClient.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEditClient.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEditClient.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnEditClient.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEditClient.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEditClient.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEditClient.DrawBorder = True
        Me.btnEditClient.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEditClient.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnEditClient.ForeColor = System.Drawing.Color.Navy
        Me.btnEditClient.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnEditClient.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnEditClient.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEditClient.Location = New System.Drawing.Point(158, 10)
        Me.btnEditClient.Name = "btnEditClient"
        Me.btnEditClient.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnEditClient.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnEditClient.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEditClient.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnEditClient.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnEditClient.SelectedText = Nothing
        Me.btnEditClient.Size = New System.Drawing.Size(128, 28)
        Me.btnEditClient.TabIndex = 17
        Me.btnEditClient.Text = "E d i t  C l i e n t "
        Me.btnEditClient.UseVisualStyleBackColor = False
        '
        'grdClientList
        '
        Me.grdClientList.AllowUserToAddRows = False
        Me.grdClientList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdClientList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdClientList.Location = New System.Drawing.Point(-4, 62)
        Me.grdClientList.Name = "grdClientList"
        Me.grdClientList.ReadOnly = True
        Me.grdClientList.Size = New System.Drawing.Size(676, 247)
        Me.grdClientList.TabIndex = 347
        '
        'frmClientContract
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(693, 407)
        Me.Controls.Add(Me.tcMain)
        Me.Name = "frmClientContract"
        Me.Text = "frmClientContract"
        Me.tcMain.ResumeLayout(False)
        Me.tpClientList.ResumeLayout(False)
        Me.grpControls.ResumeLayout(False)
        CType(Me.grdClientList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tcMain As System.Windows.Forms.TabControl
    Friend WithEvents tpClientList As System.Windows.Forms.TabPage
    Friend WithEvents btnShowCol As System.Windows.Forms.Button
    Friend WithEvents grpControls As System.Windows.Forms.GroupBox
    Friend WithEvents btnEmployeeList As BHBut.BouncingHoverButton
    Friend WithEvents btnNewClient As BHBut.BouncingHoverButton
    Friend WithEvents btnCloseList As BHBut.BouncingHoverButton
    Friend WithEvents btnEditClient As BHBut.BouncingHoverButton
    Friend WithEvents grdClientList As System.Windows.Forms.DataGridView
End Class
