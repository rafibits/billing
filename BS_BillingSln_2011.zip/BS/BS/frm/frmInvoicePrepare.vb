Imports BITSConn
Imports System.Data.SqlClient

''' <Used DB Components>
''' vwTransaction
''' tblInvoice
''' tblInvoiceDetail
''' tblClient
''' tblClientItem
''' tblTransaction
''' tblParkingArea
''' vwTransactionParkingArea
''' </Used DB Components>

Public Class frmInvoicePrepare

#Region "Form-Declaration..."

	Private dsdata As DataSet
	Private clsMr As ClsMain
	Private blnLoading As Boolean
	Private mstrCurrentGridName As String
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\InvoicePrepare\Settings"
	Private daInvoice As SqlDataAdapter
	Private daInvoiceDetail, daTransaction As SqlDataAdapter
	Private CurrID2 As Integer
	Private s As String = ""
	Private dblInvoiceTotal As Double = 0
	'Dim dblAddCharge As Double = 0

#End Region


#Region "Form-Load.........."

	Private Sub frmInvoicePrepare_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        ''
        SaveProfile(mStrSubKeyName, Me.grdInvoiceList)
    End Sub

    Private Sub frmInvoicePrepare_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

	Private Sub frmInvoiceList_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		clsMr = New ClsMain(conSql)
		''
		blnLoading = True
		MakeDataAdapter()
		FillComboBox()
		DrawGrid()
		blnLoading = False
		''
		''set defaults
		''
		cboClient.SelectedIndex = -1
		GetCompanyCurrencies()
		lblCurrSymbol.Text = GetCompanyCurrencySymbol()
		lblCurrSymbol2.Text = GetCompanyCurrencySymbol2()
		FilterGrid()
		btnUpdatePrice.Enabled = True
		btnAutoGenerateInvoice.Enabled = False
		grpTransactionParkingArea.Visible = False
		''
		'SetUserGenInvoice()
		''
	End Sub

#End Region


#Region "Form-Initialisation"

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

    End Sub

	Private Sub MakeDataAdapter()
		''
		'' set SQL for selecting active emp recs...
		clsMr.BuildSqlAdapter("SELECT seq_ID, Reg_serial, ICAO, ClientName, Make, Model, dat_orig, gates_invFinger, time_orig, dat_dest, time_dest, Hours, Days, rwy_orig, light_orig, light_dest, gate, gates_invFinger, counters, reg_weight, Aircraft_type, Discount, TotalLanding, TotalLighting, TotalParking, TotalBridges, TotalCounter, TotalTakeOffLights,InvoiceNumber, ClientID, InvoiceID ,TransactionID  FROM vwTransaction WHERE TransactionID=0", "vwTransaction")
		daTransaction = clsMr.BuildSqlAdapter("SELECT TransactionID,Seq_ID,ICAO, Hours,TotalTakeOffLights,counters, TotalLanding,TotalLighting,TotalParking,TotalBridges,TotalCounter,ClientID FROM vwTransaction  WHERE TransactionID=-1", "tblTransaction")
		daInvoice = clsMr.BuildSqlAdapter("SELECT * FROM tblInvoice WHERE InvoiceID=0 ", "tblInvoice")
		daInvoiceDetail = clsMr.BuildSqlAdapter("SELECT * FROM tblInvoiceDetail WHERE InvoiceID=0 ", "tblInvoiceDetail")
		clsMr.BuildSqlAdapter("SELECT ClientID,ClientName FROM tblClient Where Del=0 ORDER BY ClientName ", "ClientName")
		clsMr.BuildSqlAdapter("SELECT Weight,RegCode from tblClientItem WHERE Del=0 AND ClientItemID=0", "tblClientItem")
		clsMr.BuildSqlAdapter("Select ClientID,sum (Reg_Weight) ,Sum(TotalLanding) as TotalLanding,  sum (TotalParking) as TotalParking,Sum(TotalLighting) as TotalLighting , sum (TotalBridges) as TotalBridges , Sum (TotalCounter) as TotalCounter, SUM(TotalTakeOffLights) AS TotalTakeOffLights FROM tblTransaction WHERE InvoiceID IS Null Group BY ClientID", "vwClientTransSum")
		clsMr.BuildSqlAdapter("SELECT * FROM tblParkingArea  WHERE Del=0", "tblParkingArea")
		clsMr.BuildSqlAdapter("SELECT * FROM vwTransactionParkingArea", "vwTransactionParkingArea")
		dsdata = clsMr.getDataSet
	End Sub

	Private Sub FillComboBox()
		''
		clsMr.FillComboBox("ClientName", cboClient, "ClientName", "ClientID")
		''
	End Sub

	Private Sub SetDefaultValue()
		''
		'clsMr.SetDefaults("tblInvoice", "CreateByID", gIntUserID, "CreateDate", Now.Date, "Del", 0, "StatusID", 1, "InvoiceDate", Now.Date, "InvoiceFrom", Now.Date, "InvoiceTo", Now.Date)
		''
	End Sub

	Private Sub SetAutoNumber()
		''
	End Sub

#End Region


#Region "Form-UI/Methods...."

    Private Sub btnUpdateHours_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor()

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '-----------------------------' Update ParkingAreaID in tblTransactionParking'-------------------------'
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        'Try

        '    Dim cmd As New SqlCommand("UPDATE tblTransactionParking SET tblTransactionParking.ParkingAreaID = tblParkingArea.ParkingAreaID FROM tblParkingArea INNER JOIN tblTransactionParking AS tblTransactionParking_1 ON tblParkingArea.ParkingAreaCode = tblTransactionParking_1.ParkingCode where tblParkingArea.ParkingAreaCode = tblTransactionParking_1.ParkingCode ", conSql)

        '    conSql.Open()
        '    cmd.ExecuteNonQuery()
        '    conSql.Close()

        'Catch ex As Exception
        '    Windows.Forms.Cursor.Current = Cursors.Default()
        '    conSql.Close()
        'End Try

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ' reload data, since data governing the link between the tblTransactionParking and tblParkingArea
        ' has been updated
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        'FilterGrid()

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '---------------------------' Update TotalHours in tblTransactionParking ----------------------------'
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        'Try

        '    Dim cmd As New SqlCommand("Update tbltransactionParking set Totalhours= ceiling(datediff(minute, (DtIn), (DtOut))/60)", conSql)
        '    conSql.Open()
        '    cmd.ExecuteNonQuery()
        '    conSql.Close()

        'Catch ex As Exception
        '    Windows.Forms.Cursor.Current = Cursors.Default()
        '    conSql.Close()
        'End Try

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '---------------------------' Update TotalChargeableHours in tblTransactionParking--------------------
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        'Try

        '    Dim cmdChargeable As New SqlCommand("Update tblTransactionParking set TotalChargeablehours= ceiling(datediff(minute, (DtIn), (DtOut))/60) FROM tblTransactionParking inner join tblParkingArea on tblTransactionParking.ParkingAreaID=tblParkingArea.ParkingAreaID WHERE tblParkingArea.Chargeable <> 0", conSql)

        '    conSql.Open()
        '    cmdChargeable.ExecuteNonQuery()
        '    conSql.Close()

        'Catch ex As Exception
        '    Windows.Forms.Cursor.Current = Cursors.Default()
        '    conSql.Close()
        'End Try

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '-------------------------------- Update Hours in tblTransaction------------------------------------- 
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        Try
            Dim i As Integer
            Dim dv As DataView
            dv = dsdata.Tables("vwTransaction").DefaultView
            For i = 0 To dv.Count - 1
                'Dim cmd As New SqlCommand("Update tbltransaction set tbltransaction.Hours =(SELECT Sum(tblTransactionParking.TotalChargeableHours)from tblTransactionParking INNER JOIN dbo.tblTransaction ON (dbo.tblTransaction.seq_ID = dbo.tblTransactionParking.seq_ID ) WHERE tblTransaction.Seq_ID = " & dv(i)("Seq_ID") & ")", conSql)
                'strSQL = "UPDATE tbltransaction "
                'strsql &= "SET tbltransaction.Hours =( "
                'strsql &= "SELECT Sum(tblTransactionParking.TotalChargeableHours) "
                'strsql &= "FROM tblTransactionParking INNER JOIN dbo.tblTransaction ON "
                'strsql &= "(dbo.tblTransaction.seq_ID = dbo.tblTransactionParking.seq_ID ) "
                'strsql &= "WHERE tblTransaction.Seq_ID = " & dv(i)("Seq_ID") & ")"
                'strsql &= "WHERE tblTransaction.Seq_ID = " & dv(i)("Seq_ID") & ")"

                'If cboClient.SelectedIndex <> -1 Then
                '   s = s & " AND (ClientID = " & cboClient.SelectedValue & ")"
                'Else
                '   If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
                '      s = s & " AND (ClientID = " & -1 & ")"
                '   End If

                'End If
                strSQL = "UPDATE tbltransaction "
                strSQL &= "SET tbltransaction.Hours =( "
                strSQL &= "SELECT SUM(tblTransactionParking.TotalChargeableHours) "
                strSQL &= "FROM tblTransactionParking "
                strSQL &= "WHERE tblTransactionParking.Seq_ID = " & dv(i)("Seq_ID") & ")"
                strSQL &= "WHERE tblTransaction.Seq_ID = " & dv(i)("Seq_ID")
                If cboClient.SelectedIndex <> -1 Then
                    strSQL = strSQL & " AND (ClientID = " & cboClient.SelectedValue & ")"
                Else
                    If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
                        strSQL = strSQL & " AND (ClientID = " & -1 & ")"
                    End If
                End If
                'strSQL &= " AND (Dat_orig >= '" & dtpDateFrom.Value.ToShortDateString() & "') AND (Dat_orig <= '" & dtpDateTo.Value.ToShortDateString() & "')"
                strSQL &= " AND (Dat_dest >= '" & dtpDateFrom.Value.ToShortDateString() & "') AND (Dat_dest <= '" & dtpDateTo.Value.ToShortDateString() & "')"


                ''WHERE tblTransaction.Seq_ID = 18020

                Dim cmd As New SqlCommand(strSQL, conSql)
                conSql.Open()
                cmd.ExecuteNonQuery()
                conSql.Close()
            Next
        Catch ex As Exception
            Windows.Forms.Cursor.Current = Cursors.Default()
            conSql.Close()
        End Try
        '      Catch ex As Exception
        '	Windows.Forms.Cursor.Current = Cursors.Default()
        '	conSql.Close()
        'End Try
        Windows.Forms.Cursor.Current = Cursors.Default()
        FilterGrid()
        'CalculateTotal()
        ' btnUpdateClient.Enabled = False
        ' btnUpdateHours.Enabled = False
        'btnAutoGenerateInvoice.Enabled = True
        ''
    End Sub

    Private Sub btnUpdateClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Windows.Forms.Cursor.Current = Cursors.WaitCursor()
        Try
            Dim cmd As New SqlCommand("Update tbltransaction set ClientID = tblClient.ClientID FROM tblClient INNER JOIN tblTransaction ON tblTransaction.Operatr = tblClient.ICAO WHERE tblTransaction.InvoiceID is Null", conSql)

            conSql.Open()
            cmd.ExecuteNonQuery()
            conSql.Close()

        Catch ex As Exception
            Windows.Forms.Cursor.Current = Cursors.Default()
            conSql.Close()
        End Try
        Windows.Forms.Cursor.Current = Cursors.Default()
    End Sub

	Private Sub btnUpdatePrice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdatePrice.Click

		If blnLoading Then Exit Sub

		blnLoading = True
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		Dim dblTotal As Double = 0
		Dim dv As DataView = dsdata.Tables("vwTransaction").DefaultView
		Dim drv As DataRowView
		For Each drv In dv
			''
			If IsDBNull(drv("Discount")) Then
				drv("Discount") = 0
			End If
			''
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			' the service of nunber '1' is Landing Fees
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

			If drv("Reg_Weight") Is DBNull.Value Then
				drv("Reg_Weight") = 0
			End If
			dblTotal = drv("Reg_Weight") * GetServicePrice(1)
			drv("TotalLanding") = dblTotal - (dblTotal * drv("Discount") / 100)


			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			' the service of nunber '2' is Landing Lights...
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

			If drv("Light_orig") Is DBNull.Value Then	'Or drv("Light_orig") = 0 Then
				drv("TotalLighting") = 0
			Else
				dblTotal = GetServicePrice(2) + Math.Ceiling(drv("Light_orig") / 5 * GetServiceAdditionalCharge(2))
				'drv("TotalLighting") = GetServicePrice(2) + Math.Ceiling(drv("Light_orig") / 5 * GetServiceAdditionalCharge(2)) '8000) '16000
				drv("TotalLighting") = dblTotal - (dblTotal * drv("Discount") / 100)
			End If

			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			' the service of nunber '3' is Bridges 
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

			If drv("gates_invFinger") Is DBNull.Value Then 'Or drv("gates_invFinger") = 0 Then
				drv("gates_invFinger") = 0
			Else
				If drv("gates_invFinger") = -1 Then
					'drv("TotalBridges") = GetServicePrice(3) ''if invfinger then 150000
					dblTotal = GetServicePrice(3)
					drv("TotalBridges") = dblTotal - (dblTotal * drv("Discount") / 100)
				End If
			End If

			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			' the service of nunber '4' is Take Off Lights 
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

			If drv("Light_dest") Is DBNull.Value Then	'Or drv("Light_dest") = 0 Then
				drv("TotalTakeOffLights") = 0
			Else
				dblTotal = GetServicePrice(4) + Math.Ceiling(drv("Light_dest") / 5 * GetServiceAdditionalCharge(4))
				'drv("TotalTakeOffLights") = GetServicePrice(4) + Math.Ceiling(drv("Light_dest") / 5 * GetServiceAdditionalCharge(4))		'8000)	 '24000 '
				drv("TotalTakeOffLights") = dblTotal - (dblTotal * drv("Discount") / 100)
			End If

			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			' the service of nunber '5' is Counters 
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

			If drv("counters") Is DBNull.Value Then
				drv("TotalCounter") = 0
			Else
				'drv("TotalCounter") = drv("counters") * GetServicePrice(5) ''nb*150000
				dblTotal = drv("counters") * GetServicePrice(5)					''nb*150000
				drv("TotalCounter") = dblTotal - (dblTotal * drv("Discount") / 100)
			End If

			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			' the service of nunber '6' is Parking 
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

			If drv("Reg_Weight") >= 0 And drv("Reg_Weight") <= 75 Then
				''
				If drv("Hours") Is DBNull.Value Then 'Or drv("Hours") = 0 Then
					drv("TotalParking") = 0
				Else
					dblTotal = GetServicePrice(6) * GetNbOfDays(drv("Hours")) * drv("Reg_Weight")
					'drv("TotalParking") = GetServicePrice(6) * GetNbOfDays(drv("Hours")) * drv("Reg_Weight")	
					drv("TotalParking") = dblTotal - (dblTotal * drv("Discount") / 100)
					'3500 
				End If
				''
			Else
				If drv("Hours") Is DBNull.Value Then 'Or drv("Hours") = 0 Then
					drv("TotalParking") = 0
				Else
					''
					Dim dblTotal1 As Double
					Dim dblTotal2 As Double
					''
					dblTotal1 = GetServicePrice(6) * GetNbOfDays(drv("Hours")) * 75		'3500 
					dblTotal2 = GetServiceAdditionalCharge(6) * GetNbOfDays(drv("Hours")) * (drv("Reg_Weight") - 75) ''2500
					dblTotal = dblTotal1 + dblTotal2
					'drv("TotalParking") = dblTotal1 + dblTotal2
					drv("TotalParking") = dblTotal - (dblTotal * drv("Discount") / 100)
				End If
			End If

			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			''update command to update tblTransaction
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

			Dim cmd As New SqlCommand("UPDATE tblTransaction SET TotalTakeOffLights=" & drv("TotalTakeOffLights") & ",TotalLanding=" & drv("TotalLanding") & ", TotalLighting=" & drv("TotalLighting") & ", TotalParking=" & drv("TotalParking") & ", TotalBridges=" & drv("TotalBridges") & ",TotalCounter=" & drv("TotalCounter") & " WHERE TransactionID=" & drv("TransactionID"), conSql)
			conSql.Open()
			cmd.ExecuteNonQuery()
			conSql.Close()
			''
		Next
		''
		blnLoading = False
		CalculateTotal()
		Windows.Forms.Cursor.Current = Cursors.Default()
		btnUpdatePrice.Enabled = False
		If chkInvoiced.Checked = True Then
			btnAutoGenerateInvoice.Enabled = False
		Else
			btnAutoGenerateInvoice.Enabled = True
		End If
		'btnUpdateHours.Enabled = True
	End Sub

	Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
		If Me.grpShowHideColumns.Visible = False Then
			Me.grpShowHideColumns.Visible = True
			Me.grpShowHideColumns.BringToFront()
			mstrCurrentGridName = "InvoicePrepare"
			''
			'' populate list with grid's dataSource fields...
			''

			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridCol.Items.Clear()
			For Each col In grdInvoiceList.Columns
				Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
			Next

			chkLstGridCol.Items.Remove("ClientID")
			chkLstGridCol.Items.Remove("InvoiceID")
			chkLstGridCol.Items.Remove("TransactionID")
		Else
			Me.grpShowHideColumns.Visible = False
			Me.grpShowHideColumns.SendToBack()
		End If
	End Sub

	Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
		Dim i As Integer

		For i = 0 To Me.chkLstGridCol.Items.Count - 1
			Me.grdInvoiceList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
		Next

		''
		Me.grpShowHideColumns.Visible = False

	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		''
		Dim intCounter As Integer
		Dim drUpdate() As DataRow
		Dim dt As DataTable
		''
		dt = dsdata.Tables("vwTransaction").GetChanges(DataRowState.Modified)
		''
		If Not (dt Is Nothing) Then
			'
			dsdata.Tables("tblTransaction").Rows.Clear()
			'If s <> "" Then
			'	daTransaction = clsMr.BuildSqlAdapter("SELECT TransactionID,reg_weight, light_Orig, light_dest, Hours, Operatr, ClientID, TotalTakeOffLights, Counters, TotalLanding,TotalLighting,TotalParking,TotalBridges,TotalCounter FROM tblTransaction  WHERE " & s, "tblTransaction")
			'Else
			daTransaction = clsMr.BuildSqlAdapter("SELECT TransactionID,reg_weight, light_Orig, light_dest, Hours, gates_invFinger, Operatr, ClientID, TotalLanding, Counters, TotalTakeOffLights,TotalLighting,TotalParking,TotalBridges,TotalCounter FROM tblTransaction", "tblTransaction")
			'End If
			''
			For intCounter = 0 To dt.Rows.Count - 1
				drUpdate = dsdata.Tables("tblTransaction").Select("TransactionID=" & dt.Rows(intCounter)("TransactionID"))
				'drUpdate = dsdata.Tables("tblTransaction").Select("Seq_ID=" & dt.Rows(intCounter)("Seq_ID"))

				drUpdate(0).BeginEdit()
				drUpdate(0)("TotalLanding") = dt.Rows(intCounter)("TotalLanding")
				drUpdate(0)("Hours") = dt.Rows(intCounter)("Hours")
				drUpdate(0)("Operatr") = dt.Rows(intCounter)("ICAO")
				drUpdate(0)("ClientID") = dt.Rows(intCounter)("ClientID")
				drUpdate(0)("reg_weight") = dt.Rows(intCounter)("reg_weight")
				drUpdate(0)("light_Orig") = dt.Rows(intCounter)("light_Orig")
				drUpdate(0)("light_dest") = dt.Rows(intCounter)("light_dest")
				drUpdate(0)("TotalLighting") = dt.Rows(intCounter)("TotalLighting")
				drUpdate(0)("TotalBridges") = dt.Rows(intCounter)("TotalBridges")
				drUpdate(0)("TotalParking") = dt.Rows(intCounter)("TotalParking")
				drUpdate(0)("TotalBridges") = dt.Rows(intCounter)("TotalBridges")
				drUpdate(0)("TotalCounter") = dt.Rows(intCounter)("TotalCounter")
				drUpdate(0)("Counters") = dt.Rows(intCounter)("Counters")
				drUpdate(0)("gates_invFinger") = dt.Rows(intCounter)("gates_invFinger")
				drUpdate(0)("TotalTakeOffLights") = dt.Rows(intCounter)("TotalTakeOffLights")
				''
				drUpdate(0).EndEdit()
			Next
		End If
		''
		dt = dsdata.Tables("tblTransaction").GetChanges
		''
		If Not (dt Is Nothing) Then
			daTransaction.Update(dt)
			dsdata.Tables("tblTransaction").AcceptChanges()
			blnLoading = True
			dsdata.Tables("vwTransaction").AcceptChanges()
			blnLoading = False
		End If
		''
		FilterGrid()
		btnSave.Enabled = False
        'btnUpdateClient.Enabled = True
		'btnAutoGenerateInvoice.Enabled = True
		btnUpdatePrice.Enabled = True
		Windows.Forms.Cursor.Current = Cursors.Default()
	End Sub

	Private Sub cboClient_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyDown
		If e.KeyCode = Keys.F3 Then
			GetClient()
		End If
	End Sub

	Private Sub dtpDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateFrom.ValueChanged
		FilterGrid()
	End Sub

	Private Sub dtpDateTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateTo.ValueChanged
		FilterGrid()
	End Sub

	Private Sub btnAutoGenerateInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAutoGenerateInvoice.Click
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ''
        Dim strMsg As String = "Are you sure you want to Generate "
        Dim strComputerName As String = ""
        ''
        If grdInvoiceList.Rows.Count > 1 Then
            ''
            strMsg &= "these " & grdInvoiceList.Rows.Count & " Transactions "
        Else
            strMsg &= "this Transaction"
        End If
        ''
        If MsgBox(strMsg & "?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            If CheckUserGenInvoice() <> -1 And CheckDate() Then
                strComputerName = GetComputerName()
                MsgBox("You Cannot Generate an Invoice At this Time ,Another User Generate Invoice At Computer: <" & strComputerName & ">", , "Try Again Later")
                Exit Sub
            Else
                DeleteUserGenInvoice()
                SetUserGenInvoice()
            End If
            ''
            Dim StrSql As String = ""
            Dim StrSqlSort As String = ""
            ''
            StrSql = "Select ClientID, sum (Reg_Weight) , Sum(TotalLanding) as TotalLanding,  sum (TotalParking) as TotalParking,Sum(TotalLighting) as TotalLighting , sum (TotalBridges) as TotalBridges , Sum (TotalCounter) as TotalCounter , SUM(TotalTakeOffLights) AS TotalTakeOffLights From tblTransaction WHERE InvoiceID IS NULL"
            ''
            StrSqlSort = "SELECT TOP 100 PERCENT dbo.tblTransaction.ClientID, SUM(dbo.tblTransaction.TotalLanding) AS TotalLanding, SUM(dbo.tblTransaction.TotalLighting) AS TotalLighting, "
            StrSqlSort &= " SUM(dbo.tblTransaction.TotalParking) AS TotalParking, SUM(dbo.tblTransaction.TotalBridges) AS TotalBridges, "
            StrSqlSort &= " SUM(dbo.tblTransaction.TotalCounter) AS TotalCounter, SUM(dbo.tblTransaction.TotalTakeOffLights) AS TotalTakeOffLights, dbo.tblClient.ClientName "
            StrSqlSort &= " FROM  dbo.tblTransaction LEFT OUTER JOIN"
            StrSqlSort &= " dbo.tblClient ON dbo.tblTransaction.ClientID = dbo.tblClient.ClientID"
            StrSqlSort &= " WHERE (dbo.tblTransaction.InvoiceID IS NULL) AND (dbo.tblTransaction.ClientID IS NOT NULL) "
            ''
            dsdata.Tables("vwClientTransSum").Rows.Clear()
            ''
            If cboClient.SelectedIndex <> -1 Then
                'dtpContractExpiredOn.Value.ToString("yyyy-M-d")
                'clsMr.BuildSqlAdapter("Select ClientID, sum (Reg_Weight) , Sum(TotalLanding) as TotalLanding,  sum (TotalParking) as TotalParking,Sum(TotalLighting) as TotalLighting , sum (TotalBridges) as TotalBridges , Sum (TotalCounter) as TotalCounter , SUM(TotalTakeOffLights) AS TotalTakeOffLights From tblTransaction WHERE ClientID=" & cboClient.SelectedValue & " AND InvoiceID IS Null AND (Dat_orig >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (Dat_orig <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "')  Group BY ClientID", "vwClientTransSum")
                StrSql &= " AND dbo.tblTransaction.ClientID=" & cboClient.SelectedValue
                StrSqlSort &= " AND dbo.tblTransaction.ClientID=" & cboClient.SelectedValue
            End If
            ''
            'StrSql &= " AND (Dat_orig >= " & dtpDateFrom.Value.ToString("yyyy-M-d") & ") AND (Dat_orig <=" & dtpDateTo.Value.ToString("yyyy-M-d") & ")  Group BY ClientID"
            'StrSql &= " AND (Dat_orig >= '" & Format(dtpDateFrom.Value, " dd/MM / yyyy") & "') AND (Dat_orig <= '" & Format(dtpDateTo.Value, "dd /MM / yyyy") & "')  Group BY ClientID"
            'StrSql &= " AND (Dat_orig >= " & dtpDateFrom.Value.ToShortDateString & ") AND (Dat_orig <=" & dtpDateTo.Value.ToShortDateString & ")  Group BY ClientID"
            ''
            'StrSql &= " AND (Dat_orig >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (Dat_orig <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "')  Group BY ClientID"
            StrSql &= " AND (Dat_dest >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (Dat_dest <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "')  Group BY ClientID"
            StrSqlSort &= " AND (Dat_dest >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (Dat_dest <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "')  Group BY dbo.tblTransaction.ClientID, dbo.tblClient.ClientName ORDER BY dbo.tblClient.ClientName"

            ''
            clsMr.BuildSqlAdapter(StrSqlSort, "vwClientTransSum")
            ''
            's = "(InvoiceDate >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (InvoiceDate <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "')"
            Dim dv As DataView = dsdata.Tables("vwClientTransSum").DefaultView
            'Dim dv2 As DataView = dsdata.Tables("vwClientTrans").DefaultView
            Dim drv As DataRowView
            For Each drv In dv
                ''Create Invoice
                Dim drInvoice As DataRow = dsdata.Tables("tblInvoice").NewRow
                dblInvoiceTotal = 0
                drInvoice("InvoiceID") = clsMr.GetMaxNumber("InvoiceID", "tblInvoice") + 1
                drInvoice("CatID") = 1
                drInvoice("InvoiceNumber") = clsMr.GetMaxNumber("InvoiceNumber", "tblInvoice") + 1
                drInvoice("InvoiceFrom") = dtpDateFrom.Value.ToShortDateString

                ''
                Dim strYear As String = Now.Date.Year
                strYear = strYear.Substring(2, 2)
                drInvoice("InvoiceYY") = strYear
                Dim intDG As Integer = GetBranchBillingInfo()
                If intDG <> 0 Then
                    drInvoice("DGID") = intDG
                End If
                ''
                drInvoice("InvoiceTo") = dtpDateTo.Value.ToShortDateString
                drInvoice("InvoiceDate") = Now.Date
                drInvoice("CurrencyID") = gIntCompanyCurrID
                drInvoice("Rate") = GetRate(gIntCompanyCurrID, CurrID2, Now.Date)
                '	drInvoice("TotalCurr2") = GetRate(gIntCompanyCurrID, currid2, Now.Date,)
                drInvoice("StatusID") = 1
                drInvoice("BilledDate") = Now.Date
                'drInvoice("Total")=
                drInvoice("EmployeeID") = gIntUserID
                drInvoice("BranchID") = gIntBranchID
                drInvoice("Del") = 0
                'drInvoice("Description") = "Auto Generated Invoice Number:" & drInvoice("InvoiceNumber")
                drInvoice("Description") = "Landing for " & dtpDateFrom.Value.ToString("MMMM") & " " & dtpDateFrom.Value.Year
                drInvoice("CreateByID") = gIntUserID
                drInvoice("CreateDate") = Now.Date
                drInvoice("AutoGel") = 1

                drInvoice("ClientID") = drv("ClientID")
                dsdata.Tables("tblInvoice").Rows.Add(drInvoice)
                daInvoice.Update(dsdata, "tblInvoice")

                ''update tblTransaction
                'dsdata.Tables("tblTransaction").Rows.Clear()
                'clsMr.BuildSqlAdapter("select TransactionID,InvoiceID From tblTransaction WHERE ClientID=" & drv("ClientID") & " AND (Dat_orig >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (Dat_orig <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "'", "tblTransaction")
                Dim dvTrx As DataView = dsdata.Tables("vwTransaction").DefaultView '.Select("ClientID=" & drv("ClientID") & " AND (Dat_orig >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (Dat_orig <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "'")
                Dim dvt As DataRowView
                For Each dvt In dvTrx
                    dvt("InvoiceID") = drInvoice("InvoiceID")
                    ''update tblTransaction
                    'Dim cmd As New SqlCommand("Update tbltransaction set InvoiceID =" & drInvoice("InvoiceID") & " WHERE  tblTransaction.TransactionID =" & dvt("TransactionID"), conSql)
                    Dim cmd As New SqlCommand("Update tbltransaction set InvoiceID =" & drInvoice("InvoiceID") & " WHERE   tblTransaction.TransactionID =" & dvt("TransactionID") & " AND tblTransaction.ClientID =" & drv("ClientID"), conSql)

                    conSql.Open()
                    cmd.ExecuteNonQuery()
                    conSql.Close()

                    'daTransaction.Update(dsdata, "tblTransaction")

                Next
                ''Create invoiceDetail

                ''continue for all services
                UpdateInvoiceDetail(drInvoice("InvoiceID"), drv("TotalLanding"), 1)
                UpdateInvoiceDetail(drInvoice("InvoiceID"), drv("TotalLighting"), 2)
                UpdateInvoiceDetail(drInvoice("InvoiceID"), drv("TotalBridges"), 3)
                UpdateInvoiceDetail(drInvoice("InvoiceID"), drv("TotalTakeOffLights"), 4)
                UpdateInvoiceDetail(drInvoice("InvoiceID"), drv("TotalCounter"), 5)
                UpdateInvoiceDetail(drInvoice("InvoiceID"), drv("TotalParking"), 6)
                'UpdateInvoiceDetail(drInvoice("InvoiceID"), drv("TotalOverFlight"), 9)

                ''calculate invoice total and update to invoice
                drInvoice("Total") = dblInvoiceTotal
                drInvoice("TotalCurr2") = GetExchangeValue(gIntCompanyCurrID, CurrID2, Now.Date, drInvoice("Total"))
                daInvoice.Update(dsdata, "tblInvoice")

            Next
            FilterGrid()
            DeleteUserGenInvoice()
            MsgBox("Invoice(s) Successefully Generated")
            btnAutoGenerateInvoice.Enabled = False
        Else
            ''
        End If
        ''
        Windows.Forms.Cursor.Current = Cursors.Default
    End Sub

	Private Sub UpdateInvoiceDetail(ByVal pInvoiceID As Integer, ByVal pTotal As Double, ByVal pServiceID As Integer)	', Optional ByVal pQty As Integer = 1)
		''
		Dim drInvoiceDetail As DataRow = dsdata.Tables("tblInvoiceDetail").NewRow
		drInvoiceDetail("InvoiceID") = pInvoiceID
		drInvoiceDetail("InvoiceDetailID") = clsMr.GetMaxNumber("InvoiceDetailID", "tblInvoiceDetail") + 1
		drInvoiceDetail("ServiceID") = pServiceID
		drInvoiceDetail("Price") = pTotal
		' drInvoiceDetail("Price")=GetServicePrice(pServiceID)
		drInvoiceDetail("Quantity") = 1
		dblInvoiceTotal += drInvoiceDetail("Price")
		drInvoiceDetail("Discount") = 0
		drInvoiceDetail("VATAmount") = 0
		drInvoiceDetail("Del") = 0
		drInvoiceDetail("PriceUnitID") = 1
		drInvoiceDetail("TotalCurr2") = GetExchangeValue(gIntCompanyCurrID, CurrID2, Now.Date, pTotal)
		dsdata.Tables("tblInvoiceDetail").Rows.Add(drInvoiceDetail)
		daInvoiceDetail.Update(dsdata, "tblInvoiceDetail")
	End Sub

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		Me.Close()
	End Sub

	Private Sub cboClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
		AutoComplete(cboClient, e)
	End Sub

	Private Sub cboClient_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyUp
		FilterGrid()
	End Sub

	Private Sub cboClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
		FilterGrid()
	End Sub

	Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
		''
		If grdInvoiceList.RowCount = 0 Then Exit Sub
		Dim frm As New frmQuickReport
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		Dim rpt As New rptTransaction

		'frm.crvInstantViewer.SelectionFormula = "{vwTransaction.TransactionID}=" & grdInvoiceList.Item("TransactionID", grdInvoiceList.CurrentRow.Index).Value
		Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table

		Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
		''
		For Each tbCurrent In rpt.Database.Tables
			tliCurrent = tbCurrent.LogOnInfo
			''
			With tliCurrent.ConnectionInfo
				.ServerName = gStrServerName
				.DatabaseName = gStrDataBaseName
				.UserID = "" 'gStrUserName
				.Password = ""	 'gStrPassword
			End With

			tbCurrent.ApplyLogOnInfo(tliCurrent)
		Next tbCurrent
		Dim strFilter As String = InvoiceFilterString()
		frm.crvInstantViewer.SelectionFormula = strFilter
		frm.crvInstantViewer.ReportSource = rpt
		rpt.SetParameterValue("DateFrom", Format(dtpDateFrom.Value, "MMMM"))
		rpt.SetParameterValue("DateTo", Format(dtpDateTo.Value, "MMMM"))
		rpt.SetParameterValue("Year", dtpDateTo.Value.Year)

		frm.crvInstantViewer.Refresh()
		frm.Show()

		frm.crvInstantViewer.DisplayToolbar = True
		Windows.Forms.Cursor.Current = Cursors.Default()
		''
	End Sub

	Private Sub chkInvoiced_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkInvoiced.CheckedChanged
		''
		FilterGrid()
		''
		If chkInvoiced.Checked = True Then
			btnUpdatePrice.Enabled = False
		Else
			btnUpdatePrice.Enabled = True
		End If
	End Sub

    Private Sub btnDetailsParking_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        If grpTransactionParkingArea.Visible = False Then
            grpTransactionParkingArea.Visible = True
            Try
                ''clsMr.BuildSqlAdapter("SELECT * FROM vwTransactionParkingArea", "vwTransactionParkingArea")

                'Dim cmd As New SqlCommand("SELECT * FROM vwTransactionParkingArea WHERE Seq_ID=" & grdInvoiceList.Item("Seq_ID", grdInvoiceList.CurrentRow.Index).Value, conSql)
                'conSql.Open()
                'cmd.ExecuteNonQuery()
                'conSql.Close()
                'dsdata.Tables("vwTransactionParkingArea").AcceptChanges()

                grdTransactionParkingArea.DataSource = dsdata.Tables("vwTransactionParkingArea").DefaultView
                With grdTransactionParkingArea
                    .Columns("madarej_hangar").HeaderText = "Parking"
                    .Columns("Chargeable").HeaderText = "Charge"
                End With
                dsdata.Tables("vwTransactionParkingArea").DefaultView.RowFilter = "Seq_ID=" & grdInvoiceList.Item("Seq_ID", grdInvoiceList.CurrentRow.Index).Value
                'conSql.Open()
                'dsdata.Tables("vwTransactionParkingArea").Rows.Clear()
            Catch ex As Exception
                conSql.Close()
            End Try
        Else
            grpTransactionParkingArea.Visible = False
        End If

        ''
    End Sub

	Private Sub txtInvoiceNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInvoiceNum.TextChanged
		''
		FilterGrid()
	End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        'RefreshGrid()
        FilterGrid()
        Windows.Forms.Cursor.Current = Cursors.Default
    End Sub

#End Region


#Region "Form-Functions....."

	'Private Sub RefreshGrid()

	'	dsdata.Tables("vwTransaction").Rows.Clear()
	'	clsMr.BuildSqlAdapter("SELECT * FROM vwTransaction  WHERE TransactionID=-1", "vwTransaction")

	'End Sub

	Private Function GetNbOfDays(ByVal pNbHours As Decimal) As Integer

		'Select Case pNbHours

		'	Case Is < 8

		'		Return 0
		'	Case is  >= 8 and is  <= 24

		'		Return 1


		'	Case Else

		'		Return Integer.Parse(pNbHours / 24)

		'End Select
		''
		If pNbHours <= 8 Then
			Return 0
		ElseIf pNbHours > 8 And pNbHours <= 24 Then
			Return 1
		Else
			Return Math.Ceiling(pNbHours / 24)
		End If
		''
	End Function

	Private Sub btnsStatus()
		''
		If grdInvoiceList.Rows.Count = 0 Then
			btnAutoGenerateInvoice.Enabled = False
			btnSave.Enabled = False
			'btnUpdateClient.Enabled = False
			'btnUpdatePrice.Enabled = False
			'btnUpdateHours.Enabled = False
		Else
			If btnSave.Enabled = False Then
				btnAutoGenerateInvoice.Enabled = False
				'btnSave.Enabled = False
				'btnUpdateClient.Enabled = True
				'btnUpdatePrice.Enabled = True
				'btnUpdateHours.Enabled = True
				btnUpdatePrice.Enabled = True
				'btnUpdateHours.Enabled = False
			End If
		End If
	End Sub

	Private Function GetServicePrice(ByVal intServiceID As Integer) As Double
		''
		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand
		''
		Dim dblPrice As Double
		''
		strSQL = "SELECT Price,AdditionalCharge FROM dbo.tblService WHERE dbo.tblService.ServiceID=  " & intServiceID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text
		''
		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		''
		If dRdr.Read Then
			dblPrice = dRdr("Price")
		End If
		''
		dRdr.Close()
		conSql.Close()
		Return dblPrice
	End Function

	Private Function GetServiceAdditionalCharge(ByVal intServiceID As Integer) As Double
		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand

		''
		Dim dblAddCharge As Double
		''
		strSQL = "select AdditionalCharge   FROM  dbo.tblService  WHERE dbo.tblService.ServiceID=  " & intServiceID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text

		conSql.Open()
		dRdr = cmdX.ExecuteReader()

		If dRdr.Read Then


			If Not dRdr("AdditionalCharge") Is DBNull.Value Then
				dblAddCharge = dRdr("AdditionalCharge")
			End If

		End If

		dRdr.Close()
		conSql.Close()
		Return dblAddCharge
	End Function

	Private Sub CalculateTotal()
		''
		If blnLoading Then Exit Sub
		Dim dv As DataView = dsdata.Tables("vwTransaction").DefaultView
		Dim drv As DataRowView
		Dim dblLanding As Double
		Dim dblLighting As Double
		Dim dblParking As Double
		Dim dblBridges As Double
		Dim dblCounter As Double
		Dim dblTakeOffLights As Double
		Dim dblTotalNbCounters As Double

		For Each drv In dv
			dblLanding += drv("TotalLanding")
			dblLighting += drv("TotalLighting")
			dblParking += drv("TotalParking")
			dblBridges += drv("TotalBridges")
			dblCounter += drv("TotalCounter")
			If Not IsDBNull(drv("Counters")) Then
				dblTotalNbCounters += drv("Counters")
			End If

			If Not (drv("TotalTakeOffLights") Is DBNull.Value) Then
				dblTakeOffLights += drv("TotalTakeOffLights")
			End If

		Next
		txtTotalLanding.Text = dblLanding.ToString("#,###")
		txtTotalLighting.Text = dblLighting.ToString("#,###")
		txtTotalParking.Text = dblParking.ToString("#,###")
		txtTotalBridges.Text = dblBridges.ToString("#,###")
		txtTotalCounters.Text = dblCounter.ToString("#,###")
		txtTotalTakeOffLights.Text = dblTakeOffLights.ToString("#,###")
		txtCounters.Text = dblTotalNbCounters.ToString("#,###")
	End Sub

	Private Sub GetClient()
		Dim frmClient As New frmClientGet()
		'appMain.addTabPage(frmClient, frmApplicationMain.eFormType.ClientGet)
		'AddHandler frmClient.Closed, AddressOf RefreshClient
		frmClient.ShowDialog()
		cboClient.SelectedValue = frmClient.CboValue
	End Sub

	Private Function GetBranchBillingInfo()
		Dim intDGID As Integer

		Try
			Dim cmd As New SqlClient.SqlCommand("SELECT DGID FROM tblBranchBillingInfo WHERE BranchID=" & gIntBranchID, conSql)
			conSql.Open()
			intDGID = cmd.ExecuteScalar()
			conSql.Close()
			Return intDGID
		Catch ex As Exception
			conSql.Close()
			Return 0
		End Try

	End Function

	Private Sub GetCompanyCurrencies()


		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand
		''
		strSQL = "select * FROM  dbo.tblCompany  WHERE dbo.tblCompany.companyID=  " & gIntCompanyID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text

		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			CurrID2 = dRdr("CurrID2")
		End If
		dRdr.Close()
		conSql.Close()
	End Sub

	Private Sub DrawGrid()
		''
		grdInvoiceList.DataSource = dsdata.Tables("vwTransaction").DefaultView

		dsdata.Tables("vwTransaction").DefaultView.AllowNew = False

		LoadProfile(mStrSubKeyName, Me.grdInvoiceList)

		With grdInvoiceList
			''
			.ColumnHeadersHeight = btnShowCol.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
			''
			'.Columns("TransactionID").ReadOnly = True
			.Columns("seq_ID").ReadOnly = True
			.Columns("Reg_serial").ReadOnly = True
			'.Columns("ICAO").ReadOnly = True
			.Columns("ClientName").ReadOnly = True
			.Columns("Make").ReadOnly = True
			.Columns("Model").ReadOnly = True
			.Columns("dat_orig").ReadOnly = True
			.Columns("time_orig").ReadOnly = True
			.Columns("rwy_orig").ReadOnly = True
			.Columns("time_dest").ReadOnly = True
			.Columns("dat_dest").ReadOnly = True
			'.Columns("gates_invFinger").ReadOnly = True
			'.Columns("light_orig").ReadOnly = True
			.Columns("gate").ReadOnly = True
			.Columns("Aircraft_type").ReadOnly = True
			'.Columns("InvoiceID").ReadOnly = True
			'.Columns("ClientID").ReadOnly = True
			''
			.Columns("TransactionID").Visible = False
			.Columns("InvoiceID").Visible = False
			.Columns("ClientID").Visible = False
			'.Columns("TransactionParkingID").Visible = False
			.Columns("ClientName").HeaderText = "Client Name"
			.Columns("TotalLanding").HeaderText = "Landing Fees"
			.Columns("TotalLighting").HeaderText = "Lighting Fees"
			.Columns("TotalParking").HeaderText = "Parking Fees"
			.Columns("TotalBridges").HeaderText = "Bridges Fees"
			.Columns("TotalCounter").HeaderText = "Counter Fees"
			.Columns("TotalTakeOffLights").HeaderText = "TakeOff Lights Fees"
			''
			.Columns("ClientName").DefaultCellStyle.Format = "#,###.##"
			.Columns("TotalLanding").DefaultCellStyle.Format = "#,###.##"
			.Columns("TotalLighting").DefaultCellStyle.Format = "#,###.##"
			.Columns("TotalParking").DefaultCellStyle.Format = "#,###.##"
			.Columns("TotalBridges").DefaultCellStyle.Format = "#,###.##"
			.Columns("TotalCounter").DefaultCellStyle.Format = "#,###.##"
			.Columns("TotalTakeOffLights").DefaultCellStyle.Format = "#,###.##"
		End With
		''
		AddHandler dsdata.Tables("vwTransaction").ColumnChanged, AddressOf Column_Changed
	End Sub

	Private Sub Column_Changed(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
		''
		If blnLoading Then Exit Sub
		''
		If grdInvoiceList.Rows.Count = 0 Then Exit Sub
		If (grdInvoiceList.CurrentRow) Is Nothing Then
			Exit Sub
		End If
		''
		If e.Column.ColumnName = "Hours" Then
			''
			'Dim dv As DataView = dsdata.Tables("vwTransaction").DefaultView
			Dim dr As DataRow = dsdata.Tables("vwTransaction").DefaultView.Item(grdInvoiceList.CurrentRow.Index).Row
			''
			'	For Each drv In dv
			''
			If dr("Reg_Weight") Is DBNull.Value Then
				dr("Reg_Weight") = 0
			End If
			''
			If dr("Hours") Is DBNull.Value Then
				dr("Hours") = 0
			End If
			''
			If dr("Reg_Weight") >= 1 And dr("Reg_Weight") <= 75 Then
				dr("TotalParking") = GetServicePrice(6) * GetNbOfDays(dr("Hours"))	 '3500 

			Else
				dr("TotalParking") = GetServiceAdditionalCharge(6) * GetNbOfDays(dr("Hours"))	''2500
			End If
		End If
		''
		If e.Column.ColumnName = "light_dest" Or e.Column.ColumnName = "gates_invFinger" Or e.Column.ColumnName = "counters" Or e.Column.ColumnName = "Hours" Or e.Column.ColumnName = "Days" Or e.Column.ColumnName = "reg_weight" Or e.Column.ColumnName = "TotalLanding" Or e.Column.ColumnName = "TotalLighting" Or e.Column.ColumnName = "TotalBridges" Or e.Column.ColumnName = "TotalParking" Or e.Column.ColumnName = "TotalCounter" Or e.Column.ColumnName = "TotalTakeOffLights" Or e.Column.ColumnName = "light_Orig" Then
			CalculateTotal()
			btnSave.Enabled = True
			'btnUpdateClient.Enabled = False
			'btnAutoGenerateInvoice.Enabled = False
			btnUpdatePrice.Enabled = False
		End If
		''
		If e.Column.ColumnName = "ICAO" Then 'And Not IsDBNull(grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value) Then
			''
			Dim dRdr As SqlClient.SqlDataReader
			''
			Dim cmd As New SqlCommand("SELECT ClientID, ClientName FROM tblClient WHERE ICAO= '" & grdInvoiceList.Item("ICAO", grdInvoiceList.CurrentRow.Index).Value & "'", conSql)
			conSql.Open()
			dRdr = cmd.ExecuteReader()
			If dRdr.Read Then
				grdInvoiceList.Item("ClientID", grdInvoiceList.CurrentRow.Index).Value = dRdr("ClientID")
				grdInvoiceList.Item("ClientName", grdInvoiceList.CurrentRow.Index).Value = dRdr("ClientName")
			End If
			dRdr.Close()
			conSql.Close()
			''
			Try
				Dim cmdUpdate As New SqlCommand("Update tblTransaction SET InvoiceID = NULL, ClientID = " & grdInvoiceList.Item("ClientID", grdInvoiceList.CurrentRow.Index).Value & "  WHERE TransactionID = " & grdInvoiceList.Item("TransactionID", grdInvoiceList.CurrentRow.Index).Value, conSql)
				conSql.Open()
				cmdUpdate.ExecuteNonQuery()
				conSql.Close()
			Catch ex As Exception
				conSql.Close()
			End Try
			''
			'UpdateClient()
			FilterGrid()
			'btnSave.Enabled = True
			'btnUpdatePrice.Enabled = False
            'btnUpdateClient.Enabled = True
		End If

	End Sub

	Private Sub FilterGrid()
		''
		If blnLoading = True Then Exit Sub
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor
		''
		If chkInvoiced.Checked = True Then
			s = " InvoiceID IS NOT NULL "
			btnUpdatePrice.Enabled = False
		Else
			s = " InvoiceID IS Null "
            'If grdInvoiceList.Rows.Count <> 0 Then
            btnUpdatePrice.Enabled = True
            'End If
        End If

		's = s & " AND (Dat_orig >= '" & Format(dtpDateFrom.Value, "MM /dd / yyyy") & "') AND (Dat_orig <= '" & Format(dtpDateTo.Value, "MM /dd / yyyy") & "')"
		''
		'' we r using ToString("yyyy-M-d") so that it works w/ the SELECT Stmt without errors
		's = s & " AND (Dat_orig Between '" & dtpDateFrom.Value.ToString("yyyy-M-d") & "' AND '" & dtpDateTo.Value.ToString("yyyy-M-d") & "') "
		s = s & " AND (Dat_dest Between '" & dtpDateFrom.Value.ToString("yyyy-M-d") & "' AND '" & dtpDateTo.Value.ToString("yyyy-M-d") & "') "
		''
		If cboClient.SelectedIndex <> -1 Then
			s = s & " AND (ClientID = " & cboClient.SelectedValue & ")"
		Else
			If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
				s = s & " AND (ClientID = " & -1 & ")"
			End If
		End If
		''
		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				s = s & " AND  (InvoiceNumber = " & tn & ")"
			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		'dsdata.Tables("vwTransaction").DefaultView.RowFilter = s
		dsdata.Tables("vwTransaction").Rows.Clear()
		clsMr.BuildSqlAdapter("SELECT * FROM vwTransaction  WHERE " & s, "vwTransaction")
		'UpdatePrice()
		CalculateTotal()
		btnsStatus()
		''
		Windows.Forms.Cursor.Current = Cursors.Default
	End Sub

	Private Function InvoiceFilterString()
		''
		If blnLoading Then Exit Function
		''
		Dim strStatus As String
		Dim strfilter As String = "" '""" True"
		''
		If chkInvoiced.Checked = True Then
			strfilter = " NOT ISNULL({vwTransaction.InvoiceID}) "
		Else
			strfilter = " ISNULL({vwTransaction.InvoiceID}) "
		End If
		'strfilter = " ISNULL({vwTransaction.InvoiceID}) "
		'strfilter = strfilter & " AND ({vwTransaction.dat_orig} >= #" & Format(dtpDateFrom.Value, "dd /MMM / yyyy") & "#) AND ({vwTransaction.dat_orig} <= #" & Format(dtpDateTo.Value, "dd /MMM / yyyy") & "#)"
		'strfilter = strfilter & " AND ({vwTransaction.dat_orig} >= #" & dtpDateFrom.Value.ToShortDateString() & "#) AND ({vwTransaction.dat_orig} <= #" & dtpDateTo.Value.ToShortDateString() & "#)"
		'dtpContractExpiredOn.Value.ToString("yyyy-M-d")
		'strfilter = strfilter & " AND ({vwTransaction.dat_orig} >= #" & dtpDateFrom.Value.ToString("yyyy-M-d") & "#) AND ({vwTransaction.dat_orig} <= #" & dtpDateTo.Value.ToString("yyyy-M-d") & "#)"
		strfilter = strfilter & " AND ({vwTransaction.dat_dest} >= #" & dtpDateFrom.Value.ToString("yyyy-M-d") & "#) AND ({vwTransaction.dat_dest} <= #" & dtpDateTo.Value.ToString("yyyy-M-d") & "#)"
		''
		If cboClient.SelectedIndex <> -1 Then
			strfilter = strfilter & " AND ({vwTransaction.ClientID} = " & cboClient.SelectedValue & ")"
		Else
			If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
				strfilter = strfilter & " AND ({vwTransaction.ClientID} = " & -1 & ")"
			End If
		End If
		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				If strfilter = "" Then
					strfilter &= "   ({vwTransaction.InvoiceNumber} = " & tn & ")"
				Else
					strfilter &= " AND  ({vwTransaction.InvoiceNumber} = " & tn & ")"
				End If

			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		' strfilter = s
		Return strfilter
		''
	End Function

	Private Sub UpdateClient()
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		' UPDATE Client INTO Table tblTransaction 
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''
		Try
			Dim cmd As New SqlCommand("UPDATE tblTransaction SET ClientID = tblClient.ClientID FROM tblClient INNER JOIN tblTransaction ON tblTransaction.Operatr = tblClient.ICAO WHERE tblTransaction.InvoiceID IS NULL", conSql)
			conSql.Open()
			cmd.ExecuteNonQuery()
			conSql.Close()
		Catch ex As Exception
			Windows.Forms.Cursor.Current = Cursors.Default()
			conSql.Close()
		End Try
	End Sub

#End Region


End Class