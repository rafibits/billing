<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmClientItem
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblFormTitle = New System.Windows.Forms.Label
        Me.lblFormTitleLine = New System.Windows.Forms.Panel
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnDelete = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnSaveEmp = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.grdClientItem = New System.Windows.Forms.DataGridView
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.grpInfo = New System.Windows.Forms.GroupBox
        Me.lblDiscount = New System.Windows.Forms.Label
        Me.cboModel = New System.Windows.Forms.ComboBox
        Me.txtDiscount = New System.Windows.Forms.TextBox
        Me.txtDescription = New System.Windows.Forms.TextBox
        Me.cboUnit = New System.Windows.Forms.ComboBox
        Me.lblCallSign = New System.Windows.Forms.Label
        Me.lblWeightUnit = New System.Windows.Forms.Label
        Me.lblDesc = New System.Windows.Forms.Label
        Me.txtWeight = New System.Windows.Forms.TextBox
        Me.lblModel = New System.Windows.Forms.Label
        Me.lblWeight = New System.Windows.Forms.Label
        Me.txtCallSign = New System.Windows.Forms.TextBox
        Me.cboMake = New System.Windows.Forms.ComboBox
        Me.lblRegCode = New System.Windows.Forms.Label
        Me.lblMake = New System.Windows.Forms.Label
        Me.txtRegistrationCode = New System.Windows.Forms.TextBox
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.txtClientItemID = New System.Windows.Forms.TextBox
        Me.txtClientID = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.grpButtons.SuspendLayout()
        CType(Me.grdClientItem, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpShowHideColumns.SuspendLayout()
        Me.grpInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblFormTitle
        '
        Me.lblFormTitle.AutoEllipsis = True
        Me.lblFormTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblFormTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblFormTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.Black
        Me.lblFormTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(711, 40)
        Me.lblFormTitle.TabIndex = 8
        Me.lblFormTitle.Text = "  Client Item"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFormTitleLine
        '
        Me.lblFormTitleLine.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblFormTitleLine.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblFormTitleLine.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lblFormTitleLine.Location = New System.Drawing.Point(0, 40)
        Me.lblFormTitleLine.Name = "lblFormTitleLine"
        Me.lblFormTitleLine.Size = New System.Drawing.Size(711, 3)
        Me.lblFormTitleLine.TabIndex = 5
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnDelete)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Controls.Add(Me.btnSaveEmp)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Location = New System.Drawing.Point(3, 480)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(706, 45)
        Me.grpButtons.TabIndex = 1
        Me.grpButtons.TabStop = False
        '
        'btnDelete
        '
        Me.btnDelete.AlternativeGroup = Nothing
        Me.btnDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDelete.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnDelete.BackColor1 = System.Drawing.Color.White
        Me.btnDelete.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnDelete.BorderHover = True
        Me.btnDelete.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDelete.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDelete.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnDelete.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDelete.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.DrawBorder = True
        Me.btnDelete.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.Navy
        Me.btnDelete.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnDelete.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnDelete.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDelete.Location = New System.Drawing.Point(337, 11)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnDelete.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnDelete.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDelete.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnDelete.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnDelete.SelectedText = Nothing
        Me.btnDelete.Size = New System.Drawing.Size(105, 28)
        Me.btnDelete.TabIndex = 4
        Me.btnDelete.Text = "D e  l e t e"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNew.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.Location = New System.Drawing.Point(6, 11)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(105, 28)
        Me.btnNew.TabIndex = 2
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnSaveEmp
        '
        Me.btnSaveEmp.AlternativeGroup = Nothing
        Me.btnSaveEmp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSaveEmp.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSaveEmp.BackColor1 = System.Drawing.Color.White
        Me.btnSaveEmp.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSaveEmp.BorderHover = True
        Me.btnSaveEmp.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSaveEmp.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSaveEmp.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnSaveEmp.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSaveEmp.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSaveEmp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSaveEmp.DrawBorder = True
        Me.btnSaveEmp.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSaveEmp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnSaveEmp.ForeColor = System.Drawing.Color.Navy
        Me.btnSaveEmp.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnSaveEmp.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnSaveEmp.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSaveEmp.Location = New System.Drawing.Point(6, 11)
        Me.btnSaveEmp.Name = "btnSaveEmp"
        Me.btnSaveEmp.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnSaveEmp.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnSaveEmp.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSaveEmp.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnSaveEmp.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnSaveEmp.SelectedText = Nothing
        Me.btnSaveEmp.Size = New System.Drawing.Size(105, 28)
        Me.btnSaveEmp.TabIndex = 0
        Me.btnSaveEmp.Text = "S a v e"
        Me.btnSaveEmp.UseVisualStyleBackColor = False
        Me.btnSaveEmp.Visible = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.Location = New System.Drawing.Point(595, 11)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(105, 28)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnSave.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.Location = New System.Drawing.Point(116, 11)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(105, 28)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "S a v e"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCancel.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Location = New System.Drawing.Point(226, 11)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(105, 28)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'grdClientItem
        '
        Me.grdClientItem.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdClientItem.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdClientItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdClientItem.Location = New System.Drawing.Point(12, 277)
        Me.grdClientItem.Name = "grdClientItem"
        Me.grdClientItem.Size = New System.Drawing.Size(687, 197)
        Me.grdClientItem.TabIndex = 3
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(16, 281)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 2
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(53, 281)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 178)
        Me.grpShowHideColumns.TabIndex = 4
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 149)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 1
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 109)
        Me.chkLstGridCol.TabIndex = 0
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'grpInfo
        '
        Me.grpInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpInfo.BackColor = System.Drawing.Color.LightYellow
        Me.grpInfo.Controls.Add(Me.lblDiscount)
        Me.grpInfo.Controls.Add(Me.cboModel)
        Me.grpInfo.Controls.Add(Me.txtDiscount)
        Me.grpInfo.Controls.Add(Me.txtDescription)
        Me.grpInfo.Controls.Add(Me.cboUnit)
        Me.grpInfo.Controls.Add(Me.lblCallSign)
        Me.grpInfo.Controls.Add(Me.lblWeightUnit)
        Me.grpInfo.Controls.Add(Me.lblDesc)
        Me.grpInfo.Controls.Add(Me.txtWeight)
        Me.grpInfo.Controls.Add(Me.lblModel)
        Me.grpInfo.Controls.Add(Me.lblWeight)
        Me.grpInfo.Controls.Add(Me.txtCallSign)
        Me.grpInfo.Controls.Add(Me.cboMake)
        Me.grpInfo.Controls.Add(Me.lblRegCode)
        Me.grpInfo.Controls.Add(Me.lblMake)
        Me.grpInfo.Controls.Add(Me.txtRegistrationCode)
        Me.grpInfo.Location = New System.Drawing.Point(12, 49)
        Me.grpInfo.Name = "grpInfo"
        Me.grpInfo.Size = New System.Drawing.Size(687, 223)
        Me.grpInfo.TabIndex = 0
        Me.grpInfo.TabStop = False
        '
        'lblDiscount
        '
        Me.lblDiscount.AutoSize = True
        Me.lblDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiscount.ForeColor = System.Drawing.Color.Maroon
        Me.lblDiscount.Location = New System.Drawing.Point(366, 117)
        Me.lblDiscount.Name = "lblDiscount"
        Me.lblDiscount.Size = New System.Drawing.Size(60, 16)
        Me.lblDiscount.TabIndex = 5
        Me.lblDiscount.Text = "Discount"
        Me.lblDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboModel
        '
        Me.cboModel.FormattingEnabled = True
        Me.cboModel.Location = New System.Drawing.Point(135, 119)
        Me.cboModel.Name = "cboModel"
        Me.cboModel.Size = New System.Drawing.Size(195, 21)
        Me.cboModel.TabIndex = 3
        '
        'txtDiscount
        '
        Me.txtDiscount.AcceptsReturn = True
        Me.txtDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDiscount.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDiscount.Location = New System.Drawing.Point(435, 119)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(195, 22)
        Me.txtDiscount.TabIndex = 2
        '
        'txtDescription
        '
        Me.txtDescription.AcceptsReturn = True
        Me.txtDescription.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDescription.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDescription.Location = New System.Drawing.Point(134, 155)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(494, 47)
        Me.txtDescription.TabIndex = 2
        '
        'cboUnit
        '
        Me.cboUnit.FormattingEnabled = True
        Me.cboUnit.Location = New System.Drawing.Point(435, 87)
        Me.cboUnit.Name = "cboUnit"
        Me.cboUnit.Size = New System.Drawing.Size(195, 21)
        Me.cboUnit.TabIndex = 1
        '
        'lblCallSign
        '
        Me.lblCallSign.AutoSize = True
        Me.lblCallSign.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCallSign.ForeColor = System.Drawing.Color.Maroon
        Me.lblCallSign.Location = New System.Drawing.Point(64, 53)
        Me.lblCallSign.Name = "lblCallSign"
        Me.lblCallSign.Size = New System.Drawing.Size(61, 16)
        Me.lblCallSign.TabIndex = 5
        Me.lblCallSign.Text = "Call Sign"
        Me.lblCallSign.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWeightUnit
        '
        Me.lblWeightUnit.AutoSize = True
        Me.lblWeightUnit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWeightUnit.ForeColor = System.Drawing.Color.Maroon
        Me.lblWeightUnit.Location = New System.Drawing.Point(350, 85)
        Me.lblWeightUnit.Name = "lblWeightUnit"
        Me.lblWeightUnit.Size = New System.Drawing.Size(76, 16)
        Me.lblWeightUnit.TabIndex = 4
        Me.lblWeightUnit.Text = "Weight Unit"
        Me.lblWeightUnit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDesc
        '
        Me.lblDesc.AutoSize = True
        Me.lblDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDesc.ForeColor = System.Drawing.Color.Maroon
        Me.lblDesc.Location = New System.Drawing.Point(49, 153)
        Me.lblDesc.Name = "lblDesc"
        Me.lblDesc.Size = New System.Drawing.Size(76, 16)
        Me.lblDesc.TabIndex = 3
        Me.lblDesc.Text = "Description"
        Me.lblDesc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtWeight
        '
        Me.txtWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWeight.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWeight.Location = New System.Drawing.Point(435, 54)
        Me.txtWeight.Name = "txtWeight"
        Me.txtWeight.Size = New System.Drawing.Size(195, 22)
        Me.txtWeight.TabIndex = 0
        '
        'lblModel
        '
        Me.lblModel.AutoSize = True
        Me.lblModel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblModel.ForeColor = System.Drawing.Color.Maroon
        Me.lblModel.Location = New System.Drawing.Point(79, 117)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(46, 16)
        Me.lblModel.TabIndex = 7
        Me.lblModel.Text = "Model"
        Me.lblModel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblWeight
        '
        Me.lblWeight.AutoSize = True
        Me.lblWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWeight.ForeColor = System.Drawing.Color.Maroon
        Me.lblWeight.Location = New System.Drawing.Point(376, 53)
        Me.lblWeight.Name = "lblWeight"
        Me.lblWeight.Size = New System.Drawing.Size(50, 16)
        Me.lblWeight.TabIndex = 3
        Me.lblWeight.Text = "Weight"
        Me.lblWeight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtCallSign
        '
        Me.txtCallSign.AcceptsReturn = True
        Me.txtCallSign.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCallSign.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCallSign.Location = New System.Drawing.Point(135, 54)
        Me.txtCallSign.Name = "txtCallSign"
        Me.txtCallSign.Size = New System.Drawing.Size(195, 22)
        Me.txtCallSign.TabIndex = 1
        '
        'cboMake
        '
        Me.cboMake.FormattingEnabled = True
        Me.cboMake.Location = New System.Drawing.Point(135, 87)
        Me.cboMake.Name = "cboMake"
        Me.cboMake.Size = New System.Drawing.Size(195, 21)
        Me.cboMake.TabIndex = 2
        '
        'lblRegCode
        '
        Me.lblRegCode.AutoSize = True
        Me.lblRegCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRegCode.ForeColor = System.Drawing.Color.Maroon
        Me.lblRegCode.Location = New System.Drawing.Point(9, 21)
        Me.lblRegCode.Name = "lblRegCode"
        Me.lblRegCode.Size = New System.Drawing.Size(116, 16)
        Me.lblRegCode.TabIndex = 4
        Me.lblRegCode.Text = "Registration Code"
        Me.lblRegCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblMake
        '
        Me.lblMake.AutoSize = True
        Me.lblMake.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMake.ForeColor = System.Drawing.Color.Maroon
        Me.lblMake.Location = New System.Drawing.Point(83, 85)
        Me.lblMake.Name = "lblMake"
        Me.lblMake.Size = New System.Drawing.Size(42, 16)
        Me.lblMake.TabIndex = 6
        Me.lblMake.Text = "Make"
        Me.lblMake.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtRegistrationCode
        '
        Me.txtRegistrationCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRegistrationCode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRegistrationCode.Location = New System.Drawing.Point(135, 21)
        Me.txtRegistrationCode.Name = "txtRegistrationCode"
        Me.txtRegistrationCode.Size = New System.Drawing.Size(196, 22)
        Me.txtRegistrationCode.TabIndex = 0
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(632, 11)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(71, 23)
        Me.btnDataErr.TabIndex = 6
        Me.btnDataErr.Text = "Data Error"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(480, 14)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(153, 17)
        Me.lstDataErr.TabIndex = 7
        Me.lstDataErr.Visible = False
        '
        'txtClientItemID
        '
        Me.txtClientItemID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtClientItemID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtClientItemID.Location = New System.Drawing.Point(279, 12)
        Me.txtClientItemID.Name = "txtClientItemID"
        Me.txtClientItemID.Size = New System.Drawing.Size(42, 22)
        Me.txtClientItemID.TabIndex = 10
        '
        'txtClientID
        '
        Me.txtClientID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtClientID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtClientID.Location = New System.Drawing.Point(416, 12)
        Me.txtClientID.Name = "txtClientID"
        Me.txtClientID.Size = New System.Drawing.Size(42, 22)
        Me.txtClientID.TabIndex = 12
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Maroon
        Me.Label1.Location = New System.Drawing.Point(186, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 22)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Client Item ID"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Maroon
        Me.Label2.Location = New System.Drawing.Point(354, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 22)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Client ID"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmClientItem
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(711, 530)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtClientID)
        Me.Controls.Add(Me.grpInfo)
        Me.Controls.Add(Me.btnShowCol)
        Me.Controls.Add(Me.txtClientItemID)
        Me.Controls.Add(Me.grpShowHideColumns)
        Me.Controls.Add(Me.grdClientItem)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.lblFormTitleLine)
        Me.Controls.Add(Me.lblFormTitle)
        Me.KeyPreview = True
        Me.Name = "frmClientItem"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Client Item"
        Me.grpButtons.ResumeLayout(False)
        CType(Me.grdClientItem, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.grpInfo.ResumeLayout(False)
        Me.grpInfo.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents lblFormTitleLine As System.Windows.Forms.Panel
    Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
    Friend WithEvents btnNew As BHBut.BouncingHoverButton
    Friend WithEvents btnSaveEmp As BHBut.BouncingHoverButton
    Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents btnSave As BHBut.BouncingHoverButton
    Friend WithEvents btnCancel As BHBut.BouncingHoverButton
    Friend WithEvents grdClientItem As System.Windows.Forms.DataGridView
    Friend WithEvents btnShowCol As System.Windows.Forms.Button
    Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
    Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
    Friend WithEvents grpInfo As System.Windows.Forms.GroupBox
	Friend WithEvents txtClientItemID As System.Windows.Forms.TextBox
    Friend WithEvents txtClientID As System.Windows.Forms.TextBox
	Friend WithEvents lblDiscount As System.Windows.Forms.Label
    Friend WithEvents txtDiscount As System.Windows.Forms.TextBox
    Friend WithEvents cboUnit As System.Windows.Forms.ComboBox
    Friend WithEvents lblWeightUnit As System.Windows.Forms.Label
    Friend WithEvents txtWeight As System.Windows.Forms.TextBox
    Friend WithEvents lblWeight As System.Windows.Forms.Label
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents lblDesc As System.Windows.Forms.Label
    Friend WithEvents btnDelete As BHBut.BouncingHoverButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnDataErr As System.Windows.Forms.Button
	Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
	Friend WithEvents cboModel As System.Windows.Forms.ComboBox
	Friend WithEvents lblCallSign As System.Windows.Forms.Label
	Friend WithEvents lblModel As System.Windows.Forms.Label
	Friend WithEvents txtCallSign As System.Windows.Forms.TextBox
	Friend WithEvents cboMake As System.Windows.Forms.ComboBox
	Friend WithEvents lblRegCode As System.Windows.Forms.Label
	Friend WithEvents lblMake As System.Windows.Forms.Label
	Friend WithEvents txtRegistrationCode As System.Windows.Forms.TextBox
End Class
