Imports BITSConn
Imports System.Data.SqlClient

Public Class frmContractList

#Region "Form-Declaration"

	Private dsdata As DataSet
	Private clsMr As ClsMain
	Private CurrID2 As Integer
	Private blnLoading As Boolean
	Private daInvoice As SqlDataAdapter
	Private daInvoiceDetail As SqlDataAdapter
	Private mstrCurrentGridName As String
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\ContractList\Settings"
	Private intPeriodChecked As Integer = 0
	Private dblInvoiceTotal As Double = 0

#End Region

#Region "Form-Load"

	Private Sub frmContractList_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		''
		SaveProfile(mStrSubKeyName, Me.grdContractList)
    End Sub

    Private Sub frmContractList_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

	Private Sub frmContractList_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		''
		clsMr = New ClsMain(conSql)
		''
		blnLoading = True
		MakeDataAdapter()
		FillCombobox()
		blnLoading = False
		DrawGrid()
		''set defaults
		cboClient.SelectedIndex = -1
		cboArea.SelectedIndex = -1
		cboContractType.SelectedIndex = -1
		FilterGrid()

	End Sub

#End Region

#Region "Form-Initialisation"

	Private Sub MakeDataAdapter()
		''
		daInvoice = clsMr.BuildSqlAdapter("SELECT * FROM tblInvoice WHERE InvoiceID=0 ", "tblInvoice")
		'daInvoiceDetail = clsMr.BuildSqlAdapter("SELECT * FROM tblInvoiceDetail WHERE InvoiceID=0 ", "tblInvoiceDetail")
		clsMr.BuildSqlAdapter("SELECT * FROM vwAreaContract WHERE Del=0 AND statusID = 1", "vwAreaContract")
		clsMr.BuildSqlAdapter("SELECT * FROM vwClientContractSum ", "vwClientContractSum")
		clsMr.BuildSqlAdapter("SELECT * From vwContract", "vwContract")
		clsMr.BuildSqlAdapter("SELECT ClientID,ClientName  from tblClient WHERE Del =0  ORDER BY ClientName", "ClientName")
		clsMr.BuildSqlAdapter("Select * from tblContractTitle where Del =0", "tblContractTitle")
		clsMr.BuildSqlAdapter("SELECT * from tblArea where Del = 0", "tblArea")
		dsdata = clsMr.getDataSet
	End Sub

	Private Sub FillCombobox()
		''
		clsMr.FillComboBox("ClientName", cboClient, "ClientName", "ClientID")
		clsMr.FillComboBox("tblArea", cboArea, "AreaNum", "AreaID")
		clsMr.FillComboBox("tblContractTitle", cboContractType, "ContractTitle", "ContractTitleID")

	End Sub

#End Region

#Region "Form-UI/Methods"

	Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
		''
		EditContract()
	End Sub

	Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
		''
		Dim frm As New frmContract(0)
		appMain.addTabPage(frm, frmApplicationMain.eFormType.Contract)
		''Refresh form
		AddHandler frm.Closed, AddressOf RefreshList
	End Sub

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		Me.Close()
	End Sub

	Private Sub grdContractList_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdContractList.DoubleClick
		EditContract()
	End Sub

	Private Sub cboClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
		AutoComplete(cboClient, e)
	End Sub

	Private Sub cboClient_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyUp
		FilterGrid()
	End Sub

	Private Sub cboClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
		FilterGrid()
	End Sub

	Private Sub dtpDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpContractDateTo.ValueChanged
		FilterGrid()
	End Sub

	Private Sub dtpDateTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpContractDateFrom.ValueChanged
		FilterGrid()
	End Sub

	Private Sub txtContractNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContractNum.TextChanged
		FilterGrid()
	End Sub

	Private Sub cboArea_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboArea.KeyUp
		FilterGrid()
	End Sub

	Private Sub cboArea_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboArea.SelectedIndexChanged
		FilterGrid()
	End Sub

	Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
		''
		Dim frm As New frmQuickReport

		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		Dim rpt As New rptContract
		Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table

		Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
		''
		For Each tbCurrent In rpt.Database.Tables
			tliCurrent = tbCurrent.LogOnInfo
			''
			With tliCurrent.ConnectionInfo
				.ServerName = gStrServerName
				.DatabaseName = gStrDataBaseName
				.UserID = ""
				.Password = ""
			End With

			tbCurrent.ApplyLogOnInfo(tliCurrent)
		Next tbCurrent

		rpt.SetParameterValue("DateFrom", dtpContractDateFrom.Value)
		rpt.SetParameterValue("DateTo", dtpContractDateTo.Value)

		frm.crvInstantViewer.ReportSource = rpt
		frm.crvInstantViewer.Refresh()
		frm.Show()

		frm.crvInstantViewer.DisplayToolbar = True
		Windows.Forms.Cursor.Current = Cursors.Default()
	End Sub

	Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
		''
		If Me.grpShowHideColumns.Visible = False Then
			Me.grpShowHideColumns.Visible = True
			Me.grpShowHideColumns.BringToFront()
			mstrCurrentGridName = "ContractList"
			''
			'' populate list with grid's dataSource fields...
			''

			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridCol.Items.Clear()
			For Each col In grdContractList.Columns
				Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
			Next
			chkLstGridCol.Items.Remove("Del")
			chkLstGridCol.Items.Remove("ContractTitleID")
			chkLstGridCol.Items.Remove("ContractTypeID")
			chkLstGridCol.Items.Remove("AreaID")
			chkLstGridCol.Items.Remove("ContractID")
			chkLstGridCol.Items.Remove("ClientID")
			chkLstGridCol.Items.Remove("Status")
		Else
			Me.grpShowHideColumns.Visible = False
			Me.grpShowHideColumns.SendToBack()
		End If
	End Sub

	Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
		''
		Dim i As Integer

		For i = 0 To Me.chkLstGridCol.Items.Count - 1
			Me.grdContractList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
		Next

		''
		Me.grpShowHideColumns.Visible = False

	End Sub

	Private Sub cboContractType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboContractType.SelectedIndexChanged
		FilterGrid()
	End Sub

	Private Sub cboContractType_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboContractType.KeyPress
		AutoComplete(cboContractType, e)
	End Sub

	Private Sub cboContractType_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboContractType.KeyUp
		FilterGrid()
	End Sub

	Private Sub txtRefNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRefNum.TextChanged
		FilterGrid()
	End Sub


#End Region

#Region "Form-Functions"

	Private Sub DrawGrid()
		''
		grdContractList.DataSource = dsdata.Tables("vwAreaContract").DefaultView
		LoadProfile(mStrSubKeyName, Me.grdContractList)
		dsdata.Tables("vwAreaContract").DefaultView.AllowNew = False

		With grdContractList
			.ReadOnly = True
			.Columns("Del").Visible = False
			.Columns("ContractTitleID").Visible = False
			.Columns("ContractTypeID").Visible = False
			.Columns("AreaID").Visible = False
			.Columns("ContractID").Visible = False
			.Columns("ClientID").Visible = False
			.Columns("StatusID").Visible = False
			.Columns("InvoiceID").Visible = False
			.Columns("ContractType").Visible = False

			.Columns("ContractNum").HeaderText = "Number"
			.Columns("ClientName").HeaderText = "Client Name"
			.Columns("ContractDate").HeaderText = "Date"
			.Columns("ContractType").HeaderText = "Type"
			.Columns("ContractTitle").HeaderText = "Title"
			.Columns("AreaNum").HeaderText = "Area #"
			.Columns("AreaSQM").HeaderText = "Area SQM"
			.Columns("RefNum").HeaderText = "Reference #"
			.Columns("StartingDate").HeaderText = "Starting Date"
			.Columns("EndDate").HeaderText = "End Date"

			.ColumnHeadersHeight = btnShowCol.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		End With
		LoadProfile(mStrSubKeyName, Me.grdContractList)
	End Sub

	Private Sub RefreshList(ByVal sender As Object, ByVal e As System.EventArgs)
		''
		dsdata.Tables("vwAreaContract").Rows.Clear()
		clsMr.BuildSqlAdapter("SELECT * FROM vwAreaContract WHERE Del=0", "vwAreaContract")
		FilterGrid()
	End Sub

	Private Sub FilterGrid()
		''
		If blnLoading = True Then Exit Sub

		Dim s As String

		s = "(ContractDate >= '" & dtpContractDateFrom.Value.ToShortDateString() & "') AND (ContractDate <= '" & dtpContractDateTo.Value.ToShortDateString() & "')"

		If txtContractNum.Text <> String.Empty Then
			Dim tn As Integer
			''
			Try
				tn = Convert.ToInt32(txtContractNum.Text)
				s = s & " AND  (ContractNum = " & tn & ")"
			Catch ex As Exception
				txtContractNum.Text = ""
			End Try
		End If
		''

		If txtRefNum.Text <> String.Empty Then
			s = s & " AND  (RefNum = '" & txtRefNum.Text & "')"
		End If
		''

		If cboClient.SelectedIndex <> -1 Then
			s = s & " AND (ClientID = " & cboClient.SelectedValue & ")"
		Else
			If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
				s = s & " AND (ClientID = " & -1 & ")"
			End If
		End If
		''

		If cboContractType.SelectedIndex <> -1 Then
			s = s & " AND (ContractTitleID = " & cboContractType.SelectedValue & ")"
		Else
			If cboContractType.Text <> "" And cboContractType.SelectedIndex = -1 Then
				s = s & " AND (ContractTitleID = " & -1 & ")"
			End If
		End If
		''

		If cboArea.SelectedIndex <> -1 Then
			s = s & " AND (AreaID = " & cboArea.SelectedValue & ")"
		Else
			If cboArea.Text <> "" And cboArea.SelectedIndex = -1 Then
				s = s & " AND (AreaID = " & -1 & ")"
			End If
		End If
		''
		dsdata.Tables("vwAreaContract").DefaultView.RowFilter = s
	End Sub

	Private Sub EditContract()
		''
		If grdContractList.Rows.Count = 0 Then Exit Sub
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor

		Dim frm As New frmContract(grdContractList.Item("ContractID", grdContractList.CurrentRow.Index).Value)
		appMain.addTabPage(frm, frmApplicationMain.eFormType.Contract)

		Windows.Forms.Cursor.Current = Cursors.Default
		''Refresh form
		AddHandler frm.Closed, AddressOf RefreshList

	End Sub

	Private Function GetBranchBillingInfo()
		''
		Dim intDGID As Integer

		Try
			Dim cmd As New SqlClient.SqlCommand("SELECT DGID FROM tblBranchBillingInfo WHERE BranchID=" & gIntBranchID, conSql)
			conSql.Open()
			intDGID = cmd.ExecuteScalar()
			conSql.Close()
			Return intDGID
		Catch ex As Exception
			conSql.Close()
			Return 0
		End Try
	End Function

	Private Sub GetCompanyCurrencies()
		''
		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand
		''
		strSQL = "select * FROM  dbo.tblCompany  WHERE dbo.tblCompany.companyID=  " & gIntCompanyID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text
		''
		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			CurrID2 = dRdr("CurrID2")
		End If
		dRdr.Close()
		conSql.Close()
	End Sub


#End Region

	Private Sub btnAutoGenerateInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAutoGenerateInvoice.Click
		''
		dsdata.Tables("vwClientContractSum").Rows.Clear()
		''
		If cboClient.SelectedIndex <> -1 Then
			clsMr.BuildSqlAdapter("Select ClientID,SUM(TotalCost) AS TotalContract From tblClientContract WHERE ClientID=" & cboClient.SelectedValue & " AND InvoiceID IS Null AND (ContractDate >= '" & dtpContractDateFrom.Value.ToShortDateString() & "')" & "   Group BY ClientID", "vwClientContractSum")
		Else
			clsMr.BuildSqlAdapter("Select ClientID,SUM(TotalCost) AS TotalContract From tblClientContract WHERE InvoiceID IS Null AND (ContractDate >= '" & dtpContractDateFrom.Value.ToShortDateString() & "')" & "  Group BY ClientID", "vwClientContractSum")
		End If
		''
		Dim dv As DataView = dsdata.Tables("vwClientContractSum").DefaultView
		Dim drv As DataRowView
		For Each drv In dv
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			''Create Invoice
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			Dim drInvoice As DataRow = dsdata.Tables("tblInvoice").NewRow
			drInvoice("InvoiceID") = clsMr.GetMaxNumber("InvoiceID", "tblInvoice") + 1
			drInvoice("CatID") = 5
			drInvoice("InvoiceNumber") = clsMr.GetMaxNumber("InvoiceNumber", "tblInvoice") + 1
			drInvoice("InvoiceFrom") = dtpContractDateFrom.Value.ToShortDateString
			''
			Dim strYear As String = Now.Date.Year
			strYear = strYear.Substring(2, 2)
			drInvoice("InvoiceYY") = strYear
			Dim intDG As Integer = GetBranchBillingInfo()
			If intDG <> 0 Then
				drInvoice("DGID") = intDG
			End If

			drInvoice("InvoiceTo") = dtpContractDateTo.Value.ToShortDateString
			drInvoice("InvoiceDate") = Now.Date
			drInvoice("CurrencyID") = gIntCompanyCurrID
			drInvoice("Rate") = GetRate(gIntCompanyCurrID, CurrID2, Now.Date)
			drInvoice("StatusID") = 1
			drInvoice("BilledDate") = Now.Date
			drInvoice("EmployeeID") = gIntUserID
			drInvoice("BranchID") = gIntBranchID
			drInvoice("Del") = 0
			drInvoice("Description") = "Auto Generated Invoice Number:" & drInvoice("InvoiceNumber")
			drInvoice("CreateByID") = gIntUserID
			drInvoice("CreateDate") = Now.Date
			drInvoice("AutoGel") = 1
			drInvoice("ClientID") = drv("ClientID")

			' If type of Contract is "����� ������" Total = Total * diff(Month,From,To)
			'else <Other Type>


			'drInvoice("Total")=
			dsdata.Tables("tblInvoice").Rows.Add(drInvoice)
			daInvoice.Update(dsdata, "tblInvoice")
			''
			Dim dvOvF As DataView = dsdata.Tables("vwContract").DefaultView
			Dim drvOvF As DataRowView
			For Each drvOvF In dvOvF
				drvOvF("InvoiceID") = drInvoice("InvoiceID")

				Dim cmd As New SqlCommand("Update tblClientContract set InvoiceID =" & drInvoice("InvoiceID") & " WHERE  tblClientContract.ContractID =" & drvOvF("ContractID"), conSql)

				conSql.Open()
				cmd.ExecuteNonQuery()
				conSql.Close()
			Next
			If IsDBNull(drv("TotalCost")) Then
				drv("TotalCost") = 0
			End If
			'UpdateInvoiceDetail(drInvoice("InvoiceID"), drv("TotalCost"), 9)

			''calculate invoice total and update to invoice

			drInvoice("Total") = dblInvoiceTotal
			drInvoice("TotalCurr2") = GetExchangeValue(gIntCompanyCurrID, CurrID2, Now.Date, drInvoice("Total"))
			daInvoice.Update(dsdata, "tblInvoice")

		Next
		FilterGrid()
		btnAutoGenerateInvoice.Enabled = False
	End Sub

	'Private Sub UpdateInvoiceDetail(ByVal pInvoiceID As Integer, ByVal pTotal As Double, ByVal pServiceID As Integer)	', Optional ByVal pQty As Integer = 1)
	''
	'Dim drInvoiceDetail As DataRow = dsdata.Tables("tblInvoiceDetail").NewRow
	'drInvoiceDetail("InvoiceID") = pInvoiceID
	'drInvoiceDetail("InvoiceDetailID") = clsMr.GetMaxNumber("InvoiceDetailID", "tblInvoiceDetail") + 1
	'drInvoiceDetail("ServiceID") = pServiceID
	'drInvoiceDetail("Price") = pTotal
	'dblInvoiceTotal += drInvoiceDetail("Price")
	'drInvoiceDetail("Discount") = 0
	'drInvoiceDetail("VATAmount") = 0
	'drInvoiceDetail("Del") = 0
	'drInvoiceDetail("PriceUnitID") = 1
	'drInvoiceDetail("TotalCurr2") = GetExchangeValue(gIntCompanyCurrID, CurrID2, Now.Date, pTotal)
	'dsdata.Tables("tblInvoiceDetail").Rows.Add(drInvoiceDetail)
	'daInvoiceDetail.Update(dsdata, "tblInvoiceDetail")
	'End Sub


    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

    End Sub
End Class
