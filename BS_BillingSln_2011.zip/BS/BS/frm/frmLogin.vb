Public Class frmLogin

	Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' chkeck Legal Copy...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		If getLegalFileAccessInfo() = False Then
			'' exist
			End
		End If

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' check connection...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		conSql = BITSConn.modMain.CheckConnection(gStrXMLFileName)

		If conSql Is Nothing Then
			Application.Exit()
			Exit Sub
		Else
			''
			gStrServerName = conSql.DataSource
			gStrDataBaseName = conSql.Database
		End If

#If DEBUG Then
		txtUser.Text = "bits"
		txtPass.Text = "pw"
		btnOk.PerformClick()
#End If


	End Sub

	Private Sub InitializeDGCA()

		DGCA.modMain.conSql = conSql
		DGCA.modMain.gStrCompanyName = gStrCompanyName
		DGCA.modMain.gStrUserName = gStrUserName
		DGCA.modMain.gStrDataBaseName = gStrDataBaseName
		DGCA.modMain.gStrPassWord = gStrPassWord
		'DGCA.modMain.gBlnBITSSec = gBlnBITSSec
		''
		DGCA.modMain.strSQL = strSQL
		DGCA.modMain.strMsg = strMsg
		DGCA.modMain.gIntUserID = gIntUserID
		DGCA.modMain.gIntCompanyID = gIntCompanyID
		DGCA.modMain.gIntBranchID = gIntBranchID
		DGCA.modMain.gIntDepartment = gIntDepartment
		'DGCA.modMain.gIntClient = gIntClient
		'DGCA.modMain.gintLogID = gintLogID
		DGCA.modMain.gStrXMLFileName = gStrXMLFileName
		''
		DGCA.modMain.gUserLevel = gUserLevel
		''
		' DGCA.modMain.gStrFilter = gStrFilter
		' DGCA.modMain.gStrFilterStatment = gStrFilterStatment
		'DGCA.modMain.gIntLicenseTypeID = gIntLicenseTypeID
		'DGCA.modMain.gIntAcctTypeID = gIntAcctTypeID
		'to be used in voucher
		'DGCA.modMain.gIntAccountDetailID = gIntAccountDetailID
		'DGCA.modMain.gStrFullAccountName = gStrFullAccountName
		'DGCA.modMain.StrVwAccountSql = StrVwAccountSql
		'DGCA.modMain.strVwAccountDetailSql = strVwAccountDetailSql
		'DGCA.modMain.StrAccountSql = StrAccountSql
		'DGCA.modMain.strAccountDetailSql = strAccountDetailSql
		DGCA.modMain.gStrLang = gStrLang
		'' Company Declarations
		DGCA.modMain.gStrCompanyName = gStrCompanyName
		DGCA.modMain.gDtCompanyBeginDate = gDtCompanyBeginDate
		DGCA.modMain.gDtCompanyEndDate = gDtCompanyEndDate

		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

		'DGCA.modMain.gPicPathSource = gPicPathSource
		'DGCA.modMain.intPersonnelID = intPersonnelID
		'DGCA.modMain.gIntAcctType = gIntAcctType
		'DGCA.modMain.gIntTrxID = gIntTrxID
		'DGCA.modMain.gBlnOpendOrClosed = gBlnOpendOrClosed
		DGCA.modMain.gIntCompanyCurrID = gIntCompanyCurrID

		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'DGCA.modMain.gIntLicID = gIntLicID
		'DGCA.modMain.gBlnLREdit = gBlnLREdit

		''''''''''''''''''''''''''''''''''''''
		''''''Reports Declaration''''''
		'DGCA.modMain.gIntCategoryID = gIntCategoryID

		''
		DGCA.modMain.gintDecDigit = gintDecDigit
		DGCA.modMain.gblnUseComma = gblnUseComma
		DGCA.modMain.gstrSharedDataPath = gstrSharedDataPath


	End Sub

	Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click

		If CheckValues() = False Then
			Exit Sub
		End If

		Dim cmd As SqlClient.SqlCommand

		cmd = New SqlClient.SqlCommand("SELECT * FROM VwUsers WHERE userName = @userName AND Password = @Password", conSql)
		cmd.Parameters.AddWithValue("@userName", txtUser.Text)
		cmd.Parameters.AddWithValue("@Password", txtPass.Text)

		Dim dr As SqlClient.SqlDataReader

		If conSql.State = ConnectionState.Closed Then
			conSql.Open()
		End If

		dr = cmd.ExecuteReader()

		If dr.Read() Then
			'' get company / user info
			gIntUserID = dr("EmployeeID")
			gIntBranchID = dr("BranchID")
			gIntDepartment = dr("DptID")
			gIntCompanyID = dr("CompanyID")
			gStrCompanyName = dr("CompanyName")
			gDtCompanyBeginDate = dr("DateFrom")
			gDtCompanyEndDate = dr("DateTo")
			gIntCompanyCurrID = dr("CurrID")
			gIntCompanyCurrID2 = dr("CurrID2")
			gUserLevel = dr("UserLevelID")
			''
			'' close connections
			dr.Close()
			conSql.Close()
			''
			'' hide form 
			Me.Visible = False
			''
			UserPreferences()
			''
			InitializeDGCA()
			''
			'LogEnter()
			Dim clsFrmAppMain As New frmApplicationMain
			clsFrmAppMain.ShowDialog()
			''
			' '' terminate
			Me.Close()
		Else
			'' close connections
			dr.Close()
			conSql.Close()

			MsgBox("Invalid User Name or Password", MsgBoxStyle.Exclamation, "Warning")
		End If

	End Sub

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        conSql.Close()
		Me.Close()
	End Sub

	Private Function CheckValues() As Boolean
		If (txtUser.Text = "") Or (txtPass.Text = "") Then
			Return False
		End If
		Return True
	End Function

	Private Sub txtPass_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtPass.KeyPress
		If Asc(e.KeyChar) = 13 Then
			btnOk.PerformClick()
		End If
	End Sub

	Public Sub UserPreferences()
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''
		'' GET User Shared Data Path
		''
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		Dim cmd2 As SqlClient.SqlCommand
		cmd2 = New SqlClient.SqlCommand("SELECT * FROM tblUserPreferences WHERE UserID = " & gIntUserID, conSql)
		Dim dr2 As SqlClient.SqlDataReader
		''
		If conSql.State = ConnectionState.Closed Then
			conSql.Open()
		End If

		dr2 = cmd2.ExecuteReader()
		''
		If dr2.Read() Then
			'' Set User Preferences...
			gintDecDigit = dr2("DecDigit")
			gblnUseComma = dr2("UseComma")
			gstrSharedDataPath = dr2("SharedDataPath")
			''
			'' Close Connections
			dr2.Close()
			conSql.Close()
        End If

        'If conSql.State = ConnectionState.Open Then
        '	conSql.Close()
        '      End If

        dr2.Close()
        conSql.Close()
	End Sub

End Class
