<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmArea
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblFormTitleLine = New System.Windows.Forms.Panel
        Me.lblFormTitle = New System.Windows.Forms.Label
        Me.grplist = New System.Windows.Forms.GroupBox
        Me.lblZoneFilter = New System.Windows.Forms.Label
        Me.cboZoneFilter = New System.Windows.Forms.ComboBox
        Me.txtSearch = New System.Windows.Forms.TextBox
        Me.lstArea = New System.Windows.Forms.ListBox
        Me.grpArea = New System.Windows.Forms.GroupBox
        Me.rdbContains = New System.Windows.Forms.RadioButton
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.grpInfo = New System.Windows.Forms.GroupBox
        Me.txtElectrictyRef4 = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtElectrictyRef3 = New System.Windows.Forms.TextBox
        Me.txtElectrictyRef2 = New System.Windows.Forms.TextBox
        Me.txtElectrictyRef1 = New System.Windows.Forms.TextBox
        Me.lblElectricity = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.txtNetworkRef4 = New System.Windows.Forms.TextBox
        Me.txtPhoneRef4 = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtNetworkRef3 = New System.Windows.Forms.TextBox
        Me.txtNetworkRef2 = New System.Windows.Forms.TextBox
        Me.txtPhoneRef3 = New System.Windows.Forms.TextBox
        Me.txtPhoneRef2 = New System.Windows.Forms.TextBox
        Me.txtPhoneRef1 = New System.Windows.Forms.TextBox
        Me.txtPhone = New System.Windows.Forms.Label
        Me.txtNetworkRef1 = New System.Windows.Forms.TextBox
        Me.lblNetwork = New System.Windows.Forms.Label
        Me.cboZone = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.lblArea = New System.Windows.Forms.Label
        Me.txtAreaSQM = New System.Windows.Forms.TextBox
        Me.lblCurrency = New System.Windows.Forms.Label
        Me.txtDescription = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtFeePerMeter = New System.Windows.Forms.TextBox
        Me.lblfeePerMeter = New System.Windows.Forms.Label
        Me.txtAreaNum = New System.Windows.Forms.TextBox
        Me.lblAreaNumber = New System.Windows.Forms.Label
        Me.CboAreaType = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtOfficeNumber = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.lblDash = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.grpControls = New System.Windows.Forms.GroupBox
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.txtAreaID = New System.Windows.Forms.TextBox
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.grplist.SuspendLayout()
        Me.grpArea.SuspendLayout()
        Me.grpInfo.SuspendLayout()
        Me.grpControls.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblFormTitleLine
        '
        Me.lblFormTitleLine.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblFormTitleLine.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblFormTitleLine.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lblFormTitleLine.Location = New System.Drawing.Point(0, 40)
        Me.lblFormTitleLine.Name = "lblFormTitleLine"
        Me.lblFormTitleLine.Size = New System.Drawing.Size(882, 3)
        Me.lblFormTitleLine.TabIndex = 3
        '
        'lblFormTitle
        '
        Me.lblFormTitle.AutoEllipsis = True
        Me.lblFormTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblFormTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblFormTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.Black
        Me.lblFormTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(882, 40)
        Me.lblFormTitle.TabIndex = 0
        Me.lblFormTitle.Text = "Area Form"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grplist
        '
        Me.grplist.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grplist.Controls.Add(Me.lblZoneFilter)
        Me.grplist.Controls.Add(Me.cboZoneFilter)
        Me.grplist.Controls.Add(Me.txtSearch)
        Me.grplist.Controls.Add(Me.lstArea)
        Me.grplist.Controls.Add(Me.grpArea)
        Me.grplist.Location = New System.Drawing.Point(9, 49)
        Me.grplist.Name = "grplist"
        Me.grplist.Size = New System.Drawing.Size(246, 427)
        Me.grplist.TabIndex = 5
        Me.grplist.TabStop = False
        Me.grplist.Text = "Find Area"
        '
        'lblZoneFilter
        '
        Me.lblZoneFilter.AutoSize = True
        Me.lblZoneFilter.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZoneFilter.ForeColor = System.Drawing.Color.DarkRed
        Me.lblZoneFilter.Location = New System.Drawing.Point(9, 19)
        Me.lblZoneFilter.Name = "lblZoneFilter"
        Me.lblZoneFilter.Size = New System.Drawing.Size(38, 13)
        Me.lblZoneFilter.TabIndex = 3
        Me.lblZoneFilter.Text = " Zone"
        '
        'cboZoneFilter
        '
        Me.cboZoneFilter.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboZoneFilter.FormattingEnabled = True
        Me.cboZoneFilter.Location = New System.Drawing.Point(50, 14)
        Me.cboZoneFilter.Name = "cboZoneFilter"
        Me.cboZoneFilter.Size = New System.Drawing.Size(184, 24)
        Me.cboZoneFilter.TabIndex = 0
        '
        'txtSearch
        '
        Me.txtSearch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSearch.Location = New System.Drawing.Point(6, 78)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(229, 20)
        Me.txtSearch.TabIndex = 1
        '
        'lstArea
        '
        Me.lstArea.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstArea.FormattingEnabled = True
        Me.lstArea.Location = New System.Drawing.Point(6, 105)
        Me.lstArea.Name = "lstArea"
        Me.lstArea.Size = New System.Drawing.Size(229, 303)
        Me.lstArea.TabIndex = 2
        '
        'grpArea
        '
        Me.grpArea.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpArea.BackColor = System.Drawing.Color.LightYellow
        Me.grpArea.Controls.Add(Me.rdbContains)
        Me.grpArea.Controls.Add(Me.RadioButton1)
        Me.grpArea.Location = New System.Drawing.Point(6, 39)
        Me.grpArea.Name = "grpArea"
        Me.grpArea.Size = New System.Drawing.Size(229, 32)
        Me.grpArea.TabIndex = 4
        Me.grpArea.TabStop = False
        '
        'rdbContains
        '
        Me.rdbContains.AutoSize = True
        Me.rdbContains.Checked = True
        Me.rdbContains.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdbContains.Location = New System.Drawing.Point(115, 10)
        Me.rdbContains.Name = "rdbContains"
        Me.rdbContains.Size = New System.Drawing.Size(71, 18)
        Me.rdbContains.TabIndex = 1
        Me.rdbContains.TabStop = True
        Me.rdbContains.Text = "Contains"
        Me.rdbContains.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton1.Location = New System.Drawing.Point(6, 11)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(46, 18)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.Text = "Like"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'grpInfo
        '
        Me.grpInfo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpInfo.Controls.Add(Me.txtElectrictyRef4)
        Me.grpInfo.Controls.Add(Me.Label13)
        Me.grpInfo.Controls.Add(Me.txtElectrictyRef3)
        Me.grpInfo.Controls.Add(Me.txtElectrictyRef2)
        Me.grpInfo.Controls.Add(Me.txtElectrictyRef1)
        Me.grpInfo.Controls.Add(Me.lblElectricity)
        Me.grpInfo.Controls.Add(Me.Label15)
        Me.grpInfo.Controls.Add(Me.Label16)
        Me.grpInfo.Controls.Add(Me.txtNetworkRef4)
        Me.grpInfo.Controls.Add(Me.txtPhoneRef4)
        Me.grpInfo.Controls.Add(Me.Label11)
        Me.grpInfo.Controls.Add(Me.Label12)
        Me.grpInfo.Controls.Add(Me.txtNetworkRef3)
        Me.grpInfo.Controls.Add(Me.txtNetworkRef2)
        Me.grpInfo.Controls.Add(Me.txtPhoneRef3)
        Me.grpInfo.Controls.Add(Me.txtPhoneRef2)
        Me.grpInfo.Controls.Add(Me.txtPhoneRef1)
        Me.grpInfo.Controls.Add(Me.txtPhone)
        Me.grpInfo.Controls.Add(Me.txtNetworkRef1)
        Me.grpInfo.Controls.Add(Me.lblNetwork)
        Me.grpInfo.Controls.Add(Me.cboZone)
        Me.grpInfo.Controls.Add(Me.Label6)
        Me.grpInfo.Controls.Add(Me.lblArea)
        Me.grpInfo.Controls.Add(Me.txtAreaSQM)
        Me.grpInfo.Controls.Add(Me.lblCurrency)
        Me.grpInfo.Controls.Add(Me.txtDescription)
        Me.grpInfo.Controls.Add(Me.Label5)
        Me.grpInfo.Controls.Add(Me.txtFeePerMeter)
        Me.grpInfo.Controls.Add(Me.lblfeePerMeter)
        Me.grpInfo.Controls.Add(Me.txtAreaNum)
        Me.grpInfo.Controls.Add(Me.lblAreaNumber)
        Me.grpInfo.Controls.Add(Me.CboAreaType)
        Me.grpInfo.Controls.Add(Me.Label4)
        Me.grpInfo.Controls.Add(Me.Label2)
        Me.grpInfo.Controls.Add(Me.txtOfficeNumber)
        Me.grpInfo.Controls.Add(Me.Label3)
        Me.grpInfo.Controls.Add(Me.Label7)
        Me.grpInfo.Controls.Add(Me.lblDash)
        Me.grpInfo.Controls.Add(Me.Label8)
        Me.grpInfo.Controls.Add(Me.Label9)
        Me.grpInfo.Controls.Add(Me.Label10)
        Me.grpInfo.Enabled = False
        Me.grpInfo.Location = New System.Drawing.Point(268, 49)
        Me.grpInfo.Name = "grpInfo"
        Me.grpInfo.Size = New System.Drawing.Size(602, 427)
        Me.grpInfo.TabIndex = 4
        Me.grpInfo.TabStop = False
        '
        'txtElectrictyRef4
        '
        Me.txtElectrictyRef4.Location = New System.Drawing.Point(412, 394)
        Me.txtElectrictyRef4.Name = "txtElectrictyRef4"
        Me.txtElectrictyRef4.Size = New System.Drawing.Size(88, 20)
        Me.txtElectrictyRef4.TabIndex = 39
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.DarkRed
        Me.Label13.Location = New System.Drawing.Point(399, 398)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(12, 13)
        Me.Label13.TabIndex = 40
        Me.Label13.Text = "-"
        '
        'txtElectrictyRef3
        '
        Me.txtElectrictyRef3.Location = New System.Drawing.Point(307, 394)
        Me.txtElectrictyRef3.Name = "txtElectrictyRef3"
        Me.txtElectrictyRef3.Size = New System.Drawing.Size(88, 20)
        Me.txtElectrictyRef3.TabIndex = 35
        '
        'txtElectrictyRef2
        '
        Me.txtElectrictyRef2.Location = New System.Drawing.Point(203, 394)
        Me.txtElectrictyRef2.Name = "txtElectrictyRef2"
        Me.txtElectrictyRef2.Size = New System.Drawing.Size(88, 20)
        Me.txtElectrictyRef2.TabIndex = 34
        '
        'txtElectrictyRef1
        '
        Me.txtElectrictyRef1.Location = New System.Drawing.Point(99, 394)
        Me.txtElectrictyRef1.Name = "txtElectrictyRef1"
        Me.txtElectrictyRef1.Size = New System.Drawing.Size(88, 20)
        Me.txtElectrictyRef1.TabIndex = 33
        '
        'lblElectricity
        '
        Me.lblElectricity.AutoSize = True
        Me.lblElectricity.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblElectricity.ForeColor = System.Drawing.Color.DarkRed
        Me.lblElectricity.Location = New System.Drawing.Point(32, 398)
        Me.lblElectricity.Name = "lblElectricity"
        Me.lblElectricity.Size = New System.Drawing.Size(63, 13)
        Me.lblElectricity.TabIndex = 36
        Me.lblElectricity.Text = "Electricity"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.DarkRed
        Me.Label15.Location = New System.Drawing.Point(190, 398)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(12, 13)
        Me.Label15.TabIndex = 37
        Me.Label15.Text = "-"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.DarkRed
        Me.Label16.Location = New System.Drawing.Point(294, 398)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(12, 13)
        Me.Label16.TabIndex = 38
        Me.Label16.Text = "-"
        '
        'txtNetworkRef4
        '
        Me.txtNetworkRef4.Location = New System.Drawing.Point(412, 361)
        Me.txtNetworkRef4.Name = "txtNetworkRef4"
        Me.txtNetworkRef4.Size = New System.Drawing.Size(88, 20)
        Me.txtNetworkRef4.TabIndex = 30
        '
        'txtPhoneRef4
        '
        Me.txtPhoneRef4.Location = New System.Drawing.Point(411, 328)
        Me.txtPhoneRef4.Name = "txtPhoneRef4"
        Me.txtPhoneRef4.Size = New System.Drawing.Size(88, 20)
        Me.txtPhoneRef4.TabIndex = 29
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.DarkRed
        Me.Label11.Location = New System.Drawing.Point(398, 332)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(12, 13)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "-"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.DarkRed
        Me.Label12.Location = New System.Drawing.Point(399, 365)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(12, 13)
        Me.Label12.TabIndex = 32
        Me.Label12.Text = "-"
        '
        'txtNetworkRef3
        '
        Me.txtNetworkRef3.Location = New System.Drawing.Point(307, 361)
        Me.txtNetworkRef3.Name = "txtNetworkRef3"
        Me.txtNetworkRef3.Size = New System.Drawing.Size(88, 20)
        Me.txtNetworkRef3.TabIndex = 12
        '
        'txtNetworkRef2
        '
        Me.txtNetworkRef2.Location = New System.Drawing.Point(203, 361)
        Me.txtNetworkRef2.Name = "txtNetworkRef2"
        Me.txtNetworkRef2.Size = New System.Drawing.Size(88, 20)
        Me.txtNetworkRef2.TabIndex = 11
        '
        'txtPhoneRef3
        '
        Me.txtPhoneRef3.Location = New System.Drawing.Point(306, 328)
        Me.txtPhoneRef3.Name = "txtPhoneRef3"
        Me.txtPhoneRef3.Size = New System.Drawing.Size(88, 20)
        Me.txtPhoneRef3.TabIndex = 9
        '
        'txtPhoneRef2
        '
        Me.txtPhoneRef2.Location = New System.Drawing.Point(203, 328)
        Me.txtPhoneRef2.Name = "txtPhoneRef2"
        Me.txtPhoneRef2.Size = New System.Drawing.Size(88, 20)
        Me.txtPhoneRef2.TabIndex = 8
        '
        'txtPhoneRef1
        '
        Me.txtPhoneRef1.Location = New System.Drawing.Point(99, 328)
        Me.txtPhoneRef1.Name = "txtPhoneRef1"
        Me.txtPhoneRef1.Size = New System.Drawing.Size(88, 20)
        Me.txtPhoneRef1.TabIndex = 7
        '
        'txtPhone
        '
        Me.txtPhone.AutoSize = True
        Me.txtPhone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPhone.ForeColor = System.Drawing.Color.DarkRed
        Me.txtPhone.Location = New System.Drawing.Point(53, 332)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(42, 13)
        Me.txtPhone.TabIndex = 23
        Me.txtPhone.Text = "Phone"
        '
        'txtNetworkRef1
        '
        Me.txtNetworkRef1.Location = New System.Drawing.Point(99, 361)
        Me.txtNetworkRef1.Name = "txtNetworkRef1"
        Me.txtNetworkRef1.Size = New System.Drawing.Size(88, 20)
        Me.txtNetworkRef1.TabIndex = 10
        '
        'lblNetwork
        '
        Me.lblNetwork.AutoSize = True
        Me.lblNetwork.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNetwork.ForeColor = System.Drawing.Color.DarkRed
        Me.lblNetwork.Location = New System.Drawing.Point(41, 365)
        Me.lblNetwork.Name = "lblNetwork"
        Me.lblNetwork.Size = New System.Drawing.Size(54, 13)
        Me.lblNetwork.TabIndex = 26
        Me.lblNetwork.Text = "Network"
        '
        'cboZone
        '
        Me.cboZone.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboZone.FormattingEnabled = True
        Me.cboZone.Location = New System.Drawing.Point(99, 63)
        Me.cboZone.Name = "cboZone"
        Me.cboZone.Size = New System.Drawing.Size(227, 24)
        Me.cboZone.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DarkRed
        Me.Label6.Location = New System.Drawing.Point(271, 142)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(17, 13)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "M"
        '
        'lblArea
        '
        Me.lblArea.AutoSize = True
        Me.lblArea.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblArea.ForeColor = System.Drawing.Color.DarkRed
        Me.lblArea.Location = New System.Drawing.Point(60, 140)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(34, 13)
        Me.lblArea.TabIndex = 16
        Me.lblArea.Text = "Area"
        '
        'txtAreaSQM
        '
        Me.txtAreaSQM.AcceptsReturn = True
        Me.txtAreaSQM.Location = New System.Drawing.Point(99, 138)
        Me.txtAreaSQM.Name = "txtAreaSQM"
        Me.txtAreaSQM.Size = New System.Drawing.Size(171, 20)
        Me.txtAreaSQM.TabIndex = 3
        '
        'lblCurrency
        '
        Me.lblCurrency.AutoSize = True
        Me.lblCurrency.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrency.ForeColor = System.Drawing.Color.DarkRed
        Me.lblCurrency.Location = New System.Drawing.Point(272, 178)
        Me.lblCurrency.Name = "lblCurrency"
        Me.lblCurrency.Size = New System.Drawing.Size(27, 13)
        Me.lblCurrency.TabIndex = 20
        Me.lblCurrency.Text = "LBP"
        '
        'txtDescription
        '
        Me.txtDescription.Location = New System.Drawing.Point(99, 214)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(333, 57)
        Me.txtDescription.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DarkRed
        Me.Label5.Location = New System.Drawing.Point(23, 215)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 13)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Description"
        '
        'txtFeePerMeter
        '
        Me.txtFeePerMeter.AcceptsReturn = True
        Me.txtFeePerMeter.Location = New System.Drawing.Point(99, 174)
        Me.txtFeePerMeter.Name = "txtFeePerMeter"
        Me.txtFeePerMeter.Size = New System.Drawing.Size(171, 20)
        Me.txtFeePerMeter.TabIndex = 4
        '
        'lblfeePerMeter
        '
        Me.lblfeePerMeter.AutoSize = True
        Me.lblfeePerMeter.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfeePerMeter.ForeColor = System.Drawing.Color.DarkRed
        Me.lblfeePerMeter.Location = New System.Drawing.Point(8, 173)
        Me.lblfeePerMeter.Name = "lblfeePerMeter"
        Me.lblfeePerMeter.Size = New System.Drawing.Size(86, 13)
        Me.lblfeePerMeter.TabIndex = 19
        Me.lblfeePerMeter.Text = "Fee Per Meter"
        '
        'txtAreaNum
        '
        Me.txtAreaNum.Location = New System.Drawing.Point(99, 32)
        Me.txtAreaNum.Name = "txtAreaNum"
        Me.txtAreaNum.Size = New System.Drawing.Size(228, 20)
        Me.txtAreaNum.TabIndex = 0
        '
        'lblAreaNumber
        '
        Me.lblAreaNumber.AutoSize = True
        Me.lblAreaNumber.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAreaNumber.ForeColor = System.Drawing.Color.DarkRed
        Me.lblAreaNumber.Location = New System.Drawing.Point(13, 36)
        Me.lblAreaNumber.Name = "lblAreaNumber"
        Me.lblAreaNumber.Size = New System.Drawing.Size(81, 13)
        Me.lblAreaNumber.TabIndex = 13
        Me.lblAreaNumber.Text = "Area Number"
        '
        'CboAreaType
        '
        Me.CboAreaType.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboAreaType.FormattingEnabled = True
        Me.CboAreaType.Location = New System.Drawing.Point(99, 96)
        Me.CboAreaType.Name = "CboAreaType"
        Me.CboAreaType.Size = New System.Drawing.Size(227, 24)
        Me.CboAreaType.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DarkRed
        Me.Label4.Location = New System.Drawing.Point(29, 101)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Area Type"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkRed
        Me.Label2.Location = New System.Drawing.Point(59, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Zone"
        '
        'txtOfficeNumber
        '
        Me.txtOfficeNumber.Location = New System.Drawing.Point(99, 292)
        Me.txtOfficeNumber.Name = "txtOfficeNumber"
        Me.txtOfficeNumber.Size = New System.Drawing.Size(171, 20)
        Me.txtOfficeNumber.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkRed
        Me.Label3.Location = New System.Drawing.Point(8, 296)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 13)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Office Number"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DarkRed
        Me.Label7.Location = New System.Drawing.Point(286, 142)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(12, 11)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "2"
        '
        'lblDash
        '
        Me.lblDash.AutoSize = True
        Me.lblDash.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDash.ForeColor = System.Drawing.Color.DarkRed
        Me.lblDash.Location = New System.Drawing.Point(190, 332)
        Me.lblDash.Name = "lblDash"
        Me.lblDash.Size = New System.Drawing.Size(12, 13)
        Me.lblDash.TabIndex = 24
        Me.lblDash.Text = "-"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DarkRed
        Me.Label8.Location = New System.Drawing.Point(293, 332)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(12, 13)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "-"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.DarkRed
        Me.Label9.Location = New System.Drawing.Point(190, 365)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(12, 13)
        Me.Label9.TabIndex = 27
        Me.Label9.Text = "-"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DarkRed
        Me.Label10.Location = New System.Drawing.Point(294, 365)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(12, 13)
        Me.Label10.TabIndex = 28
        Me.Label10.Text = "-"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.DarkRed
        Me.Label1.Location = New System.Drawing.Point(354, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Area Name"
        '
        'grpControls
        '
        Me.grpControls.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpControls.Controls.Add(Me.btnCancel)
        Me.grpControls.Controls.Add(Me.btnNew)
        Me.grpControls.Controls.Add(Me.btnSave)
        Me.grpControls.Controls.Add(Me.btnClose)
        Me.grpControls.Location = New System.Drawing.Point(6, 478)
        Me.grpControls.Name = "grpControls"
        Me.grpControls.Size = New System.Drawing.Size(864, 52)
        Me.grpControls.TabIndex = 6
        Me.grpControls.TabStop = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCancel.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Location = New System.Drawing.Point(249, 18)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(90, 28)
        Me.btnCancel.TabIndex = 2
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNew.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.Location = New System.Drawing.Point(13, 18)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(90, 28)
        Me.btnNew.TabIndex = 1
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnSave.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.Location = New System.Drawing.Point(131, 18)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(90, 28)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "E d i t"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.Location = New System.Drawing.Point(762, 18)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(90, 28)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'txtAreaID
        '
        Me.txtAreaID.Location = New System.Drawing.Point(307, 12)
        Me.txtAreaID.Name = "txtAreaID"
        Me.txtAreaID.Size = New System.Drawing.Size(68, 20)
        Me.txtAreaID.TabIndex = 1
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(804, 9)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(66, 25)
        Me.btnDataErr.TabIndex = 7
        Me.btnDataErr.Text = "Data Error"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(545, 12)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(259, 17)
        Me.lstDataErr.TabIndex = 8
        Me.lstDataErr.Visible = False
        '
        'frmArea
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(882, 539)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.grpControls)
        Me.Controls.Add(Me.grpInfo)
        Me.Controls.Add(Me.grplist)
        Me.Controls.Add(Me.lblFormTitleLine)
        Me.Controls.Add(Me.lblFormTitle)
        Me.Controls.Add(Me.txtAreaID)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmArea"
        Me.Text = "Area"
        Me.grplist.ResumeLayout(False)
        Me.grplist.PerformLayout()
        Me.grpArea.ResumeLayout(False)
        Me.grpArea.PerformLayout()
        Me.grpInfo.ResumeLayout(False)
        Me.grpInfo.PerformLayout()
        Me.grpControls.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblFormTitleLine As System.Windows.Forms.Panel
    Friend WithEvents lblFormTitle As System.Windows.Forms.Label
    Friend WithEvents grplist As System.Windows.Forms.GroupBox
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents lstArea As System.Windows.Forms.ListBox
    Friend WithEvents grpArea As System.Windows.Forms.GroupBox
    Friend WithEvents rdbContains As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents grpInfo As System.Windows.Forms.GroupBox
    Friend WithEvents txtOfficeNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CboAreaType As System.Windows.Forms.ComboBox
    Friend WithEvents grpControls As System.Windows.Forms.GroupBox
    Friend WithEvents btnNew As BHBut.BouncingHoverButton
    Friend WithEvents btnSave As BHBut.BouncingHoverButton
    Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents txtAreaID As System.Windows.Forms.TextBox
    Friend WithEvents btnCancel As BHBut.BouncingHoverButton
    Friend WithEvents btnDataErr As System.Windows.Forms.Button
    Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
    Friend WithEvents txtAreaNum As System.Windows.Forms.TextBox
    Friend WithEvents lblAreaNumber As System.Windows.Forms.Label
    Friend WithEvents txtFeePerMeter As System.Windows.Forms.TextBox
    Friend WithEvents lblfeePerMeter As System.Windows.Forms.Label
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblCurrency As System.Windows.Forms.Label
    Friend WithEvents lblArea As System.Windows.Forms.Label
    Friend WithEvents txtAreaSQM As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtPhoneRef1 As System.Windows.Forms.TextBox
    Friend WithEvents txtPhone As System.Windows.Forms.Label
    Friend WithEvents txtNetworkRef1 As System.Windows.Forms.TextBox
    Friend WithEvents lblNetwork As System.Windows.Forms.Label
    Friend WithEvents cboZone As System.Windows.Forms.ComboBox
    Friend WithEvents txtNetworkRef3 As System.Windows.Forms.TextBox
    Friend WithEvents txtNetworkRef2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPhoneRef3 As System.Windows.Forms.TextBox
    Friend WithEvents txtPhoneRef2 As System.Windows.Forms.TextBox
    Friend WithEvents lblDash As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblZoneFilter As System.Windows.Forms.Label
    Friend WithEvents cboZoneFilter As System.Windows.Forms.ComboBox
    Friend WithEvents txtElectrictyRef4 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtElectrictyRef3 As System.Windows.Forms.TextBox
    Friend WithEvents txtElectrictyRef2 As System.Windows.Forms.TextBox
    Friend WithEvents txtElectrictyRef1 As System.Windows.Forms.TextBox
    Friend WithEvents lblElectricity As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtNetworkRef4 As System.Windows.Forms.TextBox
    Friend WithEvents txtPhoneRef4 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
End Class
