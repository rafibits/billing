Imports BITSConn
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Public Class frmAccountNew

#Region "Form-Declaration..."
    ''
    Dim clsMr As ClsMain
    Dim dsdata As New DataSet
    Private WithEvents Nav As BitsNav
    Private daAccount As SqlDataAdapter
    Dim daStreet As SqlClient.SqlDataAdapter
    Private daAddress As SqlDataAdapter
    Private daClientItem As SqlDataAdapter
    Private blnLoading As Boolean
    Private AddMode As Boolean
    Private AddressAddMode As Boolean
    Dim mStrTableName As String = "tblClient"
    Dim StrSql As String
    'Public AcctTypeID As Long
    'Private frmLedger As New frmLedger
    'Dim mID As Integer
    'Dim mBranchID As Integer
    'Dim mTypeOfID As String
    'Dim blnLedgerChg As Boolean = True
    Private mstrCurrentGridName As String
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Client\Settings"

#End Region

#Region "Form-Initialisation..."
    ''
    Private Sub frmAccountNew_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '' bug fix:
        ' If Me.Parent.Parent Is Nothing Then Return
        '' set Form's lable Title...
        Me.lblTitle.Text = Me.Text
        ''
        conSql = New SqlConnection("Data Source=BITSSERVER;Initial Catalog=Billing;Integrated Security=True")
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav
        ''
        blnLoading = True
        MakeDataAdapter()
        SetDataBinding()
        FillComboBox()
        SetAutoNumber()
        SetCurrencyManager()
        SetDefaultValue()
        ''
        DrawGrid()
        FilterAddress()
        FilterClientItem()
        SetStatus(False, "Edit")
        tcAddressDetail.TabPages.Remove(tpNewAddress)
        tcAddressDetail.TabPages.Remove(tpNewClientItem)
        ''
        'txtClientName.Focus()
        'SetFormsControls()
        'Constructor()
        'SetFormsControls()
        'updateLedgerName()
        'txtAcctTypeID.Text = AcctTypeID
        blnLoading = False
        ''
    End Sub

    Public Sub MakeDataAdapter()
        ''
        ' '' set SQL for selecting active Account recs...
        'StrSql = "SELECT * FROM tblClient"
        'StrSql &= " WHERE (AcctTypeID=" & AcctTypeID & ") "
        'StrSql &= " AND (BranchID=" & gIntBranchID & ") "
      'StrSql &= " AND (Del=0) order by ClientName"
        ''
        StrSql = "SELECT * FROM tblClient"
        StrSql &= " WHERE (Del=0) ORDER BY ClientName"
        daAccount = clsMr.BuildSqlAdapter(StrSql, mStrTableName)
        ''
        clsMr.BuildSqlAdapter("SELECT * FROM tblCurrency WHERE del =0", "tblCurrency")
        'clsMr.BuildSqlAdapter("SELECT * FROM tblAccountLedger WHERE del=0", "Ledger")
        '' A d d r e s s
        clsMr.BuildSqlAdapter("SELECT CityID, City_en, Del, StateID FROM tblAddCity WHERE del =0", "City")
        daStreet = clsMr.BuildSqlAdapter("SELECT StreetID, AreaID, CityID, Street_en, Del FROM tblAddStreet WHERE del=0", "Street")
        clsMr.BuildSqlAdapter("SELECT QadaID, RegionID, Qada_en, Del FROM tblAddQada WHERE del =0", "Qadaa")
        clsMr.BuildSqlAdapter("SELECT RegionID, StateID, Region_en, Del FROM tblAddRegion WHERE del=0", "Region")
        clsMr.BuildSqlAdapter("SELECT CityID, AreaID, Area_en, Del FROM tblAddArea WHERE del =0", "Area")
        clsMr.BuildSqlAdapter("SELECT * FROM tblAddressType ", "AddressType")
        clsMr.BuildSqlAdapter("SELECT StateID, State_en, Del FROM tblAddState WHERE del=0", "State")
        clsMr.BuildSqlAdapter("SELECT *  FROM vwAddress WHERE del =0", "vwAddress")
        daAddress = clsMr.BuildSqlAdapter("SELECT *  FROM tblAddress WHERE del =0", "tblAddress")
        ''
        daClientItem = clsMr.BuildSqlAdapter("SELECT Title, TitleID, Del FROM tblClientTitle WHERE Del = 0", "tblClientTitle")
        clsMr.BuildSqlAdapter("SELECT * FROM vwClientItem WHERE Del = 0", "vwClientItem")
        ''
        dsdata = clsMr.getDataSet
    End Sub

    Public Sub SetDataBinding()
        ''
        clsMr.BindTextBox(txtClientID, "tblClient", "ClientID")
      clsMr.BindTextBox(txtClientNum, "tblClient", "ClientNum")
        clsMr.BindTextBox(txtClientName, "tblClient", "ClientName")
        clsMr.BindTextBox(txtContactName, "tblClient", "ContactName")
        clsMr.BindComboBox(cboClientTitle, "tblClient", "ContactTitleID")
        clsMr.BindTextBox(txtTel, "tblClient", "Tel")
        clsMr.BindTextBox(txtExt, "tblClient", "Ext")
        clsMr.BindTextBox(txtCel, "tblClient", "Cell")
        clsMr.BindTextBox(txtFax, "tblClient", "Fax")
        clsMr.BindTextBox(txtEMail, "tblClient", "Email")
        clsMr.BindTextBox(txtWWW, "tblClient", "www")
        clsMr.BindTextBox(txtNote, "tblClient", "Note")
        clsMr.BindTextBox(txtDiscount, "tblClient", "Discount")
        ''
        clsMr.BindTextBox(txtBalance, "tblClient", "Balance")
        clsMr.BindTextBox(txtPendingBal, "tblClient", "PendingBal")
        clsMr.BindComboBox(cboCurrency, "tblClient", "CurrencyID")
        'clsMr.BindComboBox(cboLedger, "tblClient", "AccountLedgerID")
        'clsMr.BindTextBox(txtAcctTypeID, "tblClient", "AcctTypeID")
    End Sub

    Public Sub FillComboBox()
        ''A d d r e s s  . .
        clsMr.FillComboBox("city", cboCity, "City_en", "CityID")
        clsMr.FillComboBox("Street", cboStreet, "Street_en", "StreetID")
        clsMr.FillComboBox("Qadaa", cboQadaa, "Qada_en", "QadaID")
        clsMr.FillComboBox("Region", cboRegion, "Region_en", "RegionID")
        clsMr.FillComboBox("Area", cboArea, "Area_en", "AreaID")
        clsMr.FillComboBox("State", cboState, "State_en", "StateID")
        clsMr.FillComboBox("AddressType", cboAddType, "AddType", "AddTypeID")
        ''L e d g e r . . . .
        'clsMr.FillComboBox("Ledger", cboLedger, "LedgerNumber", "AccountLedgerID")
        ''C u r r e n c y . .
        clsMr.FillComboBox("tblCurrency", cboCurrency, "Symbol", "CurrID")
        ''C l i e n t s . . .
        clsMr.FillComboBox(mStrTableName, lstClient, "ClientName", "ClientID")
        ''C. T i t l e . .  .
        clsMr.FillComboBox("tblClientTitle", cboClientTitle, "Title", "TitleID")
    End Sub

    Public Sub SetAutoNumber()
        ''
        clsMr.SetAutoNumber(mStrTableName, "ClientID")
        ''
        'Dim lngMax As Long
        'If AcctTypeID = 7 Then
        '    lngMax = clsMr.GetMaxNumber("select max(AcctNumber) from tblAccount where branchid=" & gIntBranchID & "  And AcctTypeID = " & AcctTypeID & "  And AccountLedgerID= " & cboLedger.SelectedValue) + 1
        '    clsMr.SetAutoNumber(mStrTableName, "AcctNumber", lngMax)
        'Else
        '    lngMax = clsMr.GetMaxNumber("select max(AcctNumber) from tblAccount where branchid=" & gIntBranchID & "  And AcctTypeID = " & AcctTypeID) + 1
        '    clsMr.SetAutoNumber(mStrTableName, "AcctNumber", lngMax)
        'End If
    End Sub

    Public Sub SetCurrencyManager()
        Nav.SetCurrency(Me, clsMr.getDataSet(), mStrTableName)
    End Sub

    Public Sub SetDefaultValue()
        'clsMr.SetDefaults(mStrTableName, "Del", 0, "AcctTypeID", AcctTypeID, "CreateDate", Now.Date, "CreateBy", gIntUserID, "currencyID", gIntCompanyCurrID, "Balance", 0, "PendingBalance", 0)
        clsMr.SetDefaults(mStrTableName, "Del", 0, "CreateDate", Now.Date, "CreateBy", gIntUserID, "currencyID", gIntCompanyCurrID, "Balance", 0, "PendingBal", 0, "Discount", 0)
    End Sub

    'Public Sub New(Optional ByVal pID As Long = -1, Optional ByVal pTypeOfID As String = "", Optional ByVal pintBranchID As Integer = -1)
    '    InitializeComponent()
    '    '
    '    '' set the branch ID of the caller...
    '    'mID = pID
    '    'mTypeOfID = pTypeOfID
    '    '' set BranchID to use...
    '    'If pintBranchID = -1 Then
    '    '    mBranchID = gIntBranchID
    '    'Else
    '    '    mBranchID = pintBranchID
    '    'End If
    'End Sub

#End Region

#Region "Form-UI/Methods..."

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ''
        If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Nav.CancelCurrentEdit()
            SetStatus(False, "Edit")
            btnNew.Enabled = True
            btnSave.Enabled = True
            FilterAddress()
        End If
    End Sub

    Private Sub lstEmployee_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstClient.SelectedIndexChanged
        ''
        FilterAddress()
        FilterClientItem()
    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSearch.TextChanged
        ''
        If rdbContains.Checked = True Then
            dsdata.Tables("tblClient").DefaultView.RowFilter = "ClientName LIKE '%" & txtSearch.Text & "%'"
        Else
            dsdata.Tables("tblClient").DefaultView.RowFilter = "ClientName LIKE '" & txtSearch.Text & "%'"
        End If
        'Filter()
        FilterAddress()
        FilterClientItem()
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        NewRecord()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        save()
    End Sub

    'Public Event Closed(ByVal sender As System.Object, ByVal e As System.EventArgs)

    'Protected Sub OnClosed()
    '    RaiseEvent Closed(Me, New System.EventArgs)
    'End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        ''
        If btnSave.Text = "Save" Then
            Dim res As MsgBoxResult
            res = MsgBox("Do you want to save changes?", MsgBoxStyle.YesNoCancel)
            Select Case res
                Case MsgBoxResult.Yes
                    save()
                    Close()
                Case MsgBoxResult.No
                    Nav.CancelCurrentEdit()
                    Close()
                Case MsgBoxResult.Cancel
                    Nav.CancelCurrentEdit()
            End Select
        Else
            Close()
        End If
    End Sub

#End Region

#Region "Form-Functions..."

    Public Function GetRowIndex(ByVal pClientID As Long) As Integer
        ''
        Dim i As Integer
        For i = 0 To dsdata.Tables(mStrTableName).DefaultView.Count - 1
            If dsdata.Tables(mStrTableName).DefaultView.Item(i)("ClientID") = pClientID Then
                Return i
            End If
        Next
        Return -1
    End Function

    'Private Sub RefreshPOB()

    '    dsdata.Tables("CityOfBirth").Rows.Clear()
    '    clsMr.BuildSqlAdapter("SELECT * FROM tblAddressCity WHERE del =0", "CityOfBirth")
    '    dsdata = clsMr.getDataSet
    '    ''select max CityID
    '    Try
    '        Dim cmd As New SqlClient.SqlCommand("SELECT MAX(CityID) FROM tblAddressCity ", conSql)
    '        conSql.Open()
    '        cboPOB.SelectedValue = cmd.ExecuteScalar()
    '        dsdata.Tables("tblEmployee").DefaultView.Item(Nav.CurrentPosition)("POBID") = cmd.ExecuteScalar()
    '        conSql.Close()
    '    Catch ex As Exception
    '        conSql.Close()
    '    End Try

    'End Sub

    Private Sub SetStatus(ByVal pblnStatus As Boolean, ByVal strBtnSaveName As String)
        ''
        btnCancel.Visible = pblnStatus
        btnSave.Text = strBtnSaveName
        grpEmployee.Enabled = pblnStatus
        grpList.Enabled = Not (pblnStatus)
        tcAddressDetail.Enabled = pblnStatus
    End Sub

    Private Sub NewRecord()
        ''
        btnSave.Text = "Save"
        'blnLedgerChg = True
        Nav.AddNew()
        ''
        txtClientName.Focus()
        cboCurrency.Enabled = True
        btnNew.Enabled = False
        cboCity.SelectedIndex = -1
        cboStreet.SelectedIndex = -1
        cboCity.Text = ""
        cboStreet.Text = ""
        txtContactName.Text = ""
        txtNote.Text = ""
        ''
        txtClientName.Text = ""
        SetStatus(True, "Save")
        tcAddressDetail.Enabled = False
        btnNew.Enabled = False
        txtClientName.Focus()
        ''
        'If AcctTypeID = 7 Then
        '    cboLedger.SelectedIndex = -1
        '    cboLedger.Focus()
        'Else
        '    SetLedger()
        'End If
        ''
        FilterAddress()
    End Sub

    'Public Sub SetLedger()
    '    Select Case (AcctTypeID)
    '        Case (1) : cboLedger.SelectedValue = 227
    '        Case (2) : cboLedger.SelectedValue = 239
    '        Case (3) : cboLedger.SelectedValue = 378
    '            ''Case (7) : cboLedger.SelectedValue = 549
    '        Case (8) : cboLedger.SelectedValue = 401
    '    End Select
    'End Sub

    Private Sub save()
        ''
        If btnSave.Text = "Edit" Then
            SetStatus(True, "Save")
            If isAcctHasTrx() = False Then
                cboCurrency.Enabled = True
            Else
                cboCurrency.Enabled = False
            End If

            btnNew.Enabled = False
            txtClientName.Focus()
            'btnClientListErrorOpen.Visible = True
            'checkListValues()

            Exit Sub
        End If
        ' SetNullValues()

        blnLoading = True
        Nav.EndCurrentEdit()
        blnLoading = False

        If CheckValues() = False Then Exit Sub
        'dsdata.Tables(mStrTableName).Rows.Item(Nav.CurrentPosition)("AccountLedgerID") = cboLedger.SelectedValue
        clsMr.Update(daAccount, "tblClient")


        AddMode = False
        btnNew.Enabled = True
        tcAddressDetail.Enabled = True
        cboCurrency.Enabled = False

        SetStatus(False, "Edit")
    End Sub

    'Private Sub UpdateDataRow(ByVal pDr As DataRow)
    '    If txtClientName.Text <> "" Then
   '        pDr("ClientName") = txtClientName.Text
    '    End If

    '    'If txtMName.Text <> "" Then
    '    '    pDr("MName") = txtMName.Text
    '    'Else
    '    '    pDr("MName") = ""
    '    'End If

    '    'If txtLName.Text <> "" Then
    '    '    pDr("LName") = txtLName.Text
    '    'End If

    '    If txtNote.Text <> "" Then
    '        pDr("Note") = txtNote.Text
    '    Else
    '        pDr("Note") = ""
    '    End If


    '    'If Not (cboDoctor.SelectedValue) Is Nothing Then
    '    '    pDr("DrID") = cboDoctor.SelectedValue

    '    'End If

    '    'If Not (cboPOB.SelectedValue) Is Nothing Then
    '    '    pDr("POBID") = cboPOB.SelectedValue
    '    'Else
    '    '    pDr("POBID") = DBNull.Value
    '    'End If
    '    'If Not (cboReferring.SelectedValue) Is Nothing Then
    '    '    pDr("ReferringPartyID") = cboReferring.SelectedValue
    '    'Else
    '    '    pDr("ReferringPartyID") = DBNull.Value
    '    'End If

    '    'pDr("DOB") = dtpDOB.Value
    '    'pDr("BranchID") = gIntBranchID
    '    pDr("AcctID") = txtClientID.Text
    '    pDr("Del") = 0
    'End Sub

    Private Function CheckValues() As Boolean
        ''Checkvalues
        strMsg = ""
        If txtClientName.Text = "" Then
            strMsg = strMsg & vbCrLf & "     - Please Enter Client Name."
        Else
            Dim drClientName As DataRow()
            drClientName = dsdata.Tables(mStrTableName).Select("ClientName= '" & txtClientName.Text & "' AND not ClientID= " & txtClientID.Text & "")
            If drClientName.Length > 0 Then
                strMsg = strMsg & vbCrLf & "     - The enterded Client name is already found."
            End If
        End If
        ''
        If strMsg <> "" Then
            strMsg = "The following values are not valid:" & strMsg
            MsgBox(strMsg)
            Return False
        End If

        Return True
    End Function

#End Region

#Region "frmAddress..."

    Private Sub btnNewAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewAddress.Click
        NewAddress()
        tpNewAddress.Text = "New"
    End Sub

    Private Sub btnEditAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditAddress.Click
        EditAddress()
    End Sub

    Private Sub FilterAddress()
        ''
        Dim vw As DataView
        If txtClientID.Text = String.Empty Then
            txtClientID.Text = -1
        End If
        If txtClientID.Text <> "" Then
            vw = dsdata.Tables("vwAddress").DefaultView
            vw.RowFilter = "ClientID=" & txtClientID.Text & " "
        End If
        If grdViewAddress.Rows.Count = 0 Then
            btnDeleteAddress.Visible = False
            btnEditAddress.Visible = False
        Else
            btnEditAddress.Visible = True
            btnDeleteAddress.Visible = True
        End If
    End Sub

    Private Sub FilterClientItem()
        ''
        'Dim vw As DataView
        'If txtClientID.Text = String.Empty Then
        '    txtClientID.Text = -1
        'End If
        'If txtClientID.Text <> "" Then
        '    vw = dsdata.Tables("vwAddress").DefaultView
        '    vw.RowFilter = "ClientID=" & txtClientID.Text & " "
        'End If
        'If grdViewAddress.Rows.Count = 0 Then
        '    btnDeleteAddress.Visible = False
        '    btnEditAddress.Visible = False
        'Else
        '    btnEditAddress.Visible = True
        '    btnDeleteAddress.Visible = True
        'End If
    End Sub

    Private Sub NewAddress()
        ''Add tab Page if not found
        If Not tcAddressDetail.TabPages.Contains(tpNewAddress) Then
            tcAddressDetail.TabPages.Add(tpNewAddress)
            'tpNewAddress.Text = "New Address"
        End If

        ' tcAddress.SelectedIndex = 1
        tcAddressDetail.SelectedTab = tpNewAddress

        ''Get Auto Number for AddressID
        Dim AddressID As Long
        Try
            Dim cmdAddressID As New SqlClient.SqlCommand("SELECT CASE WHEN MAX(AddressID) IS NULL THEN 1 ELSE MAX(AddressID)+1 END FROM tblAddress", conSql)
            conSql.Open()
            AddressID = cmdAddressID.ExecuteScalar
            conSql.Close()
        Catch ex As Exception
            conSql.Close()
        End Try

        txtAddID.Text = AddressID

        btnSaveAddress.Enabled = True
        tpNewAddress.Visible = True

        ''clear address combos
        If cboAddType.Items.Count <> 0 Then
            cboAddType.SelectedIndex = 0
        End If

        cboArea.SelectedIndex = -1
        cboCity.SelectedIndex = -1
        cboStreet.SelectedIndex = -1
        cboQadaa.SelectedIndex = -1
        If cboState.Items.Count <> 0 Then
            cboState.SelectedIndex = 0
        End If

        '  cboRegion.SelectedIndex = -1

        cboArea.Text = ""
        cboCity.Text = ""
        cboStreet.Text = ""
        ' cboQadaa.Text = ""
        ' cboState.Text = ""
        '  cboRegion.Text = ""

        btnSaveAddress.Enabled = True
        AddressAddMode = True
    End Sub

    Private Function CheckAddressValues() As Boolean
        strMsg = ""

        If cboAddType.Text = "" Then
            strMsg = "Please insert AddressType " & vbCrLf
        End If

        If cboCity.Text = "" Then
            strMsg = strMsg & "Please enter City  " & vbCrLf
        End If
        If cboStreet.Text = "" Then
            strMsg = strMsg & "Please enter  Street  " & vbCrLf
        End If
        If strMsg <> "" Then
            strMsg = "The following value(s) is/are not valid: " & vbCrLf & strMsg
            MsgBox(strMsg)
            Return False
        Else
            Return True
        End If

    End Function
    Private Sub SaveAddress()
        If CheckAddressValues() = False Then Exit Sub

        If AddressAddMode = True Then
            dsdata.Tables("vwAddress").DefaultView.AllowNew = True
            ''adding new Address
            Dim drAddress As DataRow
            Dim drNew As DataRow

            ''add new row
            drAddress = dsdata.Tables("vwAddress").NewRow
            drNew = dsdata.Tables("tblAddress").NewRow

            drAddress("ClientID") = txtClientID.Text
            drNew("ClientID") = txtClientID.Text
            ''add values to fields
            UpdateAddressDataRow(drAddress)
            UpdateAddressDataRow(drNew)

            drAddress("AddType") = cboAddType.Text
            drAddress("State_en") = cboState.Text
            ' drAddress("Region_en") = cboRegion.Text
            ' drAddress("Qadaa_en") = cboQadaa.Text
            drAddress("City_en") = cboCity.Text
            drAddress("Area_en") = cboArea.Text
            drAddress("Street_en") = cboStreet.Text

            drAddress("Del") = 0
            drNew("Del") = 0
            ''add the created row
            dsdata.Tables("vwAddress").Rows.Add(drAddress)
            drAddress.EndEdit()
            dsdata.Tables("tblAddress").Rows.Add(drNew)
            clsMr.Update(daAddress, "tblAddress")

            dsdata.Tables("vwAddress").DefaultView.AllowNew = False

            AddressAddMode = False
            'If AddMode Then
            '   save()
            'End If

        Else
            Dim drAddress() As DataRow
            Dim drUpdate() As DataRow
            drUpdate = dsdata.Tables("tblAddress").Select("AddressID = " & txtAddID.Text)
            drAddress = dsdata.Tables("vwAddress").Select("AddressID = " & txtAddID.Text)

            UpdateAddressDataRow(drAddress(0))
            UpdateAddressDataRow(drUpdate(0))
            drAddress(0)("AddType") = cboAddType.Text
            drAddress(0)("State_en") = cboState.Text
            drAddress(0)("City_en") = cboCity.Text
            drAddress(0)("Area_en") = cboArea.Text
            drAddress(0)("Street_en") = cboStreet.Text
            drAddress(0).EndEdit()
            clsMr.Update(daAddress, "tblAddress")
            dsdata.Tables("vwAddress").DefaultView.AllowNew = False

        End If

        tcAddressDetail.TabPages.Remove(tpNewAddress)
    End Sub
    Private Sub UpdateAddressDataRow(ByVal pDr As DataRow)
        pDr("AddressID") = txtAddID.Text

        If cboAddType.SelectedIndex = -1 Then
            pDr("AddTypeID") = DBNull.Value
        Else
            pDr("AddTypeID") = cboAddType.SelectedValue
            'pDr("AddType") = cboAddType.Text
        End If

        If cboState.SelectedIndex = -1 Then
            pDr("StateID") = DBNull.Value
        Else
            pDr("StateID") = cboState.SelectedValue
            'pDr("State_en") = cboState.Text
        End If


        'If cboRegion.SelectedIndex = -1 Then
        '   pDr("RegionID") = DBNull.Value
        'Else
        '   pDr("RegionID") = cboRegion.SelectedValue
        '   ' pDr("Region_en") = cboState.Text
        'End If

        'If cboQadaa.SelectedIndex = -1 Then
        '   pDr("QadaaID") = DBNull.Value
        'Else
        '   pDr("QadaaID") = cboQadaa.SelectedValue
        '   ' pDr("Qadaa_en") = cboState.Text
        'End If

        If cboCity.SelectedIndex = -1 Then
            pDr("CityID") = DBNull.Value
        Else
            pDr("CityID") = cboCity.SelectedValue
            'pDr("City_en") = cboCity.Text
        End If

        If cboArea.SelectedIndex = -1 Then
            pDr("AreaID") = DBNull.Value
        Else
            pDr("AreaID") = cboArea.SelectedValue
            ' pDr("Area_en") = cboArea.Text
        End If


        If cboStreet.SelectedIndex = -1 Then
            pDr("StreetID") = DBNull.Value
        Else
            pDr("StreetID") = cboStreet.SelectedValue
            ' pDr("Street_en") = cboStreet.Text

        End If

        If txtBNF.Text <> "" Then
            pDr("BNF") = txtBNF.Text & ""
        End If
    End Sub
    'Private Sub filterRegion()
    '   If blnLoading = True Then
    '      Exit Sub
    '   End If
    '   If cboState.Text = "" Then
    '      cboState.SelectedIndex = -1
    '      dsdata.Tables("Region").DefaultView.RowFilter = String.Empty
    '   Else
    '      dsdata.Tables("Region").DefaultView.RowFilter = " StateID =" & cboState.SelectedValue
    '   End If
    'End Sub

    'Private Sub filterQadaa()
    '   If blnLoading = True Then
    '      Exit Sub
    '   End If
    '   If cboRegion.Text = "" Then
    '      cboRegion.SelectedIndex = -1
    '      dsdata.Tables("Qadaa").DefaultView.RowFilter = String.Empty
    '   Else
    '      dsdata.Tables("Qadaa").DefaultView.RowFilter = " RegionID =" & cboRegion.SelectedValue
    '   End If

    'End Sub
    Private Sub filterCity()
        If blnLoading = True Then
            Exit Sub
        End If
        'If cboQadaa.Text = "" Then
        '   cboQadaa.SelectedIndex = -1
        '   dsdata.Tables("city").DefaultView.RowFilter = String.Empty
        'Else
        '   dsdata.Tables("city").DefaultView.RowFilter = " QadaaID =" & cboQadaa.SelectedValue
        'End If
        If cboState.Text = "" Then
            cboState.SelectedIndex = -1
            dsdata.Tables("city").DefaultView.RowFilter = String.Empty
        Else
            dsdata.Tables("city").DefaultView.RowFilter = " StateID =" & cboState.SelectedValue
        End If
    End Sub
    Private Sub filterAreaANDStreet()
        If blnLoading = True Then
            Exit Sub
        End If
        If cboCity.Text = "" Then
            cboCity.SelectedIndex = -1
            dsdata.Tables("Area").DefaultView.RowFilter = String.Empty
            dsdata.Tables("Street").DefaultView.RowFilter = String.Empty
        Else
            dsdata.Tables("Area").DefaultView.RowFilter = "cityID =" & cboCity.SelectedValue
            dsdata.Tables("Street").DefaultView.RowFilter = "CityID =" & cboCity.SelectedValue
        End If

    End Sub
    Private Sub filterStreet()
        If blnLoading = True Then
            Exit Sub
        End If
        If cboArea.Text = "" Then
            cboArea.SelectedIndex = -1
            dsdata.Tables("Street").DefaultView.RowFilter = String.Empty
        Else

            dsdata.Tables("Street").DefaultView.RowFilter = " AreaID =" & cboArea.SelectedValue

        End If
    End Sub

    Private Sub cboState_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboState.Leave
        'chkAddNewValueInCbo(clsMr, Me.cboState, "tblAddressState", "StateID", "State_en")
    End Sub
    Private Sub cboAddType_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboAddType.Leave
        ' chkAddNewValueInCbo(clsMr, Me.cboAddType, "tblAddressType", "AddTypeID", "AddType")
    End Sub
    Private Sub cboState_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboState.SelectedIndexChanged
        ' filterRegion()
        filterCity()
    End Sub

    Private Sub cboRegion_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboRegion.SelectedIndexChanged
        ' filterQadaa()
    End Sub

    Private Sub CboQadaa_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboQadaa.SelectedIndexChanged
        ' filterCity()
    End Sub

    Private Sub cboCity_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCity.Leave

        chkAddNewValueInCbo1(clsMr, Me.cboCity, Me.cboState, "tblAddCity", "CityID", "City_en", "StateID")
    End Sub

    Private Sub cboCity_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCity.SelectedIndexChanged
        ' filterArea()
        filterAreaANDStreet()
    End Sub

    Private Sub CboArea_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboArea.SelectedIndexChanged
        filterStreet()

    End Sub

    Private Sub EditAddress()
        If grdViewAddress.Rows.Count = 0 Then
            Exit Sub
        End If
        'ItemInfoStatus(False)
        If Not tcAddressDetail.TabPages.Contains(tpNewAddress) Then
            tcAddressDetail.TabPages.Add(tpNewAddress)
            tpNewAddress.Text = "Edit Address"
        End If
        ' tcAddress.SelectedIndex = 1
        tcAddressDetail.SelectedTab = tpNewAddress
        Dim drAddress As DataView
        drAddress = dsdata.Tables("vwAddress").DefaultView

        txtAddID.Text = drAddress(grdViewAddress.CurrentRow.Index)("AddressID") & ""
        If Not (drAddress(grdViewAddress.CurrentRow.Index)("AddTypeID") Is DBNull.Value) Then
            cboAddType.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("AddTypeID") & ""
        Else
            cboAddType.SelectedValue = DBNull.Value
            cboAddType.SelectedIndex = -1
        End If

        If Not (drAddress(grdViewAddress.CurrentRow.Index)("StateID") Is DBNull.Value) Then
            cboState.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("StateID") & ""
        Else
            cboState.SelectedValue = DBNull.Value
            cboState.SelectedIndex = -1
        End If
        'If Not (drAddress(grdViewAddress.CurrentRow.Index)("RegionID") Is DBNull.Value) Then
        '   cboRegion.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("RegionID") & ""
        'Else
        '   cboRegion.SelectedValue = DBNull.Value
        '   cboRegion.SelectedIndex = -1
        'End If
        'If Not (drAddress(grdViewAddress.CurrentRow.Index)("QadaaID") Is DBNull.Value) Then
        '   cboQadaa.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("QadaaID") & ""
        'Else
        '   cboQadaa.SelectedValue = DBNull.Value
        '   cboQadaa.SelectedIndex = -1
        'End If
        If Not (drAddress(grdViewAddress.CurrentRow.Index)("CityID") Is DBNull.Value) Then
            cboCity.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("CityID")
        Else
            cboCity.SelectedValue = DBNull.Value
            cboCity.SelectedIndex = -1
        End If
        If Not (drAddress(grdViewAddress.CurrentRow.Index)("AreaID") Is DBNull.Value) Then
            cboArea.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("AreaID")
        Else
            cboArea.SelectedValue = DBNull.Value
            cboArea.SelectedIndex = -1
        End If

        If Not (drAddress(grdViewAddress.CurrentRow.Index)("StreetID") Is DBNull.Value) Then
            cboStreet.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("StreetID")
        Else
            cboStreet.SelectedValue = DBNull.Value
            cboStreet.SelectedIndex = -1
        End If
        If Not (drAddress(grdViewAddress.CurrentRow.Index)("BNF") Is DBNull.Value) Then
            txtBNF.Text = drAddress(grdViewAddress.CurrentRow.Index)("BNF")
        End If
    End Sub


    Private Sub btnDeleteAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteAddress.Click

        If grdViewAddress.Rows.Count = -1 Then Exit Sub

        Dim drAddress As DataView
        drAddress = dsdata.Tables("vwAddress").DefaultView

        If MsgBox(" Are you sure you want to Delete? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution") = MsgBoxResult.Yes Then

            Dim drDel() As DataRow
            drDel = dsdata.Tables("tblAddress").Select("AddressID = " & drAddress(grdViewAddress.CurrentRow.Index)("AddressID"))
            If drDel.Length > 0 Then
                drDel(0).Delete()
                Nav.EndCurrentEdit()
                clsMr.Update(daAddress, "tblAddress")
            End If

            dsdata.Tables("vwAddress").DefaultView(grdViewAddress.CurrentRow.Index).Delete()

            If grdViewAddress.Rows.Count = 0 Then
                btnDeleteAddress.Enabled = False
            End If
        End If


    End Sub

    Private Sub btnNewAddress2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewAddress2.Click
        NewAddress()
    End Sub

    Private Sub btnSaveAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveAddress.Click
        SaveAddress()

    End Sub

    Private Sub btnCancelAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAddress.Click
        tcAddressDetail.TabPages.Remove(tpNewAddress)
        'tcAddress.SelectedIndex = 1
        tcAddressDetail.SelectedTab = tpViewAddress
        ' ItemInfoStatus(True)
        btnNewAddress.Enabled = True
        btnNewAddress.Enabled = True
        btnSaveAddress.Enabled = True
        'If changed = False Then
        ' dataChange = False
        'btnEdit.Enabled = False
        'End If
        'dataChangedVeh = False
    End Sub

    Private Sub cboStreet_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboStreet.Leave
        If cboArea.Text = "" And cboCity.Text = "" Then Exit Sub
        AddStreet()
    End Sub

#End Region

    '#Region "Ledger..."

    '    'Private Sub btnLedger_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLedger.Click
    '    '    If cboLedger.SelectedIndex <> -1 Then
    '    '        frmLedger = New frmLedger(cboLedger.Text)

    '    '        frmLedger.ShowDialog()
    '    '    End If
    '    '    If frmLedger.transferAccount <> 0 Then
    '    '        cboLedger.Text = frmLedger.transferAccount
    '    '    End If
    '    '    cboLedger.Focus()

    '    'End Sub

    '    'Private Sub Transfer(ByVal sender As Object, ByVal e As System.EventArgs)
    '    '    If frmLedger.transferAccount <> 0 Then
    '    '        cboLedger.Text = frmLedger.transferAccount
    '    '    End If
    '    '    cboLedger.Focus()
    '    'End Sub


    '    'Private Sub cboLedger_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboLedger.Leave
    '    '    If blnLoading = True Then Exit Sub
    '    '    Dim Accountvalue As Integer
    '    '    If cboLedger.Text <> "" Then
    '    '        Accountvalue = cboLedger.FindStringExact(cboLedger.Text)
    '    '        If Accountvalue = -1 Then
    '    '            MsgBox("Account Ledger Number is not found, please try again or use Advanced search...", MsgBoxStyle.Information, "Warning")
    '    '            cboLedger.Focus()
    '    '            cboLedger.SelectAll()

    '    '        Else
    '    '            cboLedger.SelectedIndex = Accountvalue
    '    '            '' update Ledger Name Text...
    '    '            updateLedgerName()
    '    '        End If
    '    '    End If
    '    '    If cboLedger.SelectedIndex = -1 Then Exit Sub
    '    '    Dim lngMax As Long
    '    '    If blnLoading = True Then Exit Sub
    '    '    'If blnLedgerChg = True Then Exit Sub
    '    '    If AcctTypeID = 7 Then
    '    '        lngMax = clsMr.GetMaxNumber("select max(AcctNumber) from tblAccount where branchid=" & gIntBranchID & "  And AcctTypeID = " & AcctTypeID & "  And AccountLedgerID= " & cboLedger.SelectedValue) + 1


    '    '        clsMr.SetAutoNumber(mStrTableName, "AcctNumber", lngMax)
    '    '        txtClientNum.Text = lngMax
    '    '    Else
    '    '        lngMax = clsMr.GetMaxNumber("select max(AcctNumber) from tblAccount where branchid=" & gIntBranchID & "  And AcctTypeID = " & AcctTypeID) + 1

    '    '        clsMr.SetAutoNumber(mStrTableName, "AcctNumber", lngMax)
    '    '    End If
    '    'End Sub

    '    Public Sub updateLedgerName()
    '        '
    '        If cboLedger.Text <> "" Then
    '            Dim dr As DataRowView
    '            dr = cboLedger.SelectedItem
    '            ''
    '            If Not dr Is Nothing Then
    '                txtLedgerName.Text = dr("Name_en") & ""
    '            End If
    '        End If
    '    End Sub

    '#End Region

#Region "GridsSetUP..."

    Private Sub DrawGrid()

        grdViewAddress.DataSource = dsdata.Tables("vwAddress").DefaultView
        LoadProfile(mStrSubKeyName, Me.grdViewAddress)
        dsdata.Tables("vwAddress").DefaultView.AllowNew = False
        grdViewAddress.ReadOnly = True
        grdViewAddress.Columns("AddType").HeaderText = "Type"
        grdViewAddress.ColumnHeadersHeight = btnShowCol.Size.Height + 2
        grdViewAddress.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        ''change column header
        'If gStrLang = "en" Then
        grdViewAddress.Columns("State_en").HeaderText = "State"
        ' grdViewAddress.Columns("Region_en").HeaderText = "Region"
        ' grdViewAddress.Columns("Qadaa_en").HeaderText = "Qadaa"
        grdViewAddress.Columns("Street_en").HeaderText = "Street"
        grdViewAddress.Columns("Area_en").HeaderText = "Area"
        grdViewAddress.Columns("City_en").HeaderText = "City"
        'Else
        'grdViewAddress.Columns("State_ar").HeaderText = "�����"
        ''grdViewAddress.Columns("Region_ar").HeaderText = ""
        '' grdViewAddress.Columns("Qadaa_ar").HeaderText = "������"
        'grdViewAddress.Columns("Street_ar").HeaderText = "������"
        'grdViewAddress.Columns("Area_ar").HeaderText = "�������"
        'grdViewAddress.Columns("City_ar").HeaderText = "�������"
        'End If
        AddressNotVisibleFields()
        ''
        With grdClientItem
            .DataSource = dsdata.Tables("vwClientItem").DefaultView
        End With

    End Sub

    Private Function chkAddNewValueInCbo1(ByRef pclsMr As BITSConn.ClsMain, ByRef pcboX As ComboBox, ByRef pcbo2 As ComboBox, ByVal psTblName As String, _
                             ByVal psIDFieldName As String, ByVal psValFieldName As String, ByVal psIDFieldName2 As String, Optional ByVal psIDFieldName3 As String = "") As Boolean
        ''
        If pcboX.Text = "" Then
            Return False
        End If
        ''
        If pcbo2.Text = "" Then
            MsgBox("Cannot Add " & psValFieldName & "! You have to choose  " & psIDFieldName2 & "first.")
            pcboX.SelectedIndex = -1
            pcboX.Text = ""
            Exit Function
        End If
        If pcboX.FindStringExact(pcboX.Text) = -1 Then
            ''
            '' value not found; ?ask user to add it?
            If MsgBox("[" & pcboX.Text & "] could not be found. Do you want to ADD it to the list!", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                pcboX.SelectedIndex = -1
                pcboX.Text = ""
            Else
                ''
                '' insert new value into tbl and reflect chages in form...
                ''
                Dim lngNextRecID As Long
                Dim strNewVal As String

                '' Get Next RecID...
                lngNextRecID = pclsMr.GetMaxNumber(psIDFieldName, psTblName) + 1
                strNewVal = pcboX.Text

                '' set Insert stmt...
                'If psIDFieldName3 = "" Then
                StrSql = "INSERT INTO " & psTblName & " (" & psIDFieldName & ", " & psValFieldName & ", Del ," & psIDFieldName2 & ") "
                StrSql &= " VALUES (" & lngNextRecID & ", '" & pcboX.Text & "',0, " & pcbo2.SelectedValue & " )"

                ' End If



                ''
                '' Insert new values into given table...
                Dim cmdSql As New SqlClient.SqlCommand(StrSql, conSql)
                conSql.Open()
                cmdSql.ExecuteNonQuery()
                conSql.Close()
                ''
                '' Insert new row into dataView...
                ''
                Dim dv As DataView
                Dim drv As DataRowView

                dv = pcboX.DataSource

                '' add it...
                drv = dv.AddNew()
                ''
                drv(psIDFieldName) = lngNextRecID
                drv(psValFieldName) = strNewVal
                drv(psIDFieldName2) = pcbo2.SelectedValue
                drv.EndEdit()

                '' set focus to new element in cbo..
                pcboX.SelectedValue = lngNextRecID

                Return True

            End If

        End If
        ''
        Return False

    End Function

    Private Sub AddStreet()

        Dim drs As DataRow() = dsdata.Tables("Street").Select("Street_en = '" & cboStreet.Text & "'")
        If drs.Length = 0 Then
            MsgBox("Do you want To Add This Street", MsgBoxStyle.YesNo)

            If Windows.Forms.DialogResult.Yes Then
                Dim dr As DataRow = dsdata.Tables("Street").NewRow
                dr("StreetID") = clsMr.GetMaxNumber("StreetID", "tblAddStreet") + 1
                dr("Street_en") = cboStreet.Text
                If cboCity.SelectedValue Is Nothing Then
                    dr("CityID") = DBNull.Value
                Else
                    dr("CityID") = cboCity.SelectedValue
                End If

                If cboArea.SelectedValue Is Nothing Then
                    dr("AreaID") = DBNull.Value
                Else
                    dr("AreaID") = cboArea.SelectedValue
                End If
                dr("Del") = 0
                dsdata.Tables("Street").Rows.Add(dr)
                daStreet.Update(dsdata, "Street")
                cboStreet.SelectedValue = dr("StreetID")


            Else
                cboStreet.Text = String.Empty
                cboStreet.SelectedIndex = -1
            End If

        Else : Exit Sub

        End If
    End Sub

    Private Sub AddressNotVisibleFields()
        With grdViewAddress

            .Columns("AddressID").Visible = False
            .Columns("AddTypeID").Visible = False
            .Columns("StreetID").Visible = False
            .Columns("Del").Visible = False
            .Columns("AreaID").Visible = False
            .Columns("RegionId").Visible = False
            .Columns("QadaID").Visible = False
            .Columns("ClientID").Visible = False
            .Columns("CityID").Visible = False
            .Columns("StateID").Visible = False
            ''
            If gStrLang = "en" Then
                .Columns("Street_ar").Visible = False
                .Columns("State_ar").Visible = False
                .Columns("Area_ar").Visible = False
                .Columns("City_ar").Visible = False
            Else
                .Columns("Street_en").Visible = False
                .Columns("State_en").Visible = False
                .Columns("Area_en").Visible = False
                .Columns("City_en").Visible = False
            End If
        End With
        ''
    End Sub

    Private Sub RemoveAddressIds()
        Me.chkLstGridCol.Items.Remove("AcctID")
        Me.chkLstGridCol.Items.Remove("AddTypeID")
        Me.chkLstGridCol.Items.Remove("QadaID")
        Me.chkLstGridCol.Items.Remove("RegionId")
        Me.chkLstGridCol.Items.Remove("AreaID")
        Me.chkLstGridCol.Items.Remove("StateID")
        Me.chkLstGridCol.Items.Remove("CityID")
        Me.chkLstGridCol.Items.Remove("Del")
        Me.chkLstGridCol.Items.Remove("StreetID")
        Me.chkLstGridCol.Items.Remove("AddressID")
    End Sub

#End Region

#Region "Grid-SaveSettings"

    Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()
            mstrCurrentGridName = "Address"
            ''
            '' populate list with grid's dataSource fields...
            ''

            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdViewAddress.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next

        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If
        RemoveAddressIds()
    End Sub

    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
        ''
        Dim i As Integer
        For i = 0 To Me.chkLstGridCol.Items.Count - 1
            grdViewAddress.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
        Next

        ''
        Me.grpShowHideColumns.Visible = False
        RemoveAddressIds()
    End Sub

    Private Sub frmAccountNew_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Closed
        SaveProfile(mStrSubKeyName, Me.grdViewAddress)
    End Sub

#End Region

    Private Function isAcctHasTrx() As Boolean
        ''
        Dim cmdSelect As New SqlClient.SqlCommand("SELECT AcctID FROM tblTransaction WHERE AcctID = " & txtClientID.Text, conSql)
        Dim dRdr As SqlClient.SqlDataReader
        ''
        cmdSelect.CommandType = CommandType.Text
        ''
        Try
            conSql.Open()
            dRdr = cmdSelect.ExecuteReader()
            If Not (dRdr.HasRows) Then
                '' 
                dRdr.Close()
                conSql.Close()
                Return False
                ''
            Else
                ''
                conSql.Close()
                Return True
            End If
            ''
        Catch ex As Exception
            conSql.Close()
        End Try
    End Function

    Private Sub btnDeletePerminantly_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeletePerminantly.Click
        Delete(1)
    End Sub

    Private Sub btnDeleteTemp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteTemp.Click
        Delete(2)
    End Sub

    Private Sub btnCancelDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelDelete.Click
        ''
        Delete(3)
    End Sub

    Private Sub Delete(ByVal pDeleteState As Integer)
        ''
        Select Case pDeleteState
            Case 1
                ''delete details
                Dim cmd As New SqlClient.SqlCommand
                Try
                    cmd.CommandText = "Delete From tblAccount WHERE AcctID=" & txtClientID.Text
                    cmd.Connection = conSql
                    conSql.Open()
                    cmd.ExecuteNonQuery()
                    conSql.Close()
                Catch ex As Exception
                    conSql.Close()
                End Try
                ''
                ' dsdata.Tables("tblAccount").DefaultView(lstAccount.SelectedIndex).Delete()
                dsdata.Tables(mStrTableName).Rows.Remove(dsdata.Tables(mStrTableName).DefaultView(Nav.CurrentPosition).Row)
                FilterAddress()

            Case 2
                ''
                Try
                    ''update tbl Voucher
                    Dim cmd As New SqlClient.SqlCommand("UPDATE tblAccount SET Del=1 WHERE AcctID= " & txtClientID.Text, conSql)
                    conSql.Open()
                    cmd.ExecuteNonQuery()
                    conSql.Close()
                Catch ex As Exception
                    conSql.Close()
                End Try
                ''
                dsdata.Tables("tblAccount").DefaultView(lstClient.SelectedIndex).Delete()
                FilterAddress()
                ''
            Case 3
                ''
        End Select
        ''
        grpDeleteOptions.Visible = False
        grpDeleteOptions.BringToFront()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        ''
        If lstClient.Items.Count = 0 Then
            MsgBox("There is no Account to Delete")
            Exit Sub
        End If
        ''
        'If isAcctHasTrx() = False Then
        '    grpDeleteOptions.Visible = True
        '    grpDeleteOptions.BringToFront()
        'Else
        '    MsgBox("Can not delete Account with related Transactions ")
        'End If
    End Sub

    'Private Sub txtAccountName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtClientName.TextChanged
    '    If blnLoading = True Then Exit Sub
    '    If txtClientName.Text = "" Then Exit Sub
    '    Dim drClientName As DataRow()
   '    'drClientName = dsdata.Tables(mStrTableName).Select("ClientName= '" & txtClientName.Text & "' AND AcctTypeID= " & AcctTypeID & " AND not AcctID= " & txtClientID.Text & "")
    '    drClientName = dsdata.Tables(mStrTableName).Select("ClientName= '" & txtClientName.Text & "")
    '    If drClientName.Length > 0 Then
    '        MsgBox("The enterded Client name is already found.")
    '    End If
    'End Sub

#Region "Permissions.."
    ''Done by Mohamad March, 2008''

    'Contact Name'
    Private Sub txtContactName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtContactName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtClientName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Telephone
    Private Sub txtTel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtTel.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Extension'
    Private Sub txtExt_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtExt.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Cell Phone'
    Private Sub txtCel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCel.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Fax'
    Private Sub txtFax_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFax.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Website'
    Private Sub txtWWW_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtWWW.Leave
        Dim Pattern As String = "^[w][\w\.-]*[w]\.[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim EmailAddressMatch As Match = Regex.Match(txtWWW.Text, Pattern)

        If EmailAddressMatch.Success = True Then
            'Do Nothing
        Else
            MsgBox("Invalid Website Name")
            txtWWW.Text = ""
        End If
    End Sub

    'Email'
    Private Sub txtEMail_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEMail.Leave
        Dim Pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim EmailAddressMatch As Match = Regex.Match(txtEMail.Text, Pattern)

        If EmailAddressMatch.Success = True Then
            'Do Nothing
        Else
            MsgBox("Invalid Email Address")
            txtEMail.Text = ""
        End If
    End Sub

#End Region

End Class