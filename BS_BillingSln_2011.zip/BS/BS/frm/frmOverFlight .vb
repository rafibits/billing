Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmOverFlight


#Region " Form Declaration  .  .  . "
	''
	Dim clsMr As ClsMain
	Dim dsData As New DataSet
	Dim daOverFlight As New SqlDataAdapter
	Private WithEvents Nav As BitsNav
	Dim blnLoading As Boolean = True
	Dim blnCountMdf As Boolean = False
	''
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\NewOverFlight\Settings"
	Private mStrSubKeyName2 As String = "Software\BIT Solutions\BS\ModifiedOverFlight\Settings"
	Private mstrCurrentGridName As String
	''
#End Region


#Region " Form Initialization . . . "

	Private Sub frmOverFlight_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		''
		SaveProfile(mStrSubKeyName, grdNewOverFlight)
		SaveProfile(mStrSubKeyName2, grdModifiedOverFlight)
    End Sub

    Private Sub frmOverFlight_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

	Private Sub frmOverFlight_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		''
		clsMr = New ClsMain(conSql)
		Nav = New BitsNav
		''
		blnLoading = True
		''
		MakeDataAdapter()
		SetAutoNumber()
		SetCurrency()
		DrawGrid()
		ChangeColor()
		''
		btnDelete.Enabled = False
		btnCopyData.Enabled = True
		btnUpdateTransactions.Enabled = False
        blnLoading = False
        ''
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

	Private Sub MakeDataAdapter()
		''
		clsMr.BuildSqlAdapter("SELECT OvFl_date, OvFl_time, Reg_serial, Co_Code, Ap_orig, Ap_dest, modificationDate, Trip_no, Aircraft_type, Ovfl_ID,Aircraft_weight FROM OverFlight", "OverFlight")
		daOverFlight = clsMr.BuildSqlAdapter("SELECT OverFlightID,OvFl_date, OvFl_time, Reg_serial, Co_Code, Ap_orig, Ap_dest, modificationDate, Trip_no, Aircraft_type, Ovfl_ID,Aircraft_weight FROM tblOverFlight", "tblOverFlight")
		clsMr.BuildSqlAdapter("SELECT Ovfl_ID, Aircraft_type, Trip_no, modificationDate, Ap_dest, Ap_orig, Co_Code, Reg_serial, OvFl_time, OvFl_date, OverFlightID,Aircraft_weight FROM vwNewOverFlight", "vwNewOverFlight")
		clsMr.BuildSqlAdapter("SELECT  Ovfl_ID, Aircraft_type, Trip_no, modificationDate, Ap_dest, Ap_orig, Co_Code, Reg_serial, OvFl_time, OvFl_date,Aircraft_weight,OverFlightID FROM tblOverFlight WHERE(Ovfl_ID IN(SELECT [Ovfl_ID] FROM [OverFlight]))", "ModifiedOverFlight")
		''
		dsData = clsMr.getDataSet
	End Sub

	Private Sub DrawGrid()
		''
		dsData.Tables("vwNewOverFlight").DefaultView.AllowNew = False
		dsData.Tables("ModifiedOverFlight").DefaultView.AllowNew = False
		''
		With grdNewOverFlight
			''
			.AllowUserToDeleteRows = False
			.DataSource = dsData.Tables("vwNewOverFlight").DefaultView
			.ReadOnly = True
			''
			'.Columns("ClientID").Visible = False
			'.Columns("InvoiceID").Visible = False
			.Columns("OverFlightID").Visible = False
			'.Columns("Ovfl_ID").Visible = False
			.ColumnHeadersHeight = btnShowCol.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		End With
		''
		RemoveGrdListItems()
		LoadProfile(mStrSubKeyName, grdNewOverFlight)
		''
		With grdModifiedOverFlight
			''
			.DataSource = dsData.Tables("ModifiedOverFlight").DefaultView
			.AllowUserToDeleteRows = False
			.Columns("OverFlightID").Visible = False
			''
			.Columns("Ovfl_ID").ReadOnly = True
			'.Columns("Aircraft_type").ReadOnly = True
			'.Columns("Trip_no").ReadOnly = True
			.Columns("modificationDate").ReadOnly = True
			.Columns("Ap_dest").ReadOnly = True
			.Columns("Ap_orig").ReadOnly = True
			.Columns("Co_Code").ReadOnly = True
			'.Columns("Reg_serial").ReadOnly = True
			.Columns("OvFl_time").ReadOnly = True
			.Columns("OvFl_date").ReadOnly = True
			'.Columns("OverFlightID").ReadOnly = True
			'.Columns("reg_weight").ReadOnly = True
			''
			.ColumnHeadersHeight = btnShowCol.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
			.Columns("Ovfl_ID").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			.Columns("modificationDate").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			.Columns("Ap_dest").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			.Columns("Ap_orig").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			.Columns("Co_Code").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			'.Columns("Reg_serial").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			.Columns("OvFl_time").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			.Columns("OvFl_date").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			'.Columns("light_orig").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			'.Columns("gate").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			''.Columns("reg_weight").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			'.Columns("time_dest").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
			''
		End With
		''
		LoadProfile(mStrSubKeyName2, grdModifiedOverFlight)
		''
		'
		AddHandler dsData.Tables("ModifiedOverFlight").ColumnChanged, AddressOf Column_Changed
	End Sub

	Private Sub SetAutoNumber()
		''
		Dim lngMax As Long
		lngMax = clsMr.GetMaxNumber("SELECT MAX(OverFlightID) FROM tblOverFlight ") + 1
		clsMr.SetAutoNumber("tblOverFlight", "OverFlightID", lngMax)
		''
		'Dim lngMaxPar As Long
		'lngMaxPar = clsMr.GetMaxNumber("SELECT MAX(TransactionParkingID) FROM tblTransactionParking ") + 1
		'clsMr.SetAutoNumber("tblTransactionParking", "TransactionParkingID", lngMaxPar)
	End Sub

	Private Sub setDefaultValue()
		''
		'clsMr.SetDefaults("tblTransactionParking", "CreateByID", gIntUserID, "CreateDate", Now.Date, "Del", 0)
	End Sub

	Public Sub SetCurrency()
		''
		Nav.SetCurrency(Me, dsData, "tblOverFlight")
	End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

    End Sub

#End Region


#Region " Form Functions   .   .   ."

	Private Sub ChangeColor()
		''
		'change color for Modified Transactions ..........
		''
		Dim i As Integer
		If grdNewOverFlight.Rows.Count <> 0 Then
			For i = 0 To dsData.Tables("vwNewOverFlight").DefaultView.Count - 1
				Dim Seq As Integer
				Try
					Dim cmd As New SqlClient.SqlCommand("SELECT Ovfl_ID FROM tblOverFlight WHERE Ovfl_ID=" & dsData.Tables("vwNewOverFlight").DefaultView.Item(i)("Ovfl_ID"), conSql)

					conSql.Open()
					Seq = cmd.ExecuteScalar
					conSql.Close()
					If Seq <> 0 Then
						grdNewOverFlight.Rows(i).DefaultCellStyle.BackColor = Color.LightSteelBlue
					End If
				Catch ex As Exception
					conSql.Close()
				End Try
			Next
		End If
	End Sub

	Private Sub RemoveGrdListItems()
		''
		'chkLstGridCol.Items.Remove("ClientID")
		'chkLstGridCol.Items.Remove("InvoiceID")
		chkLstGridCol.Items.Remove("OverFlightID")
		'chkLstGridCol.Items.Remove("Ovfl_ID")
	End Sub

	Private Sub Column_Changed(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
		''
		If blnLoading Then Exit Sub
		''
		If grdModifiedOverFlight.Rows.Count = 0 Then Exit Sub
		''
		If (grdModifiedOverFlight.CurrentRow) Is Nothing Then
			Exit Sub
		End If
		''
		If e.Column.ColumnName = "Aircraft_type" Or e.Column.ColumnName = "Trip_no" Or e.Column.ColumnName = "Aircraft_weight" Or e.Column.ColumnName = "Reg_serial" Then
			btnSave.Enabled = True
		End If
	End Sub

	Private Sub filterGrid()
		''
		If blnLoading Then Exit Sub
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor

		If rdbAllTransactions.Checked = True Then
			dsData.Tables("vwNewOverFlight").DefaultView.RowFilter = ""
		ElseIf rdbNewTransactions.Checked = True Then
			dsData.Tables("vwNewOverFlight").DefaultView.RowFilter = "OverFlightID IS  NULL"
		Else
			dsData.Tables("vwNewOverFlight").DefaultView.RowFilter = "OverFlightID IS NOT NULL"
		End If
		''
		ChangeColor()
		Windows.Forms.Cursor.Current = Cursors.Default
	End Sub

	Private Sub RefreshGrids()
		''
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''Refresh Grid grdNewtransactions
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		dsData.Tables("vwNewOverFlight").Rows.Clear()
		clsMr.BuildSqlAdapter("SELECT Ovfl_ID, Aircraft_type, Aircraft_weight, Trip_no, modificationDate, Ap_dest, Ap_orig, Co_Code, Reg_serial, OvFl_time, OvFl_date, OverFlightID FROM vwNewOverFlight", "vwNewOverFlight")
		''
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''Refresh Grid  grdModifiedtransactions
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		dsData.Tables("ModifiedOverFlight").Rows.Clear()
		clsMr.BuildSqlAdapter("SELECT OverFlightID, ClientID, InvoiceID, Reg_serial, OvFl_date, OvFl_time, Co_Code, Ap_orig, Ap_dest, modificationDate, TotalOverFlight, Trip_no, Aircraft_type, Aircraft_weight, Ovfl_ID FROM tblOverFlight WHERE(Ovfl_ID IN(SELECT [Ovfl_ID] FROM [OverFlight]))", "ModifiedOverFlight")
		''
		ChangeColor()
	End Sub

	Private Sub updateClient()
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		Try
			Dim cmd As New SqlCommand("Update tblOverFlight set ClientID = tblClient.ClientID FROM tblClient INNER JOIN tblOverFlight ON tblOverFlight.Co_Code = tblClient.ICAO WHERE tblOverFlight.InvoiceID is Null", conSql)

			conSql.Open()
			cmd.ExecuteNonQuery()
			conSql.Close()

		Catch ex As Exception
			Windows.Forms.Cursor.Current = Cursors.Default()
			conSql.Close()
		End Try
		filterGrid()
		Windows.Forms.Cursor.Current = Cursors.Default()
	End Sub

	Private Sub DeleteTransactionsOvfl()
		'
		Try
			Dim cmd As New SqlClient.SqlCommand("DELETE FROM [OverFlight]", conSql)
			conSql.Open()
			cmd.ExecuteNonQuery()
			conSql.Close()
			RefreshGrids()
		Catch ex As Exception
			conSql.Close()
		End Try
	End Sub

	Private Sub ChekModified()
		''
		If dsData.Tables("ModifiedOverFlight").Rows.Count <> 0 Then
			btnDelete.Enabled = True
		Else
			btnDelete.Enabled = False
		End If
	End Sub

	Private Function CopyNewOverFlightIntoOverFlight() As Boolean
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' RUN spInsertOverFlightFromCommonDB
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		Dim command As New SqlClient.SqlCommand
		command.CommandText = "spInsertOverFlightFromCommonDB"
		Try
			command.Connection = conSql
			command.CommandType = CommandType.StoredProcedure
			conSql.Open()
			command.ExecuteNonQuery()
			conSql.Close()
		Catch ex As Exception
			conSql.Close()
		End Try
	End Function

	Private Function InsertIntotblOverFlight() As Boolean
		''
		dsData.Tables("OverFlight").Rows.Clear()
		clsMr.BuildSqlAdapter("SELECT OvFl_date, OvFl_time, Reg_serial, Co_Code, Ap_orig, Ap_dest, modificationDate, Trip_no, Aircraft_type, Aircraft_weight, Ovfl_ID FROM OverFlight", "OverFlight")
		''
		Dim dvOverFlight As DataView = dsData.Tables("OverFlight").DefaultView
		Dim drtblOverFlight As DataRow
		Dim drOverFlight As DataRowView
		''
		For Each drOverFlight In dvOverFlight
			drtblOverFlight = dsData.Tables("tblOverFlight").NewRow
			drtblOverFlight("Reg_serial") = drOverFlight("Reg_serial")
			drtblOverFlight("OvFl_date") = drOverFlight("OvFl_date")
			drtblOverFlight("OvFl_time") = drOverFlight("OvFl_time")
			drtblOverFlight("Co_Code") = drOverFlight("Co_Code")
			drtblOverFlight("Ap_orig") = drOverFlight("Ap_orig")
			drtblOverFlight("Ap_dest") = drOverFlight("Ap_dest")
			drtblOverFlight("Trip_no") = drOverFlight("Trip_no")
			drtblOverFlight("Aircraft_type") = drOverFlight("Aircraft_type")
			drtblOverFlight("Ovfl_ID") = drOverFlight("Ovfl_ID")
			drtblOverFlight("Aircraft_weight") = drOverFlight("Aircraft_weight")

			''
			drtblOverFlight("modificationDate") = drOverFlight("modificationDate")
			dsData.Tables("tblOverFlight").Rows.Add(drtblOverFlight)
		Next
		''
		daOverFlight.Update(dsData, "tblOverFlight")

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

	End Function

	Private Function CopyOvflIntotblOvfl() As Boolean
		''
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'---------------- COPY Data - INTO BitsMArt - FROM OverFlight TO tblOverFlight --------------------------
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''
		Dim dvOverFlight As DataView = dsData.Tables("vwNewOverFlight").DefaultView
		Dim drtblOverFlight As DataRow
		Dim drOverFlight As DataRowView

		''	
		For Each drOverFlight In dvOverFlight
			drtblOverFlight = dsData.Tables("tblOverFlight").NewRow
			''
			drtblOverFlight("Ovfl_ID") = drOverFlight("Ovfl_ID")
			drtblOverFlight("Aircraft_type") = drOverFlight("Aircraft_type")
			drtblOverFlight("Trip_no") = drOverFlight("Trip_no")
			drtblOverFlight("modificationDate") = drOverFlight("modificationDate")
			drtblOverFlight("Ap_dest") = drOverFlight("Ap_dest")
			drtblOverFlight("Ap_orig") = drOverFlight("Ap_orig")
			drtblOverFlight("Co_Code") = drOverFlight("Co_Code")
			drtblOverFlight("Reg_serial") = drOverFlight("Reg_serial")
			drtblOverFlight("OvFl_time") = drOverFlight("OvFl_time")
			drtblOverFlight("OvFl_date") = drOverFlight("OvFl_date")
			drtblOverFlight("Aircraft_weight") = drOverFlight("Aircraft_weight")
			''
			Dim OvflID As Integer
			Try
				Dim cmd As New SqlClient.SqlCommand("SELECT Ovfl_ID FROM tblOverFlight WHERE Ovfl_ID=" & drOverFlight("Ovfl_ID"), conSql)
				conSql.Open()
				OvflID = cmd.ExecuteScalar()
				conSql.Close()
			Catch ex As Exception
				conSql.Close()
			End Try
			If OvflID = 0 Then
				dsData.Tables("tblOverFlight").Rows.Add(drtblOverFlight)
				Try
					Dim cmd As New SqlClient.SqlCommand("DELETE FROM [OverFlight] where Ovfl_ID =" & drOverFlight("Ovfl_ID"), conSql)
					conSql.Open()
					cmd.ExecuteNonQuery()
					conSql.Close()
				Catch ex As Exception
					conSql.Close()
				End Try
			End If
		Next
		daOverFlight.Update(dsData, "tblOverFlight")
		''
	End Function

#End Region


#Region "UI-Events . . . . . . . .  "

	Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
		''
		If Me.grpShowHideColumns.Visible = False Then
			Me.grpShowHideColumns.Visible = True
			Me.grpShowHideColumns.BringToFront()
			mstrCurrentGridName = "ImportOverFlight"
			''
			'' populate list with grid's dataSource fields...
			''
			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridCol.Items.Clear()
			For Each col In grdNewOverFlight.Columns
				Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
			Next
			RemoveGrdListItems()
		Else
			Me.grpShowHideColumns.Visible = False
			Me.grpShowHideColumns.SendToBack()
		End If
		''
	End Sub

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		''
		Me.Close()
	End Sub

	Private Sub btnGrdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGrdClose.Click
		''
		pnlModified.Visible = False
		Me.grdNewOverFlight.Height += 114
	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		Dim intCounter As Integer
		''
		Dim drUpdate() As DataRow
        Dim dt As New DataTable
        ''
        dt = dsData.Tables("ModifiedOverFlight").GetChanges(DataRowState.Modified)
        'dt.Rows.Clear()

		If Not (dt Is Nothing) Then
			''
            For intCounter = 0 To dt.Rows.Count - 1
                drUpdate = dsData.Tables("tblOverFlight").Select("OverFlightID=" & grdModifiedOverFlight.Item("OverFlightID", 0).Value)
                drUpdate(0).BeginEdit()
                drUpdate(0)("Trip_no") = dt.Rows(intCounter)("Trip_no")
                drUpdate(0)("Aircraft_type") = dt.Rows(intCounter)("Aircraft_type")
                drUpdate(0)("Aircraft_weight") = dt.Rows(intCounter)("Aircraft_weight")
                drUpdate(0)("Reg_serial") = dt.Rows(intCounter)("Reg_serial")
                ''
                drUpdate(0).EndEdit()
            Next
            ''
        End If
		''
		dt = dsData.Tables("tblOverFlight").GetChanges
		''
		If Not (dt Is Nothing) Then
			daOverFlight.Update(dt)
			dsData.Tables("tblOverFlight").AcceptChanges()
		End If
        ''
        dsData.Tables("ModifiedOverFlight").Rows.Clear()
        clsMr.BuildSqlAdapter("SELECT  Ovfl_ID, Aircraft_type, Trip_no, modificationDate, Ap_dest, Ap_orig, Co_Code, Reg_serial, OvFl_time, OvFl_date,Aircraft_weight,OverFlightID FROM tblOverFlight WHERE(Ovfl_ID IN(SELECT [Ovfl_ID] FROM [OverFlight]))", "ModifiedOverFlight")
        btnSave.Enabled = False
        Windows.Forms.Cursor.Current = Cursors.Default()

	End Sub

	Private Sub btnCopyData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyData.Click
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		''
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' COPY Data FROM OverFlight in CommonDB TO OverFlight IN Billing...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		CopyNewOverFlightIntoOverFlight()
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		' '' COPY Data - INTO Billing - FROM OverFlight TO tblOverFlight...
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'InsertIntotblOverFlight()
		' ''
		'Try
		'	Dim cmd As New SqlClient.SqlCommand("DELETE FROM [OverFlight]", conSql)
		'	conSql.Open()
		'	cmd.ExecuteNonQuery()
		'	conSql.Close()
		'Catch ex As Exception
		'	conSql.Close()
		'End Try
		''
		'updateClient()
		RefreshGrids()
		ChekModified()
		filterGrid()
		btnCopyData.Enabled = False
		btnUpdateTransactions.Enabled = True
		''
		Windows.Forms.Cursor.Current = Cursors.Default()
	End Sub

	Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
		''
		If grdNewOverFlight.Rows.Count = 0 Then Exit Sub
		''

		Dim response As MsgBoxResult
		response = MsgBox("Are you sure you want to delete?", MsgBoxStyle.YesNo, "BitSolution")

		If response = MsgBoxResult.Yes Then

			Dim i As Integer


			Dim dv As DataGridViewSelectedRowCollection = grdNewOverFlight.SelectedRows

			For i = 0 To grdNewOverFlight.SelectedRows.Count - 1

				Dim cmd As New SqlClient.SqlCommand("DELETE FROM [OverFlight] where Ovfl_ID =" & dv(i).Cells("Ovfl_ID").Value, conSql)
				Try
					conSql.Open()
					cmd.ExecuteNonQuery()
					conSql.Close()
					''

				Catch ex As Exception
					conSql.Close()
				End Try

			Next

		End If

		RefreshGrids()
		ChekModified()
	End Sub

	Private Sub btnUpdateTransactions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateTransactions.Click
		''
		'InsertIntotblOverFlight()
		CopyOvflIntotblOvfl()
		''
		updateClient()
		filterGrid()
        btnDelete.Enabled = True
        btnUpdateTransactions.Enabled = False
	End Sub

	Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
		''
		Dim i As Integer

		For i = 0 To Me.chkLstGridCol.Items.Count - 1
			Me.grdNewOverFlight.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
		Next
		''
		Me.grpShowHideColumns.Visible = False
	End Sub

	Private Sub btnDeleteAllTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteAllTransaction.Click
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		' Delete data from table Transaction after Copy New Data
		''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		DeleteTransactionsOvfl()
	End Sub

	Private Sub rdbAllTransactions_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbAllTransactions.CheckedChanged
		filterGrid()
	End Sub

	Private Sub rdbNewTransactions_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbNewTransactions.CheckedChanged
		filterGrid()
	End Sub

	Private Sub rdbModifiedTransactions_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbModifiedTransactions.CheckedChanged
		filterGrid()
	End Sub

	Private Sub grdNewTransactions_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdNewOverFlight.CellDoubleClick
		''
		If grdNewOverFlight.Rows.Count <> 0 Then
			dsData.Tables("ModifiedOverFlight").DefaultView.RowFilter = "Ovfl_ID=" & grdNewOverFlight.Item("Ovfl_ID", grdNewOverFlight.CurrentRow.Index).Value
		End If
		''
		Dim intDiff As Int16
		If pnlModified.Visible = True Then
			'' hide it...
			pnlModified.Visible = False
			intDiff = 114
		Else
			pnlModified.Visible = True
			intDiff = -114
		End If
		''
		'' up/dwn: grd...
		''
		Me.grdNewOverFlight.Height += intDiff
	End Sub

#End Region


End Class