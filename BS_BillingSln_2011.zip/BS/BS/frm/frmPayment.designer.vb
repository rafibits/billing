<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPayment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHotKeys = New System.Windows.Forms.Label
        Me.lblHotKeyLabel = New System.Windows.Forms.Label
        Me.txtNet = New System.Windows.Forms.TextBox
        Me.lblNetCurr = New System.Windows.Forms.Label
        Me.lblNet = New System.Windows.Forms.Label
        Me.grpInvoices = New System.Windows.Forms.GroupBox
        Me.grpShowHideColumnsInvoice = New System.Windows.Forms.GroupBox
        Me.btnSaveSettingsInvoice = New System.Windows.Forms.Button
        Me.chkLstGridColInvoice = New System.Windows.Forms.CheckedListBox
        Me.lblInvoiceCurr2 = New System.Windows.Forms.Label
        Me.txtInvoiceTotal2 = New System.Windows.Forms.TextBox
        Me.btnRemoveInvoice = New BHBut.BouncingHoverButton
        Me.lblInvoiceCurr1 = New System.Windows.Forms.Label
        Me.btnInvoice = New BHBut.BouncingHoverButton
        Me.lblTotal = New System.Windows.Forms.Label
        Me.txtInvoiceTotal = New System.Windows.Forms.TextBox
        Me.btnShowColInvoice = New System.Windows.Forms.Button
        Me.grdInvoices = New System.Windows.Forms.DataGridView
        Me.grpNums = New System.Windows.Forms.GroupBox
        Me.txtPmtTrxNum2 = New System.Windows.Forms.TextBox
        Me.lblPmtTrxNum = New System.Windows.Forms.Label
        Me.lblReceiptNum = New System.Windows.Forms.Label
        Me.txtReceiptNum2 = New System.Windows.Forms.TextBox
        Me.grpDetails = New System.Windows.Forms.GroupBox
        Me.txtPaymentYY = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtReceiptNum = New System.Windows.Forms.TextBox
        Me.txtPmtTrxNum = New System.Windows.Forms.TextBox
        Me.chkWhithStamp = New System.Windows.Forms.CheckBox
        Me.cboStatus = New System.Windows.Forms.ComboBox
        Me.cboEmployee = New System.Windows.Forms.ComboBox
        Me.lblClient = New System.Windows.Forms.Label
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.lblEmployee = New System.Windows.Forms.Label
        Me.dtpPmtDate = New System.Windows.Forms.DateTimePicker
        Me.lblPmtNumber = New System.Windows.Forms.Label
        Me.txtPmtNum = New System.Windows.Forms.TextBox
        Me.lblPmtDate = New System.Windows.Forms.Label
        Me.lblStatus = New System.Windows.Forms.Label
        Me.grpPmtDetail = New System.Windows.Forms.GroupBox
        Me.grpShowHideColumnsPmtDetails = New System.Windows.Forms.GroupBox
        Me.btnSaveSettingsPmtDetails = New System.Windows.Forms.Button
        Me.chkLstGridColPmtDetails = New System.Windows.Forms.CheckedListBox
        Me.btnEditPmt = New BHBut.BouncingHoverButton
        Me.btnDeletePMT = New BHBut.BouncingHoverButton
        Me.btnNewPMT = New BHBut.BouncingHoverButton
        Me.btnShowColPmtDetails = New System.Windows.Forms.Button
        Me.grdPaymentDetails = New System.Windows.Forms.DataGridView
        Me.grpPmtDetails = New System.Windows.Forms.GroupBox
        Me.cboCurrency = New System.Windows.Forms.ComboBox
        Me.btnCancelPMT = New BHBut.BouncingHoverButton
        Me.txtNote = New System.Windows.Forms.TextBox
        Me.btnSavePMT = New BHBut.BouncingHoverButton
        Me.lblNote = New System.Windows.Forms.Label
        Me.lblAmount = New System.Windows.Forms.Label
        Me.txtAmount = New System.Windows.Forms.TextBox
        Me.grpCheck = New System.Windows.Forms.GroupBox
        Me.lblBank = New System.Windows.Forms.Label
        Me.cboBank = New System.Windows.Forms.ComboBox
        Me.dtpValueDate = New System.Windows.Forms.DateTimePicker
        Me.chkClear = New System.Windows.Forms.CheckBox
        Me.lblCheckNum = New System.Windows.Forms.Label
        Me.txtCheckNum = New System.Windows.Forms.TextBox
        Me.lblValueDate = New System.Windows.Forms.Label
        Me.cboPaymentType = New System.Windows.Forms.ComboBox
        Me.lblPmtType = New System.Windows.Forms.Label
        Me.txtPaymentID = New System.Windows.Forms.TextBox
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.grpPmtDetailButtons = New System.Windows.Forms.GroupBox
        Me.btnSetNum = New BHBut.BouncingHoverButton
        Me.btnReciept = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.lblDiscount = New System.Windows.Forms.Label
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnPost = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtNet2 = New System.Windows.Forms.TextBox
        Me.lblCurrency = New System.Windows.Forms.Label
        Me.txtPmtTotal = New System.Windows.Forms.TextBox
        Me.lblPmtTotal = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtPmtTotal2 = New System.Windows.Forms.TextBox
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.txtPmtDescription = New System.Windows.Forms.TextBox
        Me.lblDescription = New System.Windows.Forms.Label
        Me.grpInvoices.SuspendLayout()
        Me.grpShowHideColumnsInvoice.SuspendLayout()
        CType(Me.grdInvoices, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpNums.SuspendLayout()
        Me.grpDetails.SuspendLayout()
        Me.grpPmtDetail.SuspendLayout()
        Me.grpShowHideColumnsPmtDetails.SuspendLayout()
        CType(Me.grdPaymentDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpPmtDetails.SuspendLayout()
        Me.grpCheck.SuspendLayout()
        Me.grpPmtDetailButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblHotKeys
        '
        Me.lblHotKeys.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblHotKeys.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblHotKeys.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHotKeys.ForeColor = System.Drawing.Color.Red
        Me.lblHotKeys.Location = New System.Drawing.Point(72, 544)
        Me.lblHotKeys.Name = "lblHotKeys"
        Me.lblHotKeys.Size = New System.Drawing.Size(257, 21)
        Me.lblHotKeys.TabIndex = 370
        Me.lblHotKeys.Text = " F3= Client Search, F5= Get Invoice"
        Me.lblHotKeys.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblHotKeyLabel
        '
        Me.lblHotKeyLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblHotKeyLabel.BackColor = System.Drawing.Color.Red
        Me.lblHotKeyLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblHotKeyLabel.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHotKeyLabel.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblHotKeyLabel.Location = New System.Drawing.Point(5, 544)
        Me.lblHotKeyLabel.Name = "lblHotKeyLabel"
        Me.lblHotKeyLabel.Size = New System.Drawing.Size(66, 21)
        Me.lblHotKeyLabel.TabIndex = 371
        Me.lblHotKeyLabel.Text = "Hot Keys:"
        Me.lblHotKeyLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtNet
        '
        Me.txtNet.AcceptsReturn = True
        Me.txtNet.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNet.BackColor = System.Drawing.Color.Maroon
        Me.txtNet.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNet.ForeColor = System.Drawing.Color.White
        Me.txtNet.Location = New System.Drawing.Point(714, 18)
        Me.txtNet.Name = "txtNet"
        Me.txtNet.ReadOnly = True
        Me.txtNet.Size = New System.Drawing.Size(107, 23)
        Me.txtNet.TabIndex = 379
        Me.txtNet.Text = "0"
        Me.txtNet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblNetCurr
        '
        Me.lblNetCurr.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblNetCurr.AutoSize = True
        Me.lblNetCurr.BackColor = System.Drawing.Color.Transparent
        Me.lblNetCurr.ForeColor = System.Drawing.Color.Red
        Me.lblNetCurr.Location = New System.Drawing.Point(824, 23)
        Me.lblNetCurr.Name = "lblNetCurr"
        Me.lblNetCurr.Size = New System.Drawing.Size(24, 13)
        Me.lblNetCurr.TabIndex = 389
        Me.lblNetCurr.Text = "LBP"
        Me.lblNetCurr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNet
        '
        Me.lblNet.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblNet.AutoSize = True
        Me.lblNet.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblNet.ForeColor = System.Drawing.Color.Maroon
        Me.lblNet.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblNet.Location = New System.Drawing.Point(686, 23)
        Me.lblNet.Name = "lblNet"
        Me.lblNet.Size = New System.Drawing.Size(24, 13)
        Me.lblNet.TabIndex = 378
        Me.lblNet.Text = "Net"
        Me.lblNet.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpInvoices
        '
        Me.grpInvoices.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpInvoices.Controls.Add(Me.grpShowHideColumnsInvoice)
        Me.grpInvoices.Controls.Add(Me.lblInvoiceCurr2)
        Me.grpInvoices.Controls.Add(Me.txtInvoiceTotal2)
        Me.grpInvoices.Controls.Add(Me.btnRemoveInvoice)
        Me.grpInvoices.Controls.Add(Me.lblInvoiceCurr1)
        Me.grpInvoices.Controls.Add(Me.btnInvoice)
        Me.grpInvoices.Controls.Add(Me.lblTotal)
        Me.grpInvoices.Controls.Add(Me.txtInvoiceTotal)
        Me.grpInvoices.Controls.Add(Me.btnShowColInvoice)
        Me.grpInvoices.Controls.Add(Me.grdInvoices)
        Me.grpInvoices.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpInvoices.ForeColor = System.Drawing.Color.Blue
        Me.grpInvoices.Location = New System.Drawing.Point(3, 158)
        Me.grpInvoices.Name = "grpInvoices"
        Me.grpInvoices.Size = New System.Drawing.Size(939, 168)
        Me.grpInvoices.TabIndex = 387
        Me.grpInvoices.TabStop = False
        Me.grpInvoices.Text = "Invoices"
        '
        'grpShowHideColumnsInvoice
        '
        Me.grpShowHideColumnsInvoice.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumnsInvoice.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumnsInvoice.Controls.Add(Me.btnSaveSettingsInvoice)
        Me.grpShowHideColumnsInvoice.Controls.Add(Me.chkLstGridColInvoice)
        Me.grpShowHideColumnsInvoice.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumnsInvoice.Location = New System.Drawing.Point(49, 23)
        Me.grpShowHideColumnsInvoice.Name = "grpShowHideColumnsInvoice"
        Me.grpShowHideColumnsInvoice.Size = New System.Drawing.Size(169, 144)
        Me.grpShowHideColumnsInvoice.TabIndex = 391
        Me.grpShowHideColumnsInvoice.TabStop = False
        Me.grpShowHideColumnsInvoice.Text = "Custom Columns"
        Me.grpShowHideColumnsInvoice.Visible = False
        '
        'btnSaveSettingsInvoice
        '
        Me.btnSaveSettingsInvoice.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettingsInvoice.Location = New System.Drawing.Point(7, 115)
        Me.btnSaveSettingsInvoice.Name = "btnSaveSettingsInvoice"
        Me.btnSaveSettingsInvoice.Size = New System.Drawing.Size(156, 27)
        Me.btnSaveSettingsInvoice.TabIndex = 0
        Me.btnSaveSettingsInvoice.Text = "Save Settings"
        Me.btnSaveSettingsInvoice.UseVisualStyleBackColor = True
        '
        'chkLstGridColInvoice
        '
        Me.chkLstGridColInvoice.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridColInvoice.CheckOnClick = True
        Me.chkLstGridColInvoice.FormattingEnabled = True
        Me.chkLstGridColInvoice.Location = New System.Drawing.Point(7, 19)
        Me.chkLstGridColInvoice.Name = "chkLstGridColInvoice"
        Me.chkLstGridColInvoice.Size = New System.Drawing.Size(156, 76)
        Me.chkLstGridColInvoice.TabIndex = 92
        Me.chkLstGridColInvoice.ThreeDCheckBoxes = True
        '
        'lblInvoiceCurr2
        '
        Me.lblInvoiceCurr2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblInvoiceCurr2.AutoSize = True
        Me.lblInvoiceCurr2.BackColor = System.Drawing.Color.Transparent
        Me.lblInvoiceCurr2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInvoiceCurr2.ForeColor = System.Drawing.Color.Red
        Me.lblInvoiceCurr2.Location = New System.Drawing.Point(828, 144)
        Me.lblInvoiceCurr2.Name = "lblInvoiceCurr2"
        Me.lblInvoiceCurr2.Size = New System.Drawing.Size(13, 13)
        Me.lblInvoiceCurr2.TabIndex = 393
        Me.lblInvoiceCurr2.Text = "$"
        Me.lblInvoiceCurr2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtInvoiceTotal2
        '
        Me.txtInvoiceTotal2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtInvoiceTotal2.BackColor = System.Drawing.Color.Maroon
        Me.txtInvoiceTotal2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInvoiceTotal2.ForeColor = System.Drawing.Color.White
        Me.txtInvoiceTotal2.Location = New System.Drawing.Point(720, 139)
        Me.txtInvoiceTotal2.Name = "txtInvoiceTotal2"
        Me.txtInvoiceTotal2.ReadOnly = True
        Me.txtInvoiceTotal2.Size = New System.Drawing.Size(107, 23)
        Me.txtInvoiceTotal2.TabIndex = 392
        Me.txtInvoiceTotal2.Text = "0"
        Me.txtInvoiceTotal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnRemoveInvoice
        '
        Me.btnRemoveInvoice.AlternativeGroup = Nothing
        Me.btnRemoveInvoice.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRemoveInvoice.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnRemoveInvoice.BackColor1 = System.Drawing.Color.White
        Me.btnRemoveInvoice.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnRemoveInvoice.BorderHover = True
        Me.btnRemoveInvoice.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnRemoveInvoice.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnRemoveInvoice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnRemoveInvoice.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnRemoveInvoice.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnRemoveInvoice.DrawBorder = True
        Me.btnRemoveInvoice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnRemoveInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnRemoveInvoice.ForeColor = System.Drawing.Color.Navy
        Me.btnRemoveInvoice.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnRemoveInvoice.HoverColor2 = System.Drawing.Color.White
        Me.btnRemoveInvoice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnRemoveInvoice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnRemoveInvoice.Location = New System.Drawing.Point(849, 58)
        Me.btnRemoveInvoice.Name = "btnRemoveInvoice"
        Me.btnRemoveInvoice.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnRemoveInvoice.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnRemoveInvoice.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnRemoveInvoice.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnRemoveInvoice.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnRemoveInvoice.SelectedText = Nothing
        Me.btnRemoveInvoice.Size = New System.Drawing.Size(87, 28)
        Me.btnRemoveInvoice.TabIndex = 386
        Me.btnRemoveInvoice.TabStop = False
        Me.btnRemoveInvoice.Text = "R e m o v e"
        Me.btnRemoveInvoice.UseVisualStyleBackColor = False
        '
        'lblInvoiceCurr1
        '
        Me.lblInvoiceCurr1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblInvoiceCurr1.AutoSize = True
        Me.lblInvoiceCurr1.BackColor = System.Drawing.Color.Transparent
        Me.lblInvoiceCurr1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInvoiceCurr1.ForeColor = System.Drawing.Color.Red
        Me.lblInvoiceCurr1.Location = New System.Drawing.Point(692, 144)
        Me.lblInvoiceCurr1.Name = "lblInvoiceCurr1"
        Me.lblInvoiceCurr1.Size = New System.Drawing.Size(24, 13)
        Me.lblInvoiceCurr1.TabIndex = 381
        Me.lblInvoiceCurr1.Text = "LBP"
        Me.lblInvoiceCurr1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnInvoice
        '
        Me.btnInvoice.AlternativeGroup = Nothing
        Me.btnInvoice.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnInvoice.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnInvoice.BackColor1 = System.Drawing.Color.White
        Me.btnInvoice.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnInvoice.BorderHover = True
        Me.btnInvoice.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnInvoice.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnInvoice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnInvoice.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnInvoice.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnInvoice.DrawBorder = True
        Me.btnInvoice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnInvoice.ForeColor = System.Drawing.Color.Navy
        Me.btnInvoice.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnInvoice.HoverColor2 = System.Drawing.Color.White
        Me.btnInvoice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnInvoice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnInvoice.Location = New System.Drawing.Point(848, 24)
        Me.btnInvoice.Name = "btnInvoice"
        Me.btnInvoice.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnInvoice.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnInvoice.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnInvoice.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnInvoice.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnInvoice.SelectedText = Nothing
        Me.btnInvoice.Size = New System.Drawing.Size(87, 28)
        Me.btnInvoice.TabIndex = 11
        Me.btnInvoice.TabStop = False
        Me.btnInvoice.Text = "G e t"
        Me.btnInvoice.UseVisualStyleBackColor = False
        '
        'lblTotal
        '
        Me.lblTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotal.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblTotal.Location = New System.Drawing.Point(509, 144)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(69, 13)
        Me.lblTotal.TabIndex = 358
        Me.lblTotal.Text = "Invoice Total"
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtInvoiceTotal
        '
        Me.txtInvoiceTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtInvoiceTotal.BackColor = System.Drawing.Color.Maroon
        Me.txtInvoiceTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInvoiceTotal.ForeColor = System.Drawing.Color.White
        Me.txtInvoiceTotal.Location = New System.Drawing.Point(582, 139)
        Me.txtInvoiceTotal.Name = "txtInvoiceTotal"
        Me.txtInvoiceTotal.ReadOnly = True
        Me.txtInvoiceTotal.Size = New System.Drawing.Size(107, 23)
        Me.txtInvoiceTotal.TabIndex = 363
        Me.txtInvoiceTotal.Text = "0"
        Me.txtInvoiceTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnShowColInvoice
        '
        Me.btnShowColInvoice.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowColInvoice.BackColor = System.Drawing.Color.Linen
        Me.btnShowColInvoice.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowColInvoice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowColInvoice.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowColInvoice.FlatAppearance.BorderSize = 2
        Me.btnShowColInvoice.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColInvoice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowColInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowColInvoice.ForeColor = System.Drawing.Color.White
        Me.btnShowColInvoice.Location = New System.Drawing.Point(11, 24)
        Me.btnShowColInvoice.Name = "btnShowColInvoice"
        Me.btnShowColInvoice.Size = New System.Drawing.Size(36, 30)
        Me.btnShowColInvoice.TabIndex = 367
        Me.btnShowColInvoice.UseVisualStyleBackColor = False
        '
        'grdInvoices
        '
        Me.grdInvoices.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdInvoices.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdInvoices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdInvoices.Location = New System.Drawing.Point(9, 22)
        Me.grdInvoices.MultiSelect = False
        Me.grdInvoices.Name = "grdInvoices"
        Me.grdInvoices.ReadOnly = True
        Me.grdInvoices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdInvoices.Size = New System.Drawing.Size(835, 111)
        Me.grdInvoices.TabIndex = 2
        '
        'grpNums
        '
        Me.grpNums.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpNums.BackColor = System.Drawing.Color.Linen
        Me.grpNums.Controls.Add(Me.txtPmtTrxNum2)
        Me.grpNums.Controls.Add(Me.lblPmtTrxNum)
        Me.grpNums.Controls.Add(Me.lblReceiptNum)
        Me.grpNums.Controls.Add(Me.txtReceiptNum2)
        Me.grpNums.Location = New System.Drawing.Point(643, 43)
        Me.grpNums.Name = "grpNums"
        Me.grpNums.Size = New System.Drawing.Size(299, 109)
        Me.grpNums.TabIndex = 373
        Me.grpNums.TabStop = False
        '
        'txtPmtTrxNum2
        '
        Me.txtPmtTrxNum2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPmtTrxNum2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPmtTrxNum2.ForeColor = System.Drawing.Color.Navy
        Me.txtPmtTrxNum2.Location = New System.Drawing.Point(65, 39)
        Me.txtPmtTrxNum2.Name = "txtPmtTrxNum2"
        Me.txtPmtTrxNum2.Size = New System.Drawing.Size(214, 22)
        Me.txtPmtTrxNum2.TabIndex = 373
        '
        'lblPmtTrxNum
        '
        Me.lblPmtTrxNum.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblPmtTrxNum.AutoSize = True
        Me.lblPmtTrxNum.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPmtTrxNum.ForeColor = System.Drawing.Color.Navy
        Me.lblPmtTrxNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPmtTrxNum.Location = New System.Drawing.Point(6, 44)
        Me.lblPmtTrxNum.Name = "lblPmtTrxNum"
        Me.lblPmtTrxNum.Size = New System.Drawing.Size(55, 13)
        Me.lblPmtTrxNum.TabIndex = 372
        Me.lblPmtTrxNum.Text = "Pmt Trx #"
        Me.lblPmtTrxNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblReceiptNum
        '
        Me.lblReceiptNum.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblReceiptNum.AutoSize = True
        Me.lblReceiptNum.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblReceiptNum.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReceiptNum.ForeColor = System.Drawing.Color.Navy
        Me.lblReceiptNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblReceiptNum.Location = New System.Drawing.Point(7, 11)
        Me.lblReceiptNum.Name = "lblReceiptNum"
        Me.lblReceiptNum.Size = New System.Drawing.Size(54, 13)
        Me.lblReceiptNum.TabIndex = 272
        Me.lblReceiptNum.Text = "Receipt #"
        Me.lblReceiptNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtReceiptNum2
        '
        Me.txtReceiptNum2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtReceiptNum2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReceiptNum2.ForeColor = System.Drawing.Color.Navy
        Me.txtReceiptNum2.Location = New System.Drawing.Point(65, 11)
        Me.txtReceiptNum2.Name = "txtReceiptNum2"
        Me.txtReceiptNum2.Size = New System.Drawing.Size(214, 22)
        Me.txtReceiptNum2.TabIndex = 270
        '
        'grpDetails
        '
        Me.grpDetails.BackColor = System.Drawing.Color.LightYellow
        Me.grpDetails.Controls.Add(Me.txtPmtDescription)
        Me.grpDetails.Controls.Add(Me.lblDescription)
        Me.grpDetails.Controls.Add(Me.txtPaymentYY)
        Me.grpDetails.Controls.Add(Me.Label4)
        Me.grpDetails.Controls.Add(Me.Label1)
        Me.grpDetails.Controls.Add(Me.txtReceiptNum)
        Me.grpDetails.Controls.Add(Me.txtPmtTrxNum)
        Me.grpDetails.Controls.Add(Me.chkWhithStamp)
        Me.grpDetails.Controls.Add(Me.cboStatus)
        Me.grpDetails.Controls.Add(Me.cboEmployee)
        Me.grpDetails.Controls.Add(Me.lblClient)
        Me.grpDetails.Controls.Add(Me.cboClient)
        Me.grpDetails.Controls.Add(Me.lblEmployee)
        Me.grpDetails.Controls.Add(Me.dtpPmtDate)
        Me.grpDetails.Controls.Add(Me.lblPmtNumber)
        Me.grpDetails.Controls.Add(Me.txtPmtNum)
        Me.grpDetails.Controls.Add(Me.lblPmtDate)
        Me.grpDetails.Controls.Add(Me.lblStatus)
        Me.grpDetails.Location = New System.Drawing.Point(6, 43)
        Me.grpDetails.Name = "grpDetails"
        Me.grpDetails.Size = New System.Drawing.Size(631, 109)
        Me.grpDetails.TabIndex = 261
        Me.grpDetails.TabStop = False
        Me.grpDetails.Tag = "m "
        '
        'txtPaymentYY
        '
        Me.txtPaymentYY.BackColor = System.Drawing.Color.Maroon
        Me.txtPaymentYY.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtPaymentYY.ForeColor = System.Drawing.Color.White
        Me.txtPaymentYY.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtPaymentYY.Location = New System.Drawing.Point(137, 10)
        Me.txtPaymentYY.Multiline = True
        Me.txtPaymentYY.Name = "txtPaymentYY"
        Me.txtPaymentYY.ReadOnly = True
        Me.txtPaymentYY.Size = New System.Drawing.Size(55, 23)
        Me.txtPaymentYY.TabIndex = 382
        Me.txtPaymentYY.TabStop = False
        Me.txtPaymentYY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Maroon
        Me.Label4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label4.Location = New System.Drawing.Point(668, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 16)
        Me.Label4.TabIndex = 379
        Me.Label4.Text = "Receipt #"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label4.Visible = False
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Maroon
        Me.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label1.Location = New System.Drawing.Point(668, 54)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(141, 16)
        Me.Label1.TabIndex = 380
        Me.Label1.Text = "Payment Transaction #"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label1.Visible = False
        '
        'txtReceiptNum
        '
        Me.txtReceiptNum.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtReceiptNum.Enabled = False
        Me.txtReceiptNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReceiptNum.ForeColor = System.Drawing.Color.Navy
        Me.txtReceiptNum.Location = New System.Drawing.Point(669, 29)
        Me.txtReceiptNum.Name = "txtReceiptNum"
        Me.txtReceiptNum.Size = New System.Drawing.Size(0, 22)
        Me.txtReceiptNum.TabIndex = 381
        Me.txtReceiptNum.Visible = False
        '
        'txtPmtTrxNum
        '
        Me.txtPmtTrxNum.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPmtTrxNum.Enabled = False
        Me.txtPmtTrxNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPmtTrxNum.ForeColor = System.Drawing.Color.Navy
        Me.txtPmtTrxNum.Location = New System.Drawing.Point(669, 75)
        Me.txtPmtTrxNum.Name = "txtPmtTrxNum"
        Me.txtPmtTrxNum.Size = New System.Drawing.Size(0, 22)
        Me.txtPmtTrxNum.TabIndex = 378
        Me.txtPmtTrxNum.Visible = False
        '
        'chkWhithStamp
        '
        Me.chkWhithStamp.AutoSize = True
        Me.chkWhithStamp.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkWhithStamp.ForeColor = System.Drawing.Color.Maroon
        Me.chkWhithStamp.Location = New System.Drawing.Point(537, 13)
        Me.chkWhithStamp.Name = "chkWhithStamp"
        Me.chkWhithStamp.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.chkWhithStamp.Size = New System.Drawing.Size(84, 17)
        Me.chkWhithStamp.TabIndex = 370
        Me.chkWhithStamp.Text = " With Stamp"
        Me.chkWhithStamp.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkWhithStamp.UseVisualStyleBackColor = True
        '
        'cboStatus
        '
        Me.cboStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple
        Me.cboStatus.Enabled = False
        Me.cboStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Location = New System.Drawing.Point(396, 10)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(135, 24)
        Me.cboStatus.TabIndex = 368
        '
        'cboEmployee
        '
        Me.cboEmployee.BackColor = System.Drawing.SystemColors.Window
        Me.cboEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple
        Me.cboEmployee.Enabled = False
        Me.cboEmployee.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboEmployee.FormattingEnabled = True
        Me.cboEmployee.Location = New System.Drawing.Point(396, 39)
        Me.cboEmployee.Name = "cboEmployee"
        Me.cboEmployee.Size = New System.Drawing.Size(225, 24)
        Me.cboEmployee.TabIndex = 276
        '
        'lblClient
        '
        Me.lblClient.AutoSize = True
        Me.lblClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblClient.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClient.ForeColor = System.Drawing.Color.Maroon
        Me.lblClient.Location = New System.Drawing.Point(31, 43)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(34, 13)
        Me.lblClient.TabIndex = 268
        Me.lblClient.Text = "Client"
        Me.lblClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboClient
        '
        Me.cboClient.BackColor = System.Drawing.SystemColors.Window
        Me.cboClient.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(67, 39)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(275, 24)
        Me.cboClient.TabIndex = 269
        '
        'lblEmployee
        '
        Me.lblEmployee.AutoSize = True
        Me.lblEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblEmployee.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmployee.ForeColor = System.Drawing.Color.Maroon
        Me.lblEmployee.Location = New System.Drawing.Point(344, 44)
        Me.lblEmployee.Name = "lblEmployee"
        Me.lblEmployee.Size = New System.Drawing.Size(53, 13)
        Me.lblEmployee.TabIndex = 366
        Me.lblEmployee.Text = "Employee"
        Me.lblEmployee.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpPmtDate
        '
        Me.dtpPmtDate.CustomFormat = "dd MMM yyyy"
        Me.dtpPmtDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpPmtDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpPmtDate.Location = New System.Drawing.Point(237, 10)
        Me.dtpPmtDate.Name = "dtpPmtDate"
        Me.dtpPmtDate.Size = New System.Drawing.Size(105, 22)
        Me.dtpPmtDate.TabIndex = 267
        Me.dtpPmtDate.Value = New Date(2007, 12, 13, 0, 0, 0, 0)
        '
        'lblPmtNumber
        '
        Me.lblPmtNumber.AutoSize = True
        Me.lblPmtNumber.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPmtNumber.ForeColor = System.Drawing.Color.Maroon
        Me.lblPmtNumber.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPmtNumber.Location = New System.Drawing.Point(21, 14)
        Me.lblPmtNumber.Name = "lblPmtNumber"
        Me.lblPmtNumber.Size = New System.Drawing.Size(44, 13)
        Me.lblPmtNumber.TabIndex = 262
        Me.lblPmtNumber.Text = "Number"
        Me.lblPmtNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtPmtNum
        '
        Me.txtPmtNum.BackColor = System.Drawing.Color.White
        Me.txtPmtNum.Enabled = False
        Me.txtPmtNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPmtNum.Location = New System.Drawing.Point(67, 10)
        Me.txtPmtNum.Name = "txtPmtNum"
        Me.txtPmtNum.ReadOnly = True
        Me.txtPmtNum.Size = New System.Drawing.Size(64, 23)
        Me.txtPmtNum.TabIndex = 266
        Me.txtPmtNum.Text = "000"
        Me.txtPmtNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblPmtDate
        '
        Me.lblPmtDate.AutoSize = True
        Me.lblPmtDate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPmtDate.ForeColor = System.Drawing.Color.Maroon
        Me.lblPmtDate.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPmtDate.Location = New System.Drawing.Point(200, 14)
        Me.lblPmtDate.Name = "lblPmtDate"
        Me.lblPmtDate.Size = New System.Drawing.Size(33, 13)
        Me.lblPmtDate.TabIndex = 264
        Me.lblPmtDate.Text = " Date"
        Me.lblPmtDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblStatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.ForeColor = System.Drawing.Color.Maroon
        Me.lblStatus.Location = New System.Drawing.Point(359, 15)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(38, 13)
        Me.lblStatus.TabIndex = 367
        Me.lblStatus.Text = "Status"
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpPmtDetail
        '
        Me.grpPmtDetail.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpPmtDetail.Controls.Add(Me.grpShowHideColumnsPmtDetails)
        Me.grpPmtDetail.Controls.Add(Me.btnEditPmt)
        Me.grpPmtDetail.Controls.Add(Me.btnDeletePMT)
        Me.grpPmtDetail.Controls.Add(Me.btnNewPMT)
        Me.grpPmtDetail.Controls.Add(Me.btnShowColPmtDetails)
        Me.grpPmtDetail.Controls.Add(Me.grdPaymentDetails)
        Me.grpPmtDetail.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPmtDetail.ForeColor = System.Drawing.Color.Blue
        Me.grpPmtDetail.Location = New System.Drawing.Point(4, 331)
        Me.grpPmtDetail.Name = "grpPmtDetail"
        Me.grpPmtDetail.Size = New System.Drawing.Size(939, 204)
        Me.grpPmtDetail.TabIndex = 388
        Me.grpPmtDetail.TabStop = False
        Me.grpPmtDetail.Text = "Payments"
        '
        'grpShowHideColumnsPmtDetails
        '
        Me.grpShowHideColumnsPmtDetails.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumnsPmtDetails.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumnsPmtDetails.Controls.Add(Me.btnSaveSettingsPmtDetails)
        Me.grpShowHideColumnsPmtDetails.Controls.Add(Me.chkLstGridColPmtDetails)
        Me.grpShowHideColumnsPmtDetails.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumnsPmtDetails.Location = New System.Drawing.Point(50, 25)
        Me.grpShowHideColumnsPmtDetails.Name = "grpShowHideColumnsPmtDetails"
        Me.grpShowHideColumnsPmtDetails.Size = New System.Drawing.Size(175, 152)
        Me.grpShowHideColumnsPmtDetails.TabIndex = 392
        Me.grpShowHideColumnsPmtDetails.TabStop = False
        Me.grpShowHideColumnsPmtDetails.Text = "Custom Columns"
        Me.grpShowHideColumnsPmtDetails.Visible = False
        '
        'btnSaveSettingsPmtDetails
        '
        Me.btnSaveSettingsPmtDetails.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettingsPmtDetails.Location = New System.Drawing.Point(7, 123)
        Me.btnSaveSettingsPmtDetails.Name = "btnSaveSettingsPmtDetails"
        Me.btnSaveSettingsPmtDetails.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettingsPmtDetails.TabIndex = 0
        Me.btnSaveSettingsPmtDetails.Text = "Save Settings"
        Me.btnSaveSettingsPmtDetails.UseVisualStyleBackColor = True
        '
        'chkLstGridColPmtDetails
        '
        Me.chkLstGridColPmtDetails.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridColPmtDetails.CheckOnClick = True
        Me.chkLstGridColPmtDetails.FormattingEnabled = True
        Me.chkLstGridColPmtDetails.Location = New System.Drawing.Point(7, 18)
        Me.chkLstGridColPmtDetails.Name = "chkLstGridColPmtDetails"
        Me.chkLstGridColPmtDetails.Size = New System.Drawing.Size(162, 76)
        Me.chkLstGridColPmtDetails.TabIndex = 92
        Me.chkLstGridColPmtDetails.ThreeDCheckBoxes = True
        '
        'btnEditPmt
        '
        Me.btnEditPmt.AlternativeGroup = Nothing
        Me.btnEditPmt.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEditPmt.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEditPmt.BackColor1 = System.Drawing.Color.White
        Me.btnEditPmt.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEditPmt.BorderHover = True
        Me.btnEditPmt.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEditPmt.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEditPmt.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnEditPmt.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEditPmt.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEditPmt.DrawBorder = True
        Me.btnEditPmt.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEditPmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnEditPmt.ForeColor = System.Drawing.Color.Navy
        Me.btnEditPmt.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEditPmt.HoverColor2 = System.Drawing.Color.White
        Me.btnEditPmt.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEditPmt.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnEditPmt.Location = New System.Drawing.Point(848, 88)
        Me.btnEditPmt.Name = "btnEditPmt"
        Me.btnEditPmt.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEditPmt.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnEditPmt.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnEditPmt.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnEditPmt.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnEditPmt.SelectedText = Nothing
        Me.btnEditPmt.Size = New System.Drawing.Size(87, 28)
        Me.btnEditPmt.TabIndex = 386
        Me.btnEditPmt.TabStop = False
        Me.btnEditPmt.Text = "E d i t"
        Me.btnEditPmt.UseVisualStyleBackColor = False
        '
        'btnDeletePMT
        '
        Me.btnDeletePMT.AlternativeGroup = Nothing
        Me.btnDeletePMT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDeletePMT.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnDeletePMT.BackColor1 = System.Drawing.Color.White
        Me.btnDeletePMT.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnDeletePMT.BorderHover = True
        Me.btnDeletePMT.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDeletePMT.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDeletePMT.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDeletePMT.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDeletePMT.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDeletePMT.DrawBorder = True
        Me.btnDeletePMT.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDeletePMT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnDeletePMT.ForeColor = System.Drawing.Color.Navy
        Me.btnDeletePMT.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDeletePMT.HoverColor2 = System.Drawing.Color.White
        Me.btnDeletePMT.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDeletePMT.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnDeletePMT.Location = New System.Drawing.Point(848, 54)
        Me.btnDeletePMT.Name = "btnDeletePMT"
        Me.btnDeletePMT.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDeletePMT.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnDeletePMT.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDeletePMT.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDeletePMT.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnDeletePMT.SelectedText = Nothing
        Me.btnDeletePMT.Size = New System.Drawing.Size(87, 28)
        Me.btnDeletePMT.TabIndex = 385
        Me.btnDeletePMT.TabStop = False
        Me.btnDeletePMT.Text = "R e m o v e"
        Me.btnDeletePMT.UseVisualStyleBackColor = False
        '
        'btnNewPMT
        '
        Me.btnNewPMT.AlternativeGroup = Nothing
        Me.btnNewPMT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNewPMT.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNewPMT.BackColor1 = System.Drawing.Color.White
        Me.btnNewPMT.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNewPMT.BorderHover = True
        Me.btnNewPMT.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNewPMT.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNewPMT.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNewPMT.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNewPMT.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNewPMT.DrawBorder = True
        Me.btnNewPMT.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNewPMT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnNewPMT.ForeColor = System.Drawing.Color.Navy
        Me.btnNewPMT.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNewPMT.HoverColor2 = System.Drawing.Color.White
        Me.btnNewPMT.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewPMT.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNewPMT.Location = New System.Drawing.Point(848, 22)
        Me.btnNewPMT.Name = "btnNewPMT"
        Me.btnNewPMT.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNewPMT.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNewPMT.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNewPMT.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNewPMT.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNewPMT.SelectedText = Nothing
        Me.btnNewPMT.Size = New System.Drawing.Size(87, 28)
        Me.btnNewPMT.TabIndex = 382
        Me.btnNewPMT.TabStop = False
        Me.btnNewPMT.Text = "N e w"
        Me.btnNewPMT.UseVisualStyleBackColor = False
        '
        'btnShowColPmtDetails
        '
        Me.btnShowColPmtDetails.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowColPmtDetails.BackColor = System.Drawing.Color.Linen
        Me.btnShowColPmtDetails.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowColPmtDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowColPmtDetails.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowColPmtDetails.FlatAppearance.BorderSize = 2
        Me.btnShowColPmtDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColPmtDetails.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColPmtDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowColPmtDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowColPmtDetails.ForeColor = System.Drawing.Color.White
        Me.btnShowColPmtDetails.Location = New System.Drawing.Point(11, 25)
        Me.btnShowColPmtDetails.Name = "btnShowColPmtDetails"
        Me.btnShowColPmtDetails.Size = New System.Drawing.Size(36, 30)
        Me.btnShowColPmtDetails.TabIndex = 375
        Me.btnShowColPmtDetails.UseVisualStyleBackColor = False
        '
        'grdPaymentDetails
        '
        Me.grdPaymentDetails.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdPaymentDetails.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdPaymentDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdPaymentDetails.Location = New System.Drawing.Point(8, 23)
        Me.grdPaymentDetails.Name = "grdPaymentDetails"
        Me.grdPaymentDetails.ReadOnly = True
        Me.grdPaymentDetails.Size = New System.Drawing.Size(835, 164)
        Me.grdPaymentDetails.TabIndex = 372
        '
        'grpPmtDetails
        '
        Me.grpPmtDetails.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpPmtDetails.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpPmtDetails.Controls.Add(Me.cboCurrency)
        Me.grpPmtDetails.Controls.Add(Me.btnCancelPMT)
        Me.grpPmtDetails.Controls.Add(Me.txtNote)
        Me.grpPmtDetails.Controls.Add(Me.btnSavePMT)
        Me.grpPmtDetails.Controls.Add(Me.lblNote)
        Me.grpPmtDetails.Controls.Add(Me.lblAmount)
        Me.grpPmtDetails.Controls.Add(Me.txtAmount)
        Me.grpPmtDetails.Controls.Add(Me.grpCheck)
        Me.grpPmtDetails.Controls.Add(Me.cboPaymentType)
        Me.grpPmtDetails.Controls.Add(Me.lblPmtType)
        Me.grpPmtDetails.Location = New System.Drawing.Point(12, 350)
        Me.grpPmtDetails.Name = "grpPmtDetails"
        Me.grpPmtDetails.Size = New System.Drawing.Size(927, 168)
        Me.grpPmtDetails.TabIndex = 387
        Me.grpPmtDetails.TabStop = False
        '
        'cboCurrency
        '
        Me.cboCurrency.BackColor = System.Drawing.Color.White
        Me.cboCurrency.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCurrency.FormattingEnabled = True
        Me.cboCurrency.Location = New System.Drawing.Point(237, 58)
        Me.cboCurrency.Name = "cboCurrency"
        Me.cboCurrency.Size = New System.Drawing.Size(52, 26)
        Me.cboCurrency.TabIndex = 374
        '
        'btnCancelPMT
        '
        Me.btnCancelPMT.AlternativeGroup = Nothing
        Me.btnCancelPMT.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCancelPMT.BackColor = System.Drawing.Color.Orange
        Me.btnCancelPMT.BackColor1 = System.Drawing.Color.White
        Me.btnCancelPMT.BackColor2 = System.Drawing.Color.Orange
        Me.btnCancelPMT.BorderHover = True
        Me.btnCancelPMT.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancelPMT.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancelPMT.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCancelPMT.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancelPMT.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancelPMT.DrawBorder = True
        Me.btnCancelPMT.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancelPMT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCancelPMT.ForeColor = System.Drawing.Color.Navy
        Me.btnCancelPMT.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancelPMT.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnCancelPMT.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancelPMT.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCancelPMT.Location = New System.Drawing.Point(797, 134)
        Me.btnCancelPMT.Name = "btnCancelPMT"
        Me.btnCancelPMT.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancelPMT.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCancelPMT.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCancelPMT.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCancelPMT.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCancelPMT.SelectedText = Nothing
        Me.btnCancelPMT.Size = New System.Drawing.Size(98, 28)
        Me.btnCancelPMT.TabIndex = 384
        Me.btnCancelPMT.TabStop = False
        Me.btnCancelPMT.Text = "C a n c e l"
        Me.btnCancelPMT.UseVisualStyleBackColor = False
        '
        'txtNote
        '
        Me.txtNote.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNote.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNote.ForeColor = System.Drawing.Color.Navy
        Me.txtNote.Location = New System.Drawing.Point(91, 90)
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.Size = New System.Drawing.Size(804, 24)
        Me.txtNote.TabIndex = 370
        '
        'btnSavePMT
        '
        Me.btnSavePMT.AlternativeGroup = Nothing
        Me.btnSavePMT.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSavePMT.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSavePMT.BackColor1 = System.Drawing.Color.White
        Me.btnSavePMT.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSavePMT.BorderHover = True
        Me.btnSavePMT.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSavePMT.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSavePMT.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSavePMT.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSavePMT.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSavePMT.DrawBorder = True
        Me.btnSavePMT.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSavePMT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSavePMT.ForeColor = System.Drawing.Color.Navy
        Me.btnSavePMT.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSavePMT.HoverColor2 = System.Drawing.Color.White
        Me.btnSavePMT.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSavePMT.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSavePMT.Location = New System.Drawing.Point(91, 134)
        Me.btnSavePMT.Name = "btnSavePMT"
        Me.btnSavePMT.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSavePMT.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSavePMT.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSavePMT.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSavePMT.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSavePMT.SelectedText = Nothing
        Me.btnSavePMT.Size = New System.Drawing.Size(97, 28)
        Me.btnSavePMT.TabIndex = 383
        Me.btnSavePMT.TabStop = False
        Me.btnSavePMT.Text = "A d d"
        Me.btnSavePMT.UseVisualStyleBackColor = False
        '
        'lblNote
        '
        Me.lblNote.AutoSize = True
        Me.lblNote.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNote.ForeColor = System.Drawing.Color.Navy
        Me.lblNote.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblNote.Location = New System.Drawing.Point(3, 95)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(85, 13)
        Me.lblNote.TabIndex = 371
        Me.lblNote.Text = "Pmt Detail Desc."
        Me.lblNote.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblAmount
        '
        Me.lblAmount.AutoSize = True
        Me.lblAmount.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAmount.ForeColor = System.Drawing.Color.Navy
        Me.lblAmount.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAmount.Location = New System.Drawing.Point(44, 64)
        Me.lblAmount.Name = "lblAmount"
        Me.lblAmount.Size = New System.Drawing.Size(44, 13)
        Me.lblAmount.TabIndex = 369
        Me.lblAmount.Text = "Amount"
        Me.lblAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtAmount
        '
        Me.txtAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAmount.ForeColor = System.Drawing.Color.Navy
        Me.txtAmount.Location = New System.Drawing.Point(91, 58)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(144, 26)
        Me.txtAmount.TabIndex = 368
        '
        'grpCheck
        '
        Me.grpCheck.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpCheck.BackColor = System.Drawing.Color.Lavender
        Me.grpCheck.Controls.Add(Me.lblBank)
        Me.grpCheck.Controls.Add(Me.cboBank)
        Me.grpCheck.Controls.Add(Me.dtpValueDate)
        Me.grpCheck.Controls.Add(Me.chkClear)
        Me.grpCheck.Controls.Add(Me.lblCheckNum)
        Me.grpCheck.Controls.Add(Me.txtCheckNum)
        Me.grpCheck.Controls.Add(Me.lblValueDate)
        Me.grpCheck.Location = New System.Drawing.Point(295, 21)
        Me.grpCheck.Name = "grpCheck"
        Me.grpCheck.Size = New System.Drawing.Size(600, 63)
        Me.grpCheck.TabIndex = 367
        Me.grpCheck.TabStop = False
        '
        'lblBank
        '
        Me.lblBank.AutoSize = True
        Me.lblBank.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBank.ForeColor = System.Drawing.Color.Navy
        Me.lblBank.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblBank.Location = New System.Drawing.Point(21, 43)
        Me.lblBank.Name = "lblBank"
        Me.lblBank.Size = New System.Drawing.Size(30, 13)
        Me.lblBank.TabIndex = 372
        Me.lblBank.Text = "Bank"
        Me.lblBank.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboBank
        '
        Me.cboBank.BackColor = System.Drawing.SystemColors.Window
        Me.cboBank.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBank.FormattingEnabled = True
        Me.cboBank.Location = New System.Drawing.Point(54, 37)
        Me.cboBank.Name = "cboBank"
        Me.cboBank.Size = New System.Drawing.Size(294, 24)
        Me.cboBank.TabIndex = 371
        '
        'dtpValueDate
        '
        Me.dtpValueDate.CalendarFont = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpValueDate.CustomFormat = "dd MMM yyyy"
        Me.dtpValueDate.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpValueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpValueDate.Location = New System.Drawing.Point(193, 9)
        Me.dtpValueDate.Name = "dtpValueDate"
        Me.dtpValueDate.Size = New System.Drawing.Size(94, 24)
        Me.dtpValueDate.TabIndex = 370
        '
        'chkClear
        '
        Me.chkClear.AutoSize = True
        Me.chkClear.BackColor = System.Drawing.Color.Transparent
        Me.chkClear.Enabled = False
        Me.chkClear.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkClear.ForeColor = System.Drawing.Color.Red
        Me.chkClear.Location = New System.Drawing.Point(285, 13)
        Me.chkClear.Name = "chkClear"
        Me.chkClear.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.chkClear.Size = New System.Drawing.Size(63, 17)
        Me.chkClear.TabIndex = 369
        Me.chkClear.Text = "Cleared"
        Me.chkClear.UseVisualStyleBackColor = False
        '
        'lblCheckNum
        '
        Me.lblCheckNum.AutoSize = True
        Me.lblCheckNum.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblCheckNum.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCheckNum.ForeColor = System.Drawing.Color.Navy
        Me.lblCheckNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCheckNum.Location = New System.Drawing.Point(4, 13)
        Me.lblCheckNum.Name = "lblCheckNum"
        Me.lblCheckNum.Size = New System.Drawing.Size(47, 13)
        Me.lblCheckNum.TabIndex = 272
        Me.lblCheckNum.Text = "Check #"
        Me.lblCheckNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtCheckNum
        '
        Me.txtCheckNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCheckNum.ForeColor = System.Drawing.Color.Navy
        Me.txtCheckNum.Location = New System.Drawing.Point(54, 9)
        Me.txtCheckNum.Name = "txtCheckNum"
        Me.txtCheckNum.Size = New System.Drawing.Size(84, 22)
        Me.txtCheckNum.TabIndex = 270
        '
        'lblValueDate
        '
        Me.lblValueDate.AutoSize = True
        Me.lblValueDate.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblValueDate.ForeColor = System.Drawing.Color.Navy
        Me.lblValueDate.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblValueDate.Location = New System.Drawing.Point(137, 13)
        Me.lblValueDate.Name = "lblValueDate"
        Me.lblValueDate.Size = New System.Drawing.Size(59, 13)
        Me.lblValueDate.TabIndex = 368
        Me.lblValueDate.Text = "Value Date"
        Me.lblValueDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboPaymentType
        '
        Me.cboPaymentType.BackColor = System.Drawing.SystemColors.Window
        Me.cboPaymentType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPaymentType.FormattingEnabled = True
        Me.cboPaymentType.Location = New System.Drawing.Point(91, 24)
        Me.cboPaymentType.Name = "cboPaymentType"
        Me.cboPaymentType.Size = New System.Drawing.Size(198, 28)
        Me.cboPaymentType.TabIndex = 366
        '
        'lblPmtType
        '
        Me.lblPmtType.AutoSize = True
        Me.lblPmtType.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPmtType.ForeColor = System.Drawing.Color.Navy
        Me.lblPmtType.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPmtType.Location = New System.Drawing.Point(36, 30)
        Me.lblPmtType.Name = "lblPmtType"
        Me.lblPmtType.Size = New System.Drawing.Size(52, 13)
        Me.lblPmtType.TabIndex = 259
        Me.lblPmtType.Text = "Pmt Type"
        Me.lblPmtType.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtPaymentID
        '
        Me.txtPaymentID.Location = New System.Drawing.Point(301, 12)
        Me.txtPaymentID.Name = "txtPaymentID"
        Me.txtPaymentID.Size = New System.Drawing.Size(40, 20)
        Me.txtPaymentID.TabIndex = 160
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(954, 40)
        Me.lblfrmTitle.TabIndex = 161
        Me.lblfrmTitle.Text = "Payment"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(954, 3)
        Me.pnlTitle.TabIndex = 340
        '
        'grpPmtDetailButtons
        '
        Me.grpPmtDetailButtons.BackColor = System.Drawing.SystemColors.Control
        Me.grpPmtDetailButtons.Controls.Add(Me.btnSetNum)
        Me.grpPmtDetailButtons.Controls.Add(Me.btnReciept)
        Me.grpPmtDetailButtons.Controls.Add(Me.lblNet)
        Me.grpPmtDetailButtons.Controls.Add(Me.btnSave)
        Me.grpPmtDetailButtons.Controls.Add(Me.lblDiscount)
        Me.grpPmtDetailButtons.Controls.Add(Me.btnCancel)
        Me.grpPmtDetailButtons.Controls.Add(Me.txtNet)
        Me.grpPmtDetailButtons.Controls.Add(Me.btnPost)
        Me.grpPmtDetailButtons.Controls.Add(Me.btnClose)
        Me.grpPmtDetailButtons.Controls.Add(Me.lblNetCurr)
        Me.grpPmtDetailButtons.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.grpPmtDetailButtons.Location = New System.Drawing.Point(0, 580)
        Me.grpPmtDetailButtons.Name = "grpPmtDetailButtons"
        Me.grpPmtDetailButtons.Size = New System.Drawing.Size(954, 51)
        Me.grpPmtDetailButtons.TabIndex = 388
        Me.grpPmtDetailButtons.TabStop = False
        '
        'btnSetNum
        '
        Me.btnSetNum.AlternativeGroup = Nothing
        Me.btnSetNum.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSetNum.BackColor = System.Drawing.Color.Red
        Me.btnSetNum.BackColor1 = System.Drawing.Color.Maroon
        Me.btnSetNum.BackColor2 = System.Drawing.Color.Red
        Me.btnSetNum.BorderHover = True
        Me.btnSetNum.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnSetNum.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSetNum.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSetNum.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnSetNum.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSetNum.DrawBorder = True
        Me.btnSetNum.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSetNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSetNum.ForeColor = System.Drawing.Color.White
        Me.btnSetNum.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnSetNum.HoverColor2 = System.Drawing.Color.White
        Me.btnSetNum.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSetNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSetNum.Location = New System.Drawing.Point(428, 15)
        Me.btnSetNum.Name = "btnSetNum"
        Me.btnSetNum.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnSetNum.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSetNum.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSetNum.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSetNum.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnSetNum.SelectedText = Nothing
        Me.btnSetNum.Size = New System.Drawing.Size(122, 28)
        Me.btnSetNum.TabIndex = 390
        Me.btnSetNum.Text = "Set Number(s)"
        Me.btnSetNum.UseVisualStyleBackColor = False
        '
        'btnReciept
        '
        Me.btnReciept.AlternativeGroup = Nothing
        Me.btnReciept.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnReciept.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnReciept.BackColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnReciept.BackColor2 = System.Drawing.Color.White
        Me.btnReciept.BorderHover = True
        Me.btnReciept.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnReciept.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnReciept.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnReciept.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnReciept.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnReciept.DrawBorder = True
        Me.btnReciept.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnReciept.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnReciept.ForeColor = System.Drawing.Color.Navy
        Me.btnReciept.HoverColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnReciept.HoverColor2 = System.Drawing.Color.White
        Me.btnReciept.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnReciept.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnReciept.Location = New System.Drawing.Point(323, 15)
        Me.btnReciept.Name = "btnReciept"
        Me.btnReciept.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnReciept.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnReciept.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnReciept.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnReciept.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnReciept.SelectedText = Nothing
        Me.btnReciept.Size = New System.Drawing.Size(102, 28)
        Me.btnReciept.TabIndex = 371
        Me.btnReciept.Text = "R e c i e p t"
        Me.btnReciept.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(8, 15)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(102, 28)
        Me.btnSave.TabIndex = 368
        Me.btnSave.TabStop = False
        Me.btnSave.Text = "S a v e"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'lblDiscount
        '
        Me.lblDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblDiscount.ForeColor = System.Drawing.Color.Maroon
        Me.lblDiscount.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDiscount.Location = New System.Drawing.Point(763, -89)
        Me.lblDiscount.Name = "lblDiscount"
        Me.lblDiscount.Size = New System.Drawing.Size(34, 23)
        Me.lblDiscount.TabIndex = 366
        Me.lblDiscount.Text = "Discount"
        Me.lblDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.HoverColor2 = System.Drawing.Color.White
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCancel.Location = New System.Drawing.Point(113, 15)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCancel.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(102, 28)
        Me.btnCancel.TabIndex = 277
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnPost
        '
        Me.btnPost.AlternativeGroup = Nothing
        Me.btnPost.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPost.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPost.BackColor1 = System.Drawing.Color.White
        Me.btnPost.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPost.BorderHover = True
        Me.btnPost.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPost.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPost.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPost.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPost.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPost.DrawBorder = True
        Me.btnPost.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPost.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPost.ForeColor = System.Drawing.Color.Navy
        Me.btnPost.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPost.HoverColor2 = System.Drawing.Color.White
        Me.btnPost.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPost.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPost.Location = New System.Drawing.Point(218, 15)
        Me.btnPost.Name = "btnPost"
        Me.btnPost.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPost.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPost.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPost.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPost.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPost.SelectedText = Nothing
        Me.btnPost.Size = New System.Drawing.Size(102, 28)
        Me.btnPost.TabIndex = 12
        Me.btnPost.Text = "P o s t"
        Me.btnPost.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(855, 15)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(95, 28)
        Me.btnClose.TabIndex = 9
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(554, 547)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(13, 13)
        Me.Label3.TabIndex = 397
        Me.Label3.Text = "$"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label3.Visible = False
        '
        'txtNet2
        '
        Me.txtNet2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNet2.BackColor = System.Drawing.Color.Khaki
        Me.txtNet2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNet2.ForeColor = System.Drawing.Color.Maroon
        Me.txtNet2.Location = New System.Drawing.Point(446, 544)
        Me.txtNet2.Name = "txtNet2"
        Me.txtNet2.ReadOnly = True
        Me.txtNet2.Size = New System.Drawing.Size(107, 23)
        Me.txtNet2.TabIndex = 396
        Me.txtNet2.Text = "0"
        Me.txtNet2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtNet2.Visible = False
        '
        'lblCurrency
        '
        Me.lblCurrency.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCurrency.AutoSize = True
        Me.lblCurrency.BackColor = System.Drawing.Color.Transparent
        Me.lblCurrency.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrency.ForeColor = System.Drawing.Color.Red
        Me.lblCurrency.Location = New System.Drawing.Point(824, 548)
        Me.lblCurrency.Name = "lblCurrency"
        Me.lblCurrency.Size = New System.Drawing.Size(24, 13)
        Me.lblCurrency.TabIndex = 390
        Me.lblCurrency.Text = "LBP"
        Me.lblCurrency.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtPmtTotal
        '
        Me.txtPmtTotal.AcceptsReturn = True
        Me.txtPmtTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPmtTotal.BackColor = System.Drawing.Color.Maroon
        Me.txtPmtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPmtTotal.ForeColor = System.Drawing.Color.White
        Me.txtPmtTotal.Location = New System.Drawing.Point(714, 544)
        Me.txtPmtTotal.Name = "txtPmtTotal"
        Me.txtPmtTotal.ReadOnly = True
        Me.txtPmtTotal.Size = New System.Drawing.Size(107, 23)
        Me.txtPmtTotal.TabIndex = 377
        Me.txtPmtTotal.Text = "0"
        Me.txtPmtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblPmtTotal
        '
        Me.lblPmtTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblPmtTotal.AutoSize = True
        Me.lblPmtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPmtTotal.ForeColor = System.Drawing.Color.Maroon
        Me.lblPmtTotal.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPmtTotal.Location = New System.Drawing.Point(635, 548)
        Me.lblPmtTotal.Name = "lblPmtTotal"
        Me.lblPmtTotal.Size = New System.Drawing.Size(75, 13)
        Me.lblPmtTotal.TabIndex = 376
        Me.lblPmtTotal.Text = "Payment Total"
        Me.lblPmtTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(966, 549)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(13, 13)
        Me.Label2.TabIndex = 395
        Me.Label2.Text = "$"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label2.Visible = False
        '
        'txtPmtTotal2
        '
        Me.txtPmtTotal2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPmtTotal2.BackColor = System.Drawing.Color.Maroon
        Me.txtPmtTotal2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPmtTotal2.ForeColor = System.Drawing.Color.White
        Me.txtPmtTotal2.Location = New System.Drawing.Point(858, 544)
        Me.txtPmtTotal2.Name = "txtPmtTotal2"
        Me.txtPmtTotal2.ReadOnly = True
        Me.txtPmtTotal2.Size = New System.Drawing.Size(81, 23)
        Me.txtPmtTotal2.TabIndex = 394
        Me.txtPmtTotal2.Text = "0"
        Me.txtPmtTotal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtPmtTotal2.Visible = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(639, 6)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(228, 30)
        Me.lstDataErr.TabIndex = 340
        Me.lstDataErr.Visible = False
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(870, 7)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(52, 25)
        Me.btnDataErr.TabIndex = 339
        Me.btnDataErr.Text = "E r r o r"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'txtPmtDescription
        '
        Me.txtPmtDescription.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPmtDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPmtDescription.ForeColor = System.Drawing.Color.Navy
        Me.txtPmtDescription.Location = New System.Drawing.Point(67, 72)
        Me.txtPmtDescription.Multiline = True
        Me.txtPmtDescription.Name = "txtPmtDescription"
        Me.txtPmtDescription.Size = New System.Drawing.Size(554, 24)
        Me.txtPmtDescription.TabIndex = 385
        '
        'lblDescription
        '
        Me.lblDescription.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescription.ForeColor = System.Drawing.Color.Maroon
        Me.lblDescription.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDescription.Location = New System.Drawing.Point(10, 77)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(55, 13)
        Me.lblDescription.TabIndex = 386
        Me.lblDescription.Text = "Pmt Desc."
        Me.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'frmPayment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(954, 631)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.grpPmtDetails)
        Me.Controls.Add(Me.grpNums)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtNet2)
        Me.Controls.Add(Me.txtPmtTotal2)
        Me.Controls.Add(Me.lblCurrency)
        Me.Controls.Add(Me.txtPmtTotal)
        Me.Controls.Add(Me.lblPmtTotal)
        Me.Controls.Add(Me.lblHotKeyLabel)
        Me.Controls.Add(Me.lblHotKeys)
        Me.Controls.Add(Me.grpPmtDetailButtons)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.txtPaymentID)
        Me.Controls.Add(Me.grpDetails)
        Me.Controls.Add(Me.grpPmtDetail)
        Me.Controls.Add(Me.grpInvoices)
        Me.KeyPreview = True
        Me.Name = "frmPayment"
        Me.Text = " Payment"
        Me.grpInvoices.ResumeLayout(False)
        Me.grpInvoices.PerformLayout()
        Me.grpShowHideColumnsInvoice.ResumeLayout(False)
        CType(Me.grdInvoices, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpNums.ResumeLayout(False)
        Me.grpNums.PerformLayout()
        Me.grpDetails.ResumeLayout(False)
        Me.grpDetails.PerformLayout()
        Me.grpPmtDetail.ResumeLayout(False)
        Me.grpShowHideColumnsPmtDetails.ResumeLayout(False)
        CType(Me.grdPaymentDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpPmtDetails.ResumeLayout(False)
        Me.grpPmtDetails.PerformLayout()
        Me.grpCheck.ResumeLayout(False)
        Me.grpCheck.PerformLayout()
        Me.grpPmtDetailButtons.ResumeLayout(False)
        Me.grpPmtDetailButtons.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtPaymentID As System.Windows.Forms.TextBox
    Friend WithEvents btnShowColInvoice As System.Windows.Forms.Button
    Friend WithEvents grdInvoices As System.Windows.Forms.DataGridView
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents txtInvoiceTotal As System.Windows.Forms.TextBox
    Friend WithEvents grpDetails As System.Windows.Forms.GroupBox
    Friend WithEvents cboEmployee As System.Windows.Forms.ComboBox
    Friend WithEvents dtpPmtDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblPmtDate As System.Windows.Forms.Label
    Friend WithEvents txtPmtNum As System.Windows.Forms.TextBox
    Friend WithEvents lblPmtNumber As System.Windows.Forms.Label
    Friend WithEvents cboClient As System.Windows.Forms.ComboBox
    Friend WithEvents lblClient As System.Windows.Forms.Label
    Friend WithEvents btnInvoice As BHBut.BouncingHoverButton
    Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblEmployee As System.Windows.Forms.Label
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents lblHotKeyLabel As System.Windows.Forms.Label
    Friend WithEvents lblHotKeys As System.Windows.Forms.Label
    Friend WithEvents grdPaymentDetails As System.Windows.Forms.DataGridView
    Friend WithEvents btnShowColPmtDetails As System.Windows.Forms.Button
    Friend WithEvents lblNet As System.Windows.Forms.Label
    Friend WithEvents txtNet As System.Windows.Forms.TextBox
    Friend WithEvents lblInvoiceCurr1 As System.Windows.Forms.Label
    Friend WithEvents btnDeletePMT As BHBut.BouncingHoverButton
    Friend WithEvents btnNewPMT As BHBut.BouncingHoverButton
    Friend WithEvents btnRemoveInvoice As BHBut.BouncingHoverButton
    Friend WithEvents grpInvoices As System.Windows.Forms.GroupBox
    Friend WithEvents grpPmtDetail As System.Windows.Forms.GroupBox
    Friend WithEvents lblNetCurr As System.Windows.Forms.Label
    Friend WithEvents btnEditPmt As BHBut.BouncingHoverButton
    Friend WithEvents chkWhithStamp As System.Windows.Forms.CheckBox
    Friend WithEvents grpPmtDetails As System.Windows.Forms.GroupBox
    Friend WithEvents cboCurrency As System.Windows.Forms.ComboBox
    Friend WithEvents btnCancelPMT As BHBut.BouncingHoverButton
    Friend WithEvents txtNote As System.Windows.Forms.TextBox
    Friend WithEvents btnSavePMT As BHBut.BouncingHoverButton
    Friend WithEvents lblNote As System.Windows.Forms.Label
    Friend WithEvents lblAmount As System.Windows.Forms.Label
    Friend WithEvents txtAmount As System.Windows.Forms.TextBox
    Friend WithEvents grpCheck As System.Windows.Forms.GroupBox
    Friend WithEvents lblBank As System.Windows.Forms.Label
    Friend WithEvents cboBank As System.Windows.Forms.ComboBox
    Friend WithEvents dtpValueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkClear As System.Windows.Forms.CheckBox
    Friend WithEvents lblCheckNum As System.Windows.Forms.Label
    Friend WithEvents txtCheckNum As System.Windows.Forms.TextBox
    Friend WithEvents lblValueDate As System.Windows.Forms.Label
    Friend WithEvents cboPaymentType As System.Windows.Forms.ComboBox
    Friend WithEvents lblPmtType As System.Windows.Forms.Label
    Friend WithEvents grpPmtDetailButtons As System.Windows.Forms.GroupBox
    Friend WithEvents lblCurrency As System.Windows.Forms.Label
    Friend WithEvents txtPmtTotal As System.Windows.Forms.TextBox
    Friend WithEvents lblPmtTotal As System.Windows.Forms.Label
    Friend WithEvents btnReciept As BHBut.BouncingHoverButton
    Friend WithEvents btnSave As BHBut.BouncingHoverButton
    Friend WithEvents lblDiscount As System.Windows.Forms.Label
    Friend WithEvents btnCancel As BHBut.BouncingHoverButton
    Friend WithEvents btnPost As BHBut.BouncingHoverButton
    Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents grpShowHideColumnsInvoice As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveSettingsInvoice As System.Windows.Forms.Button
    Friend WithEvents chkLstGridColInvoice As System.Windows.Forms.CheckedListBox
    Friend WithEvents grpShowHideColumnsPmtDetails As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveSettingsPmtDetails As System.Windows.Forms.Button
    Friend WithEvents chkLstGridColPmtDetails As System.Windows.Forms.CheckedListBox
    Friend WithEvents lblInvoiceCurr2 As System.Windows.Forms.Label
    Friend WithEvents txtInvoiceTotal2 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtNet2 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtPmtTotal2 As System.Windows.Forms.TextBox
    Friend WithEvents btnSetNum As BHBut.BouncingHoverButton
    Friend WithEvents grpNums As System.Windows.Forms.GroupBox
    Friend WithEvents txtPmtTrxNum2 As System.Windows.Forms.TextBox
    Friend WithEvents lblPmtTrxNum As System.Windows.Forms.Label
    Friend WithEvents lblReceiptNum As System.Windows.Forms.Label
    Friend WithEvents txtReceiptNum2 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtReceiptNum As System.Windows.Forms.TextBox
    Friend WithEvents txtPmtTrxNum As System.Windows.Forms.TextBox
    Friend WithEvents txtPaymentYY As System.Windows.Forms.TextBox
    Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
    Friend WithEvents btnDataErr As System.Windows.Forms.Button
    Friend WithEvents txtPmtDescription As System.Windows.Forms.TextBox
    Friend WithEvents lblDescription As System.Windows.Forms.Label
End Class
