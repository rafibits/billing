<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAccountNew
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAccountNew))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnDelete = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.grpEmployee = New System.Windows.Forms.GroupBox
        Me.lblDiscount = New System.Windows.Forms.Label
        Me.txtDiscount = New System.Windows.Forms.TextBox
        Me.grpLedger = New System.Windows.Forms.GroupBox
        Me.btnLedger = New BHBut.BouncingHoverButton
        Me.lblLedger = New System.Windows.Forms.Label
        Me.txtLedgerName = New System.Windows.Forms.TextBox
        Me.cboLedger = New System.Windows.Forms.ComboBox
        Me.lblRouting = New System.Windows.Forms.Label
        Me.lblNote = New System.Windows.Forms.Label
        Me.txtNote = New System.Windows.Forms.TextBox
        Me.grpContactInfo = New System.Windows.Forms.GroupBox
        Me.txtWWW = New System.Windows.Forms.TextBox
        Me.cboClientTitle = New System.Windows.Forms.ComboBox
        Me.lblClientTitle = New System.Windows.Forms.Label
        Me.txtFax = New System.Windows.Forms.TextBox
        Me.txtExt = New System.Windows.Forms.TextBox
        Me.txtContactName = New System.Windows.Forms.TextBox
        Me.lblContact = New System.Windows.Forms.Label
        Me.lblTel = New System.Windows.Forms.Label
        Me.txtCel = New System.Windows.Forms.TextBox
        Me.txtTel = New System.Windows.Forms.TextBox
        Me.txtEMail = New System.Windows.Forms.TextBox
        Me.lblCel = New System.Windows.Forms.Label
        Me.lblFax = New System.Windows.Forms.Label
        Me.lblEMail = New System.Windows.Forms.Label
        Me.lblWWW = New System.Windows.Forms.Label
        Me.grpName = New System.Windows.Forms.GroupBox
        Me.cboCurrency = New System.Windows.Forms.ComboBox
        Me.txtClientName = New System.Windows.Forms.TextBox
        Me.txtClientNum = New System.Windows.Forms.TextBox
        Me.lblCurrency = New System.Windows.Forms.Label
        Me.txtBalance = New System.Windows.Forms.TextBox
        Me.lblClientName = New System.Windows.Forms.Label
        Me.lblClientNum = New System.Windows.Forms.Label
        Me.lblBalance = New System.Windows.Forms.Label
        Me.txtPendingBal = New System.Windows.Forms.TextBox
        Me.lblPendingBal = New System.Windows.Forms.Label
        Me.grpInfo = New System.Windows.Forms.GroupBox
        Me.lblRoutNum = New System.Windows.Forms.Label
        Me.txtRouting = New System.Windows.Forms.TextBox
        Me.txtAccountNum = New System.Windows.Forms.TextBox
        Me.lblAccountNum = New System.Windows.Forms.Label
        Me.txtLocation = New System.Windows.Forms.TextBox
        Me.tcAddressDetail = New System.Windows.Forms.TabControl
        Me.tpViewAddress = New System.Windows.Forms.TabPage
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grdViewAddress = New System.Windows.Forms.DataGridView
        Me.btnEditAddress = New System.Windows.Forms.Button
        Me.btnDeleteAddress = New System.Windows.Forms.Button
        Me.btnNewAddress = New System.Windows.Forms.Button
        Me.tpNewAddress = New System.Windows.Forms.TabPage
        Me.btnSaveAddress = New System.Windows.Forms.Button
        Me.btnCancelAddress = New System.Windows.Forms.Button
        Me.btnNewAddress2 = New System.Windows.Forms.Button
        Me.lblAddType = New System.Windows.Forms.Label
        Me.lblStreet = New System.Windows.Forms.Label
        Me.lblCity = New System.Windows.Forms.Label
        Me.lblArea = New System.Windows.Forms.Label
        Me.lblState = New System.Windows.Forms.Label
        Me.cboState = New System.Windows.Forms.ComboBox
        Me.cboRegion = New System.Windows.Forms.ComboBox
        Me.cboQadaa = New System.Windows.Forms.ComboBox
        Me.cboAddType = New System.Windows.Forms.ComboBox
        Me.cboCity = New System.Windows.Forms.ComboBox
        Me.cboArea = New System.Windows.Forms.ComboBox
        Me.cboStreet = New System.Windows.Forms.ComboBox
        Me.lblBNF = New System.Windows.Forms.Label
        Me.txtBNF = New System.Windows.Forms.TextBox
        Me.txtAddID = New System.Windows.Forms.TextBox
        Me.lblAddID = New System.Windows.Forms.Label
        Me.tpClientItems = New System.Windows.Forms.TabPage
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.grdClientItem = New System.Windows.Forms.DataGridView
        Me.tpNewClientItem = New System.Windows.Forms.TabPage
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.ComboBox3 = New System.Windows.Forms.ComboBox
        Me.ComboBox4 = New System.Windows.Forms.ComboBox
        Me.grpList = New System.Windows.Forms.GroupBox
        Me.lstClient = New System.Windows.Forms.ListBox
        Me.txtSearch = New System.Windows.Forms.TextBox
        Me.rdbContains = New System.Windows.Forms.RadioButton
        Me.rdbLike = New System.Windows.Forms.RadioButton
        Me.txtClientID = New System.Windows.Forms.TextBox
        Me.txtPtID = New System.Windows.Forms.TextBox
        Me.toolTipClient = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtAcctTypeID = New System.Windows.Forms.TextBox
        Me.grpDeleteOptions = New System.Windows.Forms.GroupBox
        Me.lblDeleteMsg = New System.Windows.Forms.Label
        Me.btnCancelDelete = New BHBut.BouncingHoverButton
        Me.btnDeletePerminantly = New BHBut.BouncingHoverButton
        Me.btnDeleteTemp = New BHBut.BouncingHoverButton
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.lblTitle = New System.Windows.Forms.Label
        Me.grpButtons.SuspendLayout()
        Me.grpEmployee.SuspendLayout()
        Me.grpLedger.SuspendLayout()
        Me.grpContactInfo.SuspendLayout()
        Me.grpName.SuspendLayout()
        Me.grpInfo.SuspendLayout()
        Me.tcAddressDetail.SuspendLayout()
        Me.tpViewAddress.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        CType(Me.grdViewAddress, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpNewAddress.SuspendLayout()
        Me.tpClientItems.SuspendLayout()
        CType(Me.grdClientItem, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpNewClientItem.SuspendLayout()
        Me.grpList.SuspendLayout()
        Me.grpDeleteOptions.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpButtons
        '
        resources.ApplyResources(Me.grpButtons, "grpButtons")
        Me.grpButtons.Controls.Add(Me.btnDelete)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.TabStop = False
        '
        'btnDelete
        '
        Me.btnDelete.AlternativeGroup = Nothing
        resources.ApplyResources(Me.btnDelete, "btnDelete")
        Me.btnDelete.BackColor = System.Drawing.Color.Orange
        Me.btnDelete.BackColor1 = System.Drawing.Color.White
        Me.btnDelete.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnDelete.BorderHover = True
        Me.btnDelete.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDelete.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDelete.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnDelete.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDelete.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.DrawBorder = True
        Me.btnDelete.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDelete.ForeColor = System.Drawing.Color.Navy
        Me.btnDelete.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnDelete.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnDelete.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnDelete.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnDelete.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDelete.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnDelete.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnDelete.SelectedText = Nothing
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        resources.ApplyResources(Me.btnNew, "btnNew")
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNew.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        resources.ApplyResources(Me.btnClose, "btnClose")
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        resources.ApplyResources(Me.btnSave, "btnSave")
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnSave.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        resources.ApplyResources(Me.btnCancel, "btnCancel")
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCancel.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'grpEmployee
        '
        resources.ApplyResources(Me.grpEmployee, "grpEmployee")
        Me.grpEmployee.Controls.Add(Me.lblDiscount)
        Me.grpEmployee.Controls.Add(Me.txtDiscount)
        Me.grpEmployee.Controls.Add(Me.grpLedger)
        Me.grpEmployee.Controls.Add(Me.lblRouting)
        Me.grpEmployee.Controls.Add(Me.lblNote)
        Me.grpEmployee.Controls.Add(Me.txtNote)
        Me.grpEmployee.Controls.Add(Me.grpContactInfo)
        Me.grpEmployee.Controls.Add(Me.grpName)
        Me.grpEmployee.Name = "grpEmployee"
        Me.grpEmployee.TabStop = False
        '
        'lblDiscount
        '
        resources.ApplyResources(Me.lblDiscount, "lblDiscount")
        Me.lblDiscount.Name = "lblDiscount"
        '
        'txtDiscount
        '
        resources.ApplyResources(Me.txtDiscount, "txtDiscount")
        Me.txtDiscount.Name = "txtDiscount"
        '
        'grpLedger
        '
        resources.ApplyResources(Me.grpLedger, "grpLedger")
        Me.grpLedger.Controls.Add(Me.btnLedger)
        Me.grpLedger.Controls.Add(Me.lblLedger)
        Me.grpLedger.Controls.Add(Me.txtLedgerName)
        Me.grpLedger.Controls.Add(Me.cboLedger)
        Me.grpLedger.Name = "grpLedger"
        Me.grpLedger.TabStop = False
        '
        'btnLedger
        '
        Me.btnLedger.AlternativeGroup = Nothing
        resources.ApplyResources(Me.btnLedger, "btnLedger")
        Me.btnLedger.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnLedger.BackColor1 = System.Drawing.Color.White
        Me.btnLedger.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnLedger.BorderHover = True
        Me.btnLedger.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnLedger.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnLedger.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnLedger.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnLedger.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnLedger.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLedger.DrawBorder = True
        Me.btnLedger.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnLedger.ForeColor = System.Drawing.Color.Maroon
        Me.btnLedger.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnLedger.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnLedger.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnLedger.Name = "btnLedger"
        Me.btnLedger.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnLedger.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnLedger.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnLedger.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnLedger.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnLedger.SelectedText = Nothing
        Me.btnLedger.UseVisualStyleBackColor = False
        '
        'lblLedger
        '
        resources.ApplyResources(Me.lblLedger, "lblLedger")
        Me.lblLedger.ForeColor = System.Drawing.Color.Maroon
        Me.lblLedger.Name = "lblLedger"
        '
        'txtLedgerName
        '
        resources.ApplyResources(Me.txtLedgerName, "txtLedgerName")
        Me.txtLedgerName.ForeColor = System.Drawing.Color.Maroon
        Me.txtLedgerName.Name = "txtLedgerName"
        Me.txtLedgerName.ReadOnly = True
        Me.txtLedgerName.TabStop = False
        '
        'cboLedger
        '
        Me.cboLedger.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple
        resources.ApplyResources(Me.cboLedger, "cboLedger")
        Me.cboLedger.ForeColor = System.Drawing.Color.Maroon
        Me.cboLedger.FormattingEnabled = True
        Me.cboLedger.Name = "cboLedger"
        '
        'lblRouting
        '
        resources.ApplyResources(Me.lblRouting, "lblRouting")
        Me.lblRouting.Name = "lblRouting"
        '
        'lblNote
        '
        resources.ApplyResources(Me.lblNote, "lblNote")
        Me.lblNote.Name = "lblNote"
        '
        'txtNote
        '
        resources.ApplyResources(Me.txtNote, "txtNote")
        Me.txtNote.Name = "txtNote"
        '
        'grpContactInfo
        '
        resources.ApplyResources(Me.grpContactInfo, "grpContactInfo")
        Me.grpContactInfo.BackColor = System.Drawing.Color.Lavender
        Me.grpContactInfo.Controls.Add(Me.txtWWW)
        Me.grpContactInfo.Controls.Add(Me.cboClientTitle)
        Me.grpContactInfo.Controls.Add(Me.lblClientTitle)
        Me.grpContactInfo.Controls.Add(Me.txtFax)
        Me.grpContactInfo.Controls.Add(Me.txtExt)
        Me.grpContactInfo.Controls.Add(Me.txtContactName)
        Me.grpContactInfo.Controls.Add(Me.lblContact)
        Me.grpContactInfo.Controls.Add(Me.lblTel)
        Me.grpContactInfo.Controls.Add(Me.txtCel)
        Me.grpContactInfo.Controls.Add(Me.txtTel)
        Me.grpContactInfo.Controls.Add(Me.txtEMail)
        Me.grpContactInfo.Controls.Add(Me.lblCel)
        Me.grpContactInfo.Controls.Add(Me.lblFax)
        Me.grpContactInfo.Controls.Add(Me.lblEMail)
        Me.grpContactInfo.Controls.Add(Me.lblWWW)
        Me.grpContactInfo.Name = "grpContactInfo"
        Me.grpContactInfo.TabStop = False
        '
        'txtWWW
        '
        resources.ApplyResources(Me.txtWWW, "txtWWW")
        Me.txtWWW.Name = "txtWWW"
        '
        'cboClientTitle
        '
        resources.ApplyResources(Me.cboClientTitle, "cboClientTitle")
        Me.cboClientTitle.FormattingEnabled = True
        Me.cboClientTitle.Name = "cboClientTitle"
        '
        'lblClientTitle
        '
        resources.ApplyResources(Me.lblClientTitle, "lblClientTitle")
        Me.lblClientTitle.Name = "lblClientTitle"
        '
        'txtFax
        '
        resources.ApplyResources(Me.txtFax, "txtFax")
        Me.txtFax.Name = "txtFax"
        '
        'txtExt
        '
        resources.ApplyResources(Me.txtExt, "txtExt")
        Me.txtExt.Name = "txtExt"
        '
        'txtContactName
        '
        resources.ApplyResources(Me.txtContactName, "txtContactName")
        Me.txtContactName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtContactName.Name = "txtContactName"
        '
        'lblContact
        '
        resources.ApplyResources(Me.lblContact, "lblContact")
        Me.lblContact.ForeColor = System.Drawing.Color.Black
        Me.lblContact.Name = "lblContact"
        '
        'lblTel
        '
        resources.ApplyResources(Me.lblTel, "lblTel")
        Me.lblTel.Name = "lblTel"
        '
        'txtCel
        '
        resources.ApplyResources(Me.txtCel, "txtCel")
        Me.txtCel.Name = "txtCel"
        '
        'txtTel
        '
        resources.ApplyResources(Me.txtTel, "txtTel")
        Me.txtTel.Name = "txtTel"
        '
        'txtEMail
        '
        resources.ApplyResources(Me.txtEMail, "txtEMail")
        Me.txtEMail.Name = "txtEMail"
        '
        'lblCel
        '
        resources.ApplyResources(Me.lblCel, "lblCel")
        Me.lblCel.Name = "lblCel"
        '
        'lblFax
        '
        resources.ApplyResources(Me.lblFax, "lblFax")
        Me.lblFax.Name = "lblFax"
        '
        'lblEMail
        '
        resources.ApplyResources(Me.lblEMail, "lblEMail")
        Me.lblEMail.Name = "lblEMail"
        '
        'lblWWW
        '
        resources.ApplyResources(Me.lblWWW, "lblWWW")
        Me.lblWWW.Name = "lblWWW"
        '
        'grpName
        '
        resources.ApplyResources(Me.grpName, "grpName")
        Me.grpName.BackColor = System.Drawing.Color.LightYellow
        Me.grpName.Controls.Add(Me.cboCurrency)
        Me.grpName.Controls.Add(Me.txtClientName)
        Me.grpName.Controls.Add(Me.txtClientNum)
        Me.grpName.Controls.Add(Me.lblCurrency)
        Me.grpName.Controls.Add(Me.txtBalance)
        Me.grpName.Controls.Add(Me.lblClientName)
        Me.grpName.Controls.Add(Me.lblClientNum)
        Me.grpName.Controls.Add(Me.lblBalance)
        Me.grpName.Controls.Add(Me.txtPendingBal)
        Me.grpName.Controls.Add(Me.lblPendingBal)
        Me.grpName.Name = "grpName"
        Me.grpName.TabStop = False
        '
        'cboCurrency
        '
        resources.ApplyResources(Me.cboCurrency, "cboCurrency")
        Me.cboCurrency.FormattingEnabled = True
        Me.cboCurrency.Name = "cboCurrency"
        '
        'txtClientName
        '
        resources.ApplyResources(Me.txtClientName, "txtClientName")
        Me.txtClientName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtClientName.Name = "txtClientName"
        '
        'txtClientNum
        '
        Me.txtClientNum.BackColor = System.Drawing.Color.Maroon
        resources.ApplyResources(Me.txtClientNum, "txtClientNum")
        Me.txtClientNum.ForeColor = System.Drawing.Color.White
        Me.txtClientNum.Name = "txtClientNum"
        Me.txtClientNum.ReadOnly = True
        Me.txtClientNum.TabStop = False
        '
        'lblCurrency
        '
        resources.ApplyResources(Me.lblCurrency, "lblCurrency")
        Me.lblCurrency.Name = "lblCurrency"
        '
        'txtBalance
        '
        resources.ApplyResources(Me.txtBalance, "txtBalance")
        Me.txtBalance.ForeColor = System.Drawing.Color.Maroon
        Me.txtBalance.Name = "txtBalance"
        Me.txtBalance.ReadOnly = True
        Me.txtBalance.TabStop = False
        '
        'lblClientName
        '
        resources.ApplyResources(Me.lblClientName, "lblClientName")
        Me.lblClientName.ForeColor = System.Drawing.Color.Maroon
        Me.lblClientName.Name = "lblClientName"
        '
        'lblClientNum
        '
        resources.ApplyResources(Me.lblClientNum, "lblClientNum")
        Me.lblClientNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblClientNum.Name = "lblClientNum"
        '
        'lblBalance
        '
        resources.ApplyResources(Me.lblBalance, "lblBalance")
        Me.lblBalance.ForeColor = System.Drawing.Color.Maroon
        Me.lblBalance.Name = "lblBalance"
        '
        'txtPendingBal
        '
        resources.ApplyResources(Me.txtPendingBal, "txtPendingBal")
        Me.txtPendingBal.ForeColor = System.Drawing.Color.Maroon
        Me.txtPendingBal.Name = "txtPendingBal"
        Me.txtPendingBal.ReadOnly = True
        Me.txtPendingBal.TabStop = False
        '
        'lblPendingBal
        '
        Me.lblPendingBal.ForeColor = System.Drawing.Color.Maroon
        resources.ApplyResources(Me.lblPendingBal, "lblPendingBal")
        Me.lblPendingBal.Name = "lblPendingBal"
        '
        'grpInfo
        '
        resources.ApplyResources(Me.grpInfo, "grpInfo")
        Me.grpInfo.BackColor = System.Drawing.Color.LightYellow
        Me.grpInfo.Controls.Add(Me.lblRoutNum)
        Me.grpInfo.Controls.Add(Me.txtRouting)
        Me.grpInfo.Controls.Add(Me.txtAccountNum)
        Me.grpInfo.Controls.Add(Me.lblAccountNum)
        Me.grpInfo.Name = "grpInfo"
        Me.grpInfo.TabStop = False
        '
        'lblRoutNum
        '
        resources.ApplyResources(Me.lblRoutNum, "lblRoutNum")
        Me.lblRoutNum.Name = "lblRoutNum"
        '
        'txtRouting
        '
        resources.ApplyResources(Me.txtRouting, "txtRouting")
        Me.txtRouting.Name = "txtRouting"
        '
        'txtAccountNum
        '
        resources.ApplyResources(Me.txtAccountNum, "txtAccountNum")
        Me.txtAccountNum.Name = "txtAccountNum"
        '
        'lblAccountNum
        '
        resources.ApplyResources(Me.lblAccountNum, "lblAccountNum")
        Me.lblAccountNum.Name = "lblAccountNum"
        '
        'txtLocation
        '
        resources.ApplyResources(Me.txtLocation, "txtLocation")
        Me.txtLocation.Name = "txtLocation"
        '
        'tcAddressDetail
        '
        resources.ApplyResources(Me.tcAddressDetail, "tcAddressDetail")
        Me.tcAddressDetail.Controls.Add(Me.tpViewAddress)
        Me.tcAddressDetail.Controls.Add(Me.tpNewAddress)
        Me.tcAddressDetail.Controls.Add(Me.tpClientItems)
        Me.tcAddressDetail.Controls.Add(Me.tpNewClientItem)
        Me.tcAddressDetail.Name = "tcAddressDetail"
        Me.tcAddressDetail.SelectedIndex = 0
        '
        'tpViewAddress
        '
        Me.tpViewAddress.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tpViewAddress.Controls.Add(Me.grpShowHideColumns)
        Me.tpViewAddress.Controls.Add(Me.btnShowCol)
        Me.tpViewAddress.Controls.Add(Me.grdViewAddress)
        Me.tpViewAddress.Controls.Add(Me.btnEditAddress)
        Me.tpViewAddress.Controls.Add(Me.btnDeleteAddress)
        Me.tpViewAddress.Controls.Add(Me.btnNewAddress)
        resources.ApplyResources(Me.tpViewAddress, "tpViewAddress")
        Me.tpViewAddress.Name = "tpViewAddress"
        Me.tpViewAddress.UseVisualStyleBackColor = True
        '
        'grpShowHideColumns
        '
        resources.ApplyResources(Me.grpShowHideColumns, "grpShowHideColumns")
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.TabStop = False
        '
        'btnSaveSettings
        '
        resources.ApplyResources(Me.btnSaveSettings, "btnSaveSettings")
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        resources.ApplyResources(Me.chkLstGridCol, "chkLstGridCol")
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnShowCol
        '
        resources.ApplyResources(Me.btnShowCol, "btnShowCol")
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grdViewAddress
        '
        resources.ApplyResources(Me.grdViewAddress, "grdViewAddress")
        Me.grdViewAddress.BackgroundColor = System.Drawing.Color.Lavender
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.InactiveCaption
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grdViewAddress.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grdViewAddress.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdViewAddress.Name = "grdViewAddress"
        '
        'btnEditAddress
        '
        resources.ApplyResources(Me.btnEditAddress, "btnEditAddress")
        Me.btnEditAddress.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEditAddress.Name = "btnEditAddress"
        Me.btnEditAddress.UseVisualStyleBackColor = True
        '
        'btnDeleteAddress
        '
        resources.ApplyResources(Me.btnDeleteAddress, "btnDeleteAddress")
        Me.btnDeleteAddress.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDeleteAddress.Name = "btnDeleteAddress"
        Me.btnDeleteAddress.UseVisualStyleBackColor = True
        '
        'btnNewAddress
        '
        resources.ApplyResources(Me.btnNewAddress, "btnNewAddress")
        Me.btnNewAddress.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNewAddress.Name = "btnNewAddress"
        Me.btnNewAddress.UseVisualStyleBackColor = True
        '
        'tpNewAddress
        '
        resources.ApplyResources(Me.tpNewAddress, "tpNewAddress")
        Me.tpNewAddress.Controls.Add(Me.btnSaveAddress)
        Me.tpNewAddress.Controls.Add(Me.btnCancelAddress)
        Me.tpNewAddress.Controls.Add(Me.btnNewAddress2)
        Me.tpNewAddress.Controls.Add(Me.lblAddType)
        Me.tpNewAddress.Controls.Add(Me.lblStreet)
        Me.tpNewAddress.Controls.Add(Me.lblCity)
        Me.tpNewAddress.Controls.Add(Me.lblArea)
        Me.tpNewAddress.Controls.Add(Me.lblState)
        Me.tpNewAddress.Controls.Add(Me.cboState)
        Me.tpNewAddress.Controls.Add(Me.cboRegion)
        Me.tpNewAddress.Controls.Add(Me.cboQadaa)
        Me.tpNewAddress.Controls.Add(Me.cboAddType)
        Me.tpNewAddress.Controls.Add(Me.cboCity)
        Me.tpNewAddress.Controls.Add(Me.cboArea)
        Me.tpNewAddress.Controls.Add(Me.cboStreet)
        Me.tpNewAddress.Controls.Add(Me.lblBNF)
        Me.tpNewAddress.Controls.Add(Me.txtBNF)
        Me.tpNewAddress.Controls.Add(Me.txtAddID)
        Me.tpNewAddress.Controls.Add(Me.lblAddID)
        Me.tpNewAddress.Name = "tpNewAddress"
        Me.tpNewAddress.UseVisualStyleBackColor = True
        '
        'btnSaveAddress
        '
        Me.btnSaveAddress.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.btnSaveAddress, "btnSaveAddress")
        Me.btnSaveAddress.Name = "btnSaveAddress"
        Me.btnSaveAddress.UseVisualStyleBackColor = True
        '
        'btnCancelAddress
        '
        Me.btnCancelAddress.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.btnCancelAddress, "btnCancelAddress")
        Me.btnCancelAddress.Name = "btnCancelAddress"
        Me.btnCancelAddress.UseVisualStyleBackColor = True
        '
        'btnNewAddress2
        '
        Me.btnNewAddress2.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.btnNewAddress2, "btnNewAddress2")
        Me.btnNewAddress2.Name = "btnNewAddress2"
        Me.btnNewAddress2.UseVisualStyleBackColor = True
        '
        'lblAddType
        '
        resources.ApplyResources(Me.lblAddType, "lblAddType")
        Me.lblAddType.Name = "lblAddType"
        '
        'lblStreet
        '
        resources.ApplyResources(Me.lblStreet, "lblStreet")
        Me.lblStreet.Name = "lblStreet"
        '
        'lblCity
        '
        resources.ApplyResources(Me.lblCity, "lblCity")
        Me.lblCity.Name = "lblCity"
        '
        'lblArea
        '
        resources.ApplyResources(Me.lblArea, "lblArea")
        Me.lblArea.Name = "lblArea"
        '
        'lblState
        '
        resources.ApplyResources(Me.lblState, "lblState")
        Me.lblState.Name = "lblState"
        '
        'cboState
        '
        Me.cboState.FormattingEnabled = True
        resources.ApplyResources(Me.cboState, "cboState")
        Me.cboState.Name = "cboState"
        '
        'cboRegion
        '
        Me.cboRegion.FormattingEnabled = True
        resources.ApplyResources(Me.cboRegion, "cboRegion")
        Me.cboRegion.Name = "cboRegion"
        '
        'cboQadaa
        '
        Me.cboQadaa.FormattingEnabled = True
        resources.ApplyResources(Me.cboQadaa, "cboQadaa")
        Me.cboQadaa.Name = "cboQadaa"
        '
        'cboAddType
        '
        Me.cboAddType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAddType.FormattingEnabled = True
        resources.ApplyResources(Me.cboAddType, "cboAddType")
        Me.cboAddType.Name = "cboAddType"
        '
        'cboCity
        '
        Me.cboCity.FormattingEnabled = True
        resources.ApplyResources(Me.cboCity, "cboCity")
        Me.cboCity.Name = "cboCity"
        '
        'cboArea
        '
        Me.cboArea.FormattingEnabled = True
        resources.ApplyResources(Me.cboArea, "cboArea")
        Me.cboArea.Name = "cboArea"
        '
        'cboStreet
        '
        Me.cboStreet.FormattingEnabled = True
        resources.ApplyResources(Me.cboStreet, "cboStreet")
        Me.cboStreet.Name = "cboStreet"
        '
        'lblBNF
        '
        resources.ApplyResources(Me.lblBNF, "lblBNF")
        Me.lblBNF.Name = "lblBNF"
        '
        'txtBNF
        '
        resources.ApplyResources(Me.txtBNF, "txtBNF")
        Me.txtBNF.Name = "txtBNF"
        '
        'txtAddID
        '
        resources.ApplyResources(Me.txtAddID, "txtAddID")
        Me.txtAddID.Name = "txtAddID"
        Me.txtAddID.ReadOnly = True
        Me.txtAddID.TabStop = False
        '
        'lblAddID
        '
        resources.ApplyResources(Me.lblAddID, "lblAddID")
        Me.lblAddID.Name = "lblAddID"
        '
        'tpClientItems
        '
        Me.tpClientItems.Controls.Add(Me.Button1)
        Me.tpClientItems.Controls.Add(Me.Button2)
        Me.tpClientItems.Controls.Add(Me.Button3)
        Me.tpClientItems.Controls.Add(Me.grdClientItem)
        resources.ApplyResources(Me.tpClientItems, "tpClientItems")
        Me.tpClientItems.Name = "tpClientItems"
        Me.tpClientItems.UseVisualStyleBackColor = True
        '
        'Button1
        '
        resources.ApplyResources(Me.Button1, "Button1")
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Name = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        resources.ApplyResources(Me.Button2, "Button2")
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.Name = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        resources.ApplyResources(Me.Button3, "Button3")
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.Name = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'grdClientItem
        '
        resources.ApplyResources(Me.grdClientItem, "grdClientItem")
        Me.grdClientItem.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdClientItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdClientItem.Name = "grdClientItem"
        '
        'tpNewClientItem
        '
        Me.tpNewClientItem.Controls.Add(Me.Button4)
        Me.tpNewClientItem.Controls.Add(Me.Button5)
        Me.tpNewClientItem.Controls.Add(Me.TextBox1)
        Me.tpNewClientItem.Controls.Add(Me.Label1)
        Me.tpNewClientItem.Controls.Add(Me.Label2)
        Me.tpNewClientItem.Controls.Add(Me.Label3)
        Me.tpNewClientItem.Controls.Add(Me.Label4)
        Me.tpNewClientItem.Controls.Add(Me.Label5)
        Me.tpNewClientItem.Controls.Add(Me.ComboBox1)
        Me.tpNewClientItem.Controls.Add(Me.ComboBox2)
        Me.tpNewClientItem.Controls.Add(Me.ComboBox3)
        Me.tpNewClientItem.Controls.Add(Me.ComboBox4)
        resources.ApplyResources(Me.tpNewClientItem, "tpNewClientItem")
        Me.tpNewClientItem.Name = "tpNewClientItem"
        Me.tpNewClientItem.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.Button4, "Button4")
        Me.Button4.Name = "Button4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.Button5, "Button5")
        Me.Button5.Name = "Button5"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        resources.ApplyResources(Me.TextBox1, "TextBox1")
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.TabStop = False
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        resources.ApplyResources(Me.ComboBox1, "ComboBox1")
        Me.ComboBox1.Name = "ComboBox1"
        '
        'ComboBox2
        '
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.FormattingEnabled = True
        resources.ApplyResources(Me.ComboBox2, "ComboBox2")
        Me.ComboBox2.Name = "ComboBox2"
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        resources.ApplyResources(Me.ComboBox3, "ComboBox3")
        Me.ComboBox3.Name = "ComboBox3"
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        resources.ApplyResources(Me.ComboBox4, "ComboBox4")
        Me.ComboBox4.Name = "ComboBox4"
        '
        'grpList
        '
        resources.ApplyResources(Me.grpList, "grpList")
        Me.grpList.Controls.Add(Me.lstClient)
        Me.grpList.Controls.Add(Me.txtSearch)
        Me.grpList.Controls.Add(Me.rdbContains)
        Me.grpList.Controls.Add(Me.rdbLike)
        Me.grpList.Name = "grpList"
        Me.grpList.TabStop = False
        '
        'lstClient
        '
        resources.ApplyResources(Me.lstClient, "lstClient")
        Me.lstClient.FormattingEnabled = True
        Me.lstClient.Name = "lstClient"
        '
        'txtSearch
        '
        resources.ApplyResources(Me.txtSearch, "txtSearch")
        Me.txtSearch.Name = "txtSearch"
        '
        'rdbContains
        '
        resources.ApplyResources(Me.rdbContains, "rdbContains")
        Me.rdbContains.Name = "rdbContains"
        Me.rdbContains.UseVisualStyleBackColor = True
        '
        'rdbLike
        '
        resources.ApplyResources(Me.rdbLike, "rdbLike")
        Me.rdbLike.Checked = True
        Me.rdbLike.Name = "rdbLike"
        Me.rdbLike.TabStop = True
        Me.rdbLike.UseVisualStyleBackColor = True
        '
        'txtClientID
        '
        resources.ApplyResources(Me.txtClientID, "txtClientID")
        Me.txtClientID.Name = "txtClientID"
        '
        'txtPtID
        '
        Me.txtPtID.BackColor = System.Drawing.SystemColors.Control
        Me.txtPtID.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtPtID.ForeColor = System.Drawing.SystemColors.MenuBar
        resources.ApplyResources(Me.txtPtID, "txtPtID")
        Me.txtPtID.Name = "txtPtID"
        Me.txtPtID.TabStop = False
        '
        'toolTipClient
        '
        Me.toolTipClient.Active = False
        '
        'txtAcctTypeID
        '
        resources.ApplyResources(Me.txtAcctTypeID, "txtAcctTypeID")
        Me.txtAcctTypeID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAcctTypeID.Name = "txtAcctTypeID"
        '
        'grpDeleteOptions
        '
        resources.ApplyResources(Me.grpDeleteOptions, "grpDeleteOptions")
        Me.grpDeleteOptions.Controls.Add(Me.lblDeleteMsg)
        Me.grpDeleteOptions.Controls.Add(Me.btnCancelDelete)
        Me.grpDeleteOptions.Controls.Add(Me.btnDeletePerminantly)
        Me.grpDeleteOptions.Controls.Add(Me.btnDeleteTemp)
        Me.grpDeleteOptions.Name = "grpDeleteOptions"
        Me.grpDeleteOptions.TabStop = False
        '
        'lblDeleteMsg
        '
        resources.ApplyResources(Me.lblDeleteMsg, "lblDeleteMsg")
        Me.lblDeleteMsg.ForeColor = System.Drawing.Color.Maroon
        Me.lblDeleteMsg.Name = "lblDeleteMsg"
        '
        'btnCancelDelete
        '
        Me.btnCancelDelete.AlternativeGroup = Nothing
        resources.ApplyResources(Me.btnCancelDelete, "btnCancelDelete")
        Me.btnCancelDelete.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancelDelete.BackColor1 = System.Drawing.Color.White
        Me.btnCancelDelete.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancelDelete.BorderHover = True
        Me.btnCancelDelete.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancelDelete.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancelDelete.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCancelDelete.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancelDelete.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancelDelete.DrawBorder = True
        Me.btnCancelDelete.FlatStyle = BHBut.BouncingHoverButton.FltStyle.Standard
        Me.btnCancelDelete.ForeColor = System.Drawing.Color.Navy
        Me.btnCancelDelete.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancelDelete.HoverColor2 = System.Drawing.Color.White
        Me.btnCancelDelete.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancelDelete.Name = "btnCancelDelete"
        Me.btnCancelDelete.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancelDelete.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCancelDelete.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCancelDelete.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCancelDelete.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCancelDelete.SelectedText = Nothing
        Me.btnCancelDelete.UseVisualStyleBackColor = False
        '
        'btnDeletePerminantly
        '
        Me.btnDeletePerminantly.AlternativeGroup = Nothing
        resources.ApplyResources(Me.btnDeletePerminantly, "btnDeletePerminantly")
        Me.btnDeletePerminantly.BackColor = System.Drawing.Color.LightSlateGray
        Me.btnDeletePerminantly.BackColor1 = System.Drawing.Color.White
        Me.btnDeletePerminantly.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnDeletePerminantly.BorderHover = True
        Me.btnDeletePerminantly.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDeletePerminantly.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDeletePerminantly.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDeletePerminantly.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDeletePerminantly.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDeletePerminantly.DrawBorder = True
        Me.btnDeletePerminantly.FlatStyle = BHBut.BouncingHoverButton.FltStyle.Standard
        Me.btnDeletePerminantly.ForeColor = System.Drawing.Color.White
        Me.btnDeletePerminantly.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDeletePerminantly.HoverColor2 = System.Drawing.Color.White
        Me.btnDeletePerminantly.HoverForeColor = System.Drawing.Color.White
        Me.btnDeletePerminantly.Name = "btnDeletePerminantly"
        Me.btnDeletePerminantly.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDeletePerminantly.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnDeletePerminantly.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDeletePerminantly.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDeletePerminantly.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnDeletePerminantly.SelectedText = Nothing
        Me.btnDeletePerminantly.UseVisualStyleBackColor = False
        '
        'btnDeleteTemp
        '
        Me.btnDeleteTemp.AlternativeGroup = Nothing
        resources.ApplyResources(Me.btnDeleteTemp, "btnDeleteTemp")
        Me.btnDeleteTemp.BackColor = System.Drawing.Color.Tan
        Me.btnDeleteTemp.BackColor1 = System.Drawing.Color.White
        Me.btnDeleteTemp.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnDeleteTemp.BorderHover = True
        Me.btnDeleteTemp.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDeleteTemp.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDeleteTemp.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDeleteTemp.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDeleteTemp.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDeleteTemp.DrawBorder = True
        Me.btnDeleteTemp.FlatStyle = BHBut.BouncingHoverButton.FltStyle.Standard
        Me.btnDeleteTemp.ForeColor = System.Drawing.Color.Navy
        Me.btnDeleteTemp.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDeleteTemp.HoverColor2 = System.Drawing.Color.White
        Me.btnDeleteTemp.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDeleteTemp.Name = "btnDeleteTemp"
        Me.btnDeleteTemp.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDeleteTemp.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnDeleteTemp.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDeleteTemp.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDeleteTemp.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnDeleteTemp.SelectedText = Nothing
        Me.btnDeleteTemp.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        resources.ApplyResources(Me.PictureBox1, "PictureBox1")
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.LightSteelBlue
        resources.ApplyResources(Me.lblTitle, "lblTitle")
        Me.lblTitle.ForeColor = System.Drawing.Color.Black
        Me.lblTitle.Name = "lblTitle"
        '
        'frmAccountNew
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.grpDeleteOptions)
        Me.Controls.Add(Me.tcAddressDetail)
        Me.Controls.Add(Me.txtPtID)
        Me.Controls.Add(Me.grpInfo)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grpEmployee)
        Me.Controls.Add(Me.grpList)
        Me.Controls.Add(Me.txtClientID)
        Me.Controls.Add(Me.txtLocation)
        Me.Controls.Add(Me.txtAcctTypeID)
        Me.Name = "frmAccountNew"
        Me.grpButtons.ResumeLayout(False)
        Me.grpEmployee.ResumeLayout(False)
        Me.grpEmployee.PerformLayout()
        Me.grpLedger.ResumeLayout(False)
        Me.grpLedger.PerformLayout()
        Me.grpContactInfo.ResumeLayout(False)
        Me.grpContactInfo.PerformLayout()
        Me.grpName.ResumeLayout(False)
        Me.grpName.PerformLayout()
        Me.grpInfo.ResumeLayout(False)
        Me.grpInfo.PerformLayout()
        Me.tcAddressDetail.ResumeLayout(False)
        Me.tpViewAddress.ResumeLayout(False)
        Me.grpShowHideColumns.ResumeLayout(False)
        CType(Me.grdViewAddress, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpNewAddress.ResumeLayout(False)
        Me.tpNewAddress.PerformLayout()
        Me.tpClientItems.ResumeLayout(False)
        CType(Me.grdClientItem, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpNewClientItem.ResumeLayout(False)
        Me.tpNewClientItem.PerformLayout()
        Me.grpList.ResumeLayout(False)
        Me.grpList.PerformLayout()
        Me.grpDeleteOptions.ResumeLayout(False)
        Me.grpDeleteOptions.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
    Friend WithEvents btnNew As BHBut.BouncingHoverButton
    Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents btnSave As BHBut.BouncingHoverButton
    Friend WithEvents btnCancel As BHBut.BouncingHoverButton
    Friend WithEvents grpEmployee As System.Windows.Forms.GroupBox
    Friend WithEvents tcAddressDetail As System.Windows.Forms.TabControl
    Friend WithEvents tpViewAddress As System.Windows.Forms.TabPage
    Friend WithEvents btnEditAddress As System.Windows.Forms.Button
    Friend WithEvents btnDeleteAddress As System.Windows.Forms.Button
    Friend WithEvents btnNewAddress As System.Windows.Forms.Button
    Friend WithEvents grdViewAddress As System.Windows.Forms.DataGridView
    Friend WithEvents tpNewAddress As System.Windows.Forms.TabPage
    Friend WithEvents txtAddID As System.Windows.Forms.TextBox
    Friend WithEvents btnSaveAddress As System.Windows.Forms.Button
    Friend WithEvents btnCancelAddress As System.Windows.Forms.Button
    Friend WithEvents btnNewAddress2 As System.Windows.Forms.Button
    Friend WithEvents lblAddType As System.Windows.Forms.Label
    Friend WithEvents lblStreet As System.Windows.Forms.Label
    Friend WithEvents lblCity As System.Windows.Forms.Label
    Friend WithEvents lblArea As System.Windows.Forms.Label
    Friend WithEvents lblState As System.Windows.Forms.Label
    Friend WithEvents lblAddID As System.Windows.Forms.Label
    Friend WithEvents cboState As System.Windows.Forms.ComboBox
    Friend WithEvents cboRegion As System.Windows.Forms.ComboBox
    Friend WithEvents cboQadaa As System.Windows.Forms.ComboBox
    Friend WithEvents cboAddType As System.Windows.Forms.ComboBox
    Friend WithEvents cboCity As System.Windows.Forms.ComboBox
    Friend WithEvents cboArea As System.Windows.Forms.ComboBox
    Friend WithEvents cboStreet As System.Windows.Forms.ComboBox
    Friend WithEvents lblBNF As System.Windows.Forms.Label
    Friend WithEvents txtBNF As System.Windows.Forms.TextBox
    Friend WithEvents grpContactInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblCel As System.Windows.Forms.Label
    Friend WithEvents lblTel As System.Windows.Forms.Label
    Friend WithEvents lblEMail As System.Windows.Forms.Label
    Friend WithEvents txtCel As System.Windows.Forms.TextBox
    Friend WithEvents txtTel As System.Windows.Forms.TextBox
    Friend WithEvents txtEMail As System.Windows.Forms.TextBox
    Friend WithEvents grpLedger As System.Windows.Forms.GroupBox
    Friend WithEvents btnLedger As BHBut.BouncingHoverButton
    Friend WithEvents lblLedger As System.Windows.Forms.Label
    Friend WithEvents txtLedgerName As System.Windows.Forms.TextBox
    Friend WithEvents cboLedger As System.Windows.Forms.ComboBox
    Friend WithEvents grpInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblRouting As System.Windows.Forms.Label
    Friend WithEvents lblAccountNum As System.Windows.Forms.Label
    Friend WithEvents grpName As System.Windows.Forms.GroupBox
    Friend WithEvents txtClientName As System.Windows.Forms.TextBox
    Friend WithEvents txtClientNum As System.Windows.Forms.TextBox
    Friend WithEvents lblClientName As System.Windows.Forms.Label
    Friend WithEvents lblClientNum As System.Windows.Forms.Label
    Friend WithEvents grpList As System.Windows.Forms.GroupBox
    Friend WithEvents lstClient As System.Windows.Forms.ListBox
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents rdbContains As System.Windows.Forms.RadioButton
    Friend WithEvents rdbLike As System.Windows.Forms.RadioButton
    Friend WithEvents txtBalance As System.Windows.Forms.TextBox
    Friend WithEvents txtPendingBal As System.Windows.Forms.TextBox
    Friend WithEvents lblPendingBal As System.Windows.Forms.Label
    Friend WithEvents lblBalance As System.Windows.Forms.Label
    Friend WithEvents lblCurrency As System.Windows.Forms.Label
    Friend WithEvents lblNote As System.Windows.Forms.Label
    Friend WithEvents txtNote As System.Windows.Forms.TextBox
    Friend WithEvents txtClientID As System.Windows.Forms.TextBox
    Friend WithEvents txtPtID As System.Windows.Forms.TextBox
    Friend WithEvents txtLocation As System.Windows.Forms.TextBox
    Friend WithEvents toolTipClient As System.Windows.Forms.ToolTip
    Friend WithEvents cboCurrency As System.Windows.Forms.ComboBox
    Friend WithEvents txtRouting As System.Windows.Forms.TextBox
    Friend WithEvents txtAccountNum As System.Windows.Forms.TextBox
    Friend WithEvents lblRoutNum As System.Windows.Forms.Label
    Friend WithEvents txtAcctTypeID As System.Windows.Forms.TextBox
    Friend WithEvents txtContactName As System.Windows.Forms.TextBox
    Friend WithEvents lblContact As System.Windows.Forms.Label
    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents txtExt As System.Windows.Forms.TextBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
    Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
    Friend WithEvents btnShowCol As System.Windows.Forms.Button
    Friend WithEvents grpDeleteOptions As System.Windows.Forms.GroupBox
    Friend WithEvents lblDeleteMsg As System.Windows.Forms.Label
    Friend WithEvents btnCancelDelete As BHBut.BouncingHoverButton
    Friend WithEvents btnDeletePerminantly As BHBut.BouncingHoverButton
    Friend WithEvents btnDeleteTemp As BHBut.BouncingHoverButton
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents btnDelete As BHBut.BouncingHoverButton
    Friend WithEvents cboClientTitle As System.Windows.Forms.ComboBox
    Friend WithEvents lblClientTitle As System.Windows.Forms.Label
    Friend WithEvents txtWWW As System.Windows.Forms.TextBox
    Friend WithEvents lblWWW As System.Windows.Forms.Label
    Friend WithEvents lblDiscount As System.Windows.Forms.Label
    Friend WithEvents txtDiscount As System.Windows.Forms.TextBox
    Friend WithEvents tpClientItems As System.Windows.Forms.TabPage
    Friend WithEvents tpNewClientItem As System.Windows.Forms.TabPage
    Friend WithEvents grdClientItem As System.Windows.Forms.DataGridView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
End Class
