<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmContractList
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing AndAlso components IsNot Nothing Then
			components.Dispose()
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.grdContractList = New System.Windows.Forms.DataGridView
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnAutoGenerateInvoice = New BHBut.BouncingHoverButton
        Me.btnPrint = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnEdit = New BHBut.BouncingHoverButton
        Me.cboArea = New System.Windows.Forms.ComboBox
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.lblRefNumber = New System.Windows.Forms.Label
        Me.txtRefNum = New System.Windows.Forms.TextBox
        Me.cboContractType = New System.Windows.Forms.ComboBox
        Me.lblContractType = New System.Windows.Forms.Label
        Me.lblContractNum = New System.Windows.Forms.Label
        Me.txtContractNum = New System.Windows.Forms.TextBox
        Me.lblArea = New System.Windows.Forms.Label
        Me.dtpContractDateTo = New System.Windows.Forms.DateTimePicker
        Me.lblDateFrom = New System.Windows.Forms.Label
        Me.dtpContractDateFrom = New System.Windows.Forms.DateTimePicker
        Me.lblDateTo = New System.Windows.Forms.Label
        Me.lblClient = New System.Windows.Forms.Label
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        CType(Me.grdContractList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpButtons.SuspendLayout()
        Me.grpFilter.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        Me.SuspendLayout()
        '
        'grdContractList
        '
        Me.grdContractList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdContractList.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdContractList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdContractList.Location = New System.Drawing.Point(5, 128)
        Me.grdContractList.Name = "grdContractList"
        Me.grdContractList.Size = New System.Drawing.Size(817, 357)
        Me.grdContractList.TabIndex = 0
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnAutoGenerateInvoice)
        Me.grpButtons.Controls.Add(Me.btnPrint)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Controls.Add(Me.btnEdit)
        Me.grpButtons.Location = New System.Drawing.Point(5, 491)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(816, 52)
        Me.grpButtons.TabIndex = 155
        Me.grpButtons.TabStop = False
        '
        'btnAutoGenerateInvoice
        '
        Me.btnAutoGenerateInvoice.AlternativeGroup = Nothing
        Me.btnAutoGenerateInvoice.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnAutoGenerateInvoice.BackColor = System.Drawing.Color.Red
        Me.btnAutoGenerateInvoice.BackColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.BackColor2 = System.Drawing.Color.Red
        Me.btnAutoGenerateInvoice.BorderHover = True
        Me.btnAutoGenerateInvoice.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnAutoGenerateInvoice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnAutoGenerateInvoice.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnAutoGenerateInvoice.DrawBorder = True
        Me.btnAutoGenerateInvoice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnAutoGenerateInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAutoGenerateInvoice.ForeColor = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.HoverColor2 = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnAutoGenerateInvoice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnAutoGenerateInvoice.Location = New System.Drawing.Point(109, 15)
        Me.btnAutoGenerateInvoice.Name = "btnAutoGenerateInvoice"
        Me.btnAutoGenerateInvoice.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnAutoGenerateInvoice.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnAutoGenerateInvoice.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.SelectedText = Nothing
        Me.btnAutoGenerateInvoice.Size = New System.Drawing.Size(242, 28)
        Me.btnAutoGenerateInvoice.TabIndex = 165
        Me.btnAutoGenerateInvoice.Text = "Generate Invoice for Above Selection"
        Me.btnAutoGenerateInvoice.UseVisualStyleBackColor = False
        Me.btnAutoGenerateInvoice.Visible = False
        '
        'btnPrint
        '
        Me.btnPrint.AlternativeGroup = Nothing
        Me.btnPrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPrint.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPrint.BackColor1 = System.Drawing.Color.White
        Me.btnPrint.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPrint.BorderHover = True
        Me.btnPrint.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPrint.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPrint.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPrint.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPrint.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPrint.DrawBorder = True
        Me.btnPrint.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPrint.ForeColor = System.Drawing.Color.Navy
        Me.btnPrint.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.HoverColor2 = System.Drawing.Color.White
        Me.btnPrint.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPrint.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPrint.Location = New System.Drawing.Point(4, 15)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPrint.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPrint.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPrint.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.SelectedText = Nothing
        Me.btnPrint.Size = New System.Drawing.Size(99, 27)
        Me.btnPrint.TabIndex = 159
        Me.btnPrint.Text = "P r e v i e w"
        Me.btnPrint.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(711, 15)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(99, 27)
        Me.btnClose.TabIndex = 157
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.HoverColor2 = System.Drawing.Color.White
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNew.Location = New System.Drawing.Point(497, 15)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(99, 27)
        Me.btnNew.TabIndex = 156
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        Me.btnNew.Visible = False
        '
        'btnEdit
        '
        Me.btnEdit.AlternativeGroup = Nothing
        Me.btnEdit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnEdit.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BackColor1 = System.Drawing.Color.White
        Me.btnEdit.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BorderHover = True
        Me.btnEdit.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEdit.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEdit.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnEdit.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEdit.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEdit.DrawBorder = True
        Me.btnEdit.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnEdit.ForeColor = System.Drawing.Color.Navy
        Me.btnEdit.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.HoverColor2 = System.Drawing.Color.White
        Me.btnEdit.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEdit.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnEdit.Location = New System.Drawing.Point(602, 15)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnEdit.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnEdit.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnEdit.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.SelectedText = Nothing
        Me.btnEdit.Size = New System.Drawing.Size(99, 27)
        Me.btnEdit.TabIndex = 158
        Me.btnEdit.Text = "E d i t"
        Me.btnEdit.UseVisualStyleBackColor = False
        Me.btnEdit.Visible = False
        '
        'cboArea
        '
        Me.cboArea.FormattingEnabled = True
        Me.cboArea.Location = New System.Drawing.Point(255, 43)
        Me.cboArea.Name = "cboArea"
        Me.cboArea.Size = New System.Drawing.Size(243, 21)
        Me.cboArea.TabIndex = 23
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.lblRefNumber)
        Me.grpFilter.Controls.Add(Me.txtRefNum)
        Me.grpFilter.Controls.Add(Me.cboContractType)
        Me.grpFilter.Controls.Add(Me.lblContractType)
        Me.grpFilter.Controls.Add(Me.lblContractNum)
        Me.grpFilter.Controls.Add(Me.cboArea)
        Me.grpFilter.Controls.Add(Me.txtContractNum)
        Me.grpFilter.Controls.Add(Me.lblArea)
        Me.grpFilter.Controls.Add(Me.dtpContractDateTo)
        Me.grpFilter.Controls.Add(Me.lblDateFrom)
        Me.grpFilter.Controls.Add(Me.dtpContractDateFrom)
        Me.grpFilter.Controls.Add(Me.lblDateTo)
        Me.grpFilter.Controls.Add(Me.lblClient)
        Me.grpFilter.Controls.Add(Me.cboClient)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(5, 45)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(816, 76)
        Me.grpFilter.TabIndex = 157
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Data Filter"
        '
        'lblRefNumber
        '
        Me.lblRefNumber.AutoSize = True
        Me.lblRefNumber.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblRefNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRefNumber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblRefNumber.Location = New System.Drawing.Point(9, 44)
        Me.lblRefNumber.Name = "lblRefNumber"
        Me.lblRefNumber.Size = New System.Drawing.Size(60, 13)
        Me.lblRefNumber.TabIndex = 172
        Me.lblRefNumber.Text = "Ref Num."
        Me.lblRefNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtRefNum
        '
        Me.txtRefNum.AcceptsReturn = True
        Me.txtRefNum.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRefNum.ForeColor = System.Drawing.Color.Black
        Me.txtRefNum.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtRefNum.Location = New System.Drawing.Point(71, 43)
        Me.txtRefNum.Multiline = True
        Me.txtRefNum.Name = "txtRefNum"
        Me.txtRefNum.Size = New System.Drawing.Size(106, 20)
        Me.txtRefNum.TabIndex = 171
        '
        'cboContractType
        '
        Me.cboContractType.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboContractType.BackColor = System.Drawing.SystemColors.Window
        Me.cboContractType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboContractType.ForeColor = System.Drawing.Color.Black
        Me.cboContractType.FormattingEnabled = True
        Me.cboContractType.ItemHeight = 13
        Me.cboContractType.Location = New System.Drawing.Point(586, 43)
        Me.cboContractType.Name = "cboContractType"
        Me.cboContractType.Size = New System.Drawing.Size(224, 21)
        Me.cboContractType.TabIndex = 170
        '
        'lblContractType
        '
        Me.lblContractType.AutoSize = True
        Me.lblContractType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblContractType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContractType.ForeColor = System.Drawing.Color.Navy
        Me.lblContractType.Location = New System.Drawing.Point(504, 44)
        Me.lblContractType.Name = "lblContractType"
        Me.lblContractType.Size = New System.Drawing.Size(74, 13)
        Me.lblContractType.TabIndex = 169
        Me.lblContractType.Text = "Contract Type"
        Me.lblContractType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblContractNum
        '
        Me.lblContractNum.AutoSize = True
        Me.lblContractNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblContractNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblContractNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblContractNum.Location = New System.Drawing.Point(12, 20)
        Me.lblContractNum.Name = "lblContractNum"
        Me.lblContractNum.Size = New System.Drawing.Size(57, 13)
        Me.lblContractNum.TabIndex = 158
        Me.lblContractNum.Text = "Contract #"
        Me.lblContractNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtContractNum
        '
        Me.txtContractNum.AcceptsReturn = True
        Me.txtContractNum.ForeColor = System.Drawing.Color.Navy
        Me.txtContractNum.Location = New System.Drawing.Point(71, 17)
        Me.txtContractNum.Name = "txtContractNum"
        Me.txtContractNum.Size = New System.Drawing.Size(106, 20)
        Me.txtContractNum.TabIndex = 157
        Me.txtContractNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblArea
        '
        Me.lblArea.AutoSize = True
        Me.lblArea.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblArea.ForeColor = System.Drawing.Color.Maroon
        Me.lblArea.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblArea.Location = New System.Drawing.Point(181, 44)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(69, 13)
        Me.lblArea.TabIndex = 154
        Me.lblArea.Text = "Area Number"
        Me.lblArea.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpContractDateTo
        '
        Me.dtpContractDateTo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtpContractDateTo.CustomFormat = "dd MMM yyyy"
        Me.dtpContractDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpContractDateTo.Location = New System.Drawing.Point(718, 17)
        Me.dtpContractDateTo.Name = "dtpContractDateTo"
        Me.dtpContractDateTo.Size = New System.Drawing.Size(92, 20)
        Me.dtpContractDateTo.TabIndex = 16
        '
        'lblDateFrom
        '
        Me.lblDateFrom.AutoSize = True
        Me.lblDateFrom.ForeColor = System.Drawing.Color.Navy
        Me.lblDateFrom.Location = New System.Drawing.Point(521, 20)
        Me.lblDateFrom.Name = "lblDateFrom"
        Me.lblDateFrom.Size = New System.Drawing.Size(57, 13)
        Me.lblDateFrom.TabIndex = 15
        Me.lblDateFrom.Text = "Date From"
        Me.lblDateFrom.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpContractDateFrom
        '
        Me.dtpContractDateFrom.CustomFormat = "dd MMM yyyy"
        Me.dtpContractDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpContractDateFrom.Location = New System.Drawing.Point(586, 17)
        Me.dtpContractDateFrom.Name = "dtpContractDateFrom"
        Me.dtpContractDateFrom.Size = New System.Drawing.Size(92, 20)
        Me.dtpContractDateFrom.TabIndex = 14
        '
        'lblDateTo
        '
        Me.lblDateTo.AutoSize = True
        Me.lblDateTo.ForeColor = System.Drawing.Color.Navy
        Me.lblDateTo.Location = New System.Drawing.Point(688, 20)
        Me.lblDateTo.Name = "lblDateTo"
        Me.lblDateTo.Size = New System.Drawing.Size(19, 13)
        Me.lblDateTo.TabIndex = 7
        Me.lblDateTo.Text = "To"
        Me.lblDateTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblClient
        '
        Me.lblClient.AutoSize = True
        Me.lblClient.ForeColor = System.Drawing.Color.Maroon
        Me.lblClient.Location = New System.Drawing.Point(214, 20)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(34, 13)
        Me.lblClient.TabIndex = 5
        Me.lblClient.Text = "Client"
        Me.lblClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboClient
        '
        Me.cboClient.ForeColor = System.Drawing.Color.Maroon
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(254, 17)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(244, 21)
        Me.cboClient.TabIndex = 2
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(825, 3)
        Me.pnlTitle.TabIndex = 351
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(825, 40)
        Me.lblfrmTitle.TabIndex = 350
        Me.lblfrmTitle.Text = "  Contract List"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(9, 129)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 353
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(46, 133)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 327)
        Me.grpShowHideColumns.TabIndex = 352
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 298)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 244)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'frmContractList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(825, 546)
        Me.Controls.Add(Me.btnShowCol)
        Me.Controls.Add(Me.grpShowHideColumns)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.grpFilter)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grdContractList)
        Me.KeyPreview = True
        Me.Name = "frmContractList"
        Me.Text = "Contract List"
        CType(Me.grdContractList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpButtons.ResumeLayout(False)
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents grdContractList As System.Windows.Forms.DataGridView
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
	Friend WithEvents btnNew As BHBut.BouncingHoverButton
	Friend WithEvents btnEdit As BHBut.BouncingHoverButton
	Friend WithEvents cboArea As System.Windows.Forms.ComboBox
	Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
	Friend WithEvents txtContractNum As System.Windows.Forms.TextBox
	Friend WithEvents lblArea As System.Windows.Forms.Label
	Friend WithEvents dtpContractDateTo As System.Windows.Forms.DateTimePicker
	Friend WithEvents lblDateFrom As System.Windows.Forms.Label
	Friend WithEvents dtpContractDateFrom As System.Windows.Forms.DateTimePicker
	Friend WithEvents lblDateTo As System.Windows.Forms.Label
	Friend WithEvents lblClient As System.Windows.Forms.Label
	Friend WithEvents cboClient As System.Windows.Forms.ComboBox
	Friend WithEvents lblContractNum As System.Windows.Forms.Label
	Friend WithEvents pnlTitle As System.Windows.Forms.Panel
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents btnShowCol As System.Windows.Forms.Button
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
	Friend WithEvents btnPrint As BHBut.BouncingHoverButton
	Friend WithEvents btnAutoGenerateInvoice As BHBut.BouncingHoverButton
	Friend WithEvents lblRefNumber As System.Windows.Forms.Label
	Friend WithEvents txtRefNum As System.Windows.Forms.TextBox
	Friend WithEvents cboContractType As System.Windows.Forms.ComboBox
	Friend WithEvents lblContractType As System.Windows.Forms.Label
End Class
