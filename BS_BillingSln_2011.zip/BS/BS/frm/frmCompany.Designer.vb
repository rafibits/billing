<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCompany
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlFrmTitleLine = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.pnlCompanyInfo = New System.Windows.Forms.Panel
        Me.grpCompanyInfo = New System.Windows.Forms.GroupBox
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.txtCompanyNumber = New System.Windows.Forms.TextBox
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.txtCompanyName = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.lblCurrency2 = New System.Windows.Forms.Label
        Me.cboCurrency2 = New System.Windows.Forms.ComboBox
        Me.txtCurrBal = New System.Windows.Forms.TextBox
        Me.lblCurrBal = New System.Windows.Forms.Label
        Me.lblCurrID1 = New System.Windows.Forms.Label
        Me.cboCurrID = New System.Windows.Forms.ComboBox
        Me.lblCompanyNumber = New System.Windows.Forms.Label
        Me.lblNote = New System.Windows.Forms.Label
        Me.lblCompanyName = New System.Windows.Forms.Label
        Me.txtNote = New System.Windows.Forms.TextBox
        Me.PicPersonnel = New System.Windows.Forms.PictureBox
        Me.txtLocation = New System.Windows.Forms.TextBox
        Me.btnGetPicture = New System.Windows.Forms.Button
        Me.grpBtns = New System.Windows.Forms.GroupBox
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.grpBranchAccounts = New System.Windows.Forms.GroupBox
        Me.grdBranch = New System.Windows.Forms.DataGrid
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnEdit = New BHBut.BouncingHoverButton
        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblTo = New System.Windows.Forms.Label
        Me.dtpDateTo = New System.Windows.Forms.DateTimePicker
        Me.gpBranchName = New System.Windows.Forms.GroupBox
        Me.txtBranchName = New System.Windows.Forms.TextBox
        Me.btnBrNameOK = New BHBut.BouncingHoverButton
        Me.btnBrNameCancel = New BHBut.BouncingHoverButton
        Me.ofdGetPhoto = New System.Windows.Forms.OpenFileDialog
        Me.fbdDataFile = New System.Windows.Forms.FolderBrowserDialog
        Me.pnlCompanyInfo.SuspendLayout()
        Me.grpCompanyInfo.SuspendLayout()
        CType(Me.PicPersonnel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpBtns.SuspendLayout()
        Me.grpBranchAccounts.SuspendLayout()
        CType(Me.grdBranch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gpBranchName.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlFrmTitleLine
        '
        Me.pnlFrmTitleLine.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlFrmTitleLine.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlFrmTitleLine.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlFrmTitleLine.Location = New System.Drawing.Point(0, 40)
        Me.pnlFrmTitleLine.Name = "pnlFrmTitleLine"
        Me.pnlFrmTitleLine.Size = New System.Drawing.Size(808, 3)
        Me.pnlFrmTitleLine.TabIndex = 2
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(808, 40)
        Me.lblfrmTitle.TabIndex = 1
        Me.lblfrmTitle.Text = "DGCA Form"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlCompanyInfo
        '
        Me.pnlCompanyInfo.AllowDrop = True
        Me.pnlCompanyInfo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlCompanyInfo.BackColor = System.Drawing.SystemColors.Control
        Me.pnlCompanyInfo.Controls.Add(Me.grpCompanyInfo)
        Me.pnlCompanyInfo.Controls.Add(Me.grpBtns)
        Me.pnlCompanyInfo.Controls.Add(Me.grpBranchAccounts)
        Me.pnlCompanyInfo.Location = New System.Drawing.Point(12, 49)
        Me.pnlCompanyInfo.Name = "pnlCompanyInfo"
        Me.pnlCompanyInfo.Size = New System.Drawing.Size(784, 406)
        Me.pnlCompanyInfo.TabIndex = 0
        '
        'grpCompanyInfo
        '
        Me.grpCompanyInfo.Controls.Add(Me.txtCompanyNumber)
        Me.grpCompanyInfo.Controls.Add(Me.txtCompanyName)
        Me.grpCompanyInfo.Controls.Add(Me.Label2)
        Me.grpCompanyInfo.Controls.Add(Me.lblCurrency2)
        Me.grpCompanyInfo.Controls.Add(Me.cboCurrency2)
        Me.grpCompanyInfo.Controls.Add(Me.txtCurrBal)
        Me.grpCompanyInfo.Controls.Add(Me.lblCurrBal)
        Me.grpCompanyInfo.Controls.Add(Me.lblCurrID1)
        Me.grpCompanyInfo.Controls.Add(Me.cboCurrID)
        Me.grpCompanyInfo.Controls.Add(Me.lblCompanyNumber)
        Me.grpCompanyInfo.Controls.Add(Me.lblNote)
        Me.grpCompanyInfo.Controls.Add(Me.lblCompanyName)
        Me.grpCompanyInfo.Controls.Add(Me.txtNote)
        Me.grpCompanyInfo.Controls.Add(Me.PicPersonnel)
        Me.grpCompanyInfo.Controls.Add(Me.txtLocation)
        Me.grpCompanyInfo.Controls.Add(Me.btnGetPicture)
        Me.grpCompanyInfo.ImeMode = System.Windows.Forms.ImeMode.Hiragana
        Me.grpCompanyInfo.Location = New System.Drawing.Point(3, 7)
        Me.grpCompanyInfo.Name = "grpCompanyInfo"
        Me.grpCompanyInfo.Size = New System.Drawing.Size(778, 196)
        Me.grpCompanyInfo.TabIndex = 1
        Me.grpCompanyInfo.TabStop = False
        Me.grpCompanyInfo.Text = "Company Info"
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(455, 12)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(259, 17)
        Me.lstDataErr.TabIndex = 386
        Me.lstDataErr.Visible = False
        '
        'txtCompanyNumber
        '
        Me.txtCompanyNumber.BackColor = System.Drawing.Color.White
        Me.txtCompanyNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtCompanyNumber.ForeColor = System.Drawing.Color.Maroon
        Me.txtCompanyNumber.Location = New System.Drawing.Point(87, 28)
        Me.txtCompanyNumber.Name = "txtCompanyNumber"
        Me.txtCompanyNumber.ReadOnly = True
        Me.txtCompanyNumber.Size = New System.Drawing.Size(107, 26)
        Me.txtCompanyNumber.TabIndex = 3
        Me.txtCompanyNumber.TabStop = False
        Me.txtCompanyNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(718, 12)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(66, 25)
        Me.btnDataErr.TabIndex = 387
        Me.btnDataErr.Text = "Data Error"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'txtCompanyName
        '
        Me.txtCompanyName.BackColor = System.Drawing.Color.White
        Me.txtCompanyName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtCompanyName.ForeColor = System.Drawing.Color.Maroon
        Me.txtCompanyName.Location = New System.Drawing.Point(200, 27)
        Me.txtCompanyName.Name = "txtCompanyName"
        Me.txtCompanyName.Size = New System.Drawing.Size(377, 26)
        Me.txtCompanyName.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Label2.ForeColor = System.Drawing.Color.Gray
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(200, 11)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 16)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "N a m e"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblCurrency2
        '
        Me.lblCurrency2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrency2.ForeColor = System.Drawing.Color.Maroon
        Me.lblCurrency2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrency2.Location = New System.Drawing.Point(196, 70)
        Me.lblCurrency2.Name = "lblCurrency2"
        Me.lblCurrency2.Size = New System.Drawing.Size(51, 18)
        Me.lblCurrency2.TabIndex = 7
        Me.lblCurrency2.Text = "2nd Curr"
        Me.lblCurrency2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboCurrency2
        '
        Me.cboCurrency2.Enabled = False
        Me.cboCurrency2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCurrency2.ForeColor = System.Drawing.Color.Maroon
        Me.cboCurrency2.ItemHeight = 13
        Me.cboCurrency2.Location = New System.Drawing.Point(250, 70)
        Me.cboCurrency2.Name = "cboCurrency2"
        Me.cboCurrency2.Size = New System.Drawing.Size(93, 21)
        Me.cboCurrency2.TabIndex = 8
        '
        'txtCurrBal
        '
        Me.txtCurrBal.BackColor = System.Drawing.Color.White
        Me.txtCurrBal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCurrBal.Location = New System.Drawing.Point(418, 70)
        Me.txtCurrBal.Name = "txtCurrBal"
        Me.txtCurrBal.ReadOnly = True
        Me.txtCurrBal.Size = New System.Drawing.Size(159, 20)
        Me.txtCurrBal.TabIndex = 10
        Me.txtCurrBal.TabStop = False
        Me.txtCurrBal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblCurrBal
        '
        Me.lblCurrBal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrBal.ForeColor = System.Drawing.Color.Maroon
        Me.lblCurrBal.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrBal.Location = New System.Drawing.Point(346, 70)
        Me.lblCurrBal.Name = "lblCurrBal"
        Me.lblCurrBal.Size = New System.Drawing.Size(66, 18)
        Me.lblCurrBal.TabIndex = 9
        Me.lblCurrBal.Text = "Balance"
        Me.lblCurrBal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCurrID1
        '
        Me.lblCurrID1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrID1.ForeColor = System.Drawing.Color.Maroon
        Me.lblCurrID1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrID1.Location = New System.Drawing.Point(1, 70)
        Me.lblCurrID1.Name = "lblCurrID1"
        Me.lblCurrID1.Size = New System.Drawing.Size(84, 18)
        Me.lblCurrID1.TabIndex = 5
        Me.lblCurrID1.Text = "1st Currency"
        Me.lblCurrID1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboCurrID
        '
        Me.cboCurrID.Enabled = False
        Me.cboCurrID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCurrID.ForeColor = System.Drawing.Color.Maroon
        Me.cboCurrID.ItemHeight = 13
        Me.cboCurrID.Location = New System.Drawing.Point(87, 70)
        Me.cboCurrID.Name = "cboCurrID"
        Me.cboCurrID.Size = New System.Drawing.Size(107, 21)
        Me.cboCurrID.TabIndex = 6
        '
        'lblCompanyNumber
        '
        Me.lblCompanyNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblCompanyNumber.ForeColor = System.Drawing.Color.Gray
        Me.lblCompanyNumber.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCompanyNumber.Location = New System.Drawing.Point(87, 11)
        Me.lblCompanyNumber.Name = "lblCompanyNumber"
        Me.lblCompanyNumber.Size = New System.Drawing.Size(84, 16)
        Me.lblCompanyNumber.TabIndex = 0
        Me.lblCompanyNumber.Text = "N u m b e r"
        Me.lblCompanyNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblNote
        '
        Me.lblNote.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNote.ForeColor = System.Drawing.Color.Navy
        Me.lblNote.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblNote.Location = New System.Drawing.Point(6, 109)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(78, 21)
        Me.lblNote.TabIndex = 15
        Me.lblNote.Text = "Note"
        Me.lblNote.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCompanyName
        '
        Me.lblCompanyName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.lblCompanyName.ForeColor = System.Drawing.Color.Maroon
        Me.lblCompanyName.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCompanyName.Location = New System.Drawing.Point(6, 28)
        Me.lblCompanyName.Name = "lblCompanyName"
        Me.lblCompanyName.Size = New System.Drawing.Size(78, 21)
        Me.lblCompanyName.TabIndex = 2
        Me.lblCompanyName.Text = "Company"
        Me.lblCompanyName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtNote
        '
        Me.txtNote.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNote.ForeColor = System.Drawing.Color.Navy
        Me.txtNote.Location = New System.Drawing.Point(87, 112)
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.ReadOnly = True
        Me.txtNote.Size = New System.Drawing.Size(490, 66)
        Me.txtNote.TabIndex = 16
        '
        'PicPersonnel
        '
        Me.PicPersonnel.BackColor = System.Drawing.Color.Linen
        Me.PicPersonnel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PicPersonnel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PicPersonnel.Location = New System.Drawing.Point(605, 19)
        Me.PicPersonnel.Name = "PicPersonnel"
        Me.PicPersonnel.Size = New System.Drawing.Size(164, 100)
        Me.PicPersonnel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicPersonnel.TabIndex = 236
        Me.PicPersonnel.TabStop = False
        '
        'txtLocation
        '
        Me.txtLocation.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLocation.Location = New System.Drawing.Point(605, 154)
        Me.txtLocation.Name = "txtLocation"
        Me.txtLocation.Size = New System.Drawing.Size(164, 20)
        Me.txtLocation.TabIndex = 18
        Me.txtLocation.Visible = False
        '
        'btnGetPicture
        '
        Me.btnGetPicture.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnGetPicture.Enabled = False
        Me.btnGetPicture.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnGetPicture.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnGetPicture.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGetPicture.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnGetPicture.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnGetPicture.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnGetPicture.Location = New System.Drawing.Point(605, 118)
        Me.btnGetPicture.Name = "btnGetPicture"
        Me.btnGetPicture.Size = New System.Drawing.Size(164, 36)
        Me.btnGetPicture.TabIndex = 17
        Me.btnGetPicture.Text = "Get Image"
        Me.btnGetPicture.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btnGetPicture.UseCompatibleTextRendering = True
        Me.btnGetPicture.UseVisualStyleBackColor = False
        '
        'grpBtns
        '
        Me.grpBtns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpBtns.Controls.Add(Me.btnCancel)
        Me.grpBtns.Controls.Add(Me.btnClose)
        Me.grpBtns.Controls.Add(Me.btnSave)
        Me.grpBtns.Location = New System.Drawing.Point(3, 352)
        Me.grpBtns.Name = "grpBtns"
        Me.grpBtns.Size = New System.Drawing.Size(778, 53)
        Me.grpBtns.TabIndex = 0
        Me.grpBtns.TabStop = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.HoverColor2 = System.Drawing.Color.White
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCancel.Location = New System.Drawing.Point(175, 16)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCancel.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(113, 28)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(656, 16)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(113, 28)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(24, 16)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(113, 28)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "E d i t"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'grpBranchAccounts
        '
        Me.grpBranchAccounts.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpBranchAccounts.Controls.Add(Me.grdBranch)
        Me.grpBranchAccounts.Controls.Add(Me.btnNew)
        Me.grpBranchAccounts.Controls.Add(Me.btnEdit)
        Me.grpBranchAccounts.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.grpBranchAccounts.Location = New System.Drawing.Point(3, 209)
        Me.grpBranchAccounts.Name = "grpBranchAccounts"
        Me.grpBranchAccounts.Size = New System.Drawing.Size(778, 135)
        Me.grpBranchAccounts.TabIndex = 2
        Me.grpBranchAccounts.TabStop = False
        '
        'grdBranch
        '
        Me.grdBranch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grdBranch.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdBranch.CaptionBackColor = System.Drawing.SystemColors.Control
        Me.grdBranch.DataMember = ""
        Me.grdBranch.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdBranch.Location = New System.Drawing.Point(87, 19)
        Me.grdBranch.Name = "grdBranch"
        Me.grdBranch.Size = New System.Drawing.Size(400, 110)
        Me.grdBranch.TabIndex = 0
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.HoverColor2 = System.Drawing.Color.White
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNew.Location = New System.Drawing.Point(493, 19)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(84, 27)
        Me.btnNew.TabIndex = 1
        Me.btnNew.Text = "New"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnEdit
        '
        Me.btnEdit.AlternativeGroup = Nothing
        Me.btnEdit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEdit.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BackColor1 = System.Drawing.Color.White
        Me.btnEdit.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BorderHover = True
        Me.btnEdit.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEdit.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEdit.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnEdit.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEdit.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEdit.DrawBorder = True
        Me.btnEdit.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.btnEdit.ForeColor = System.Drawing.Color.Navy
        Me.btnEdit.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.HoverColor2 = System.Drawing.Color.White
        Me.btnEdit.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEdit.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnEdit.Location = New System.Drawing.Point(493, 52)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnEdit.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnEdit.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnEdit.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.SelectedText = Nothing
        Me.btnEdit.Size = New System.Drawing.Size(84, 27)
        Me.btnEdit.TabIndex = 2
        Me.btnEdit.Text = "Edit"
        Me.btnEdit.UseVisualStyleBackColor = False
        '
        'dtpDateFrom
        '
        Me.dtpDateFrom.Enabled = False
        Me.dtpDateFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDateFrom.Location = New System.Drawing.Point(181, 12)
        Me.dtpDateFrom.Name = "dtpDateFrom"
        Me.dtpDateFrom.Size = New System.Drawing.Size(37, 20)
        Me.dtpDateFrom.TabIndex = 12
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Label1.ForeColor = System.Drawing.Color.Navy
        Me.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label1.Location = New System.Drawing.Point(220, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 20)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Date From"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTo
        '
        Me.lblTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblTo.ForeColor = System.Drawing.Color.Navy
        Me.lblTo.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblTo.Location = New System.Drawing.Point(244, 12)
        Me.lblTo.Name = "lblTo"
        Me.lblTo.Size = New System.Drawing.Size(21, 20)
        Me.lblTo.TabIndex = 13
        Me.lblTo.Text = "To"
        Me.lblTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpDateTo
        '
        Me.dtpDateTo.Enabled = False
        Me.dtpDateTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDateTo.Location = New System.Drawing.Point(271, 12)
        Me.dtpDateTo.Name = "dtpDateTo"
        Me.dtpDateTo.Size = New System.Drawing.Size(39, 20)
        Me.dtpDateTo.TabIndex = 14
        '
        'gpBranchName
        '
        Me.gpBranchName.Controls.Add(Me.txtBranchName)
        Me.gpBranchName.Controls.Add(Me.btnBrNameOK)
        Me.gpBranchName.Controls.Add(Me.btnBrNameCancel)
        Me.gpBranchName.ForeColor = System.Drawing.Color.SteelBlue
        Me.gpBranchName.Location = New System.Drawing.Point(259, 207)
        Me.gpBranchName.Name = "gpBranchName"
        Me.gpBranchName.Size = New System.Drawing.Size(291, 117)
        Me.gpBranchName.TabIndex = 182
        Me.gpBranchName.TabStop = False
        Me.gpBranchName.Text = "Enter Branch Name"
        Me.gpBranchName.Visible = False
        '
        'txtBranchName
        '
        Me.txtBranchName.Location = New System.Drawing.Point(12, 33)
        Me.txtBranchName.Name = "txtBranchName"
        Me.txtBranchName.Size = New System.Drawing.Size(270, 20)
        Me.txtBranchName.TabIndex = 0
        '
        'btnBrNameOK
        '
        Me.btnBrNameOK.AlternativeGroup = Nothing
        Me.btnBrNameOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBrNameOK.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnBrNameOK.BackColor1 = System.Drawing.Color.White
        Me.btnBrNameOK.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnBrNameOK.BorderHover = True
        Me.btnBrNameOK.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnBrNameOK.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnBrNameOK.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnBrNameOK.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnBrNameOK.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnBrNameOK.DrawBorder = True
        Me.btnBrNameOK.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnBrNameOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnBrNameOK.ForeColor = System.Drawing.Color.Navy
        Me.btnBrNameOK.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnBrNameOK.HoverColor2 = System.Drawing.Color.White
        Me.btnBrNameOK.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnBrNameOK.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnBrNameOK.Location = New System.Drawing.Point(21, 75)
        Me.btnBrNameOK.Name = "btnBrNameOK"
        Me.btnBrNameOK.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnBrNameOK.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnBrNameOK.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnBrNameOK.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnBrNameOK.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnBrNameOK.SelectedText = Nothing
        Me.btnBrNameOK.Size = New System.Drawing.Size(93, 27)
        Me.btnBrNameOK.TabIndex = 0
        Me.btnBrNameOK.Text = "Ok"
        Me.btnBrNameOK.UseVisualStyleBackColor = False
        '
        'btnBrNameCancel
        '
        Me.btnBrNameCancel.AlternativeGroup = Nothing
        Me.btnBrNameCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBrNameCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnBrNameCancel.BackColor1 = System.Drawing.Color.White
        Me.btnBrNameCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnBrNameCancel.BorderHover = True
        Me.btnBrNameCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnBrNameCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnBrNameCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnBrNameCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnBrNameCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnBrNameCancel.DrawBorder = True
        Me.btnBrNameCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnBrNameCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnBrNameCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnBrNameCancel.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnBrNameCancel.HoverColor2 = System.Drawing.Color.White
        Me.btnBrNameCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnBrNameCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnBrNameCancel.Location = New System.Drawing.Point(177, 75)
        Me.btnBrNameCancel.Name = "btnBrNameCancel"
        Me.btnBrNameCancel.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnBrNameCancel.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnBrNameCancel.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnBrNameCancel.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnBrNameCancel.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnBrNameCancel.SelectedText = Nothing
        Me.btnBrNameCancel.Size = New System.Drawing.Size(93, 27)
        Me.btnBrNameCancel.TabIndex = 0
        Me.btnBrNameCancel.Text = "Cancel"
        Me.btnBrNameCancel.UseVisualStyleBackColor = False
        '
        'frmCompany
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(808, 467)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.gpBranchName)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.pnlCompanyInfo)
        Me.Controls.Add(Me.pnlFrmTitleLine)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.dtpDateTo)
        Me.Controls.Add(Me.lblTo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dtpDateFrom)
        Me.Name = "frmCompany"
        Me.Text = "Company"
        Me.pnlCompanyInfo.ResumeLayout(False)
        Me.grpCompanyInfo.ResumeLayout(False)
        Me.grpCompanyInfo.PerformLayout()
        CType(Me.PicPersonnel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpBtns.ResumeLayout(False)
        Me.grpBranchAccounts.ResumeLayout(False)
        CType(Me.grdBranch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gpBranchName.ResumeLayout(False)
        Me.gpBranchName.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents pnlFrmTitleLine As System.Windows.Forms.Panel
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents pnlCompanyInfo As System.Windows.Forms.Panel
	Friend WithEvents grpCompanyInfo As System.Windows.Forms.GroupBox
	Friend WithEvents lblCurrency2 As System.Windows.Forms.Label
	Friend WithEvents cboCurrency2 As System.Windows.Forms.ComboBox
	Friend WithEvents txtCurrBal As System.Windows.Forms.TextBox
	Friend WithEvents lblCurrBal As System.Windows.Forms.Label
	Friend WithEvents lblCurrID1 As System.Windows.Forms.Label
	Friend WithEvents cboCurrID As System.Windows.Forms.ComboBox
	Friend WithEvents txtCompanyNumber As System.Windows.Forms.TextBox
	Friend WithEvents lblCompanyNumber As System.Windows.Forms.Label
	Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents lblNote As System.Windows.Forms.Label
	Friend WithEvents lblCompanyName As System.Windows.Forms.Label
	Friend WithEvents txtNote As System.Windows.Forms.TextBox
	Friend WithEvents txtCompanyName As System.Windows.Forms.TextBox
	Friend WithEvents PicPersonnel As System.Windows.Forms.PictureBox
	Friend WithEvents txtLocation As System.Windows.Forms.TextBox
	Friend WithEvents btnGetPicture As System.Windows.Forms.Button
	Friend WithEvents lblTo As System.Windows.Forms.Label
	Friend WithEvents dtpDateTo As System.Windows.Forms.DateTimePicker
	Friend WithEvents grpBtns As System.Windows.Forms.GroupBox
	Friend WithEvents btnCancel As BHBut.BouncingHoverButton
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
	Friend WithEvents btnSave As BHBut.BouncingHoverButton
	Friend WithEvents grpBranchAccounts As System.Windows.Forms.GroupBox
	Friend WithEvents grdBranch As System.Windows.Forms.DataGrid
	Friend WithEvents btnNew As BHBut.BouncingHoverButton
	Friend WithEvents btnEdit As BHBut.BouncingHoverButton
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
	Friend WithEvents btnDataErr As System.Windows.Forms.Button
	Friend WithEvents gpBranchName As System.Windows.Forms.GroupBox
	Friend WithEvents txtBranchName As System.Windows.Forms.TextBox
	Friend WithEvents btnBrNameOK As BHBut.BouncingHoverButton
	Friend WithEvents btnBrNameCancel As BHBut.BouncingHoverButton
	Friend WithEvents ofdGetPhoto As System.Windows.Forms.OpenFileDialog
	Friend WithEvents fbdDataFile As System.Windows.Forms.FolderBrowserDialog
End Class
