<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInvoicePrepare
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.lblInvoiceNum = New System.Windows.Forms.Label
        Me.txtInvoiceNum = New System.Windows.Forms.TextBox
        Me.chkInvoiced = New System.Windows.Forms.CheckBox
        Me.dtpDateTo = New System.Windows.Forms.DateTimePicker
        Me.lblDateFrom = New System.Windows.Forms.Label
        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker
        Me.lblDateTo = New System.Windows.Forms.Label
        Me.lblClient = New System.Windows.Forms.Label
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.lblCurrSymbol = New System.Windows.Forms.Label
        Me.lblTotal = New System.Windows.Forms.Label
        Me.txtTotal = New System.Windows.Forms.TextBox
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grpGrid = New System.Windows.Forms.GroupBox
        Me.lblCounters = New System.Windows.Forms.Label
        Me.txtCounters = New System.Windows.Forms.TextBox
        Me.lblTotalTakeOffLights = New System.Windows.Forms.Label
        Me.txtTotalTakeOffLights = New System.Windows.Forms.TextBox
        Me.lblTotalCounters = New System.Windows.Forms.Label
        Me.lblTotalBridges = New System.Windows.Forms.Label
        Me.lblTotalParking = New System.Windows.Forms.Label
        Me.lblTotalLighting = New System.Windows.Forms.Label
        Me.lblTotalLanding = New System.Windows.Forms.Label
        Me.txtTotalParking = New System.Windows.Forms.TextBox
        Me.txtTotalBridges = New System.Windows.Forms.TextBox
        Me.txtTotalCounters = New System.Windows.Forms.TextBox
        Me.txtTotalLanding = New System.Windows.Forms.TextBox
        Me.txtTotalLighting = New System.Windows.Forms.TextBox
        Me.grdInvoiceList = New System.Windows.Forms.DataGridView
        Me.grpTransactionParkingArea = New System.Windows.Forms.GroupBox
        Me.grdTransactionParkingArea = New System.Windows.Forms.DataGridView
        Me.lblCurrSymbol2 = New System.Windows.Forms.Label
        Me.lblTotalCurr2 = New System.Windows.Forms.Label
        Me.txtTotalCurr2 = New System.Windows.Forms.TextBox
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnPrint = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnUpdatePrice = New BHBut.BouncingHoverButton
        Me.btnAutoGenerateInvoice = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnRefresh = New System.Windows.Forms.Button
        Me.grpFilter.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        Me.grpGrid.SuspendLayout()
        CType(Me.grdInvoiceList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpTransactionParkingArea.SuspendLayout()
        CType(Me.grdTransactionParkingArea, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(926, 3)
        Me.pnlTitle.TabIndex = 351
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(926, 40)
        Me.lblfrmTitle.TabIndex = 350
        Me.lblfrmTitle.Text = " Invoice Preparations"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.lblInvoiceNum)
        Me.grpFilter.Controls.Add(Me.txtInvoiceNum)
        Me.grpFilter.Controls.Add(Me.chkInvoiced)
        Me.grpFilter.Controls.Add(Me.dtpDateTo)
        Me.grpFilter.Controls.Add(Me.lblDateFrom)
        Me.grpFilter.Controls.Add(Me.dtpDateFrom)
        Me.grpFilter.Controls.Add(Me.lblDateTo)
        Me.grpFilter.Controls.Add(Me.lblClient)
        Me.grpFilter.Controls.Add(Me.cboClient)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(2, 49)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(912, 46)
        Me.grpFilter.TabIndex = 352
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Data Filter"
        '
        'lblInvoiceNum
        '
        Me.lblInvoiceNum.AutoSize = True
        Me.lblInvoiceNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblInvoiceNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblInvoiceNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInvoiceNum.Location = New System.Drawing.Point(568, 18)
        Me.lblInvoiceNum.Name = "lblInvoiceNum"
        Me.lblInvoiceNum.Size = New System.Drawing.Size(52, 13)
        Me.lblInvoiceNum.TabIndex = 375
        Me.lblInvoiceNum.Text = "Invoice #"
        Me.lblInvoiceNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtInvoiceNum
        '
        Me.txtInvoiceNum.ForeColor = System.Drawing.Color.Navy
        Me.txtInvoiceNum.Location = New System.Drawing.Point(621, 14)
        Me.txtInvoiceNum.Name = "txtInvoiceNum"
        Me.txtInvoiceNum.Size = New System.Drawing.Size(89, 20)
        Me.txtInvoiceNum.TabIndex = 376
        Me.txtInvoiceNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkInvoiced
        '
        Me.chkInvoiced.AutoSize = True
        Me.chkInvoiced.CausesValidation = False
        Me.chkInvoiced.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkInvoiced.ForeColor = System.Drawing.Color.Red
        Me.chkInvoiced.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkInvoiced.Location = New System.Drawing.Point(716, 17)
        Me.chkInvoiced.Name = "chkInvoiced"
        Me.chkInvoiced.Size = New System.Drawing.Size(75, 17)
        Me.chkInvoiced.TabIndex = 371
        Me.chkInvoiced.Text = "Invoiced"
        '
        'dtpDateTo
        '
        Me.dtpDateTo.CustomFormat = "dd MMM yyyy"
        Me.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateTo.Location = New System.Drawing.Point(475, 15)
        Me.dtpDateTo.Name = "dtpDateTo"
        Me.dtpDateTo.Size = New System.Drawing.Size(92, 20)
        Me.dtpDateTo.TabIndex = 16
        '
        'lblDateFrom
        '
        Me.lblDateFrom.AutoSize = True
        Me.lblDateFrom.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateFrom.Location = New System.Drawing.Point(297, 17)
        Me.lblDateFrom.Name = "lblDateFrom"
        Me.lblDateFrom.Size = New System.Drawing.Size(57, 13)
        Me.lblDateFrom.TabIndex = 15
        Me.lblDateFrom.Text = "Date From"
        Me.lblDateFrom.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpDateFrom
        '
        Me.dtpDateFrom.CustomFormat = "dd MMM yyyy"
        Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateFrom.Location = New System.Drawing.Point(356, 15)
        Me.dtpDateFrom.Name = "dtpDateFrom"
        Me.dtpDateFrom.Size = New System.Drawing.Size(92, 20)
        Me.dtpDateFrom.TabIndex = 14
        '
        'lblDateTo
        '
        Me.lblDateTo.AutoSize = True
        Me.lblDateTo.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateTo.Location = New System.Drawing.Point(453, 17)
        Me.lblDateTo.Name = "lblDateTo"
        Me.lblDateTo.Size = New System.Drawing.Size(19, 13)
        Me.lblDateTo.TabIndex = 7
        Me.lblDateTo.Text = "To"
        Me.lblDateTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblClient
        '
        Me.lblClient.AutoSize = True
        Me.lblClient.ForeColor = System.Drawing.Color.Maroon
        Me.lblClient.Location = New System.Drawing.Point(2, 17)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(34, 13)
        Me.lblClient.TabIndex = 5
        Me.lblClient.Text = "Client"
        Me.lblClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboClient
        '
        Me.cboClient.ForeColor = System.Drawing.Color.Maroon
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(38, 15)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(256, 21)
        Me.cboClient.TabIndex = 2
        '
        'lblCurrSymbol
        '
        Me.lblCurrSymbol.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblCurrSymbol.AutoSize = True
        Me.lblCurrSymbol.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol.ForeColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol.Location = New System.Drawing.Point(876, 339)
        Me.lblCurrSymbol.Name = "lblCurrSymbol"
        Me.lblCurrSymbol.Size = New System.Drawing.Size(28, 13)
        Me.lblCurrSymbol.TabIndex = 360
        Me.lblCurrSymbol.Text = "Curr"
        Me.lblCurrSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTotal
        '
        Me.lblTotal.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotal.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblTotal.Location = New System.Drawing.Point(380, 62)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(57, 20)
        Me.lblTotal.TabIndex = 358
        Me.lblTotal.Text = "Total"
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTotal
        '
        Me.txtTotal.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotal.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotal.Location = New System.Drawing.Point(449, 61)
        Me.txtTotal.Multiline = True
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(105, 23)
        Me.txtTotal.TabIndex = 359
        Me.txtTotal.TabStop = False
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(53, 13)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 279)
        Me.grpShowHideColumns.TabIndex = 155
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 250)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 184)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(6, 13)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 156
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grpGrid
        '
        Me.grpGrid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpGrid.Controls.Add(Me.lblCounters)
        Me.grpGrid.Controls.Add(Me.txtCounters)
        Me.grpGrid.Controls.Add(Me.lblTotalTakeOffLights)
        Me.grpGrid.Controls.Add(Me.txtTotalTakeOffLights)
        Me.grpGrid.Controls.Add(Me.lblTotalCounters)
        Me.grpGrid.Controls.Add(Me.lblTotalBridges)
        Me.grpGrid.Controls.Add(Me.lblTotalParking)
        Me.grpGrid.Controls.Add(Me.lblTotalLighting)
        Me.grpGrid.Controls.Add(Me.lblTotalLanding)
        Me.grpGrid.Controls.Add(Me.txtTotalParking)
        Me.grpGrid.Controls.Add(Me.txtTotalBridges)
        Me.grpGrid.Controls.Add(Me.txtTotalCounters)
        Me.grpGrid.Controls.Add(Me.txtTotalLanding)
        Me.grpGrid.Controls.Add(Me.txtTotalLighting)
        Me.grpGrid.Controls.Add(Me.lblCurrSymbol)
        Me.grpGrid.Controls.Add(Me.grpShowHideColumns)
        Me.grpGrid.Controls.Add(Me.btnShowCol)
        Me.grpGrid.Controls.Add(Me.grdInvoiceList)
        Me.grpGrid.Controls.Add(Me.grpTransactionParkingArea)
        Me.grpGrid.Location = New System.Drawing.Point(2, 92)
        Me.grpGrid.Name = "grpGrid"
        Me.grpGrid.Size = New System.Drawing.Size(912, 376)
        Me.grpGrid.TabIndex = 353
        Me.grpGrid.TabStop = False
        '
        'lblCounters
        '
        Me.lblCounters.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblCounters.AutoSize = True
        Me.lblCounters.ForeColor = System.Drawing.Color.Maroon
        Me.lblCounters.Location = New System.Drawing.Point(48, 317)
        Me.lblCounters.Name = "lblCounters"
        Me.lblCounters.Size = New System.Drawing.Size(78, 13)
        Me.lblCounters.TabIndex = 377
        Me.lblCounters.Text = "Total Counters"
        Me.lblCounters.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtCounters
        '
        Me.txtCounters.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtCounters.BackColor = System.Drawing.Color.LightYellow
        Me.txtCounters.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCounters.ForeColor = System.Drawing.Color.Maroon
        Me.txtCounters.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtCounters.Location = New System.Drawing.Point(45, 335)
        Me.txtCounters.Multiline = True
        Me.txtCounters.Name = "txtCounters"
        Me.txtCounters.ReadOnly = True
        Me.txtCounters.Size = New System.Drawing.Size(81, 23)
        Me.txtCounters.TabIndex = 376
        Me.txtCounters.TabStop = False
        Me.txtCounters.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblTotalTakeOffLights
        '
        Me.lblTotalTakeOffLights.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblTotalTakeOffLights.AutoSize = True
        Me.lblTotalTakeOffLights.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotalTakeOffLights.Location = New System.Drawing.Point(750, 318)
        Me.lblTotalTakeOffLights.Name = "lblTotalTakeOffLights"
        Me.lblTotalTakeOffLights.Size = New System.Drawing.Size(128, 13)
        Me.lblTotalTakeOffLights.TabIndex = 374
        Me.lblTotalTakeOffLights.Text = "Total TakeOff Lights fees"
        Me.lblTotalTakeOffLights.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTotalTakeOffLights
        '
        Me.txtTotalTakeOffLights.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtTotalTakeOffLights.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalTakeOffLights.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalTakeOffLights.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalTakeOffLights.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalTakeOffLights.Location = New System.Drawing.Point(753, 335)
        Me.txtTotalTakeOffLights.Multiline = True
        Me.txtTotalTakeOffLights.Name = "txtTotalTakeOffLights"
        Me.txtTotalTakeOffLights.ReadOnly = True
        Me.txtTotalTakeOffLights.Size = New System.Drawing.Size(121, 23)
        Me.txtTotalTakeOffLights.TabIndex = 373
        Me.txtTotalTakeOffLights.TabStop = False
        '
        'lblTotalCounters
        '
        Me.lblTotalCounters.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblTotalCounters.AutoSize = True
        Me.lblTotalCounters.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotalCounters.Location = New System.Drawing.Point(631, 317)
        Me.lblTotalCounters.Name = "lblTotalCounters"
        Me.lblTotalCounters.Size = New System.Drawing.Size(102, 13)
        Me.lblTotalCounters.TabIndex = 372
        Me.lblTotalCounters.Text = "Total Counters fees"
        Me.lblTotalCounters.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalBridges
        '
        Me.lblTotalBridges.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblTotalBridges.AutoSize = True
        Me.lblTotalBridges.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotalBridges.Location = New System.Drawing.Point(511, 317)
        Me.lblTotalBridges.Name = "lblTotalBridges"
        Me.lblTotalBridges.Size = New System.Drawing.Size(93, 13)
        Me.lblTotalBridges.TabIndex = 371
        Me.lblTotalBridges.Text = "Total Bridges fees"
        Me.lblTotalBridges.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalParking
        '
        Me.lblTotalParking.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblTotalParking.AutoSize = True
        Me.lblTotalParking.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotalParking.Location = New System.Drawing.Point(394, 317)
        Me.lblTotalParking.Name = "lblTotalParking"
        Me.lblTotalParking.Size = New System.Drawing.Size(93, 13)
        Me.lblTotalParking.TabIndex = 370
        Me.lblTotalParking.Text = "Total Parking fees"
        Me.lblTotalParking.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalLighting
        '
        Me.lblTotalLighting.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblTotalLighting.AutoSize = True
        Me.lblTotalLighting.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotalLighting.Location = New System.Drawing.Point(252, 317)
        Me.lblTotalLighting.Name = "lblTotalLighting"
        Me.lblTotalLighting.Size = New System.Drawing.Size(126, 13)
        Me.lblTotalLighting.TabIndex = 369
        Me.lblTotalLighting.Text = "Total Landing Lights fees"
        Me.lblTotalLighting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalLanding
        '
        Me.lblTotalLanding.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblTotalLanding.AutoSize = True
        Me.lblTotalLanding.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotalLanding.Location = New System.Drawing.Point(139, 317)
        Me.lblTotalLanding.Name = "lblTotalLanding"
        Me.lblTotalLanding.Size = New System.Drawing.Size(95, 13)
        Me.lblTotalLanding.TabIndex = 368
        Me.lblTotalLanding.Text = "Total Landing fees"
        Me.lblTotalLanding.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTotalParking
        '
        Me.txtTotalParking.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtTotalParking.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalParking.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalParking.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalParking.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalParking.Location = New System.Drawing.Point(378, 335)
        Me.txtTotalParking.Multiline = True
        Me.txtTotalParking.Name = "txtTotalParking"
        Me.txtTotalParking.ReadOnly = True
        Me.txtTotalParking.Size = New System.Drawing.Size(123, 23)
        Me.txtTotalParking.TabIndex = 367
        Me.txtTotalParking.TabStop = False
        '
        'txtTotalBridges
        '
        Me.txtTotalBridges.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtTotalBridges.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalBridges.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalBridges.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalBridges.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalBridges.Location = New System.Drawing.Point(502, 335)
        Me.txtTotalBridges.Multiline = True
        Me.txtTotalBridges.Name = "txtTotalBridges"
        Me.txtTotalBridges.ReadOnly = True
        Me.txtTotalBridges.Size = New System.Drawing.Size(123, 23)
        Me.txtTotalBridges.TabIndex = 366
        Me.txtTotalBridges.TabStop = False
        '
        'txtTotalCounters
        '
        Me.txtTotalCounters.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtTotalCounters.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalCounters.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalCounters.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalCounters.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalCounters.Location = New System.Drawing.Point(626, 335)
        Me.txtTotalCounters.Multiline = True
        Me.txtTotalCounters.Name = "txtTotalCounters"
        Me.txtTotalCounters.ReadOnly = True
        Me.txtTotalCounters.Size = New System.Drawing.Size(123, 23)
        Me.txtTotalCounters.TabIndex = 365
        Me.txtTotalCounters.TabStop = False
        '
        'txtTotalLanding
        '
        Me.txtTotalLanding.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtTotalLanding.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalLanding.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalLanding.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalLanding.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalLanding.Location = New System.Drawing.Point(129, 335)
        Me.txtTotalLanding.Multiline = True
        Me.txtTotalLanding.Name = "txtTotalLanding"
        Me.txtTotalLanding.ReadOnly = True
        Me.txtTotalLanding.Size = New System.Drawing.Size(123, 23)
        Me.txtTotalLanding.TabIndex = 364
        Me.txtTotalLanding.TabStop = False
        '
        'txtTotalLighting
        '
        Me.txtTotalLighting.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtTotalLighting.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalLighting.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalLighting.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalLighting.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalLighting.Location = New System.Drawing.Point(254, 335)
        Me.txtTotalLighting.Multiline = True
        Me.txtTotalLighting.Name = "txtTotalLighting"
        Me.txtTotalLighting.ReadOnly = True
        Me.txtTotalLighting.Size = New System.Drawing.Size(123, 23)
        Me.txtTotalLighting.TabIndex = 363
        Me.txtTotalLighting.TabStop = False
        '
        'grdInvoiceList
        '
        Me.grdInvoiceList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdInvoiceList.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdInvoiceList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdInvoiceList.Location = New System.Drawing.Point(3, 10)
        Me.grdInvoiceList.Name = "grdInvoiceList"
        Me.grdInvoiceList.Size = New System.Drawing.Size(903, 304)
        Me.grdInvoiceList.TabIndex = 152
        '
        'grpTransactionParkingArea
        '
        Me.grpTransactionParkingArea.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpTransactionParkingArea.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpTransactionParkingArea.Controls.Add(Me.grdTransactionParkingArea)
        Me.grpTransactionParkingArea.ForeColor = System.Drawing.Color.Navy
        Me.grpTransactionParkingArea.Location = New System.Drawing.Point(527, 121)
        Me.grpTransactionParkingArea.Name = "grpTransactionParkingArea"
        Me.grpTransactionParkingArea.Size = New System.Drawing.Size(365, 181)
        Me.grpTransactionParkingArea.TabIndex = 375
        Me.grpTransactionParkingArea.TabStop = False
        Me.grpTransactionParkingArea.Text = "Transaction Parking"
        Me.grpTransactionParkingArea.Visible = False
        '
        'grdTransactionParkingArea
        '
        Me.grdTransactionParkingArea.BackgroundColor = System.Drawing.Color.LightYellow
        Me.grdTransactionParkingArea.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdTransactionParkingArea.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdTransactionParkingArea.Location = New System.Drawing.Point(3, 16)
        Me.grdTransactionParkingArea.Name = "grdTransactionParkingArea"
        Me.grdTransactionParkingArea.ReadOnly = True
        Me.grdTransactionParkingArea.Size = New System.Drawing.Size(359, 162)
        Me.grdTransactionParkingArea.TabIndex = 0
        '
        'lblCurrSymbol2
        '
        Me.lblCurrSymbol2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol2.ForeColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol2.Location = New System.Drawing.Point(556, 124)
        Me.lblCurrSymbol2.Name = "lblCurrSymbol2"
        Me.lblCurrSymbol2.Size = New System.Drawing.Size(45, 20)
        Me.lblCurrSymbol2.TabIndex = 363
        Me.lblCurrSymbol2.Text = "Curr"
        Me.lblCurrSymbol2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTotalCurr2
        '
        Me.lblTotalCurr2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalCurr2.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotalCurr2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblTotalCurr2.Location = New System.Drawing.Point(380, 124)
        Me.lblTotalCurr2.Name = "lblTotalCurr2"
        Me.lblTotalCurr2.Size = New System.Drawing.Size(57, 20)
        Me.lblTotalCurr2.TabIndex = 361
        Me.lblTotalCurr2.Text = "Total"
        Me.lblTotalCurr2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTotalCurr2
        '
        Me.txtTotalCurr2.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalCurr2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalCurr2.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalCurr2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalCurr2.Location = New System.Drawing.Point(443, 121)
        Me.txtTotalCurr2.Multiline = True
        Me.txtTotalCurr2.Name = "txtTotalCurr2"
        Me.txtTotalCurr2.ReadOnly = True
        Me.txtTotalCurr2.Size = New System.Drawing.Size(105, 23)
        Me.txtTotalCurr2.TabIndex = 362
        Me.txtTotalCurr2.TabStop = False
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnPrint)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnUpdatePrice)
        Me.grpButtons.Controls.Add(Me.btnAutoGenerateInvoice)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Location = New System.Drawing.Point(2, 456)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(912, 53)
        Me.grpButtons.TabIndex = 354
        Me.grpButtons.TabStop = False
        '
        'btnPrint
        '
        Me.btnPrint.AlternativeGroup = Nothing
        Me.btnPrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPrint.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPrint.BackColor1 = System.Drawing.Color.White
        Me.btnPrint.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPrint.BorderHover = True
        Me.btnPrint.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPrint.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPrint.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPrint.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPrint.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPrint.DrawBorder = True
        Me.btnPrint.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPrint.ForeColor = System.Drawing.Color.Navy
        Me.btnPrint.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.HoverColor2 = System.Drawing.Color.White
        Me.btnPrint.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPrint.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPrint.Location = New System.Drawing.Point(201, 19)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPrint.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPrint.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPrint.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.SelectedText = Nothing
        Me.btnPrint.Size = New System.Drawing.Size(94, 27)
        Me.btnPrint.TabIndex = 168
        Me.btnPrint.Text = "Preview"
        Me.btnPrint.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.Enabled = False
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(103, 19)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(94, 27)
        Me.btnSave.TabIndex = 167
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnUpdatePrice
        '
        Me.btnUpdatePrice.AlternativeGroup = Nothing
        Me.btnUpdatePrice.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnUpdatePrice.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnUpdatePrice.BackColor1 = System.Drawing.Color.White
        Me.btnUpdatePrice.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnUpdatePrice.BorderHover = True
        Me.btnUpdatePrice.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnUpdatePrice.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnUpdatePrice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnUpdatePrice.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnUpdatePrice.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnUpdatePrice.DrawBorder = True
        Me.btnUpdatePrice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnUpdatePrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnUpdatePrice.ForeColor = System.Drawing.Color.Navy
        Me.btnUpdatePrice.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnUpdatePrice.HoverColor2 = System.Drawing.Color.White
        Me.btnUpdatePrice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnUpdatePrice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnUpdatePrice.Location = New System.Drawing.Point(5, 19)
        Me.btnUpdatePrice.Name = "btnUpdatePrice"
        Me.btnUpdatePrice.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnUpdatePrice.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnUpdatePrice.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnUpdatePrice.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnUpdatePrice.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnUpdatePrice.SelectedText = Nothing
        Me.btnUpdatePrice.Size = New System.Drawing.Size(94, 27)
        Me.btnUpdatePrice.TabIndex = 166
        Me.btnUpdatePrice.Text = "Update Price"
        Me.btnUpdatePrice.UseVisualStyleBackColor = False
        '
        'btnAutoGenerateInvoice
        '
        Me.btnAutoGenerateInvoice.AlternativeGroup = Nothing
        Me.btnAutoGenerateInvoice.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnAutoGenerateInvoice.BackColor = System.Drawing.Color.Red
        Me.btnAutoGenerateInvoice.BackColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.BackColor2 = System.Drawing.Color.Red
        Me.btnAutoGenerateInvoice.BorderHover = True
        Me.btnAutoGenerateInvoice.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnAutoGenerateInvoice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnAutoGenerateInvoice.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnAutoGenerateInvoice.DrawBorder = True
        Me.btnAutoGenerateInvoice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnAutoGenerateInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAutoGenerateInvoice.ForeColor = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.HoverColor2 = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnAutoGenerateInvoice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnAutoGenerateInvoice.Location = New System.Drawing.Point(299, 18)
        Me.btnAutoGenerateInvoice.Name = "btnAutoGenerateInvoice"
        Me.btnAutoGenerateInvoice.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnAutoGenerateInvoice.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnAutoGenerateInvoice.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.SelectedText = Nothing
        Me.btnAutoGenerateInvoice.Size = New System.Drawing.Size(252, 28)
        Me.btnAutoGenerateInvoice.TabIndex = 164
        Me.btnAutoGenerateInvoice.Text = "Generate Invoice for Above Selection"
        Me.btnAutoGenerateInvoice.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(801, 18)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(104, 27)
        Me.btnClose.TabIndex = 157
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnRefresh
        '
        Me.btnRefresh.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRefresh.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnRefresh.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnRefresh.Location = New System.Drawing.Point(819, 11)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(95, 23)
        Me.btnRefresh.TabIndex = 364
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'frmInvoicePrepare
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(926, 521)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.grpFilter)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grpGrid)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.txtTotalCurr2)
        Me.Controls.Add(Me.lblCurrSymbol2)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.lblTotalCurr2)
        Me.Controls.Add(Me.lblTotal)
        Me.KeyPreview = True
        Me.Name = "frmInvoicePrepare"
        Me.Text = " Invoice Preparations"
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.grpGrid.ResumeLayout(False)
        Me.grpGrid.PerformLayout()
        CType(Me.grdInvoiceList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpTransactionParkingArea.ResumeLayout(False)
        CType(Me.grdTransactionParkingArea, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpButtons.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
	Friend WithEvents pnlTitle As System.Windows.Forms.Panel
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
	Friend WithEvents dtpDateTo As System.Windows.Forms.DateTimePicker
	Friend WithEvents lblDateFrom As System.Windows.Forms.Label
	Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker
	Friend WithEvents lblDateTo As System.Windows.Forms.Label
	Friend WithEvents lblClient As System.Windows.Forms.Label
	Friend WithEvents cboClient As System.Windows.Forms.ComboBox
	Friend WithEvents lblCurrSymbol As System.Windows.Forms.Label
	Friend WithEvents lblTotal As System.Windows.Forms.Label
	Friend WithEvents txtTotal As System.Windows.Forms.TextBox
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
	Friend WithEvents btnShowCol As System.Windows.Forms.Button
	Friend WithEvents grpGrid As System.Windows.Forms.GroupBox
	Friend WithEvents lblCurrSymbol2 As System.Windows.Forms.Label
	Friend WithEvents lblTotalCurr2 As System.Windows.Forms.Label
	Friend WithEvents txtTotalCurr2 As System.Windows.Forms.TextBox
	Friend WithEvents grdInvoiceList As System.Windows.Forms.DataGridView
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnAutoGenerateInvoice As BHBut.BouncingHoverButton
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
	Friend WithEvents btnUpdatePrice As BHBut.BouncingHoverButton
    Friend WithEvents txtTotalParking As System.Windows.Forms.TextBox
	Friend WithEvents txtTotalBridges As System.Windows.Forms.TextBox
	Friend WithEvents txtTotalCounters As System.Windows.Forms.TextBox
	Friend WithEvents txtTotalLanding As System.Windows.Forms.TextBox
	Friend WithEvents txtTotalLighting As System.Windows.Forms.TextBox
	Friend WithEvents btnSave As BHBut.BouncingHoverButton
	Friend WithEvents lblTotalCounters As System.Windows.Forms.Label
	Friend WithEvents lblTotalBridges As System.Windows.Forms.Label
	Friend WithEvents lblTotalParking As System.Windows.Forms.Label
	Friend WithEvents lblTotalLighting As System.Windows.Forms.Label
	Friend WithEvents lblTotalLanding As System.Windows.Forms.Label
	Friend WithEvents lblTotalTakeOffLights As System.Windows.Forms.Label
	Friend WithEvents txtTotalTakeOffLights As System.Windows.Forms.TextBox
    Friend WithEvents btnPrint As BHBut.BouncingHoverButton
    Friend WithEvents grpTransactionParkingArea As System.Windows.Forms.GroupBox
	Friend WithEvents grdTransactionParkingArea As System.Windows.Forms.DataGridView
	Friend WithEvents chkInvoiced As System.Windows.Forms.CheckBox
	Friend WithEvents lblInvoiceNum As System.Windows.Forms.Label
	Friend WithEvents txtInvoiceNum As System.Windows.Forms.TextBox
	Friend WithEvents lblCounters As System.Windows.Forms.Label
	Friend WithEvents txtCounters As System.Windows.Forms.TextBox
	Friend WithEvents btnRefresh As System.Windows.Forms.Button
End Class
