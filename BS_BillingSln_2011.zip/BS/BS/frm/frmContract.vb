Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmContract

#Region "Form-Declaration..."

    Private dsdata As DataSet
    Private clsMr As ClsMain
    Private blnLoading As Boolean
    Private WithEvents Nav As BitsNav
    Private mstrCurrentGridName As String
    Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Contact\Settings"
    Private daContract As SqlDataAdapter
    Private daArea As SqlDataAdapter
    Dim dataChange As Boolean = False
    Dim mContractID As Integer
    Private mStrCurrentState As String
    Private AddMode As Boolean = False

#End Region


#Region "Form-Load..."

    Private Sub frmContract_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmContract_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        clsMr = New ClsMain(conSql)
        ''
        Nav = New BitsNav
        blnLoading = True


        MakeDataAdapter()
        FillComboBox()
        SetDataBinding()
        SetAutoNumber()
        SetCurrencyManager()

        SetDefaultValue()


        If mContractID = 0 Then
            NewRecord()
        Else
            Nav.CurrentPosition = GetRowIndex(mContractID)
            setState("BROWSE")
        End If

        blnLoading = False
        'FilterArea()
        'FilterContractTitle()

    End Sub
#End Region


#Region "Form-Initialisation..."

    Public Sub New(Optional ByVal pContractID As Integer = -1)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        mContractID = pContractID

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

    Private Sub MakeDataAdapter()
        '' set SQL for selecting active emp recs...
        daContract = clsMr.BuildSqlAdapter("SELECT * FROM tblClientContract WHERE Del=0 ", "tblClientContract")

        clsMr.BuildSqlAdapter("SELECT ContractTypeID,ContractType FROM tblContractType WHERE Del =0 ", "tblContractType")
        clsMr.BuildSqlAdapter("Select * from tblContractTitle where Del =0", "daContractTitle")
        clsMr.BuildSqlAdapter("SELECT ClientID,ClientName FROM tblClient WHERE Del =0 ORDER BY ClientName", "tblClient")
        clsMr.BuildSqlAdapter("SELECT ContractTitleID ,ContractTitle from tblContractTitle WHERE Del =0  ", "tblContractTitle")
        clsMr.BuildSqlAdapter("SELECT AreaID,AreaName,FeePerMeter from tblArea WHERE Del =0 ", "tblArea")
        clsMr.BuildSqlAdapter("SELECT * from tblArea WHERE Del =0  ", "daArea")
        dsdata = clsMr.getDataSet

    End Sub

    Private Sub FillComboBox()

        clsMr.FillComboBox("tblClient", cboClient, "ClientName", "ClientID")
        clsMr.FillComboBox("tblContractType", cboContractType, "ContractType", "ContractTypeID")
        clsMr.FillComboBox("tblContractTitle", cboContractTitle, "ContractTitle", "ContractTitleID")
        clsMr.FillComboBox("tblArea", cboAreaName, "AreaName", "AreaID")

    End Sub

    Private Sub SetCurrencyManager()
        Nav.SetCurrency(Me, dsdata, "tblClientContract")
    End Sub

    Private Sub SetDefaultValue()
        clsMr.SetDefaults("tblClientContract", "Del", 0, "ContractDate", Now.Date, "Status", 1, "AreaFee", 0, "TotalCost", 0, "StartingDate", Now.Date)
    End Sub

    Private Sub SetAutoNumber()
        Dim lngMax As Long
        clsMr.SetAutoNumber("tblClientContract", "ContractID")

        lngMax = clsMr.GetMaxNumber("select max(ContractNum) from tblClientContract") + 1
        clsMr.SetAutoNumber("tblClientContract", "ContractNum", lngMax)

    End Sub

    Private Sub SetDataBinding()
        clsMr.BindTextBox(txtContractID, "tblClientContract", "ContractID")
        clsMr.BindTextBox(txtContNum, "tblClientContract", "ContractNum")
        clsMr.BindDateTimePicker(dtpContractDate, "tblClientContract", "ContractDate")
        clsMr.BindComboBox(cboClient, "tblClientContract", "ClientID")
        clsMr.BindComboBox(cboContractType, "tblClientContract", "ContractTypeID")
        clsMr.BindComboBox(cboContractTitle, "tblClientContract", "ContractTitleID")
        clsMr.BindComboBox(cboAreaName, "tblClientContract", "AreaID")
        clsMr.BindTextBox(txtAreaSqm, "tblClientContract", "AreaSQM")
        clsMr.BindTextBox(txtAreaNote, "tblClientContract", "Note")
        clsMr.BindCheckBox(chkStatus, "tblClientContract", "Status")
        clsMr.BindTextBox(txtAreaFeeTotal, "tblClientContract", "TotalCost")
        clsMr.BindTextBox(txtAreaFee, "tblClientContract", "AreaFee")
        clsMr.BindDateTimePicker(dtpStartingDay, "tblClientContract", "StartingDate")
        clsMr.BindTextBox(txtOffice, "tblClientContract", "Office")
        clsMr.BindTextBox(txtPhoneFee, "tblClientContract", "AnnualPhoneFee")
    End Sub
#End Region


#Region "Function........"

    Private Sub DrawGrid()
        grdArea.DataSource = dsdata.Tables("daArea").DefaultView
        grdArea.Columns("AreaID").Visible = False
        grdArea.Columns("AreaTypeID").Visible = False
        grdArea.Columns("FeePerMeter").Visible = False
        grdArea.Columns("AreaName").Visible = False
        grdArea.Columns("Occupied").Visible = False
        grdArea.Columns("CreateBy").Visible = False
        grdArea.Columns("CreateDate").Visible = False
    End Sub

    Private Sub CalculateTotal()
        If blnLoading = True Then Exit Sub
        txtAreaFeeTotal.Text = CDbl(txtAreaFee.Text) * CDbl(txtAreaSqm.Text)
    End Sub

    Private Sub NewRecord()
        ''Add New Record
        Nav.AddNew()

        ''Reset Columns
        txtAreaSqm.Text = ""
        cboAreaName.SelectedIndex = -1
        cboClient.SelectedIndex = -1
        cboContractTitle.SelectedIndex = -1
        txtAreaFee.Text = ""
        cboContractType.SelectedIndex = -1
        txtLawSection.Text = ""
        setState("NEW")
        FilterArea()


    End Sub

    Public Function GetRowIndex(ByVal pContractID As Long) As Integer

        Dim i As Integer

        For i = 0 To dsdata.Tables("tblClientContract").DefaultView.Count - 1
            If dsdata.Tables("tblClientContract").DefaultView.Item(i)("ContractID") = pContractID Then
                Return i
            End If
        Next

        Return -1

    End Function

    Private Sub FilterArea()
        If cboAreaName.SelectedIndex <> -1 Then
            dsdata.Tables("daArea").DefaultView.RowFilter = "AreaID= " & cboAreaName.SelectedValue
        End If

    End Sub

    Private Sub AddAreaFee()
        If cboAreaName.SelectedIndex <> -1 Then
            Dim drAreaFee() As DataRow = dsdata.Tables("tblArea").Select("AreaID=" & cboAreaName.SelectedValue)
            txtAreaFee.Text = drAreaFee(0)("FeePerMeter")
        End If

    End Sub

    Private Sub AddLawSection()
        If cboContractTitle.SelectedIndex <> -1 Then
            Dim drContractTitle() As DataRow = dsdata.Tables("daContractTitle").Select("ContractTitleID=" & cboContractTitle.SelectedValue)
            txtLawSection.Text = drContractTitle(0)("LawSection")
        End If
    End Sub

    Private Sub setState(ByRef pStrMode As String)
        ''
        mStrCurrentState = UCase(pStrMode)
        '' 
        Select Case mStrCurrentState
            Case Is = "NEW"

                Me.btnSave.Enabled = False
                Me.btnCancel.Enabled = True
                Me.btnNew.Enabled = False

                grpContractInfo.Enabled = True
                grpPermit.Enabled = True
                grpArea.Enabled = True
                btnSave.Text = "S a v e"

                AddMode = True
            Case Is = "EDIT"

                Me.btnSave.Enabled = False
                Me.btnCancel.Enabled = True
                Me.btnNew.Enabled = False

                grpContractInfo.Enabled = True
                grpPermit.Enabled = True
                grpArea.Enabled = True
                btnSave.Text = "S a v e"

            Case Is = "SAVE"

                Me.btnSave.Enabled = True
                Me.btnCancel.Enabled = False
                Me.btnNew.Enabled = True
                btnSave.Text = "E d i t"

                grpContractInfo.Enabled = False
                grpPermit.Enabled = False
                grpArea.Enabled = False
                AddMode = False
            Case Is = "BROWSE"

                Me.btnSave.Enabled = True
                Me.btnCancel.Enabled = False
                Me.btnNew.Enabled = True
                btnSave.Text = "E d i t"

                grpContractInfo.Enabled = False
                grpArea.Enabled = False
        End Select

    End Sub

    Private Sub checkValues()
        ''
        If blnLoading = True Then Exit Sub
        ''
        dataChange = True
        'btnCancel.Enabled = True
        ''
        '' clear entir list & start fresh check...
        ''
        lstDataErr.Items.Clear()
        Dim intErrCount As Int16 = 0

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' check Error - Mandatory Data Objects...
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        ''
        If Me.cboClient.SelectedIndex = -1 Then
            lstDataErr.Items.Add("Error: Missing Client Name")
            intErrCount += 1
        End If
        If cboAreaName.SelectedIndex = -1 Then
            lstDataErr.Items.Add("Error: Enter Area")
            intErrCount += 1
        End If
        If Me.cboContractTitle.SelectedIndex = -1 Then
            lstDataErr.Items.Add("Error: Missing Contract Title")
            intErrCount += 1
        End If
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' Set appropriate controls based on errors check results...
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If lstDataErr.Items.Count = 0 Then
            lstDataErr.Visible = False
            btnDataErr.Visible = False
            'lblHelpErr.Visible = False
        Else
            btnDataErr.Visible = True
            'lblHelpErr.Visible = True
        End If
        ''
        If dataChange And intErrCount = 0 Then
            btnSave.Enabled = True


        Else
            btnSave.Enabled = False

        End If
    End Sub

    Private Sub Save()
        If dataChange Then
            ''Update Contract
            Nav.EndCurrentEdit()
            daContract.Update(dsdata, "tblClientContract")
            dataChange = False
        End If
    End Sub

#End Region


#Region "UI-Methods.........."

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        ''Close the Form
        Me.Close()
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        ''Add New Contract

        NewRecord()


    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        If dataChange Then
            If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

                Try
                    Nav.CancelCurrentEdit()
                Catch ex As Exception

                End Try

                dataChange = False
                AddMode = False

            End If
        Else

            'AddMode = False
        End If
        setState("BROWSE")

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If btnSave.Text = "E d i t" Then
            setState("EDIT")
            Exit Sub
        End If
        Save()
        setState("SAVE")
    End Sub

    Private Sub cboContractTitle_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboContractTitle.TextChanged
        checkValues()
    End Sub

    Private Sub cboClient_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
        checkValues()
    End Sub

    Private Sub cboContractType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboContractType.SelectedIndexChanged
        checkValues()
    End Sub

    Private Sub cboContractType_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboContractType.TextChanged
        checkValues()
    End Sub

    Private Sub txtAreaNote_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAreaNote.TextChanged
        checkValues()
    End Sub

    Private Sub txtAreaSqm_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtAreaSqm.TextChanged
        checkValues()
        CalculateTotal()
    End Sub

    Private Sub dtpContractDate_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtpContractDate.ValueChanged
        checkValues()
    End Sub

    Private Sub cboContractTitle_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboContractTitle.SelectedIndexChanged
        If blnLoading = True Then Exit Sub
        AddLawSection()
        checkValues()
    End Sub

    Private Sub cboAreaName_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboAreaName.SelectedIndexChanged
        If blnLoading = True Then Exit Sub

        checkValues()

        FilterArea()

        DrawGrid()

        AddAreaFee()
    End Sub

    Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
        ''
        '' Show/Hide error list...
        If lstDataErr.Visible = True Then
            lstDataErr.Visible = False
        Else
            lstDataErr.Visible = True
            lstDataErr.Height = 251
            lstDataErr.BringToFront()
        End If
    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Dim frm As New frmQuickReport

        Windows.Forms.Cursor.Current = Cursors.WaitCursor()
        Dim rpt As New rptContract
        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table

        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
        ''
        For Each tbCurrent In rpt.Database.Tables
            tliCurrent = tbCurrent.LogOnInfo
            ''
            With tliCurrent.ConnectionInfo
                .ServerName = gStrServerName
                .DatabaseName = gStrDataBaseName
                .UserID = ""
                .Password = ""
            End With

            tbCurrent.ApplyLogOnInfo(tliCurrent)
        Next tbCurrent
        rpt.SetParameterValue("ContractNum", txtContNum.Text)
        frm.crvInstantViewer.ReportSource = rpt
        frm.crvInstantViewer.Refresh()
        frm.Show()

        frm.crvInstantViewer.DisplayToolbar = True
        Windows.Forms.Cursor.Current = Cursors.Default()
    End Sub

#End Region


#Region "Permissions........"

    Private Sub txtAreaFee_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtAreaFee.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Or e.KeyChar = "." Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtAreaSqm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtAreaSqm.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Or e.KeyChar = "." Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

#End Region


End Class