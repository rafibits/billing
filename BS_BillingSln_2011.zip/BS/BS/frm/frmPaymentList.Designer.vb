<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPaymentList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.grpCurrency = New System.Windows.Forms.GroupBox
        Me.rdbLBP = New System.Windows.Forms.RadioButton
        Me.rdbLBPAndUSD = New System.Windows.Forms.RadioButton
        Me.rdbUSD = New System.Windows.Forms.RadioButton
        Me.dtpDateTo = New System.Windows.Forms.DateTimePicker
        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker
        Me.txtPmtNum = New System.Windows.Forms.TextBox
        Me.grpFilterStatus = New System.Windows.Forms.GroupBox
        Me.chkNew = New System.Windows.Forms.CheckBox
        Me.chkPosted = New System.Windows.Forms.CheckBox
        Me.chkNotPosted = New System.Windows.Forms.CheckBox
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.lblTo = New System.Windows.Forms.Label
        Me.lblFrom = New System.Windows.Forms.Label
        Me.lblClientFilter = New System.Windows.Forms.Label
        Me.lblPaymentNumFilter = New System.Windows.Forms.Label
        Me.chkCorrected = New System.Windows.Forms.CheckBox
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grdPayments = New System.Windows.Forms.DataGridView
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnPreviewList = New BHBut.BouncingHoverButton
        Me.btnPreview = New BHBut.BouncingHoverButton
        Me.btnEdit = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.grpFilter.SuspendLayout()
        Me.grpCurrency.SuspendLayout()
        Me.grpFilterStatus.SuspendLayout()
        CType(Me.grdPayments, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpButtons.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.grpCurrency)
        Me.grpFilter.Controls.Add(Me.dtpDateTo)
        Me.grpFilter.Controls.Add(Me.dtpDateFrom)
        Me.grpFilter.Controls.Add(Me.txtPmtNum)
        Me.grpFilter.Controls.Add(Me.grpFilterStatus)
        Me.grpFilter.Controls.Add(Me.cboClient)
        Me.grpFilter.Controls.Add(Me.lblTo)
        Me.grpFilter.Controls.Add(Me.lblFrom)
        Me.grpFilter.Controls.Add(Me.lblClientFilter)
        Me.grpFilter.Controls.Add(Me.lblPaymentNumFilter)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(5, 44)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(884, 85)
        Me.grpFilter.TabIndex = 2
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Data Filter"
        '
        'grpCurrency
        '
        Me.grpCurrency.BackColor = System.Drawing.Color.LavenderBlush
        Me.grpCurrency.Controls.Add(Me.rdbLBP)
        Me.grpCurrency.Controls.Add(Me.rdbLBPAndUSD)
        Me.grpCurrency.Controls.Add(Me.rdbUSD)
        Me.grpCurrency.ForeColor = System.Drawing.Color.Gray
        Me.grpCurrency.Location = New System.Drawing.Point(513, 7)
        Me.grpCurrency.Name = "grpCurrency"
        Me.grpCurrency.Size = New System.Drawing.Size(99, 72)
        Me.grpCurrency.TabIndex = 381
        Me.grpCurrency.TabStop = False
        Me.grpCurrency.Text = "Currencies"
        '
        'rdbLBP
        '
        Me.rdbLBP.AutoSize = True
        Me.rdbLBP.Checked = True
        Me.rdbLBP.ForeColor = System.Drawing.Color.Red
        Me.rdbLBP.Location = New System.Drawing.Point(6, 14)
        Me.rdbLBP.Name = "rdbLBP"
        Me.rdbLBP.Size = New System.Drawing.Size(42, 17)
        Me.rdbLBP.TabIndex = 377
        Me.rdbLBP.TabStop = True
        Me.rdbLBP.Text = "LBP"
        Me.rdbLBP.UseVisualStyleBackColor = True
        '
        'rdbLBPAndUSD
        '
        Me.rdbLBPAndUSD.AutoSize = True
        Me.rdbLBPAndUSD.ForeColor = System.Drawing.Color.DarkGreen
        Me.rdbLBPAndUSD.Location = New System.Drawing.Point(6, 53)
        Me.rdbLBPAndUSD.Name = "rdbLBPAndUSD"
        Me.rdbLBPAndUSD.Size = New System.Drawing.Size(66, 17)
        Me.rdbLBPAndUSD.TabIndex = 376
        Me.rdbLBPAndUSD.Text = "LBP/USD"
        Me.rdbLBPAndUSD.UseVisualStyleBackColor = True
        '
        'rdbUSD
        '
        Me.rdbUSD.AutoSize = True
        Me.rdbUSD.ForeColor = System.Drawing.Color.Navy
        Me.rdbUSD.Location = New System.Drawing.Point(6, 33)
        Me.rdbUSD.Name = "rdbUSD"
        Me.rdbUSD.Size = New System.Drawing.Size(45, 17)
        Me.rdbUSD.TabIndex = 375
        Me.rdbUSD.Text = "USD"
        Me.rdbUSD.UseVisualStyleBackColor = True
        '
        'dtpDateTo
        '
        Me.dtpDateTo.CalendarForeColor = System.Drawing.Color.Navy
        Me.dtpDateTo.CustomFormat = "dd MMM yyyy"
        Me.dtpDateTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateTo.Location = New System.Drawing.Point(295, 16)
        Me.dtpDateTo.Name = "dtpDateTo"
        Me.dtpDateTo.Size = New System.Drawing.Size(94, 21)
        Me.dtpDateTo.TabIndex = 1
        '
        'dtpDateFrom
        '
        Me.dtpDateFrom.CalendarForeColor = System.Drawing.Color.Navy
        Me.dtpDateFrom.CustomFormat = "dd MMM yyyy"
        Me.dtpDateFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateFrom.Location = New System.Drawing.Point(165, 16)
        Me.dtpDateFrom.Name = "dtpDateFrom"
        Me.dtpDateFrom.Size = New System.Drawing.Size(94, 21)
        Me.dtpDateFrom.TabIndex = 0
        '
        'txtPmtNum
        '
        Me.txtPmtNum.BackColor = System.Drawing.Color.White
        Me.txtPmtNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPmtNum.ForeColor = System.Drawing.Color.Navy
        Me.txtPmtNum.Location = New System.Drawing.Point(54, 16)
        Me.txtPmtNum.Name = "txtPmtNum"
        Me.txtPmtNum.Size = New System.Drawing.Size(74, 23)
        Me.txtPmtNum.TabIndex = 318
        '
        'grpFilterStatus
        '
        Me.grpFilterStatus.Controls.Add(Me.chkNew)
        Me.grpFilterStatus.Controls.Add(Me.chkPosted)
        Me.grpFilterStatus.Controls.Add(Me.chkNotPosted)
        Me.grpFilterStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.grpFilterStatus.ForeColor = System.Drawing.Color.Gray
        Me.grpFilterStatus.Location = New System.Drawing.Point(400, 7)
        Me.grpFilterStatus.Name = "grpFilterStatus"
        Me.grpFilterStatus.Size = New System.Drawing.Size(99, 72)
        Me.grpFilterStatus.TabIndex = 317
        Me.grpFilterStatus.TabStop = False
        Me.grpFilterStatus.Text = "Status"
        '
        'chkNew
        '
        Me.chkNew.AutoSize = True
        Me.chkNew.Checked = True
        Me.chkNew.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkNew.ForeColor = System.Drawing.Color.Red
        Me.chkNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkNew.Location = New System.Drawing.Point(7, 13)
        Me.chkNew.Name = "chkNew"
        Me.chkNew.Size = New System.Drawing.Size(48, 17)
        Me.chkNew.TabIndex = 4
        Me.chkNew.Text = "New"
        '
        'chkPosted
        '
        Me.chkPosted.AutoSize = True
        Me.chkPosted.Checked = True
        Me.chkPosted.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPosted.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPosted.ForeColor = System.Drawing.Color.Navy
        Me.chkPosted.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkPosted.Location = New System.Drawing.Point(7, 32)
        Me.chkPosted.Name = "chkPosted"
        Me.chkPosted.Size = New System.Drawing.Size(59, 17)
        Me.chkPosted.TabIndex = 5
        Me.chkPosted.Text = "Posted"
        '
        'chkNotPosted
        '
        Me.chkNotPosted.AutoSize = True
        Me.chkNotPosted.Checked = True
        Me.chkNotPosted.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkNotPosted.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkNotPosted.ForeColor = System.Drawing.Color.LightCoral
        Me.chkNotPosted.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkNotPosted.Location = New System.Drawing.Point(7, 50)
        Me.chkNotPosted.Name = "chkNotPosted"
        Me.chkNotPosted.Size = New System.Drawing.Size(72, 17)
        Me.chkNotPosted.TabIndex = 3
        Me.chkNotPosted.Text = "Unposted"
        '
        'cboClient
        '
        Me.cboClient.BackColor = System.Drawing.SystemColors.Window
        Me.cboClient.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboClient.ForeColor = System.Drawing.Color.Navy
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(54, 45)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(335, 24)
        Me.cboClient.TabIndex = 5
        '
        'lblTo
        '
        Me.lblTo.AutoSize = True
        Me.lblTo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTo.ForeColor = System.Drawing.Color.Maroon
        Me.lblTo.Location = New System.Drawing.Point(272, 20)
        Me.lblTo.Name = "lblTo"
        Me.lblTo.Size = New System.Drawing.Size(20, 13)
        Me.lblTo.TabIndex = 3
        Me.lblTo.Text = "To"
        Me.lblTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblFrom
        '
        Me.lblFrom.AutoSize = True
        Me.lblFrom.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFrom.ForeColor = System.Drawing.Color.Maroon
        Me.lblFrom.Location = New System.Drawing.Point(134, 20)
        Me.lblFrom.Name = "lblFrom"
        Me.lblFrom.Size = New System.Drawing.Size(30, 13)
        Me.lblFrom.TabIndex = 2
        Me.lblFrom.Text = "From"
        Me.lblFrom.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblClientFilter
        '
        Me.lblClientFilter.AutoSize = True
        Me.lblClientFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblClientFilter.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblClientFilter.ForeColor = System.Drawing.Color.Maroon
        Me.lblClientFilter.Location = New System.Drawing.Point(17, 49)
        Me.lblClientFilter.Name = "lblClientFilter"
        Me.lblClientFilter.Size = New System.Drawing.Size(33, 13)
        Me.lblClientFilter.TabIndex = 4
        Me.lblClientFilter.Text = "Client"
        Me.lblClientFilter.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPaymentNumFilter
        '
        Me.lblPaymentNumFilter.AutoSize = True
        Me.lblPaymentNumFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblPaymentNumFilter.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblPaymentNumFilter.ForeColor = System.Drawing.Color.Maroon
        Me.lblPaymentNumFilter.Location = New System.Drawing.Point(6, 20)
        Me.lblPaymentNumFilter.Name = "lblPaymentNumFilter"
        Me.lblPaymentNumFilter.Size = New System.Drawing.Size(44, 13)
        Me.lblPaymentNumFilter.TabIndex = 11
        Me.lblPaymentNumFilter.Text = "Number"
        Me.lblPaymentNumFilter.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'chkCorrected
        '
        Me.chkCorrected.AutoSize = True
        Me.chkCorrected.Checked = True
        Me.chkCorrected.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkCorrected.ForeColor = System.Drawing.Color.Maroon
        Me.chkCorrected.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkCorrected.Location = New System.Drawing.Point(676, 17)
        Me.chkCorrected.Name = "chkCorrected"
        Me.chkCorrected.Size = New System.Drawing.Size(74, 17)
        Me.chkCorrected.TabIndex = 6
        Me.chkCorrected.Text = "Corrected"
        Me.chkCorrected.Visible = False
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(901, 3)
        Me.pnlTitle.TabIndex = 342
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(901, 40)
        Me.lblfrmTitle.TabIndex = 341
        Me.lblfrmTitle.Text = "Payment"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(9, 138)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 344
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grdPayments
        '
        Me.grdPayments.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdPayments.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdPayments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdPayments.Location = New System.Drawing.Point(7, 135)
        Me.grdPayments.MultiSelect = False
        Me.grdPayments.Name = "grdPayments"
        Me.grdPayments.ReadOnly = True
        Me.grdPayments.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdPayments.Size = New System.Drawing.Size(882, 255)
        Me.grdPayments.TabIndex = 343
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnPreviewList)
        Me.grpButtons.Controls.Add(Me.btnPreview)
        Me.grpButtons.Controls.Add(Me.btnEdit)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Location = New System.Drawing.Point(7, 396)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(882, 53)
        Me.grpButtons.TabIndex = 345
        Me.grpButtons.TabStop = False
        '
        'btnPreviewList
        '
        Me.btnPreviewList.AlternativeGroup = Nothing
        Me.btnPreviewList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPreviewList.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPreviewList.BackColor1 = System.Drawing.Color.White
        Me.btnPreviewList.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPreviewList.BorderHover = True
        Me.btnPreviewList.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPreviewList.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPreviewList.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPreviewList.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPreviewList.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPreviewList.DrawBorder = True
        Me.btnPreviewList.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPreviewList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPreviewList.ForeColor = System.Drawing.Color.Navy
        Me.btnPreviewList.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreviewList.HoverColor2 = System.Drawing.Color.White
        Me.btnPreviewList.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPreviewList.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPreviewList.Location = New System.Drawing.Point(341, 16)
        Me.btnPreviewList.Name = "btnPreviewList"
        Me.btnPreviewList.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreviewList.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPreviewList.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPreviewList.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPreviewList.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPreviewList.SelectedText = Nothing
        Me.btnPreviewList.Size = New System.Drawing.Size(105, 28)
        Me.btnPreviewList.TabIndex = 169
        Me.btnPreviewList.Text = "Preview List"
        Me.btnPreviewList.UseVisualStyleBackColor = False
        '
        'btnPreview
        '
        Me.btnPreview.AlternativeGroup = Nothing
        Me.btnPreview.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPreview.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPreview.BackColor1 = System.Drawing.Color.White
        Me.btnPreview.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPreview.BorderHover = True
        Me.btnPreview.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPreview.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPreview.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPreview.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPreview.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPreview.DrawBorder = True
        Me.btnPreview.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPreview.ForeColor = System.Drawing.Color.Navy
        Me.btnPreview.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.HoverColor2 = System.Drawing.Color.White
        Me.btnPreview.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPreview.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPreview.Location = New System.Drawing.Point(230, 16)
        Me.btnPreview.Name = "btnPreview"
        Me.btnPreview.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPreview.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPreview.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPreview.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.SelectedText = Nothing
        Me.btnPreview.Size = New System.Drawing.Size(105, 28)
        Me.btnPreview.TabIndex = 10
        Me.btnPreview.Text = "P r e v i e w"
        Me.btnPreview.UseVisualStyleBackColor = False
        '
        'btnEdit
        '
        Me.btnEdit.AlternativeGroup = Nothing
        Me.btnEdit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnEdit.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BackColor1 = System.Drawing.Color.White
        Me.btnEdit.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BorderHover = True
        Me.btnEdit.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEdit.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEdit.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnEdit.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEdit.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEdit.DrawBorder = True
        Me.btnEdit.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnEdit.ForeColor = System.Drawing.Color.Navy
        Me.btnEdit.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.HoverColor2 = System.Drawing.Color.White
        Me.btnEdit.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEdit.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnEdit.Location = New System.Drawing.Point(119, 16)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnEdit.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnEdit.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnEdit.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.SelectedText = Nothing
        Me.btnEdit.Size = New System.Drawing.Size(105, 28)
        Me.btnEdit.TabIndex = 0
        Me.btnEdit.Text = "O p e n"
        Me.btnEdit.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.HoverColor2 = System.Drawing.Color.White
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNew.Location = New System.Drawing.Point(8, 16)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(105, 28)
        Me.btnNew.TabIndex = 3
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(726, 19)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(105, 28)
        Me.btnClose.TabIndex = 9
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(45, 138)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 163)
        Me.grpShowHideColumns.TabIndex = 353
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 131)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 109)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'frmPaymentList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 449)
        Me.Controls.Add(Me.chkCorrected)
        Me.Controls.Add(Me.grpShowHideColumns)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.btnShowCol)
        Me.Controls.Add(Me.grdPayments)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.grpFilter)
        Me.KeyPreview = True
        Me.Name = "frmPaymentList"
        Me.Text = "frmPaymentList"
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        Me.grpCurrency.ResumeLayout(False)
        Me.grpCurrency.PerformLayout()
        Me.grpFilterStatus.ResumeLayout(False)
        Me.grpFilterStatus.PerformLayout()
        CType(Me.grdPayments, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpButtons.ResumeLayout(False)
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
	Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
	Friend WithEvents dtpDateTo As System.Windows.Forms.DateTimePicker
	Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker
	Friend WithEvents txtPmtNum As System.Windows.Forms.TextBox
	Friend WithEvents grpFilterStatus As System.Windows.Forms.GroupBox
	Friend WithEvents cboClient As System.Windows.Forms.ComboBox
	Friend WithEvents lblTo As System.Windows.Forms.Label
	Friend WithEvents lblFrom As System.Windows.Forms.Label
	Friend WithEvents lblClientFilter As System.Windows.Forms.Label
	Friend WithEvents lblPaymentNumFilter As System.Windows.Forms.Label
	Friend WithEvents pnlTitle As System.Windows.Forms.Panel
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents btnShowCol As System.Windows.Forms.Button
	Friend WithEvents grdPayments As System.Windows.Forms.DataGridView
	Friend WithEvents chkNew As System.Windows.Forms.CheckBox
	Friend WithEvents chkPosted As System.Windows.Forms.CheckBox
	Friend WithEvents chkNotPosted As System.Windows.Forms.CheckBox
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnPreview As BHBut.BouncingHoverButton
	Friend WithEvents btnEdit As BHBut.BouncingHoverButton
	Friend WithEvents btnNew As BHBut.BouncingHoverButton
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
    Friend WithEvents chkCorrected As System.Windows.Forms.CheckBox
    Friend WithEvents btnPreviewList As BHBut.BouncingHoverButton
    Friend WithEvents grpCurrency As System.Windows.Forms.GroupBox
    Friend WithEvents rdbLBP As System.Windows.Forms.RadioButton
    Friend WithEvents rdbLBPAndUSD As System.Windows.Forms.RadioButton
    Friend WithEvents rdbUSD As System.Windows.Forms.RadioButton
End Class
