Imports BITSConn
Imports System.Data.SqlClient

Public Class frmAccountGet

#Region " Form Declaration  .  .  ."
   ''
   Private dsdata As DataSet
   Private clsMr As ClsMain
   Private daService As SqlClient.SqlDataAdapter
   ''
   Private blnLoading As Boolean
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\ClientGet\Settings"
   ''
   Public arrAcctID(1) As Integer
   Public CboValue As Integer
   Private mAcctTypeID As Integer
   Private mstrCurrentGridName As String
#End Region


#Region " Form Initialization . . ."

   Private Sub frmGetService_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
      ''
      clsMr = New ClsMain(conSql)
      blnLoading = True
      MakeDataAdapter()
      DrawGrid()
      blnLoading = False
      ''
      txtFilterAcctNum.Text = ""
      txtFilterAcctName.Text = ""
      txtFilterAcctNum.Focus()
      ''
   End Sub

   Private Sub MakeDataAdapter()
      ''
      clsMr.BuildSqlAdapter("SELECT * FROM vwClients WHERE Del=0 ", "vwClients")
      dsdata = clsMr.getDataSet
   End Sub

#End Region


#Region " UI Events       .   .   ."

   Private Sub txtFilterAcctNum_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFilterAcctNum.KeyPress
      Integers_KeyPress(txtFilterAcctNum, e)
   End Sub

   Private Sub frmAccountGet_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
      ''
      SaveProfile(mStrSubKeyName, grdAcctSearch)
   End Sub

   Private Sub txtFilterAcctNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFilterAcctNum.TextChanged
      ''
      If blnLoading = True Then Exit Sub
      ''
      dsdata.Tables("vwClients").DefaultView.RowFilter = "ClientNum LIKE '" & txtFilterAcctNum.Text & "*' AND ClientName  like '*" & txtFilterAcctName.Text & "*'"
   End Sub

   Private Sub txtFilterAcctNum_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtFilterAcctNum.KeyDown
      ''
      If e.KeyCode = Keys.Delete Or e.KeyCode = Keys.Back Then
         txtFilterAcctName.Text = ""
      Else
         If e.KeyCode = Keys.Down And grdAcctSearch.Visible = True Then
            grdAcctSearch.Focus()
         End If
      End If

   End Sub

   Private Sub txtFilterAcctName_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtFilterAcctName.KeyDown
      ''
      If e.KeyCode = Keys.Delete Or e.KeyCode = Keys.Back Then
         txtFilterAcctNum.Text = ""
      Else
         If e.KeyCode = Keys.Down And grdAcctSearch.Visible = True Then
            grdAcctSearch.Focus()
         End If
      End If
   End Sub

   Private Sub txtFilterAcctName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFilterAcctName.TextChanged
      ''
      dsdata.Tables("vwClients").DefaultView.RowFilter = "ClientNum LIKE '" & Integer.Parse(txtFilterAcctNum.Text) & "*' AND ClientName like '*" & txtFilterAcctName.Text & "*'"
   End Sub

   Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      Me.Close()
   End Sub

   Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
      ''
      If grdAcctSearch.Rows.Count = 0 Then Exit Sub
      ' ''
      'Dim i As Integer
      'Dim dv As DataGridViewSelectedRowCollection = grdAcctSearch.SelectedRows
      ' ''
      'ReDim arrAcctID(dv.Count)
      ''
      'For i = 0 To dv.Count - 1
      '	Dim drv As DataGridViewRow = dv(i)
      '	arrAcctID(i) = dv(i).Cells("AcctID").Value
      'Next
      CboValue = grdAcctSearch.Item("ClientID", grdAcctSearch.CurrentRow.Index).Value
      Me.Close()
   End Sub

   Private Sub grdAcctSearch_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles grdAcctSearch.KeyDown
      ''
      If e.KeyCode = Keys.Enter Then
         CboValue = grdAcctSearch.Item("ClientID", grdAcctSearch.CurrentRow.Index).Value
         Me.Close()
      End If
   End Sub

   Private Sub btnSaveSettings_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
      ''
      Dim i As Integer

      For i = 0 To Me.chkLstGridCol.Items.Count - 1
         Me.grdAcctSearch.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
      Next
      ''
      Me.grpShowHideColumns.Visible = False
   End Sub

    Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()
            mstrCurrentGridName = "Client"
            ''
            '' populate list with grid's dataSource fields...
            ''
            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdAcctSearch.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next
        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If
        RemoveItemFromList()
    End Sub

#End Region


#Region " Form Functions    .  .  ."

   Private Sub DrawGrid()
      ''
      '' set draw grdAcctSearch
      ''
      With grdAcctSearch()
         .DataSource = dsdata.Tables("vwClients")
         dsdata.Tables("vwClients").DefaultView.AllowNew = False
         .Columns("ClientID").Visible = False
         .Columns("Del").Visible = False
       
         .Columns("ClientName").HeaderText = "Name"
         .Columns("ClientNum").HeaderText = "Number"
         .ReadOnly = True
         .Visible = True
         .ColumnHeadersHeight = btnShowCol.Height + 2
         .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
      End With

      RemoveItemFromList()
      ''
      LoadProfile(mStrSubKeyName, Me.grdAcctSearch)
   End Sub

   Private Sub RemoveItemFromList()
      chkLstGridCol.Items.Remove("ClientID")
      chkLstGridCol.Items.Remove("Del")
   End Sub

#End Region


End Class