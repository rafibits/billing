Imports BITSConn
''
Public Class frmUserPreferences

#Region " Form-Declarations"
    ''
    Private daUserPref As SqlClient.SqlDataAdapter
    Private clsMr As BITSConn.ClsMain
    Private dsData As New DataSet
    ''
    Private WithEvents Nav As New BitsNav
    ''
    Private mblnLoading As Boolean           '' indicates loading mode...
    Private mblnDataChg As Boolean           '' indicates Data Changed...

#End Region


#Region " Form-Load........"

    Private Sub frmUserPreferences_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmUserPreferences_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ''
        '' Start Loading...
        ''
        mblnLoading = True
        ''
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav()
        ''
        makeDataAdapter()
        SetDataBinding()
        SetAutoNumber()
        SetCurrencyManager()
        SetDefaultValue()
        setState("Browse")

        ''
        '' End Loading...
        ''

        mblnLoading = False
        ''
        Me.lblUserID.Text = gIntUserID
        If Nav.CurrentPosition < 1 Then
            cboDecDigit.Text = "0"
        Else

            cboDecDigit.Text = dsData.Tables("tblUserPreferences").DefaultView.Item(Nav.CurrentPosition)("DecDigit")

        End If
    End Sub

    Public Sub makeDataAdapter()
        ''
        '' Get main form's data from tblUserPreferences...
        ''
        daUserPref = clsMr.BuildSqlAdapter("SELECT * FROM tblUserPreferences WHERE UserID = " & gIntUserID, "tblUserPreferences")
        dsData = clsMr.getDataSet

    End Sub

    Private Sub SetDataBinding()
        ''
        '' Bind form ctrls...
        ''
        clsMr.BindComboBox(cboDecDigit, "tblUserPreferences", "DecDigit")
        ''
        clsMr.BindCheckBox(chkUseComma, "tblUserPreferences", "UseComma")
        ''
        clsMr.BindTextBox(txtSharedDataPath, "tblUserPreferences", "SharedDataPath")
        ''
        clsMr.BindTextBox(txtTitleBackColor, "tblUserPreferences", "TitleBackColor")
        ''
        clsMr.BindTextBox(txtTitleForeColor, "tblUserPreferences", "TitleForeColor")
        ''
        clsMr.BindTextBox(txtGridBackColor, "tblUserPreferences", "GridBackColor")

    End Sub

    Private Sub SetAutoNumber()
        ''
        clsMr.SetAutoNumber("tblUserPreferences", "UPID")
    End Sub

    Private Sub SetCurrencyManager()
        ''
        Nav.SetCurrency(Me, clsMr.getDataSet, "tblUserPreferences")
    End Sub

    Private Sub SetDefaultValue()
        ''
        clsMr.SetDefaults("tblUserPreferences", "UserID", gIntUserID, "Del", 0, "UseComma", 0)
    End Sub

#End Region


#Region " Form-Events......"

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        ''New..
        If btnSave.Text = "E d i t" Then
            If dsData.Tables("tblUserPreferences").DefaultView.Count = 0 Then
                Nav.AddNew()
            End If
            setState("Edit")
            Exit Sub
        End If

        ''Update
        Nav.EndCurrentEdit()
        'dsData.Tables("tblUserPreferences").DefaultView.Item(Nav.CurrentPosition)("DecDigit") = cboDecDigit.SelectedItem
        clsMr.Update(daUserPref, "tblUserPreferences")

        gintDecDigit = cboDecDigit.Text
        gblnUseComma = chkUseComma.Checked
        gstrSharedDataPath = txtSharedDataPath.Text

        setState("Browse")

    End Sub

    ''Close 
    Private Sub BtnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click

        If btnSave.Text = "S a v e" Then
            Dim res As MsgBoxResult
            res = MsgBox("Do you want to save changes?", MsgBoxStyle.YesNoCancel)
            Select Case res

                Case MsgBoxResult.Yes
                    btnSave.PerformClick()
                    Me.Close()

                Case MsgBoxResult.No
                    Nav.CancelCurrentEdit()
                    Me.Close()

                Case MsgBoxResult.Cancel
                    Nav.CancelCurrentEdit()
                    setState("Browse")
            End Select

        Else
            Close()
        End If

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        Nav.CancelCurrentEdit()
        setState("Browse")

    End Sub

    ''Shared Data Path
    Private Sub btnGetPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetPath.Click
        ''
        ofdGetPath.ShowDialog()
        txtSharedDataPath.Text = System.IO.Path.GetDirectoryName(ofdGetPath.FileName) & "\"

    End Sub

    ''Title Back Color
    Private Sub txtTitleBackColor_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTitleBackColor.DoubleClick
        ColorDialog.ShowDialog()
        txtTitleBackColor.BackColor = ColorDialog.Color
    End Sub

    Private Sub txtTitleBackColor_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTitleBackColor.Validated
        txtTitleBackColor.Text = txtTitleBackColor.BackColor.Name.ToString
    End Sub

    ''Title Fore Color
    Private Sub txtTitleForeColor_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTitleForeColor.DoubleClick
        ColorDialog.ShowDialog()
        txtTitleForeColor.BackColor = ColorDialog.Color
    End Sub

    Private Sub txtTitleForeColor_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTitleForeColor.Validated
        txtTitleForeColor.Text = txtTitleForeColor.BackColor.Name.ToString
    End Sub

    ''Grid Back Color
    Private Sub txtGridBackColor_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtGridBackColor.DoubleClick
        ColorDialog.ShowDialog()
        txtGridBackColor.BackColor = ColorDialog.Color
    End Sub

    Private Sub txtGridBackColor_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtGridBackColor.Validated
        txtGridBackColor.Text = txtGridBackColor.BackColor.Name.ToString
    End Sub

#End Region


#Region " Form-Functions..."

    Private Sub setState(ByRef pStrMode As String)
        ''
        Dim mStrCurrentState As String
        mStrCurrentState = UCase(pStrMode)
        ''    
        Select Case mStrCurrentState

            Case Is = "BROWSE"
                btnSave.Text = "E d i t"
                btnCancel.Enabled = False
                grpUserInput.Enabled = False

            Case Is = "EDIT"
                btnSave.Text = "S a v e"
                btnCancel.Enabled = True
                grpUserInput.Enabled = True
        End Select
        ''
        DGCA.LoadPermissionsSetState(Me, Me.Name)
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

#End Region


End Class