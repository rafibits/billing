''
Imports BITSConn
Imports System.Data.SqlClient

Public Class frmRate

#Region " Form Declaration  .  .  ."
    ''
    Dim dsData As DataSet
    Dim clsMr As ClsMain
    Dim daRate As SqlDataAdapter
    Dim blnLoading As Boolean
    Dim dataChange As Boolean
    Dim WithEvents Nav As BitsNav
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Service\Rate\Settings"
    Private mstrCurrentGridName As String
#End Region


#Region " Form Initialization . . ."

    Private Sub frmRate_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ''
        conSql = New SqlConnection("Data Source=BITSSERVER;Initial Catalog=Billing;Integrated Security=True")
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav
        ''  
        blnLoading = True
        MakeDataAdapter()
        SetDataBinding()
        FillComboBox()
        SetAutoNumber()
        SetDefaults()
        SetCurrency()
        ''
        DrawGrid()
        clearDataFilter()
        btnSave.Text = "Edit"
        grdRate.ReadOnly = True
        blnLoading = False
    End Sub

    Private Sub MakeDataAdapter()
        ''
        strSQL = "SELECT * FROM tblRateXRef WHERE Del = 0"
        daRate = clsMr.BuildSqlAdapter(strSQL, "tblRateXRef")
        '' 
        clsMr.BuildSqlAdapter("SELECT * FROM vwClientServiceRate WHERE Del = 0", "vwClientServiceRate")
        ''
        '' Data Adapter to fill the combo's For Search purpose
        strSQL = "SELECT Code, Description, ClientClassID, Del FROM tblClientClass WHERE Del = 0"
        clsMr.BuildSqlAdapter(strSQL, "tblClientClass")
        ''
        strSQL = "SELECT ServiceName, Price, ServiceID, Del FROM tblService WHERE Del = 0"
        clsMr.BuildSqlAdapter(strSQL, "tblService")
        ''
        dsData = clsMr.getDataSet
    End Sub

    Private Sub SetDataBinding()
        clsMr.BindTextBox(txtRatXRefID, "tblRateXRef", "RateXRefID")
        clsMr.BindComboBox(cboClientClass, "tblRateXRef", "ClientClassID")
    End Sub

    Private Sub FillComboBox()
        clsMr.FillComboBox("tblClientClass", cboClientClass, "Code", "ClientClassID")
        clsMr.FillComboBox("tblService", cboService, "ServiceName", "ServiceID")
    End Sub

    Private Sub SetAutoNumber()
        clsMr.SetAutoNumber("tblRateXRef", "RateXRefID")
    End Sub

    Private Sub SetDefaults()
        clsMr.SetDefaults("tblRateXRef", "Del", 0)
    End Sub

    Private Sub SetCurrency()
        Nav.SetCurrency(Me, clsMr.getDataSet, "tblRateXRef")
    End Sub

#End Region


#Region " Form Functions   .  .  . "
    ''
    Private Sub DrawGrid()
        ''
        With grdRate
            .DataSource = dsData.Tables("vwClientServiceRate").DefaultView
            .Columns("RateXRefID").Visible = False
            ''remove this column in order to add it as cbo in the grid
            .Columns.Remove("ServiceID")
            .Columns("ServiceName").Visible = False
            .Columns("Del").Visible = False
            ''
            .ColumnHeadersHeight = btnShowCol.Height + 2
            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        End With
        ''
        AddHandler dsData.Tables("vwClientServiceRate").ColumnChanged, AddressOf Column_Changed
        dsData.Tables("vwClientServiceRate").DefaultView.AllowNew = False
        ''
        AddComboBoxColumns()
        RemoveGrdListItems()
        LoadProfile(mStrSubKeyName, Me.grdRate)
    End Sub

    Private Sub RemoveGrdListItems()
        ''
        chkLstGridCol.Items.Remove("RateXRefID")
        chkLstGridCol.Items.Remove("Del")
        chkLstGridCol.Items.Remove("ServiceName")
    End Sub

    Private Sub AddComboBoxColumns()
        ''
        Dim comboboxColumnService As New DataGridViewComboBoxColumn()
        ''
        comboboxColumnService = CreateComboBoxColumn("ServiceID", "ServiceID")
        ''
        SetDataSource(comboboxColumnService, dsData.Tables("tblService"), "ServiceID", "ServiceName")
        ''
        comboboxColumnService.HeaderText = "Service"
        ''
        comboboxColumnService.Name = "ServiceID"
        ''
        With grdRate
            .Columns.Insert(0, comboboxColumnService)
            .Columns(0).Width = 140
        End With
        ''
        comboboxColumnService.HeaderCell.SortGlyphDirection = 0
    End Sub

    Private Function CreateComboBoxColumn(ByRef pDataPropertyName As String, ByRef pHeaderText As String) As DataGridViewComboBoxColumn
        ''
        Dim column As New DataGridViewComboBoxColumn()
        ''
        With column
            .DataPropertyName = pDataPropertyName
            .HeaderText = pHeaderText
            .DropDownWidth = 120
            .Width = 90
            .FlatStyle = FlatStyle.Standard
        End With
        Return column
    End Function

    Private Sub SetDataSource(ByRef comboboxColumn As DataGridViewComboBoxColumn, ByRef pdt As DataTable, ByVal pStrValueMember As String, ByVal pStrDisplayMember As String)
        ''
        With comboboxColumn
            ' Dim dt As DataTable = pdt
            .DataSource = pdt
            .ValueMember = pStrValueMember
            .DisplayMember = pStrDisplayMember
        End With
    End Sub

    'Private Sub FilterGrid()
    '    '
    '    If blnLoading Then Exit Sub
    '    '
    '    Dim s As String = " True"
    '    '
    '    s = "(UpdateDate >= '" & Format(dtpFrom.Value, "dd /MMM / yyyy") & "') AND (UpdateDate <= '" & Format(dtpTo.Value, "dd /MMM / yyyy") & "')"
    '    '
    '    If cboCustomer.SelectedIndex <> -1 Then
    '        s = s & " AND (CustomerID = " & cboCustomer.SelectedValue & ")"
    '    Else
    '        If cboCustomer.Text <> "" And cboCustomer.SelectedIndex = -1 Then
    '            s = s & " AND (CustomerID = " & -1 & ")"
    '        End If
    '    End If
    '    '
    '    If cboEmployee.SelectedIndex <> -1 Then
    '        s = s & " AND (employeeID = " & cboEmployee.SelectedValue & ")"
    '    Else
    '        If cboEmployee.Text <> "" And cboEmployee.SelectedIndex = -1 Then
    '            s = s & " & AND (employeeID = " & -1 & ")"
    '        End If
    '    End If
    '    '
    '    dsData.Tables("vwCustomerSolution").DefaultView.RowFilter = s
    '    '
    'End Sub

    Private Sub refrech()
        ' ''
        'clsMr.BuildSqlAdapter("SELECT * FROM tblClientClass ", "tblClientClass")
        'dsData = clsMr.getDataSet
        'grdClientClass.DataSource = dsData.Tables("tblClientClass")
        'grdClientClass.Columns("ClientClassID").Visible = False
    End Sub

    Private Sub clearDataFilter()
        cboClientClass.SelectedIndex = -1
        cboService.SelectedIndex = -1
    End Sub

    Private Sub setState(ByRef pStrMode As String)
        ''
        Dim mStrCurrentState As String
        mStrCurrentState = UCase(pStrMode)
        '' 
        Select Case mStrCurrentState
            Case Is = "NEW"
                'grpFilter.Enabled = False
                cboService.Enabled = False
                btnNew.Enabled = False
                btnSave.Text = "Save"
            Case Is = "EDIT"
                btnSave.Text = "Save"
            Case Is = "SAVE"
                grpFilter.Enabled = True
                btnNew.Enabled = True
                btnSave.Text = "Edit"
                cboService.Enabled = True
            Case Is = "BROWSE"
                grpFilter.Enabled = True
            Case Is = "CANCEL"
                grpFilter.Enabled = True
                btnSave.Text = "Edit"
                btnNew.Enabled = True
                cboService.Enabled = True
                'cboCustomer.SelectedIndex = -1
                'cboEmployee.SelectedIndex = -1
        End Select
    End Sub

#End Region


#Region " UI - Events     .  .  .  "

    Private Sub Column_Changed(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
        ''
        If grdRate.Rows.Count = 0 Then Exit Sub
        If (grdRate.CurrentRow) Is Nothing Then
            Exit Sub
        End If
        ''
        Select Case e.Column.ColumnName
            Case "ServiceID"
                If Not (grdRate.Item("ServiceID", grdRate.CurrentRow.Index).Value Is DBNull.Value) Then
                    Dim dr As DataRow = dsData.Tables("tblService").DefaultView.Item(Nav.CurrentPosition).Row
                    grdRate.Item("Price", grdRate.CurrentRow.Index).Value = dr("Price")
                End If
        End Select
        ''
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        ''
        If dataChange Then
            ''
            Dim res As MsgBoxResult
            res = MsgBox("Do you want to save changes?", MsgBoxStyle.YesNoCancel)
            ''
            Select Case res
                Case MsgBoxResult.Yes
                    btnSave.PerformClick()
                    Me.Close()
                Case MsgBoxResult.No
                    Nav.CancelCurrentEdit()
                    Me.Close()
                Case MsgBoxResult.Cancel
                    Exit Sub
            End Select
        End If
        Me.Close()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        ''
        '' Take in consideration if there is a Rate that is used in some invoices 
        '' Delete function lacks to ensure if RateXRefID found in InvoiceDetail
        If grdRate.RowCount = 0 Then
            Exit Sub
        End If
        ''
        If MsgBox("Are you sure you want to delete Rate?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            ''
            strSQL = "Update tblRateXRef SET Del = 1 WHERE RateXRef = " & txtRatXRefID.Text
            Dim cmd As New SqlCommand(strSQL, conSql)
            ''
            Try
                conSql.Open()
                cmd.ExecuteNonQuery()
                conSql.Close()
                ''
                grdRate.Item("Del", grdRate.CurrentRow.Index).Value = 1
                dsData.Tables("tblRateXRef").DefaultView(grdRate.CurrentRow.Index).Delete()
            Catch ex As Exception
                conSql.Close()
            End Try
        End If
        ''
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ''
        If dataChange = True Then
            If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Nav.CancelCurrentEdit()
                dsData.Tables("vwClientServiceRate").DefaultView.AllowNew = False
                btnSave.Text = "Edit"
                btnNew.Enabled = True
                grdRate.ReadOnly = True
                dataChange = False
            End If
        End If
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        ''
        Nav.AddNew()
        dsData.Tables("vwClientServiceRate").DefaultView.AllowNew = True
        Dim dr As DataRow = dsData.Tables("vwClientServiceRate").NewRow
        dsData.Tables("vwClientServiceRate").Rows.Add(dr)
        dsData.Tables("vwClientServiceRate").DefaultView.AllowNew = False
        '' 
        grdRate.ReadOnly = False
        dataChange = True
        setState("NEW")
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        ''
        If btnSave.Text = "Edit" Then
            btnSave.Text = "Save"
            btnNew.Enabled = False
            grdRate.ReadOnly = False
            dataChange = True
        Else
            btnSave.Text = "Edit"
            btnNew.Enabled = True
            grdRate.ReadOnly = True
            Nav.EndCurrentEdit()
            dsData.Tables("vwClientServiceRate").DefaultView.AllowNew = True
            daRate.Update(dsData, "tblRateXRef")
            dataChange = False
            dsData.Tables("vwClientServiceRate").DefaultView.AllowNew = False
        End If
    End Sub

    Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
        ''
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()
            mstrCurrentGridName = "Client Class"
            ''
            '' populate list with grid's dataSource fields...
            ''
            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdRate.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next

        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If
        RemoveGrdListItems()
    End Sub

    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
        ''
        Dim i As Integer

        For i = 0 To Me.chkLstGridCol.Items.Count - 1
            Me.grdRate.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
        Next
        ''
        Me.grpShowHideColumns.Visible = False
    End Sub

    Private Sub frmClientClass_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        '' Save User Grid Setting...
        SaveProfile(mStrSubKeyName, Me.grdRate)
    End Sub

    Private Sub btnService_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnService.Click
        ''

        Dim frm As New frmServiceList
        frm.Show()
        ''
        '' Get Services and update my grid
        ''


        'If dsData.Tables("tblPurchaseOrderDetail").DefaultView.Count = 0 Then
        '    MsgBox("No Vehicles in stock to sell!")
        '    dsData.Tables("tblPurchaseOrderDetail").DefaultView.RowFilter = ""
        '    Exit Sub
        'End If
        'Dim dv As DataView = dsData.Tables("vwSalesOrderDetail").DefaultView

        'Dim frm As New frmGetvehicle(dv)
        'frm.ShowDialog()


        ' ''aDD vehicle
        'Dim i As Integer
        'For i = 0 To frm.arr.Length - 1
        '    If frm.arr(i) <> 0 Then


        '        dsData.Tables("vwSalesOrderDetail").DefaultView.AllowNew = True
        '        Dim drs() As DataRow = dsData.Tables("vwPurchaseOrderDetails").Select("PurchaseOrderDetailID=" & frm.arr(i))
        '        If drs.Length <> 0 Then

        '            Dim dr As DataRow = dsData.Tables("vwSalesOrderDetail").NewRow

        '            dr("VehicleID") = drs(0)("PurchaseOrderDetailID")
        '            dr("SalesOrderID") = txtSOID.Text
        '            dr("Price") = drs(0)("SRP")
        '            dr("VehYear") = drs(0)("VehYear")
        '            dr("VehMake") = drs(0)("VehMake")
        '            dr("VehModel") = drs(0)("VehModel")
        '            dr("VehColor") = drs(0)("VehColor")
        '            dr("VIN") = drs(0)("VIN")
        '            dr("SellPrice") = drs(0)("SRP")
        '            If drs(0)("VehExpense") Is DBNull.Value Then
        '                drs(0)("VehExpense") = 0
        '            End If
        '            dr("TotalCost") = drs(0)("Cost") + drs(0)("POExpense") + drs(0)("POVehExpense") + drs(0)("VehExpense") - drs(0)("Discount")
        '            dr("Del") = 0
        '            dsData.Tables("vwSalesOrderDetail").Rows.Add(dr)
        '            dsData.Tables("vwSalesOrderDetail").DefaultView.AllowNew = False

        '        End If

        '    End If
        'Next
    End Sub

#End Region


End Class