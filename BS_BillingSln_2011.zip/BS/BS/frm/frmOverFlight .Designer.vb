<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOverFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.rdbAllTransactions = New System.Windows.Forms.RadioButton
        Me.rdbModifiedTransactions = New System.Windows.Forms.RadioButton
        Me.rdbNewTransactions = New System.Windows.Forms.RadioButton
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.pnlModified = New System.Windows.Forms.Panel
        Me.btnGrdClose = New System.Windows.Forms.Button
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.grdModifiedOverFlight = New System.Windows.Forms.DataGridView
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grdNewOverFlight = New System.Windows.Forms.DataGridView
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnDeleteAllTransaction = New BHBut.BouncingHoverButton
        Me.btnUpdateTransactions = New BHBut.BouncingHoverButton
        Me.btnCopyData = New BHBut.BouncingHoverButton
        Me.btnDelete = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.grpFilter.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        Me.pnlModified.SuspendLayout()
        CType(Me.grdModifiedOverFlight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdNewOverFlight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoEllipsis = True
        Me.Label1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(700, 40)
        Me.Label1.TabIndex = 350
        Me.Label1.Text = " Import Transactions (Over Flight)"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(700, 3)
        Me.pnlTitle.TabIndex = 352
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.rdbAllTransactions)
        Me.grpFilter.Controls.Add(Me.rdbModifiedTransactions)
        Me.grpFilter.Controls.Add(Me.rdbNewTransactions)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(5, 49)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(676, 44)
        Me.grpFilter.TabIndex = 353
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "filter"
        '
        'rdbAllTransactions
        '
        Me.rdbAllTransactions.AutoSize = True
        Me.rdbAllTransactions.Checked = True
        Me.rdbAllTransactions.ForeColor = System.Drawing.Color.Maroon
        Me.rdbAllTransactions.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.rdbAllTransactions.Location = New System.Drawing.Point(23, 16)
        Me.rdbAllTransactions.Name = "rdbAllTransactions"
        Me.rdbAllTransactions.Size = New System.Drawing.Size(108, 17)
        Me.rdbAllTransactions.TabIndex = 4
        Me.rdbAllTransactions.TabStop = True
        Me.rdbAllTransactions.Text = "All Transaction(s)"
        Me.rdbAllTransactions.UseVisualStyleBackColor = True
        '
        'rdbModifiedTransactions
        '
        Me.rdbModifiedTransactions.AutoSize = True
        Me.rdbModifiedTransactions.ForeColor = System.Drawing.Color.Maroon
        Me.rdbModifiedTransactions.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.rdbModifiedTransactions.Location = New System.Drawing.Point(343, 16)
        Me.rdbModifiedTransactions.Name = "rdbModifiedTransactions"
        Me.rdbModifiedTransactions.Size = New System.Drawing.Size(137, 17)
        Me.rdbModifiedTransactions.TabIndex = 3
        Me.rdbModifiedTransactions.Text = "Modified Transaction(s)"
        Me.rdbModifiedTransactions.UseVisualStyleBackColor = True
        '
        'rdbNewTransactions
        '
        Me.rdbNewTransactions.AutoSize = True
        Me.rdbNewTransactions.ForeColor = System.Drawing.Color.Maroon
        Me.rdbNewTransactions.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.rdbNewTransactions.Location = New System.Drawing.Point(179, 16)
        Me.rdbNewTransactions.Name = "rdbNewTransactions"
        Me.rdbNewTransactions.Size = New System.Drawing.Size(118, 17)
        Me.rdbNewTransactions.TabIndex = 2
        Me.rdbNewTransactions.Text = "New Transaction(s)"
        Me.rdbNewTransactions.UseVisualStyleBackColor = True
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(46, 101)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(153, 291)
        Me.grpShowHideColumns.TabIndex = 362
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(140, 244)
        Me.chkLstGridCol.TabIndex = 0
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 262)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(140, 27)
        Me.btnSaveSettings.TabIndex = 1
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'pnlModified
        '
        Me.pnlModified.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlModified.Controls.Add(Me.btnGrdClose)
        Me.pnlModified.Controls.Add(Me.btnSave)
        Me.pnlModified.Controls.Add(Me.grdModifiedOverFlight)
        Me.pnlModified.Location = New System.Drawing.Point(7, 290)
        Me.pnlModified.Name = "pnlModified"
        Me.pnlModified.Size = New System.Drawing.Size(673, 113)
        Me.pnlModified.TabIndex = 363
        Me.pnlModified.Visible = False
        '
        'btnGrdClose
        '
        Me.btnGrdClose.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnGrdClose.BackColor = System.Drawing.Color.Linen
        Me.btnGrdClose.BackgroundImage = Global.BS.My.Resources.Resources.Close
        Me.btnGrdClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnGrdClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnGrdClose.FlatAppearance.BorderSize = 2
        Me.btnGrdClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnGrdClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnGrdClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGrdClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGrdClose.ForeColor = System.Drawing.Color.White
        Me.btnGrdClose.Location = New System.Drawing.Point(1, 4)
        Me.btnGrdClose.Name = "btnGrdClose"
        Me.btnGrdClose.Size = New System.Drawing.Size(33, 29)
        Me.btnGrdClose.TabIndex = 358
        Me.btnGrdClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.Enabled = False
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(288, 83)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(81, 27)
        Me.btnSave.TabIndex = 168
        Me.btnSave.Text = "S a v e"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'grdModifiedOverFlight
        '
        Me.grdModifiedOverFlight.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdModifiedOverFlight.BackgroundColor = System.Drawing.Color.LavenderBlush
        Me.grdModifiedOverFlight.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdModifiedOverFlight.Location = New System.Drawing.Point(0, 3)
        Me.grdModifiedOverFlight.Name = "grdModifiedOverFlight"
        Me.grdModifiedOverFlight.Size = New System.Drawing.Size(670, 74)
        Me.grdModifiedOverFlight.TabIndex = 359
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(7, 101)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 29)
        Me.btnShowCol.TabIndex = 361
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grdNewOverFlight
        '
        Me.grdNewOverFlight.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdNewOverFlight.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdNewOverFlight.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdNewOverFlight.Location = New System.Drawing.Point(5, 99)
        Me.grdNewOverFlight.Name = "grdNewOverFlight"
        Me.grdNewOverFlight.Size = New System.Drawing.Size(676, 304)
        Me.grdNewOverFlight.TabIndex = 356
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnDeleteAllTransaction)
        Me.grpButtons.Controls.Add(Me.btnUpdateTransactions)
        Me.grpButtons.Controls.Add(Me.btnCopyData)
        Me.grpButtons.Controls.Add(Me.btnDelete)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Location = New System.Drawing.Point(4, 409)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(676, 50)
        Me.grpButtons.TabIndex = 364
        Me.grpButtons.TabStop = False
        '
        'btnDeleteAllTransaction
        '
        Me.btnDeleteAllTransaction.AlternativeGroup = Nothing
        Me.btnDeleteAllTransaction.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDeleteAllTransaction.BackColor = System.Drawing.Color.Red
        Me.btnDeleteAllTransaction.BackColor1 = System.Drawing.Color.Maroon
        Me.btnDeleteAllTransaction.BackColor2 = System.Drawing.Color.Red
        Me.btnDeleteAllTransaction.BorderHover = True
        Me.btnDeleteAllTransaction.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnDeleteAllTransaction.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDeleteAllTransaction.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDeleteAllTransaction.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnDeleteAllTransaction.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDeleteAllTransaction.DrawBorder = True
        Me.btnDeleteAllTransaction.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDeleteAllTransaction.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteAllTransaction.ForeColor = System.Drawing.Color.White
        Me.btnDeleteAllTransaction.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnDeleteAllTransaction.HoverColor2 = System.Drawing.Color.White
        Me.btnDeleteAllTransaction.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDeleteAllTransaction.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnDeleteAllTransaction.Location = New System.Drawing.Point(370, 14)
        Me.btnDeleteAllTransaction.Name = "btnDeleteAllTransaction"
        Me.btnDeleteAllTransaction.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnDeleteAllTransaction.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnDeleteAllTransaction.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDeleteAllTransaction.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDeleteAllTransaction.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnDeleteAllTransaction.SelectedText = Nothing
        Me.btnDeleteAllTransaction.Size = New System.Drawing.Size(107, 28)
        Me.btnDeleteAllTransaction.TabIndex = 173
        Me.btnDeleteAllTransaction.Text = "Delete All Trx"
        Me.btnDeleteAllTransaction.UseVisualStyleBackColor = False
        '
        'btnUpdateTransactions
        '
        Me.btnUpdateTransactions.AlternativeGroup = Nothing
        Me.btnUpdateTransactions.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnUpdateTransactions.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnUpdateTransactions.BackColor1 = System.Drawing.Color.White
        Me.btnUpdateTransactions.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnUpdateTransactions.BorderHover = True
        Me.btnUpdateTransactions.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnUpdateTransactions.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnUpdateTransactions.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnUpdateTransactions.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnUpdateTransactions.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnUpdateTransactions.DrawBorder = True
        Me.btnUpdateTransactions.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnUpdateTransactions.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnUpdateTransactions.ForeColor = System.Drawing.Color.Navy
        Me.btnUpdateTransactions.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnUpdateTransactions.HoverColor2 = System.Drawing.Color.White
        Me.btnUpdateTransactions.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnUpdateTransactions.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnUpdateTransactions.Location = New System.Drawing.Point(101, 14)
        Me.btnUpdateTransactions.Name = "btnUpdateTransactions"
        Me.btnUpdateTransactions.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnUpdateTransactions.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnUpdateTransactions.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnUpdateTransactions.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnUpdateTransactions.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnUpdateTransactions.SelectedText = Nothing
        Me.btnUpdateTransactions.Size = New System.Drawing.Size(155, 27)
        Me.btnUpdateTransactions.TabIndex = 172
        Me.btnUpdateTransactions.Text = "Insert New Transactions" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnUpdateTransactions.UseVisualStyleBackColor = False
        '
        'btnCopyData
        '
        Me.btnCopyData.AlternativeGroup = Nothing
        Me.btnCopyData.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCopyData.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCopyData.BackColor1 = System.Drawing.Color.White
        Me.btnCopyData.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCopyData.BorderHover = True
        Me.btnCopyData.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCopyData.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCopyData.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCopyData.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCopyData.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCopyData.DrawBorder = True
        Me.btnCopyData.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCopyData.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCopyData.ForeColor = System.Drawing.Color.Navy
        Me.btnCopyData.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCopyData.HoverColor2 = System.Drawing.Color.White
        Me.btnCopyData.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCopyData.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCopyData.Location = New System.Drawing.Point(4, 14)
        Me.btnCopyData.Name = "btnCopyData"
        Me.btnCopyData.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCopyData.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCopyData.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCopyData.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCopyData.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCopyData.SelectedText = Nothing
        Me.btnCopyData.Size = New System.Drawing.Size(93, 27)
        Me.btnCopyData.TabIndex = 171
        Me.btnCopyData.Text = "Import Data"
        Me.btnCopyData.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.AlternativeGroup = Nothing
        Me.btnDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDelete.BackColor = System.Drawing.Color.Red
        Me.btnDelete.BackColor1 = System.Drawing.Color.Maroon
        Me.btnDelete.BackColor2 = System.Drawing.Color.Red
        Me.btnDelete.BorderHover = True
        Me.btnDelete.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnDelete.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDelete.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDelete.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnDelete.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDelete.DrawBorder = True
        Me.btnDelete.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnDelete.HoverColor2 = System.Drawing.Color.White
        Me.btnDelete.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDelete.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnDelete.Location = New System.Drawing.Point(259, 14)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnDelete.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnDelete.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDelete.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDelete.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnDelete.SelectedText = Nothing
        Me.btnDelete.Size = New System.Drawing.Size(107, 28)
        Me.btnDelete.TabIndex = 170
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(574, 16)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(93, 27)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'frmOverFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(700, 461)
        Me.Controls.Add(Me.grpShowHideColumns)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.pnlModified)
        Me.Controls.Add(Me.btnShowCol)
        Me.Controls.Add(Me.grdNewOverFlight)
        Me.Controls.Add(Me.grpFilter)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.Label1)
        Me.KeyPreview = True
        Me.Name = "frmOverFlight"
        Me.Text = "frmOverFlight"
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.pnlModified.ResumeLayout(False)
        CType(Me.grdModifiedOverFlight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdNewOverFlight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpButtons.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents pnlTitle As System.Windows.Forms.Panel
	Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
	Friend WithEvents rdbAllTransactions As System.Windows.Forms.RadioButton
	Friend WithEvents rdbModifiedTransactions As System.Windows.Forms.RadioButton
	Friend WithEvents rdbNewTransactions As System.Windows.Forms.RadioButton
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
	Friend WithEvents pnlModified As System.Windows.Forms.Panel
	Friend WithEvents btnGrdClose As System.Windows.Forms.Button
	Friend WithEvents btnSave As BHBut.BouncingHoverButton
	Friend WithEvents grdModifiedOverFlight As System.Windows.Forms.DataGridView
	Friend WithEvents btnShowCol As System.Windows.Forms.Button
	Friend WithEvents grdNewOverFlight As System.Windows.Forms.DataGridView
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnDeleteAllTransaction As BHBut.BouncingHoverButton
	Friend WithEvents btnUpdateTransactions As BHBut.BouncingHoverButton
	Friend WithEvents btnCopyData As BHBut.BouncingHoverButton
	Friend WithEvents btnDelete As BHBut.BouncingHoverButton
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
End Class
