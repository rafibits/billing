Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmCategory


#Region " Form Declaration  .  .  . "
    ''
    Dim clsMr As ClsMain
    Dim dsData As New DataSet
    Private WithEvents Nav As BitsNav
    Dim blnLoading As Boolean = False
    Private blnEdit As Boolean = False
    Private AddMode As Boolean
    Private blnExitSave As Boolean
    Dim daServiceCategory As New SqlClient.SqlDataAdapter
    Private dataChange As Boolean
    'Dim mServiceID As Integer = -1
    ''
#End Region


#Region "Form initialisation . . . "

    Private Sub frmCategory_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmCategory_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav
        ''
        blnLoading = True
        MakeDataAdapter()
        SetDataBinding()
        FillComboBox()
        SetAutoNumber()
        SetCurrency()
        SetDefaultValue()
        ''
        checkListValues()
        dataChange = False
        setState("BROWSE")
        blnLoading = False
        ''
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

#End Region


#Region " Form Functions  .  .  . "

    Private Sub MakeDataAdapter()
        ''
        daServiceCategory = clsMr.BuildSqlAdapter("SELECT * FROM tblServiceCategory WHERE Del = 0", "tblServiceCategory")
        dsData = clsMr.getDataSet
        ''
    End Sub

    Private Sub FillComboBox()
        ''
        'clsMr.FillComboBox("tblServiceCategory", CboCategory, "CatType", "CatID")
        clsMr.FillComboBox("tblServiceCategory", lstViewServiceCategory, "CatType", "CatID")
        ''
    End Sub

    Private Sub SetDataBinding()
        ''
        clsMr.BindTextBox(txtServiceCategoryID, "tblServiceCategory", "CatID")
        clsMr.BindTextBox(txtServiceCategoryName, "tblServiceCategory", "CatType")
        clsMr.BindTextBox(txtServiceCategoryCode, "tblServiceCategory", "CatCode")
        clsMr.BindTextBox(txtDescription, "tblServiceCategory", "Description")
        ''
    End Sub

    Private Sub SetAutoNumber()
        ''
        clsMr.SetAutoNumber("tblServiceCategory", "CatID")
        ''
    End Sub

    Public Sub SetDefaultValue()
        ''
        clsMr.SetDefaults("tblServiceCategory", "CreateBy", gIntUserID)
        clsMr.SetDefaults("tblServiceCategory", "CreateDate", Now.Date)
        clsMr.SetDefaults("tblServiceCategory", "Del", 0)
        ''
    End Sub

    Private Sub SetCurrency()
        ''
        Nav.SetCurrency(Me, dsData, "tblServiceCategory")
        ''
    End Sub

    Private Sub setState(ByRef pStrMode As String)
        ''
        Dim mStrCurrentState As String
        mStrCurrentState = UCase(pStrMode)
        '' 
        Select Case mStrCurrentState
            Case Is = "NEW"
                AddMode = True
                grpListServiceCategory.Enabled = False
                grpServiceCategory.Enabled = True
                'txtServiceCategoryCode.ReadOnly = False
                txtServiceCategoryName.ReadOnly = False
                btnDelete.Enabled = False
                btnNew.Enabled = False
                btnCancel.Enabled = True
                btnSave.Text = "S a v e"

            Case Is = "EDIT"
                btnNew.Enabled = False
                btnSave.Enabled = False
                btnCancel.Enabled = True
                grpListServiceCategory.Enabled = False
                grpServiceCategory.Enabled = True
                'txtServiceCategoryCode.ReadOnly = True
                txtServiceCategoryName.ReadOnly = True
                btnDelete.Enabled = False
                blnEdit = True
                btnSave.Text = "S a v e"
            Case Is = "BROWSE"
                grpServiceCategory.Enabled = False
                grpListServiceCategory.Enabled = True
                btnDelete.Enabled = True
                btnNew.Enabled = True
                btnSave.Enabled = True
                btnCancel.Enabled = False
                btnSave.Text = "E d i t"

            Case Is = "SAVE"
                grpServiceCategory.Enabled = False
                grpListServiceCategory.Enabled = True
                btnDelete.Enabled = True
                btnNew.Enabled = True
                btnCancel.Enabled = False
                AddMode = False
                btnSave.Text = "E d i t"

            Case Is = "CANCEL"
                grpServiceCategory.Enabled = False
                grpListServiceCategory.Enabled = True
                btnDelete.Enabled = True
                btnCancel.Enabled = False
                btnDataErr.Visible = False
                lstDataErr.Visible = False
                btnNew.Enabled = True
                btnSave.Enabled = False
                AddMode = False
        End Select
        ''
        ''
        DGCA.LoadPermissionsSetState(Me, Me.Name)
    End Sub

    Private Sub Save()
        ''
        checkListValues()
        Nav.EndCurrentEdit()
        clsMr.Update(daServiceCategory, "tblServiceCategory")
        ''
    End Sub

    Private Sub checkListValues()
        ''
        If blnLoading = True Then Exit Sub

        ''
        dataChange = True

        '' clear entir list & start fresh check...
        ''
        lstDataErr.Items.Clear()
        Dim intErrCount As Int16 = 0

        If txtServiceCategoryName.Text = String.Empty Then
            lstDataErr.Items.Add(" - Please Enter Service Category Name")
            intErrCount += 1
        End If

        If txtServiceCategoryCode.Text = String.Empty Then
            lstDataErr.Items.Add(" - Please Enter Service Category Code")
            intErrCount += 1
        End If
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' Set appropriate controls based on errors check results...
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If lstDataErr.Items.Count = 0 Then
            lstDataErr.Visible = False
            btnDataErr.Visible = False
            btnSave.Enabled = True
        Else
            btnDataErr.Visible = True
            btnSave.Enabled = False
        End If
        ''
    End Sub

#End Region


#Region "form - Events . . ."

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        ''
        'dsData.Tables("tblServiceCategory").DefaultView.AllowNew = True
        checkListValues()
        Nav.AddNew()
        setState("NEW")
        ''
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        ''
        If btnSave.Text = "E d i t" Then

            setState("Edit")
        Else
            Save()

            'Exit Save function in case Service Name deja exists

            If blnExitSave Then
                setState("SAVE")

                Exit Sub
            End If
            dataChange = False
            setState("SAVE")
            dsData.Tables("tblServiceCategory").DefaultView.AllowNew = False
        End If
        ''
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ''
        If dataChange Then
            If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

                Try
                    Nav.CancelCurrentEdit()
                    'If AddMode = True Then
                    '   Me.Close()

                    'End If
                Catch ex As Exception
                    ''
                End Try
                dataChange = False
                'AddMode = False
                setState("BROWSE")
            End If
        Else
            ''
            setState("BROWSE")
        End If
        ''
        ''
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        ''
        If dataChange Then
            ''
            Dim res As MsgBoxResult
            res = MsgBox("Do you want to save changes?", MsgBoxStyle.YesNoCancel)
            ''
            Select Case res
                Case MsgBoxResult.Yes
                    Save()
                    Me.Close()

                Case MsgBoxResult.No
                    Nav.CancelCurrentEdit()
                    Me.Close()

                Case MsgBoxResult.Cancel

            End Select
        Else
            Me.Close()
        End If
        ''
    End Sub

    Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
        '' Show/Hide error list...
        If lstDataErr.Visible = True Then
            lstDataErr.Visible = False
        Else
            lstDataErr.Visible = True
            lstDataErr.Height = 35
            lstDataErr.BringToFront()
        End If
        ''
    End Sub

    Private Sub dtpCreateDate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        checkListValues()
        ''
    End Sub

    Private Sub txtServiceCategoryName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtServiceCategoryName.TextChanged
        ''
        checkListValues()
        ''
    End Sub

    Private Sub txtDescription_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDescription.TextChanged
        ''
        checkListValues()
        ''
    End Sub

    Private Sub lstViewServiceCategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstViewServiceCategory.SelectedIndexChanged
        ''
        If blnLoading = True Then
            Exit Sub
        End If
        ''
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        ''
        If lstViewServiceCategory.Items.Count = 0 Then Exit Sub
        ''
        Select Case lstViewServiceCategory.SelectedValue
            ''
            Case 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
                MsgBox("You cannot Delete This Category")
                Exit Sub
        End Select
        ''
        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to delete?", MsgBoxStyle.YesNo, "BitSolution")

        If response = MsgBoxResult.Yes Then
            Try

                Dim cmd As New SqlClient.SqlCommand("UPDATE tblServiceCategory SET Del=1 WHERE CatID=" & lstViewServiceCategory.SelectedValue, conSql)
                conSql.Open()
                cmd.ExecuteNonQuery()
                conSql.Close()
            Catch ex As Exception
                conSql.Close()
            End Try
            dsData.Tables("tblServiceCategory").DefaultView.Item(Nav.CurrentPosition).Delete()
            'dsData.Tables("tblServiceCategory").DefaultView.Item(lstViewServiceCategory.SelectedValue).Delete()
        End If
        ''
    End Sub

    Private Sub txtServiceCategoryCode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtServiceCategoryCode.TextChanged
        ''
        checkListValues()
    End Sub

#End Region


End Class