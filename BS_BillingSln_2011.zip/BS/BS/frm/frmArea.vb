''
Imports BITSConn

Public Class frmArea

#Region " Form Declaration . . . ."

    Dim Nav As BitsNav
    Dim clsMr As ClsMain
    Dim daArea As SqlClient.SqlDataAdapter
    '' Form Vars...
    Private blnLoading As Boolean = True
    Dim mStrtableName As String = "tblArea"
    Dim StrSql As String = "SELECT * from tblArea"
    Dim dsdata As New DataSet
    Private dataChange As Boolean = False
    Private mStrCurrentState As String
    Private AddMode As Boolean

#End Region

#Region " Form Initialization. . ."

    Private Sub frmArea_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ''
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav
        ''
        blnLoading = True
        MakeDataAdapter()
        FillCombobox()
        SetDataBinding()
        SetAutoNumber()
        SetDefaultValue()
        SetCurrencyManager()
        blnLoading = False
        ''
        If dsdata.Tables(mStrtableName).Rows.Count = 0 Then
            btnNew.PerformClick()
        End If
        ''
        setState("BROWSE")
    End Sub

    Private Sub MakeDataAdapter()
        ''
        daArea = clsMr.BuildSqlAdapter("SELECT * From tblArea where Del =0", mStrtableName)
        clsMr.BuildSqlAdapter("SELECT AreaTypeID,AreaType from tblAreaType where Del=0", "AreaType")
        clsMr.BuildSqlAdapter("SELECT Zone, ZoneID from tblZone where Del=0", "tblZone")
        clsMr.BuildSqlAdapter("SELECT Zone, ZoneID from tblZone where Del=0", "tblZoneFilter")
        dsdata = clsMr.getDataSet
    End Sub

    Private Sub FillCombobox()
        ''
        clsMr.FillComboBox("AreaType", CboAreaType, "AreaType", "AreaTypeID")
        clsMr.FillComboBox(mStrtableName, lstArea, "AreaNum", "AreaID")
        clsMr.FillComboBox("tblZone", cboZone, "Zone", "ZoneID")
        clsMr.FillComboBox("tblZoneFilter", cboZoneFilter, "Zone", "ZoneID")

    End Sub

    Private Sub SetAutoNumber()
        ''
        clsMr.SetAutoNumber(mStrtableName, "AreaID")
    End Sub

    Private Sub SetDefaultValue()
        ''
        'clsMr.SetDefaults(mStrtableName, "Del", 0, "CreateByID", gIntUserID, "CreateDate", Now.Date)
        clsMr.SetDefaults(mStrtableName, "Del", 0)
        clsMr.SetDefaults(mStrtableName, "AreaSQM", 0, "feePerMeter", 0, "Occupied", 0)

    End Sub

    Private Sub SetCurrencyManager()
        ''
        Nav.SetCurrency(Me, dsdata, mStrtableName)
    End Sub

    Private Sub SetDataBinding()
        ''
        clsMr.BindTextBox(txtAreaID, mStrtableName, "AreaID")
        clsMr.BindComboBox(CboAreaType, mStrtableName, "AreaTypeID")
        clsMr.BindTextBox(txtAreaNum, mStrtableName, "AreaNum")
        clsMr.BindComboBox(cboZone, mStrtableName, "ZoneID")
        clsMr.BindTextBox(txtOfficeNumber, mStrtableName, "OfficeNumber")
        clsMr.BindTextBox(txtFeePerMeter, mStrtableName, "feePerMeter")
        clsMr.BindTextBox(txtDescription, mStrtableName, "Description")
        clsMr.BindTextBox(txtAreaSQM, mStrtableName, "AreaSQM")

        clsMr.BindTextBox(txtPhoneRef1, mStrtableName, "PhoneRef1")
        clsMr.BindTextBox(txtPhoneRef2, mStrtableName, "PhoneRef2")
        clsMr.BindTextBox(txtPhoneRef3, mStrtableName, "PhoneRef3")
        clsMr.BindTextBox(txtPhoneRef4, mStrtableName, "PhoneRef4")

        clsMr.BindTextBox(txtNetworkRef1, mStrtableName, "NetworkRef1")
        clsMr.BindTextBox(txtNetworkRef2, mStrtableName, "NetworkRef2")
        clsMr.BindTextBox(txtNetworkRef3, mStrtableName, "NetworkRef3")
        clsMr.BindTextBox(txtNetworkRef4, mStrtableName, "NetworkRef4")

        clsMr.BindTextBox(txtElectrictyRef1, mStrtableName, "ElectricyRef1")
        clsMr.BindTextBox(txtElectrictyRef2, mStrtableName, "ElectricyRef2")
        clsMr.BindTextBox(txtElectrictyRef3, mStrtableName, "ElectricyRef3")
        clsMr.BindTextBox(txtElectrictyRef4, mStrtableName, "ElectricyRef4")

    End Sub

#End Region

#Region " Form Functions     . . ."

    Private Sub setState(ByRef pStrMode As String)
        ''
        mStrCurrentState = UCase(pStrMode)
        '' 
        Select Case mStrCurrentState
            Case Is = "NEW"

                Me.btnSave.Enabled = False
                Me.btnCancel.Enabled = True
                Me.btnNew.Enabled = False
                grpInfo.Enabled = True
                btnSave.Text = "S a v e"
            Case Is = "EDIT"

                Me.btnSave.Enabled = False
                Me.btnCancel.Enabled = True
                Me.btnNew.Enabled = False
                grpInfo.Enabled = True
                btnSave.Text = "S a v e"

            Case Is = "SAVE"

                Me.btnSave.Enabled = True
                Me.btnCancel.Enabled = False
                Me.btnNew.Enabled = True
                btnSave.Text = "E d i t"
                grpInfo.Enabled = False

            Case Is = "BROWSE"

                Me.btnSave.Enabled = True
                Me.btnCancel.Enabled = False
                Me.btnNew.Enabled = True
                btnSave.Text = "E d i t"
                grpInfo.Enabled = False
        End Select
    End Sub

    Private Sub Save()


        dataChange = False

        Nav.EndCurrentEdit()
        daArea.Update(dsdata, mStrtableName)
    End Sub

    Private Sub CheckValues()
        If blnLoading = True Then Exit Sub

        ''
        dataChange = True

        '' clear entir list & start fresh check...
        ''
        lstDataErr.Items.Clear()
        Dim intErrCount As Int16 = 0


        intErrCount += 1

        If txtAreaNum.Text = String.Empty Then
            lstDataErr.Items.Add("Please Enter Area Number")
            intErrCount += 1
        End If

        If cboZone.SelectedIndex = -1 Then
            lstDataErr.Items.Add("Please Enter Zone")
            intErrCount += 1
        End If

        If CboAreaType.SelectedIndex = -1 Then
            lstDataErr.Items.Add("Please Enter Area Type")
            intErrCount += 1
        End If

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '' Set appropriate controls based on errors check results...
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        If lstDataErr.Items.Count = 0 Then
            lstDataErr.Visible = False
            btnDataErr.Visible = False
            btnSave.Enabled = True
        Else
            btnDataErr.Visible = True
            btnSave.Enabled = False
        End If
    End Sub

#End Region

#Region " UI Controls      . . .  "

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Nav.AddNew()
        cboZone.SelectedIndex = -1
        CboAreaType.SelectedIndex = -1
        setState("New")
        CheckValues()
        btnSave.Text = "Save"
        AddMode = True
    End Sub

    Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
        '' Show/Hide error list...
        If lstDataErr.Visible = True Then
            lstDataErr.Visible = False
        Else
            lstDataErr.Visible = True
            lstDataErr.Height = 251
            lstDataErr.BringToFront()
        End If
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If btnSave.Text = "E d i t" Then

            setState("EDIT")
            AddMode = True
            CheckValues()
            Exit Sub
        End If
        Save()
        setState("SAVE")
        AddMode = False
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ''
        If dataChange Then
            If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

                Try
                    Nav.CancelCurrentEdit()
                Catch ex As Exception

                End Try

                dataChange = False
                AddMode = False

            End If
        Else

            'AddMode = False
        End If

        setState("BROWSE")
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        '' check OK to close...
        If dataChange Then
            Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
                Case MsgBoxResult.Yes
                    '' call save...
                    If lstDataErr.Items.Count <> 0 Then
                        MsgBox("Cannot save.Please check error list")
                        Exit Sub
                    Else
                        Save()
                        Me.Close()
                    End If
                Case MsgBoxResult.No
                    '' ignore changes...

                    Try
                        Nav.CancelCurrentEdit()
                    Catch ex As Exception

                    End Try
                    Me.Close()
                Case MsgBoxResult.Cancel
                    '' ignore close press..
                    '' do nothing...

            End Select
        Else
            Me.Close()
        End If
    End Sub

    Private Sub txtCode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtOfficeNumber.TextChanged
        CheckValues()
    End Sub

    Private Sub txtZone_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        CheckValues()
    End Sub

    Private Sub txtName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        CheckValues()
    End Sub

    Private Sub CboAreaType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboAreaType.SelectedIndexChanged
        CheckValues()
    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSearch.TextChanged
        ''
        If rdbContains.Checked = True Then
            dsdata.Tables(mStrtableName).DefaultView.RowFilter = "AreaNum LIKE '%" & txtSearch.Text & "%'"
        Else
            dsdata.Tables(mStrtableName).DefaultView.RowFilter = "AreaNum LIKE '" & txtSearch.Text & "%'"
        End If
    End Sub

    Private Sub lstArea_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstArea.SelectedIndexChanged
        dataChange = False
    End Sub

    Private Sub txtDescription_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDescription.TextChanged
        ''
        CheckValues()
        If txtDescription.Text.Length > 49 Then
            txtDescription.Text = txtDescription.Text.Remove(txtDescription.Text.Length - 2)
            MsgBox("Description can not exceed 50 character")
        End If

    End Sub

#End Region

    Private Sub cboZoneFilter_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboZoneFilter.SelectedIndexChanged
        ''
        If blnLoading Then Exit Sub
        dsdata.Tables(mStrtableName).DefaultView.RowFilter = "ZoneID = " & cboZoneFilter.SelectedValue
    End Sub

    Private Sub txtAreaNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAreaNum.TextChanged
        ''
        CheckValues()
    End Sub

    Private Sub cboZone_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboZone.SelectedIndexChanged
        ''
        CheckValues()
    End Sub

#Region "Permissions.."
    ''Done by Mohamad March, 2008''

    'Area'
    Private Sub txtAreaSQM_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtAreaSQM.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Fee Per Meter'
    Private Sub txtFeePerMeter_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFeePerMeter.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

#End Region

End Class