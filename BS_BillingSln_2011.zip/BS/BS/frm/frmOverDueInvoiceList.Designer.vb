<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOverDueInvoiceList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.grdInvoiceList = New System.Windows.Forms.DataGridView
        Me.grpDuePeriods = New System.Windows.Forms.GroupBox
        Me.chkOverDue120 = New System.Windows.Forms.CheckBox
        Me.chkOverDue90 = New System.Windows.Forms.CheckBox
        Me.chkOverDue60 = New System.Windows.Forms.CheckBox
        Me.chkDue = New System.Windows.Forms.CheckBox
        Me.chkOverDue30 = New System.Windows.Forms.CheckBox
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.txtTotalCurr2 = New System.Windows.Forms.TextBox
        Me.lblCurrSymbol = New System.Windows.Forms.Label
        Me.txtTotal = New System.Windows.Forms.TextBox
        Me.lblCurrSymbol2 = New System.Windows.Forms.Label
        Me.lblInvoiceNum = New System.Windows.Forms.Label
        Me.txtInvoiceNum = New System.Windows.Forms.TextBox
        Me.lblCategory = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.grpGrid = New System.Windows.Forms.GroupBox
        Me.grpReportOptions = New System.Windows.Forms.GroupBox
        Me.btnCancelPreview = New System.Windows.Forms.Button
        Me.btnOkPreview = New System.Windows.Forms.Button
        Me.rdbArabic = New System.Windows.Forms.RadioButton
        Me.rdbEnglish = New System.Windows.Forms.RadioButton
        Me.cboCategory = New System.Windows.Forms.ComboBox
        Me.btnPreview = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.dtpDateTo = New System.Windows.Forms.DateTimePicker
        Me.lblDateFrom = New System.Windows.Forms.Label
        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.cboStatus = New System.Windows.Forms.ComboBox
        Me.lblDateTo = New System.Windows.Forms.Label
        Me.lblClient = New System.Windows.Forms.Label
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.grpShowHideColumns.SuspendLayout()
        CType(Me.grdInvoiceList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpDuePeriods.SuspendLayout()
        Me.grpGrid.SuspendLayout()
        Me.grpReportOptions.SuspendLayout()
        Me.grpButtons.SuspendLayout()
        Me.grpFilter.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(897, 3)
        Me.pnlTitle.TabIndex = 355
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(897, 40)
        Me.lblfrmTitle.TabIndex = 354
        Me.lblfrmTitle.Text = " Over-Due Invoice List"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(43, 19)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 209)
        Me.grpShowHideColumns.TabIndex = 155
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 180)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 124)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'grdInvoiceList
        '
        Me.grdInvoiceList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdInvoiceList.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdInvoiceList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdInvoiceList.Location = New System.Drawing.Point(3, 16)
        Me.grdInvoiceList.Name = "grdInvoiceList"
        Me.grdInvoiceList.Size = New System.Drawing.Size(880, 235)
        Me.grdInvoiceList.TabIndex = 152
        '
        'grpDuePeriods
        '
        Me.grpDuePeriods.BackColor = System.Drawing.Color.AliceBlue
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue120)
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue90)
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue60)
        Me.grpDuePeriods.Controls.Add(Me.chkDue)
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue30)
        Me.grpDuePeriods.Location = New System.Drawing.Point(314, 42)
        Me.grpDuePeriods.Name = "grpDuePeriods"
        Me.grpDuePeriods.Size = New System.Drawing.Size(476, 44)
        Me.grpDuePeriods.TabIndex = 158
        Me.grpDuePeriods.TabStop = False
        '
        'chkOverDue120
        '
        Me.chkOverDue120.AutoSize = True
        Me.chkOverDue120.Checked = True
        Me.chkOverDue120.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue120.ForeColor = System.Drawing.Color.Blue
        Me.chkOverDue120.Location = New System.Drawing.Point(334, 13)
        Me.chkOverDue120.Name = "chkOverDue120"
        Me.chkOverDue120.Size = New System.Drawing.Size(87, 17)
        Me.chkOverDue120.TabIndex = 5
        Me.chkOverDue120.Text = "OverDue120"
        Me.chkOverDue120.UseVisualStyleBackColor = True
        '
        'chkOverDue90
        '
        Me.chkOverDue90.Checked = True
        Me.chkOverDue90.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue90.ForeColor = System.Drawing.Color.SandyBrown
        Me.chkOverDue90.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkOverDue90.Location = New System.Drawing.Point(222, 13)
        Me.chkOverDue90.Name = "chkOverDue90"
        Me.chkOverDue90.Size = New System.Drawing.Size(87, 17)
        Me.chkOverDue90.TabIndex = 4
        Me.chkOverDue90.Text = "OverDue90"
        '
        'chkOverDue60
        '
        Me.chkOverDue60.Checked = True
        Me.chkOverDue60.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue60.ForeColor = System.Drawing.Color.DimGray
        Me.chkOverDue60.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkOverDue60.Location = New System.Drawing.Point(112, 13)
        Me.chkOverDue60.Name = "chkOverDue60"
        Me.chkOverDue60.Size = New System.Drawing.Size(87, 17)
        Me.chkOverDue60.TabIndex = 3
        Me.chkOverDue60.Text = "OverDue60"
        '
        'chkDue
        '
        Me.chkDue.ForeColor = System.Drawing.Color.Navy
        Me.chkDue.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkDue.Location = New System.Drawing.Point(426, 13)
        Me.chkDue.Name = "chkDue"
        Me.chkDue.Size = New System.Drawing.Size(15, 14)
        Me.chkDue.TabIndex = 2
        Me.chkDue.Text = "Due"
        Me.chkDue.Visible = False
        '
        'chkOverDue30
        '
        Me.chkOverDue30.Checked = True
        Me.chkOverDue30.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue30.ForeColor = System.Drawing.Color.LightCoral
        Me.chkOverDue30.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkOverDue30.Location = New System.Drawing.Point(6, 13)
        Me.chkOverDue30.Name = "chkOverDue30"
        Me.chkOverDue30.Size = New System.Drawing.Size(87, 17)
        Me.chkOverDue30.TabIndex = 0
        Me.chkOverDue30.Text = "OverDue30"
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(5, 17)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 156
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'txtTotalCurr2
        '
        Me.txtTotalCurr2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalCurr2.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalCurr2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalCurr2.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalCurr2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalCurr2.Location = New System.Drawing.Point(772, 257)
        Me.txtTotalCurr2.Multiline = True
        Me.txtTotalCurr2.Name = "txtTotalCurr2"
        Me.txtTotalCurr2.ReadOnly = True
        Me.txtTotalCurr2.Size = New System.Drawing.Size(105, 23)
        Me.txtTotalCurr2.TabIndex = 362
        Me.txtTotalCurr2.TabStop = False
        '
        'lblCurrSymbol
        '
        Me.lblCurrSymbol.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCurrSymbol.BackColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol.ForeColor = System.Drawing.Color.White
        Me.lblCurrSymbol.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol.Location = New System.Drawing.Point(585, 258)
        Me.lblCurrSymbol.Name = "lblCurrSymbol"
        Me.lblCurrSymbol.Size = New System.Drawing.Size(34, 20)
        Me.lblCurrSymbol.TabIndex = 360
        Me.lblCurrSymbol.Text = "Curr"
        Me.lblCurrSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTotal
        '
        Me.txtTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotal.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotal.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotal.Location = New System.Drawing.Point(622, 257)
        Me.txtTotal.Multiline = True
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(105, 23)
        Me.txtTotal.TabIndex = 359
        Me.txtTotal.TabStop = False
        '
        'lblCurrSymbol2
        '
        Me.lblCurrSymbol2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCurrSymbol2.BackColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol2.ForeColor = System.Drawing.Color.White
        Me.lblCurrSymbol2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol2.Location = New System.Drawing.Point(735, 258)
        Me.lblCurrSymbol2.Name = "lblCurrSymbol2"
        Me.lblCurrSymbol2.Size = New System.Drawing.Size(34, 20)
        Me.lblCurrSymbol2.TabIndex = 363
        Me.lblCurrSymbol2.Text = "Curr"
        Me.lblCurrSymbol2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblInvoiceNum
        '
        Me.lblInvoiceNum.AutoSize = True
        Me.lblInvoiceNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblInvoiceNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblInvoiceNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInvoiceNum.Location = New System.Drawing.Point(314, 18)
        Me.lblInvoiceNum.Name = "lblInvoiceNum"
        Me.lblInvoiceNum.Size = New System.Drawing.Size(52, 13)
        Me.lblInvoiceNum.TabIndex = 154
        Me.lblInvoiceNum.Text = "Invoice #"
        Me.lblInvoiceNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtInvoiceNum
        '
        Me.txtInvoiceNum.ForeColor = System.Drawing.Color.Navy
        Me.txtInvoiceNum.Location = New System.Drawing.Point(366, 16)
        Me.txtInvoiceNum.Name = "txtInvoiceNum"
        Me.txtInvoiceNum.Size = New System.Drawing.Size(106, 20)
        Me.txtInvoiceNum.TabIndex = 155
        Me.txtInvoiceNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblCategory
        '
        Me.lblCategory.AutoSize = True
        Me.lblCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblCategory.ForeColor = System.Drawing.Color.Maroon
        Me.lblCategory.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCategory.Location = New System.Drawing.Point(1, 57)
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Size = New System.Drawing.Size(49, 13)
        Me.lblCategory.TabIndex = 153
        Me.lblCategory.Text = "Category"
        Me.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.BackColor = System.Drawing.Color.Maroon
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label3.Location = New System.Drawing.Point(533, 254)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(350, 29)
        Me.Label3.TabIndex = 364
        Me.Label3.Text = "  Total"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grpGrid
        '
        Me.grpGrid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpGrid.Controls.Add(Me.grpReportOptions)
        Me.grpGrid.Controls.Add(Me.lblCurrSymbol2)
        Me.grpGrid.Controls.Add(Me.txtTotalCurr2)
        Me.grpGrid.Controls.Add(Me.lblCurrSymbol)
        Me.grpGrid.Controls.Add(Me.txtTotal)
        Me.grpGrid.Controls.Add(Me.grpShowHideColumns)
        Me.grpGrid.Controls.Add(Me.btnShowCol)
        Me.grpGrid.Controls.Add(Me.grdInvoiceList)
        Me.grpGrid.Controls.Add(Me.Label3)
        Me.grpGrid.Location = New System.Drawing.Point(5, 136)
        Me.grpGrid.Name = "grpGrid"
        Me.grpGrid.Size = New System.Drawing.Size(889, 287)
        Me.grpGrid.TabIndex = 356
        Me.grpGrid.TabStop = False
        '
        'grpReportOptions
        '
        Me.grpReportOptions.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grpReportOptions.Controls.Add(Me.btnCancelPreview)
        Me.grpReportOptions.Controls.Add(Me.btnOkPreview)
        Me.grpReportOptions.Controls.Add(Me.rdbArabic)
        Me.grpReportOptions.Controls.Add(Me.rdbEnglish)
        Me.grpReportOptions.Location = New System.Drawing.Point(382, 56)
        Me.grpReportOptions.Name = "grpReportOptions"
        Me.grpReportOptions.Size = New System.Drawing.Size(236, 103)
        Me.grpReportOptions.TabIndex = 351
        Me.grpReportOptions.TabStop = False
        Me.grpReportOptions.Visible = False
        '
        'btnCancelPreview
        '
        Me.btnCancelPreview.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCancelPreview.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancelPreview.ForeColor = System.Drawing.Color.Navy
        Me.btnCancelPreview.Location = New System.Drawing.Point(155, 72)
        Me.btnCancelPreview.Name = "btnCancelPreview"
        Me.btnCancelPreview.Size = New System.Drawing.Size(75, 23)
        Me.btnCancelPreview.TabIndex = 5
        Me.btnCancelPreview.Text = "Cancel"
        Me.btnCancelPreview.UseVisualStyleBackColor = False
        '
        'btnOkPreview
        '
        Me.btnOkPreview.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOkPreview.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnOkPreview.ForeColor = System.Drawing.Color.Navy
        Me.btnOkPreview.Location = New System.Drawing.Point(74, 72)
        Me.btnOkPreview.Name = "btnOkPreview"
        Me.btnOkPreview.Size = New System.Drawing.Size(75, 23)
        Me.btnOkPreview.TabIndex = 4
        Me.btnOkPreview.Text = "OK"
        Me.btnOkPreview.UseVisualStyleBackColor = False
        '
        'rdbArabic
        '
        Me.rdbArabic.AutoSize = True
        Me.rdbArabic.ForeColor = System.Drawing.Color.Red
        Me.rdbArabic.Location = New System.Drawing.Point(21, 42)
        Me.rdbArabic.Name = "rdbArabic"
        Me.rdbArabic.Size = New System.Drawing.Size(55, 17)
        Me.rdbArabic.TabIndex = 2
        Me.rdbArabic.Text = "Arabic"
        Me.rdbArabic.UseVisualStyleBackColor = True
        '
        'rdbEnglish
        '
        Me.rdbEnglish.AutoSize = True
        Me.rdbEnglish.Checked = True
        Me.rdbEnglish.ForeColor = System.Drawing.Color.Blue
        Me.rdbEnglish.Location = New System.Drawing.Point(21, 19)
        Me.rdbEnglish.Name = "rdbEnglish"
        Me.rdbEnglish.Size = New System.Drawing.Size(58, 17)
        Me.rdbEnglish.TabIndex = 0
        Me.rdbEnglish.TabStop = True
        Me.rdbEnglish.Text = "English"
        Me.rdbEnglish.UseVisualStyleBackColor = True
        '
        'cboCategory
        '
        Me.cboCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCategory.FormattingEnabled = True
        Me.cboCategory.Location = New System.Drawing.Point(50, 56)
        Me.cboCategory.Name = "cboCategory"
        Me.cboCategory.Size = New System.Drawing.Size(256, 21)
        Me.cboCategory.TabIndex = 318
        '
        'btnPreview
        '
        Me.btnPreview.AlternativeGroup = Nothing
        Me.btnPreview.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPreview.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPreview.BackColor1 = System.Drawing.Color.White
        Me.btnPreview.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPreview.BorderHover = True
        Me.btnPreview.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPreview.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPreview.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPreview.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPreview.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPreview.DrawBorder = True
        Me.btnPreview.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPreview.ForeColor = System.Drawing.Color.Navy
        Me.btnPreview.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.HoverColor2 = System.Drawing.Color.White
        Me.btnPreview.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPreview.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPreview.Location = New System.Drawing.Point(7, 13)
        Me.btnPreview.Name = "btnPreview"
        Me.btnPreview.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPreview.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPreview.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPreview.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.SelectedText = Nothing
        Me.btnPreview.Size = New System.Drawing.Size(111, 27)
        Me.btnPreview.TabIndex = 165
        Me.btnPreview.Text = "P r e v i e w"
        Me.btnPreview.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(783, 13)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(99, 27)
        Me.btnClose.TabIndex = 157
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnPreview)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Location = New System.Drawing.Point(3, 422)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(891, 47)
        Me.grpButtons.TabIndex = 353
        Me.grpButtons.TabStop = False
        '
        'dtpDateTo
        '
        Me.dtpDateTo.CustomFormat = "dd MMM yyyy"
        Me.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateTo.Location = New System.Drawing.Point(668, 16)
        Me.dtpDateTo.Name = "dtpDateTo"
        Me.dtpDateTo.Size = New System.Drawing.Size(92, 20)
        Me.dtpDateTo.TabIndex = 16
        '
        'lblDateFrom
        '
        Me.lblDateFrom.AutoSize = True
        Me.lblDateFrom.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateFrom.Location = New System.Drawing.Point(483, 18)
        Me.lblDateFrom.Name = "lblDateFrom"
        Me.lblDateFrom.Size = New System.Drawing.Size(57, 13)
        Me.lblDateFrom.TabIndex = 15
        Me.lblDateFrom.Text = "Date From"
        Me.lblDateFrom.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpDateFrom
        '
        Me.dtpDateFrom.CustomFormat = "dd MMM yyyy"
        Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateFrom.Location = New System.Drawing.Point(544, 16)
        Me.dtpDateFrom.Name = "dtpDateFrom"
        Me.dtpDateFrom.Size = New System.Drawing.Size(92, 20)
        Me.dtpDateFrom.TabIndex = 14
        '
        'cboClient
        '
        Me.cboClient.ForeColor = System.Drawing.Color.Maroon
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(50, 16)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(256, 21)
        Me.cboClient.TabIndex = 2
        '
        'cboStatus
        '
        Me.cboStatus.ForeColor = System.Drawing.Color.Navy
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Location = New System.Drawing.Point(811, 48)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(28, 21)
        Me.cboStatus.TabIndex = 17
        Me.cboStatus.Visible = False
        '
        'lblDateTo
        '
        Me.lblDateTo.AutoSize = True
        Me.lblDateTo.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateTo.Location = New System.Drawing.Point(641, 18)
        Me.lblDateTo.Name = "lblDateTo"
        Me.lblDateTo.Size = New System.Drawing.Size(19, 13)
        Me.lblDateTo.TabIndex = 7
        Me.lblDateTo.Text = "To"
        Me.lblDateTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblClient
        '
        Me.lblClient.AutoSize = True
        Me.lblClient.ForeColor = System.Drawing.Color.Maroon
        Me.lblClient.Location = New System.Drawing.Point(16, 18)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(34, 13)
        Me.lblClient.TabIndex = 5
        Me.lblClient.Text = "Client"
        Me.lblClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.grpDuePeriods)
        Me.grpFilter.Controls.Add(Me.cboCategory)
        Me.grpFilter.Controls.Add(Me.lblInvoiceNum)
        Me.grpFilter.Controls.Add(Me.txtInvoiceNum)
        Me.grpFilter.Controls.Add(Me.dtpDateTo)
        Me.grpFilter.Controls.Add(Me.lblDateFrom)
        Me.grpFilter.Controls.Add(Me.lblCategory)
        Me.grpFilter.Controls.Add(Me.dtpDateFrom)
        Me.grpFilter.Controls.Add(Me.lblDateTo)
        Me.grpFilter.Controls.Add(Me.lblClient)
        Me.grpFilter.Controls.Add(Me.cboClient)
        Me.grpFilter.Controls.Add(Me.cboStatus)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(3, 43)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(891, 93)
        Me.grpFilter.TabIndex = 352
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Data Filter"
        '
        'frmOverDueInvoiceList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(897, 469)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.grpGrid)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grpFilter)
        Me.KeyPreview = True
        Me.Name = "frmOverDueInvoiceList"
        Me.Text = "Over-Due Invoice List"
        Me.grpShowHideColumns.ResumeLayout(False)
        CType(Me.grdInvoiceList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpDuePeriods.ResumeLayout(False)
        Me.grpDuePeriods.PerformLayout()
        Me.grpGrid.ResumeLayout(False)
        Me.grpGrid.PerformLayout()
        Me.grpReportOptions.ResumeLayout(False)
        Me.grpReportOptions.PerformLayout()
        Me.grpButtons.ResumeLayout(False)
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
    Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
    Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
    Friend WithEvents grdInvoiceList As System.Windows.Forms.DataGridView
    Friend WithEvents grpDuePeriods As System.Windows.Forms.GroupBox
    Friend WithEvents chkOverDue90 As System.Windows.Forms.CheckBox
    Friend WithEvents chkOverDue60 As System.Windows.Forms.CheckBox
    Friend WithEvents chkDue As System.Windows.Forms.CheckBox
    Friend WithEvents chkOverDue30 As System.Windows.Forms.CheckBox
    Friend WithEvents btnShowCol As System.Windows.Forms.Button
    Friend WithEvents txtTotalCurr2 As System.Windows.Forms.TextBox
    Friend WithEvents lblCurrSymbol As System.Windows.Forms.Label
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents lblCurrSymbol2 As System.Windows.Forms.Label
    Friend WithEvents lblInvoiceNum As System.Windows.Forms.Label
    Friend WithEvents txtInvoiceNum As System.Windows.Forms.TextBox
    Friend WithEvents lblCategory As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents grpGrid As System.Windows.Forms.GroupBox
    Friend WithEvents cboCategory As System.Windows.Forms.ComboBox
    Friend WithEvents btnPreview As BHBut.BouncingHoverButton
    Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
    Friend WithEvents dtpDateTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblDateFrom As System.Windows.Forms.Label
    Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents cboClient As System.Windows.Forms.ComboBox
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents lblDateTo As System.Windows.Forms.Label
    Friend WithEvents lblClient As System.Windows.Forms.Label
    Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
    Friend WithEvents chkOverDue120 As System.Windows.Forms.CheckBox
    Friend WithEvents grpReportOptions As System.Windows.Forms.GroupBox
    Friend WithEvents btnCancelPreview As System.Windows.Forms.Button
    Friend WithEvents btnOkPreview As System.Windows.Forms.Button
    Friend WithEvents rdbArabic As System.Windows.Forms.RadioButton
    Friend WithEvents rdbEnglish As System.Windows.Forms.RadioButton
End Class
