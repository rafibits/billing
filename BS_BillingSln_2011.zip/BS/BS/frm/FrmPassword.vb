Public Class frmPassword
   Inherits System.Windows.Forms.Form

   'Public Enum Language
   '    Arabic
   '    English
   'End Enum
   Public Event OnOkClick(ByVal pBlnPassed As Boolean, ByVal pIntUserID As Integer, ByVal pIntUserLevel As Integer)
   'Public Event OnOkClick(ByVal pBlnPassed As Boolean, ByVal pIntUserID As Integer)
   Dim BlnReturn As Boolean = False
   Dim DtUsers As New DataTable

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
        DGCA.LoadPermissions(Me, Me.Name)

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lblPass As System.Windows.Forms.Label
   Friend WithEvents lblUser As System.Windows.Forms.Label
   Friend WithEvents txtPass As System.Windows.Forms.TextBox
   Friend WithEvents txtUser As System.Windows.Forms.TextBox
   Friend WithEvents btnOk As System.Windows.Forms.Button
   Friend WithEvents btnCancel As System.Windows.Forms.Button
   Friend WithEvents picTitle As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
   Friend WithEvents Label1 As System.Windows.Forms.Label
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPassword))
        Me.lblPass = New System.Windows.Forms.Label
        Me.lblUser = New System.Windows.Forms.Label
        Me.btnCancel = New System.Windows.Forms.Button
        Me.btnOk = New System.Windows.Forms.Button
        Me.txtPass = New System.Windows.Forms.TextBox
        Me.txtUser = New System.Windows.Forms.TextBox
        Me.picTitle = New System.Windows.Forms.PictureBox
        Me.PictureBox4 = New System.Windows.Forms.PictureBox
        Me.Label1 = New System.Windows.Forms.Label
        CType(Me.picTitle, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblPass
        '
        Me.lblPass.BackColor = System.Drawing.Color.Transparent
        Me.lblPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.lblPass.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblPass.Location = New System.Drawing.Point(28, 76)
        Me.lblPass.Name = "lblPass"
        Me.lblPass.Size = New System.Drawing.Size(84, 24)
        Me.lblPass.TabIndex = 0
        Me.lblPass.Text = "User Name"
        Me.lblPass.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblUser
        '
        Me.lblUser.BackColor = System.Drawing.Color.Transparent
        Me.lblUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.lblUser.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblUser.Location = New System.Drawing.Point(28, 108)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(84, 24)
        Me.lblUser.TabIndex = 2
        Me.lblUser.Text = "Password"
        Me.lblUser.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.Location = New System.Drawing.Point(292, 108)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(72, 24)
        Me.btnCancel.TabIndex = 33
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnOk
        '
        Me.btnOk.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnOk.ForeColor = System.Drawing.Color.Black
        Me.btnOk.Location = New System.Drawing.Point(292, 76)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(72, 24)
        Me.btnOk.TabIndex = 32
        Me.btnOk.Text = "Ok"
        Me.btnOk.UseVisualStyleBackColor = False
        '
        'txtPass
        '
        Me.txtPass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.txtPass.ForeColor = System.Drawing.Color.Navy
        Me.txtPass.Location = New System.Drawing.Point(116, 108)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPass.Size = New System.Drawing.Size(156, 24)
        Me.txtPass.TabIndex = 3
        Me.txtPass.Text = "123456"
        '
        'txtUser
        '
        Me.txtUser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.txtUser.ForeColor = System.Drawing.Color.Navy
        Me.txtUser.Location = New System.Drawing.Point(116, 76)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.Size = New System.Drawing.Size(156, 24)
        Me.txtUser.TabIndex = 1
        Me.txtUser.Text = "user name"
        '
        'picTitle
        '
        Me.picTitle.Location = New System.Drawing.Point(-24, 16)
        Me.picTitle.Name = "picTitle"
        Me.picTitle.Size = New System.Drawing.Size(424, 32)
        Me.picTitle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picTitle.TabIndex = 39
        Me.picTitle.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(424, 56)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 46
        Me.PictureBox4.TabStop = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Navy
        Me.Label1.Image = CType(resources.GetObject("Label1.Image"), System.Drawing.Image)
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(284, 28)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "Authorization Form"
        '
        'frmPassword
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(414, 152)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.txtPass)
        Me.Controls.Add(Me.txtUser)
        Me.Controls.Add(Me.picTitle)
        Me.Controls.Add(Me.lblPass)
        Me.Controls.Add(Me.lblUser)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOk)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.Name = "frmPassword"
        Me.Text = "Authorization"
        CType(Me.picTitle, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private Sub frmPassword_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

   Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      Try
         'GetData()
         Dim daUserData As New SqlClient.SqlDataAdapter("select * from VwUsers", conSql)
         daUserData.Fill(DtUsers)
      Catch ex As Exception
         MsgBox(ex.Message)
      End Try
   End Sub

   Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
      Ok()
	End Sub

   Private Sub Ok()
      Dim DrRow() As DataRow
      If CheckTextBoxes() = False Then Exit Sub
      'DtUsers = dsData.Tables("Users")
      DrRow = DtUsers.Select("userName = '" & txtUser.Text & "'")
      If DrRow.Length <= 0 Then MsgBox("Invalid UserName", MsgBoxStyle.Exclamation, "Warning") : Exit Sub

      'If CheckDtRow(DrRow(0)) = False Then Exit Sub
      If CStr(DrRow(0).Item(2)) <> txtPass.Text Then MsgBox("Invalid Password", MsgBoxStyle.Exclamation, "Warning") : Exit Sub

      'UpdateRow(DrRow(0))
      BlnReturn = True
      'MsgBox(DrRow(0).Item(3))

      RaiseEvent OnOkClick(BlnReturn, CType(DrRow(0).Item(0), Integer), CType(DrRow(0).Item(3), Integer))
      Me.Close()
   End Sub

   'Private Function CheckDtRow(ByVal DtRow As DataRow) As Boolean
   '   Try
   '      CheckDtRow = True
   '      If CStr(DtRow.Item(2)) <> txtPass.Text Then MsgBox("Invalid Password", MsgBoxStyle.Exclamation, "Warning") : CheckDtRow = False : Exit Function
   '   Catch ex As Exception
   '      MsgBox(ex.Message)
   '   End Try
   'End Function

   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      'RaiseEvent OnExit()
      Me.Close()
   End Sub

   Private Function CheckTextBoxes() As Boolean
      CheckTextBoxes = True
      If txtUser.Text = "" Then CheckTextBoxes = False
      If txtPass.Text = "" Then CheckTextBoxes = False
   End Function

   Public WriteOnly Property IntializeConnection() As SqlClient.SqlConnection
      Set(ByVal Value As SqlClient.SqlConnection)
         conSql = Value
      End Set
   End Property

	Private Sub txtPass_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtPass.KeyPress
		If Asc(e.KeyChar) = 13 Then Ok()
	End Sub

   Private Sub btNOk_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles btnOk.KeyPress
      If Asc(e.KeyChar) = 13 Then Ok()
   End Sub

End Class
