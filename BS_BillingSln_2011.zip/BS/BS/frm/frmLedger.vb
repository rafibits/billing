Imports BITSConn
Class frmLedger
#Region "Form-Declaration..."
    Dim dsdata As New DataSet
    Dim clsMr As ClsMain
    Dim da As SqlClient.SqlDataAdapter
    Dim blnCbo As Boolean = True
    Dim mLedger As Long
    Public CloseOnSelect As Boolean = True
    Public transferAccount As Long
    Public Event Closed(ByVal sender As System.Object, ByVal e As System.EventArgs)
   Private mstrCurrentGridName As String
   '
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Ledger\Settings"
   'Protected Sub OnClosed()
   '    RaiseEvent Closed(Me, New System.EventArgs)
   'End Sub
#End Region
#Region "Form-Loading..."
    Private Sub frmLedger_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Me.CenterToScreen()
      blnCbo = True
        ''
        clsMr = New ClsMain(conSql)
        ''
        SetData()
        ''
        clsMr.FillComboBox("AcctType", cboAccountType, "AcctType", "AcctTypeID")
        ''
        grdLedger.DataSource = dsdata.Tables("Ledger").DefaultView
        ''

        ''Set up Grid
      DrawGrid()
        ''
        ColorNonOriginal()
        ''
        ColorLstLedger()
        ''
        If mLedger <> -1 Then
            txtNum.Text = mLedger

        End If
        grpLedger.Visible = False
        cboAccountType.Text = ""
        blnCbo = False
    End Sub
#End Region

#Region "Form-Functions..."
    Private Sub FilterGrid()
        If blnCbo = True Then
            Exit Sub
        End If
        ''
        strSQL = "( True "
        '' Filter On Selected AcctType...
        If cboAccountType.SelectedIndex <> -1 Then
            strSQL = strSQL & " AND (AcctTypeID=" & cboAccountType.SelectedValue & ")"
        End If
        ''
        strSQL = strSQL & ")"

        ''
        dsdata.Tables("Ledger").DefaultView.RowFilter = strSQL
        ''
        If mLedger <> -1 Then
            txtNum.Text = mLedger

        End If
        grpLedger.Visible = False
        blnCbo = False
        ''
        ColorNonOriginal()
        ''
        ColorLstLedger()
        ''


    End Sub
    Private Sub SetObject(ByVal blnState As Boolean)
        grdLedger.Enabled = blnState
        grpControls.Enabled = blnState
        cboAccountType.Enabled = blnState
        txtNum.Enabled = blnState
        txtName.Enabled = blnState


    End Sub
    Private Sub SetData()
        '' set SQL...

      strSQL = "Select  Convert(nvarchar, LedgerNumber) AS LedgerNumber, "
      strSQL &= " Name_en, Main, BranchOf, Original ,AcctType, AcctTypeID , AccountLedgerID"
        strSQL &= " FROM  vwAccountLedger "
        strSQL &= " WHERE Del=0 "
        strSQL &= "ORDER BY LedgerNumber "
        '' load...
        da = clsMr.BuildSqlAdapter(strSQL, "Ledger")
        clsMr.BuildSqlAdapter("SELECT AcctTypeID,AcctType from tblAcctType", "AcctType")
        clsMr.BuildSqlAdapter("SELECT * from tblAccountLedger", "tblAccountLedger")
        ''
        dsdata = clsMr.getDataSet
    End Sub
    Private Sub DrawGrid()
        ''Format Columns
        grdLedger.Columns("AccountLedgerID").Visible = False
        grdLedger.Columns("AcctTypeID").Visible = False
        grdLedger.Columns("AcctType").Visible = False
      grdLedger.Columns("Name_en").Width = 300
      LoadProfile(mStrSubKeyName, grdLedger)
      grdLedger.ColumnHeadersHeight = btnShowCol.Size.Height + 2
      grdLedger.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
    End Sub
    Private Sub ColorNonOriginal()
        Dim Counter As Integer
        For Counter = 0 To grdLedger.Rows.Count - 1
            If grdLedger.Rows(Counter).Cells("Original").Value = False Then
                grdLedger.Rows(Counter).DefaultCellStyle.BackColor = Color.LightYellow
            End If
        Next
    End Sub

    Private Sub ColorLstLedger()
        Dim Counter As Integer
        For Counter = 0 To grdLedger.Rows.Count - 1
            If grdLedger.Rows(Counter).Cells("Main").Value = True Then
                grdLedger.Rows(Counter).DefaultCellStyle.BackColor = Color.DarkRed

            End If
        Next
    End Sub
    Private Sub updateLedgerName()
        ''
        If txtNum.Text <> "" Then
            Dim dr As DataRowView
            Dim dv As DataView
            dv = dsdata.Tables("Ledger").DefaultView
            If dv.Count <> 0 Then
                dr = dsdata.Tables("Ledger").DefaultView.Item(0)
                ''
                If Not dr Is Nothing Then
                    txtName.Text = dr("Name_en") & ""
                End If
            End If
        End If
    End Sub
#End Region

#Region "Form-Validation..."
    Private Sub txtNum_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtNum.KeyPress
        updateLedgerName()
    End Sub
    Private Sub grdLedger_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdLedger.DoubleClick
        Dim drRowToEdit As DataRow
        ''
        drRowToEdit = dsdata.Tables("Ledger").DefaultView.Item(grdLedger.CurrentRow.Index).Row
        transferAccount = drRowToEdit("LedgerNumber")
        If CloseOnSelect Then
         Me.Close()
        End If
    End Sub

    Private Sub txtNum_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtNum.TextChanged
        'If txtNum.Text = "" Then
        '    txtNum.Text = mLedger
        '    'txtNum.Text = mLedger.ToString.Substring(0, 1)
        'End If

        dsdata.Tables("Ledger").DefaultView.RowFilter = "LedgerNumber  like '" & txtNum.Text & "%'"

    End Sub


    Private Sub cboAccountType_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboAccountType.TextChanged
        If blnCbo = True Then Exit Sub

        FilterGrid()
    End Sub
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
      Me.Close()
    End Sub
#End Region

#Region "Form - AddLedger..."
    Private Sub RefreshGrid(ByVal sender As Object, ByVal e As System.EventArgs)
        dsdata.Tables("Ledger").Clear()
        clsMr.BuildSqlAdapter(strSQL, "Ledger")
        ''
        ColorNonOriginal()
        ''
        ColorLstLedger()
        ''
    End Sub


    Private Sub btnNewLedger_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewLedger.Click
        Call NewLedger()
        AddHandler grpLedger.VisibleChanged, AddressOf RefreshGrid
        'btnNewLedger.Enabled = False
        btnEditLedger.Enabled = True

    End Sub

    Private Sub btnEditLedger_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditLedger.Click
        If grdLedger.Rows.Count = 0 Then
            Exit Sub
        End If


        Dim drRowToEdit As DataRow

        drRowToEdit = dsdata.Tables("ledger").DefaultView.Item(grdLedger.CurrentRow.Index).Row

        txtLedgerID.Text = drRowToEdit("AccountLedgerID")
        txtLedgerNumber.Text = drRowToEdit("LedgerNumber")
        txtLedgerName.Text = drRowToEdit("Name_en")

        grpLedger.Visible = True

        AddHandler grpLedger.VisibleChanged, AddressOf RefreshGrid
        btnEditLedger.Enabled = False
        btnNewLedger.Enabled = True
    End Sub
    Private Sub NewLedger()

        Dim str As String = grdLedger.CurrentRow.Cells("LedgerNumber").Value
        If str.Length < 5 Then
            txtLedgerNumber.Text = grdLedger.CurrentRow.Cells("LedgerNumber").Value
        Else

            MsgBox("You Can't Enter A New Ledger which is More than 5 Characters", MsgBoxStyle.Exclamation, "Warning")

            Exit Sub

        End If

        grpLedger.Visible = True


        Dim AccountLedgerID As Long
        Dim cmdLedgerID As New SqlClient.SqlCommand("select case when MAX(AccountLedgerID) IS NULL then 1 else MAX(AccountLedgerID)+1 end from tblAccountLedger", conSql)
        conSql.Open()
        AccountLedgerID = cmdLedgerID.ExecuteScalar
        conSql.Close()
        txtLedgerID.Text = AccountLedgerID

    End Sub
 
   Private Sub EditLedger()
      Dim drRowToEdit As DataRow
      drRowToEdit = dsdata.Tables("ledger").DefaultView.Item(grdLedger.CurrentRow.Index).Row
      Dim strLedger As String = txtLedgerNumber.Text & txtLedger1.Text

      Dim dr() As DataRow = dsdata.Tables("Ledger").Select("AccountLedgerID= " & txtLedgerID.Text)
      Dim i As Integer
      If dr.Length > 0 Then
         For i = 0 To grdLedger.Rows.Count - 1
            Try
               Dim cmdUpdateLedger As New SqlClient.SqlCommand("Update tblAccountLedger set LedgerNumber= " & strLedger & ",Name_en='" & txtLedgerName.Text & "',AcctTypeID=" & drRowToEdit("AcctTypeID") & ",Original=" & 0 & " WHERE (AccountLedgerID=" & drRowToEdit("AccountLedgerID") & ")", conSql)
               conSql.Open()
               cmdUpdateLedger.ExecuteNonQuery()
               conSql.Close()
            Catch ex As Exception
               conSql.Close()
            End Try
         Next

      Else


         Try

            Dim cmdInsertLedger As New SqlClient.SqlCommand("INSERT INTO tblAccountLedger(AccountledgerID,AcctTypeID,LedgerNumber,Name_en,Original,Main,BranchOF,Del) values (" & txtLedgerID.Text & "," & drRowToEdit("AcctTypeID") & "," & strLedger & ",'" & txtLedgerName.Text & "'," & 0 & "," & 0 & "," & 0 & "," & 0 & ")", conSql)
            conSql.Open()
            cmdInsertLedger.ExecuteNonQuery()
            conSql.Close()
         Catch ex As Exception
            conSql.Close()
         End Try

         If strLedger <> "" Then
            Dim drLedgerNum As DataRow()
            drLedgerNum = dsdata.Tables("tblAccountLedger").Select("LedgerNumber= '" & strLedger & "'And Not AccountLedgerID= " & txtLedgerID.Text & " ")
            If drLedgerNum.Length > 0 Then
               MsgBox("The entered Ledger Number is already found.")
               Exit Sub
            End If
         End If
      End If
   End Sub

  Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click

        Dim res As MsgBoxResult
        res = MsgBox(" Are you sure you want to Delete Ledger? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution")
        If res = MsgBoxResult.Yes Then
            Try
                Dim cmdUpdateAccount As New SqlClient.SqlCommand("Update tblAccountLedger set Del=1 WHERE (AcctLedgerID=" & txtLedgerID.Text & ")", conSql)
                conSql.Open()
                cmdUpdateAccount.ExecuteNonQuery()
                conSql.Close()
            Catch ex As Exception
                conSql.Close()
            End Try
            dsdata.Tables("Ledger").Rows.Remove(dsdata.Tables("Ledger").DefaultView(grdLedger.CurrentRow.Index).Row)

        End If
        btnDelete.Enabled = False

    End Sub

    Private Sub btnClosegrp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClosegrp.Click
        grpLedger.Visible = False
        btnNewLedger.Enabled = True
    End Sub

    Private Sub btnSaveLedger_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveLedger.Click
        EditLedger()
        btnSaveLedger.Enabled = False
    End Sub
#End Region

    Private Sub txtLedger1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLedger1.TextChanged

        Dim str As String = txtLedger1.Text & txtLedgerNumber.Text
        If str.Length > 5 Then
            MsgBox("You Can't have A Branch More than 5 Characters", MsgBoxStyle.Exclamation, "Warning")
            txtLedger1.Text = ""
            Exit Sub

        End If

   End Sub
#Region "Grid-SaveSettings"
   Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
      If Me.grpShowHideColumns.Visible = False Then
         Me.grpShowHideColumns.Visible = True
         Me.grpShowHideColumns.BringToFront()
         mstrCurrentGridName = "Address"
         ''
         '' populate list with grid's dataSource fields...
         ''

         Dim col As Windows.Forms.DataGridViewColumn
         ''
         Me.chkLstGridCol.Items.Clear()
         For Each col In grdLedger.Columns
            Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
         Next

      Else
         Me.grpShowHideColumns.Visible = False
         Me.grpShowHideColumns.SendToBack()
      End If
      Me.chkLstGridCol.Items.Remove("AccountLedgerID")
      Me.chkLstGridCol.Items.Remove("AcctTypeID")

   End Sub

   Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
      Dim i As Integer

      For i = 0 To Me.chkLstGridCol.Items.Count - 1
         grdLedger.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
      Next

      ''
      Me.grpShowHideColumns.Visible = False
      Me.chkLstGridCol.Items.Remove("AccountLedgerID")
      Me.chkLstGridCol.Items.Remove("AcctTypeID")

   End Sub
   Private Sub frmAccountNew_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Closed
      SaveProfile(mStrSubKeyName, Me.grdLedger)
   End Sub

#End Region

   Private Sub btnSelect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelect.Click
      Dim drRowToEdit As DataRow
      ''
      drRowToEdit = dsdata.Tables("Ledger").DefaultView.Item(grdLedger.CurrentRow.Index).Row
      transferAccount = drRowToEdit("LedgerNumber")
      If CloseOnSelect Then
         Me.Close()
         'MsgBox(transferAccount)
      End If


   End Sub
End Class