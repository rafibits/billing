Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmPaymentList


#Region "Form-Declaration......."
    ''
    Private dsdata As DataSet
    Private clsMr As ClsMain
    Private blnLoading As Boolean = True
    Private mstrCurrentGridName As String
    Private mStrSubKeyName As String = "Software\BIT Solutions\BS\PaymentList\Settings"
    Dim mblnLoginSucces As Boolean = False
    Public WithEvents mClsFrmLogin As frmPassword
#End Region


#Region "Form-Load.............."

    Private Sub frmPaymentList_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmInvoiceList_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''
        clsMr = New ClsMain(conSql)
        ''
        blnLoading = True
        MakeDataAdapter()
        FillComboBox()
        DrawGrid()
        cboClient.SelectedIndex = -1
        blnLoading = False
        FilterGrid()
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

#End Region


#Region "Form-Initialisation...."

    Private Sub MakeDataAdapter()
        ''
        'clsMr.BuildSqlAdapter("SELECT * FROM vwPaymentList WHERE Del = 0", "vwPaymentList")
        clsMr.BuildSqlAdapter("SELECT * FROM vwPaymentsList WHERE Del = 0", "vwPaymentList")
        clsMr.BuildSqlAdapter("SELECT ClientName, ClientID, Del FROM tblClient WHERE Del = 0 ORDER BY ClientName", "tblClient")
        ''
        dsdata = clsMr.getDataSet
    End Sub

    Private Sub FillComboBox()
        ''
        clsMr.FillComboBox("tblClient", cboClient, "ClientName", "ClientID")
    End Sub

#End Region


#Region "Form-UI/Methods........"

    Private Sub btnPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreview.Click
        ''
        If grdPayments.RowCount = 0 Then Exit Sub
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor()
        ''
        Dim frm As New frmQuickReport
        Dim rpt As New rptPaymentDetails
        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
        ''
        For Each tbCurrent In rpt.Database.Tables
            tliCurrent = tbCurrent.LogOnInfo
            ''
            With tliCurrent.ConnectionInfo
                .ServerName = gStrServerName
                .DatabaseName = gStrDataBaseName
                .UserID = "" 'gStrUserName
                .Password = ""  'gStrPassword
            End With

            tbCurrent.ApplyLogOnInfo(tliCurrent)
        Next tbCurrent
        frm.crvInstantViewer.SelectionFormula = "{vwPaymentListRpt.PaymentID}=" & grdPayments.Item("PaymentID", grdPayments.CurrentRow.Index).Value 'FilterStringList() '
        ''
        frm.crvInstantViewer.ReportSource = rpt
        frm.crvInstantViewer.Refresh()
        frm.Show()
        ''
        frm.crvInstantViewer.DisplayToolbar = True
        Windows.Forms.Cursor.Current = Cursors.Default()
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        ''
        Dim frm As New frmPayment(0)
        appMain.addTabPage(frm, frmApplicationMain.eFormType.Payment)
        ''Refresh form
        AddHandler frm.Closed, AddressOf RefreshList
    End Sub

    Private Sub EditPayment()
        ''
        If grdPayments.Rows.Count = 0 Then Exit Sub
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ''
        Dim frm As New frmPayment(grdPayments.Item("PaymentID", grdPayments.CurrentRow.Index).Value)
        appMain.addTabPage(frm, frmApplicationMain.eFormType.Payment)
        ''
        Windows.Forms.Cursor.Current = Cursors.Default
        ''Refresh form
        AddHandler frm.Closed, AddressOf RefreshList
    End Sub

    Private Sub grdPayments_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdPayments.DoubleClick
        ''
        EditPayment()
    End Sub

    Private Sub cboClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
        ''
        AutoComplete(cboClient, e)
    End Sub

    Private Sub cboClient_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyUp
        ''
        FilterGrid()
    End Sub

    Private Sub cboClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
        ''
        FilterGrid()
    End Sub

    Private Sub dtpDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateFrom.ValueChanged
        ''
        FilterGrid()
    End Sub

    Private Sub dtpDateTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateTo.ValueChanged
        ''
        FilterGrid()
    End Sub

    Private Sub txtPmtNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPmtNum.TextChanged
        ''
        FilterGrid()
    End Sub

    Private Sub chkNew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkNew.Click
        ''
        FilterGrid()
    End Sub

    Private Sub chkPosted_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkPosted.Click
        ''
        FilterGrid()
    End Sub

    Private Sub chkNotPosted_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkNotPosted.Click
        ''
        FilterGrid()
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        ''
        EditPayment()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        'If grdInvoiceList.Rows.Count = 0 Then Exit Sub
        ' ''

        'If grdInvoiceList.Item("StatusID", grdInvoiceList.CurrentRow.Index).Value = 1 Then
        '    ''
        '    If MsgBox("Are you sure you want to delete?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub
        '    ''
        '    '' update invoiceDetail
        '    ''
        '    Dim cmd As New SqlCommand("UPDATE tblInvoiceDetail SET Del=1 WHERE InvoiceID=" & grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value, conSql)
        '    conSql.Open()
        '    cmd.ExecuteNonQuery()
        '    conSql.Close()
        '    ''
        '    ''update tblInvoice
        '    ''
        '    cmd.CommandText = "UPDATE tblInvoice SET Del=1 WHERE InvoiceID=" & grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value
        '    cmd.Connection = conSql
        '    conSql.Open()
        '    cmd.ExecuteNonQuery()
        '    conSql.Close()
        '    ''
        '    dsdata.Tables("vwInvoiceList").DefaultView(grdInvoiceList.CurrentRow.Index).Delete()
        'Else
        '    MsgBox("You cannot Delete this Invoice because It's " & grdInvoiceList.Item("Status", grdInvoiceList.CurrentRow.Index).Value)
        'End If
        'SetStatus()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        ''
        Me.Close()
    End Sub

    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
        ''
        Dim i As Integer

        For i = 0 To Me.chkLstGridCol.Items.Count - 1
            Me.grdPayments.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
        Next
        ''
        Me.grpShowHideColumns.Visible = False
        ''
    End Sub


    Private Sub btnCorrectionPayment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        If MsgBox(" Are you sure you want to Correct This Invoice? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution") = MsgBoxResult.Yes Then
            ''
            Dim frm As New frmInvoice(-1, -1, -1, grdPayments.Item("InvoiceID", grdPayments.CurrentRow.Index).Value, grdPayments.Item("InvoiceNumber", grdPayments.CurrentRow.Index).Value, True)
            appMain.addTabPage(frm, frmApplicationMain.eFormType.Invoice)
        End If
    End Sub

    Private Sub chkCorrected_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCorrected.Click
        FilterGrid()
    End Sub

    Private Sub rdbLBP_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbLBP.CheckedChanged
        ''
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub rdbUSD_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbUSD.CheckedChanged
        ''
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub rdbLBPAndUSD_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbLBPAndUSD.CheckedChanged
        ''
        If blnLoading Then Exit Sub
        FilterGrid()
    End Sub

    Private Sub btnPreviewList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviewList.Click
        ''
        If grdPayments.Rows.Count = 0 Then Exit Sub
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor()
        ''
        Dim frm As New frmQuickReport
        Dim rpt As New rptPaymentList
        ''
        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
        ''
        For Each tbCurrent In rpt.Database.Tables
            tliCurrent = tbCurrent.LogOnInfo
            ''
            With tliCurrent.ConnectionInfo
                .ServerName = gStrServerName
                .DatabaseName = gStrDataBaseName
                .UserID = ""
                .Password = ""
            End With
            ''
            tbCurrent.ApplyLogOnInfo(tliCurrent)
        Next tbCurrent
        ''
        rpt.SetParameterValue("DateFrom", dtpDateFrom.Value.ToString("yyyy-M-d"))
        rpt.SetParameterValue("DateTo", dtpDateTo.Value.ToString("yyyy-M-d"))
        ''
        Dim strFilter As String = FilterStringList()
        frm.crvInstantViewer.SelectionFormula = strFilter
        ''
        frm.crvInstantViewer.ReportSource = rpt
        frm.crvInstantViewer.Refresh()
        frm.Show()
        ''
        frm.crvInstantViewer.DisplayToolbar = True
        Windows.Forms.Cursor.Current = Cursors.Default()
    End Sub

    Private Sub btnCorrectionInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        If MsgBox(" Are you sure you want to Correct This Payment? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolutions") = MsgBoxResult.Yes Then
            ''
            mblnLoginSucces = False
            mClsFrmLogin = New frmPassword
            mClsFrmLogin.StartPosition = FormStartPosition.CenterScreen
            mClsFrmLogin.ShowDialog()
            ''
            If mblnLoginSucces Then
                mClsFrmLogin.Close()
            Else
                Exit Sub
                ''
            End If
            ''
            Dim frm As New frmPayment(grdPayments.Item("PaymentID", grdPayments.CurrentRow.Index).Value)
            appMain.addTabPage(frm, frmApplicationMain.eFormType.Invoice)
        End If
    End Sub

    Private Sub grdPayments_ColumnHeaderMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grdPayments.ColumnHeaderMouseClick
        ''
        Renumbering(grdPayments)
    End Sub

#End Region


#Region "Form-Functions........."

    Private Sub DrawGrid()
        ''
        With grdPayments
            .DataSource = dsdata.Tables("vwPaymentList").DefaultView
            ''
            Dim dgvc As New DataGridViewTextBoxColumn
            ''
            dgvc.DataPropertyName = "Line"
            dgvc.HeaderText = "Line"
            dgvc.Name = "Line"
            dgvc.Width = 47
            .Columns.Insert(0, dgvc)
            ''
            .Columns("PaymentNum").HeaderText = "Number"
            .Columns("PaymentDate").HeaderText = "Date"
            .Columns("ClientName").HeaderText = "Client"
            .Columns("ClientID").Visible = False
            .Columns("EmployeeID").Visible = False
            .Columns("StatusID").Visible = False
            .Columns("PaymentID").Visible = False
            .Columns("Del").Visible = False
            .Columns("CurrID").Visible = False
            ''
            .Columns("PaymentDate").DefaultCellStyle.Format = "dd-MMM-yyyy"
            .Columns("Amount").DefaultCellStyle.Format = "###,###,###,###,###.00#"
            .ColumnHeadersHeight = btnShowCol.Height + 2
            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
            ''
            dsdata.Tables("vwPaymentList").DefaultView.AllowNew = False
        End With
        ''
        LoadProfile(mStrSubKeyName, Me.grdPayments)
    End Sub

    Private Sub FilterGrid()
        ''    
        If blnLoading Then Exit Sub
        ''    
        Dim s As String = " True"
        Dim strStatus As String
        '' 
        ''YC 2010Sep21; Date Format error...
        ''
        's = "(PaymentDate >= '" & dtpDateFrom.Value.ToShortDateString() & "') AND (PaymentDate <= '" & dtpDateTo.Value.ToShortDateString() & "')"
        s = "(PaymentDate >= '" & dtpDateFrom.Value.ToString("yyyy-M-d") & "') AND (PaymentDate <= '" & dtpDateTo.Value.ToString("yyyy-M-d") & "')"
        ''
        If txtPmtNum.Text <> String.Empty Then
            Dim tn As Integer
            Try
                tn = Convert.ToInt32(txtPmtNum.Text)
                s = s & " AND  (PaymentNum = " & tn & ")"
            Catch ex As Exception
                txtPmtNum.Text = ""
            End Try
        End If
        ''
        If cboClient.SelectedIndex <> -1 Then
            s = s & " AND (ClientID = " & cboClient.SelectedValue & ")"
        Else
            If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
                s = s & " AND (ClientID = " & -1 & ")"
            End If
        End If
        ''
        If rdbLBP.Checked Then
            ''
            s &= " AND CurrID = " & 1
        ElseIf rdbUSD.Checked Then
            ''
            s &= " AND CurrID = " & 2
        End If
        ''
        If chkPosted.Checked = False And chkNotPosted.Checked = False And chkNew.Checked = False Then
            s = s & " AND (StatusID = 0) "
        Else
            ''
            strStatus = " AND StatusID IN ("
            If chkPosted.Checked = True Then

                strStatus = strStatus & "2"
            End If
            ''
            If chkNotPosted.Checked = True Then
                If strStatus = " AND StatusID IN (" Then
                    strStatus = strStatus & "3"
                Else
                    strStatus = strStatus & ",3"
                End If
            End If
            ''
            If chkNew.Checked = True Then
                If strStatus = " AND StatusID IN (" Then
                    strStatus = strStatus & "1"
                Else
                    strStatus = strStatus & ",1"
                End If
            End If
            ''
            If chkCorrected.Checked = True Then
                If strStatus = " AND StatusID IN (" Then
                    strStatus = strStatus & "5"
                Else
                    strStatus = strStatus & ",5"
                End If
            End If
            ''
            strStatus = strStatus & ")"
        End If
        s = s & strStatus
        ''
        dsdata.Tables("vwPaymentList").DefaultView.RowFilter = s
        ''
        If grdPayments.Rows.Count > 0 Then
            btnEdit.Enabled = True
            btnPreview.Enabled = True
        Else
            btnEdit.Enabled = False
            btnPreview.Enabled = False
        End If
        ''
        Renumbering(grdPayments)
        ''
        If grdPayments.Rows.Count = 0 Or rdbLBPAndUSD.Checked Then
            ''
            btnPreviewList.Enabled = False
        Else
            ''
            btnPreviewList.Enabled = True
        End If
    End Sub

    Private Sub ChangeColor()
        ''change color of visits according to status
        Dim i As Integer
        Dim intStatus As Integer
        For i = 0 To dsdata.Tables("vwInvoiceList").DefaultView.Count - 1
            intStatus = dsdata.Tables("vwInvoiceList").DefaultView.Item(i)("StatusID")

            Select Case intStatus
                Case 1
                    'grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.LightYellow

                Case 2
                    'grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.LightSteelBlue

                Case 3
                    ' grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.MistyRose

            End Select
        Next
    End Sub

    Private Sub RefreshList(ByVal sender As Object, ByVal e As System.EventArgs)
        ''
        dsdata.Tables("vwpaymentList").Rows.Clear()
        clsMr.BuildSqlAdapter("SELECT * FROM vwPaymentsList WHERE Del = 0", "vwPaymentList")
        'clsMr.BuildSqlAdapter("SELECT * FROM vwPaymentList WHERE Del = 0", "vwPaymentList")
        ''
        FilterGrid()
    End Sub

    Private Sub SetStatus()
        ''
        If grdPayments.Rows.Count = 0 Then
            btnEdit.Enabled = False
            'btnDelete.Enabled = False
        Else
            btnEdit.Enabled = True
            'btnDelete.Enabled = True
        End If
        ''
        DGCA.LoadPermissionsSetState(Me, Me.Name)
    End Sub

    Private Sub RemoveGrdListItems()
        ''
        With chkLstGridCol
            .Items.Remove("ClientID")
            .Items.Remove("EmployeeID")
            .Items.Remove("StatusID")
            .Items.Remove("PaymentID")
            .Items.Remove("Del")
        End With
    End Sub

    Private Function FilterStringList()
        ''
        If blnLoading Then Exit Function
        ''
        If blnLoading Then Exit Function
        ''    
        Dim strfilter As String = " "
        Dim strStatus As String
        '' 
        'strfilter = " ({vwPaymentsList.PaymentDate} >= {?DateFrom}) AND ({vwPaymentsList.PaymentDate} <= {?DateTo})"
        strfilter = " ({vwPaymentsList.PaymentDate} >= #" & dtpDateFrom.Value.ToString("yyyy-M-d") & "# AND {vwPaymentsList.PaymentDate} <= #" & dtpDateTo.Value.ToString("yyyy-M-d") & "#)"
        ''
        If txtPmtNum.Text <> String.Empty Then
            Dim tn As Integer
            Try
                tn = Convert.ToInt32(txtPmtNum.Text)
                strfilter &= " AND  ({vwPaymentsList.PaymentNum} = " & tn & ")"
            Catch ex As Exception
                txtPmtNum.Text = ""
            End Try
        End If
        ''
        If cboClient.SelectedIndex <> -1 Then
            strfilter &= " AND ({vwPaymentsList.ClientID} = " & cboClient.SelectedValue & ")"
        Else
            If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
                strfilter &= " AND ({vwPaymentsList.ClientID} = " & -1 & ")"
            End If
        End If
        ''
        If rdbLBP.Checked Then
            ''
            strfilter &= " AND {vwPaymentsList.CurrID} = '" & 1 & "'"
        ElseIf rdbUSD.Checked Then
            ''
            strfilter &= " AND {vwPaymentsList.CurrID} = '" & 2 & "'"
        End If
        ''
        If chkPosted.Checked = False And chkNotPosted.Checked = False And chkNew.Checked = False And chkCorrected.Checked = False Then
            '' Do Nothing
        Else
            ''
            If chkPosted.Checked = True Then
                strStatus = " ( {vwPaymentsList.StatusID}=" & 2
            End If
            ''
            If chkNotPosted.Checked = True Then
                If strStatus = "" Then
                    strStatus = " ( {vwPaymentsList.StatusID}=" & 3
                Else
                    strStatus = strStatus & " OR {vwPaymentsList.StatusID}=" & 3
                End If
            End If
            ''
            If chkNew.Checked = True Then
                If strStatus = "" Then
                    strStatus = " ( {vwPaymentsList.StatusID}=" & 1
                Else
                    strStatus = strStatus & " OR {vwPaymentsList.StatusID}=" & 1
                End If
            End If
            ''
            If strStatus <> "" And Not (strStatus.EndsWith(")")) Then
                strStatus = strStatus & " )"
            End If
            ''
        End If
        ''
        If strfilter <> "" And strStatus <> "" Then

            strfilter = strfilter & " AND" & strStatus
        Else
            strfilter = strfilter & strStatus
        End If
        ''
        strfilter &= " AND {vwPaymentsList.Del}= " & False
        ''
        Return strfilter
    End Function

#End Region


#Region "GrdSetUp..............."

    Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()
            mstrCurrentGridName = "InvoiceList"
            ''
            '' populate list with grid's dataSource fields...
            ''

            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdPayments.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next
            chkLstGridCol.Items.Remove("StatusID")
            chkLstGridCol.Items.Remove("ClientID")
            chkLstGridCol.Items.Remove("InvoiceID")
            chkLstGridCol.Items.Remove("Del")
            chkLstGridCol.Items.Remove("CatID")
            chkLstGridCol.Items.Remove("AutoGel")

        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If
    End Sub

    Private Sub frmInvoiceList_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        SaveProfile(mStrSubKeyName, Me.grdPayments)
    End Sub

#End Region


End Class