<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInvoiceList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnPreviewList = New BHBut.BouncingHoverButton
        Me.btnCorrectionInvoice = New BHBut.BouncingHoverButton
        Me.btnPreview = New BHBut.BouncingHoverButton
        Me.btnDelete = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnEdit = New BHBut.BouncingHoverButton
        Me.btnAutoGenerateInvoice = New BHBut.BouncingHoverButton
        Me.cboStatus = New System.Windows.Forms.ComboBox
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.grdInvoiceList = New System.Windows.Forms.DataGridView
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grpPeriods = New System.Windows.Forms.GroupBox
        Me.btnCancel = New System.Windows.Forms.Button
        Me.btnOK = New System.Windows.Forms.Button
        Me.rdbAnnualy = New System.Windows.Forms.RadioButton
        Me.rdbBiAnnualy = New System.Windows.Forms.RadioButton
        Me.rdbQuarterly = New System.Windows.Forms.RadioButton
        Me.rdbMonthly = New System.Windows.Forms.RadioButton
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.grpGrid = New System.Windows.Forms.GroupBox
        Me.lblCurrSymbol2 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtTotalCurr2 = New System.Windows.Forms.TextBox
        Me.lblCurrSymbol = New System.Windows.Forms.Label
        Me.txtTotal = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.lblClient = New System.Windows.Forms.Label
        Me.lblDateTo = New System.Windows.Forms.Label
        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker
        Me.lblDateFrom = New System.Windows.Forms.Label
        Me.dtpDateTo = New System.Windows.Forms.DateTimePicker
        Me.lblStatus = New System.Windows.Forms.Label
        Me.lblCategory = New System.Windows.Forms.Label
        Me.txtInvoiceNum = New System.Windows.Forms.TextBox
        Me.lblInvoiceNum = New System.Windows.Forms.Label
        Me.grpStatus = New System.Windows.Forms.GroupBox
        Me.chkPartial = New System.Windows.Forms.CheckBox
        Me.chkCorrected = New System.Windows.Forms.CheckBox
        Me.chkPaid = New System.Windows.Forms.CheckBox
        Me.chkNew = New System.Windows.Forms.CheckBox
        Me.chkPosted = New System.Windows.Forms.CheckBox
        Me.chkNotPosted = New System.Windows.Forms.CheckBox
        Me.cboCategory = New System.Windows.Forms.ComboBox
        Me.cboTypeOfPreparation = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.grpDuePeriods = New System.Windows.Forms.GroupBox
        Me.chkOverDue120 = New System.Windows.Forms.CheckBox
        Me.chkOverDue90 = New System.Windows.Forms.CheckBox
        Me.chkOverDue60 = New System.Windows.Forms.CheckBox
        Me.chkCurrent = New System.Windows.Forms.CheckBox
        Me.chkDue = New System.Windows.Forms.CheckBox
        Me.chkOverDue30 = New System.Windows.Forms.CheckBox
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.grpButtons.SuspendLayout()
        CType(Me.grdInvoiceList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpPeriods.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        Me.grpGrid.SuspendLayout()
        Me.grpStatus.SuspendLayout()
        Me.grpDuePeriods.SuspendLayout()
        Me.grpFilter.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnPreviewList)
        Me.grpButtons.Controls.Add(Me.btnCorrectionInvoice)
        Me.grpButtons.Controls.Add(Me.btnPreview)
        Me.grpButtons.Controls.Add(Me.btnDelete)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Controls.Add(Me.btnEdit)
        Me.grpButtons.Controls.Add(Me.btnAutoGenerateInvoice)
        Me.grpButtons.Location = New System.Drawing.Point(3, 481)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(994, 50)
        Me.grpButtons.TabIndex = 154
        Me.grpButtons.TabStop = False
        '
        'btnPreviewList
        '
        Me.btnPreviewList.AlternativeGroup = Nothing
        Me.btnPreviewList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPreviewList.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPreviewList.BackColor1 = System.Drawing.Color.White
        Me.btnPreviewList.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPreviewList.BorderHover = True
        Me.btnPreviewList.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPreviewList.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPreviewList.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPreviewList.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPreviewList.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPreviewList.DrawBorder = True
        Me.btnPreviewList.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPreviewList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPreviewList.ForeColor = System.Drawing.Color.Navy
        Me.btnPreviewList.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreviewList.HoverColor2 = System.Drawing.Color.White
        Me.btnPreviewList.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPreviewList.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPreviewList.Location = New System.Drawing.Point(559, 14)
        Me.btnPreviewList.Name = "btnPreviewList"
        Me.btnPreviewList.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreviewList.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPreviewList.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPreviewList.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPreviewList.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPreviewList.SelectedText = Nothing
        Me.btnPreviewList.Size = New System.Drawing.Size(99, 27)
        Me.btnPreviewList.TabIndex = 168
        Me.btnPreviewList.Text = "Preview List"
        Me.btnPreviewList.UseVisualStyleBackColor = False
        '
        'btnCorrectionInvoice
        '
        Me.btnCorrectionInvoice.AlternativeGroup = Nothing
        Me.btnCorrectionInvoice.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCorrectionInvoice.BackColor = System.Drawing.Color.Maroon
        Me.btnCorrectionInvoice.BackColor1 = System.Drawing.Color.White
        Me.btnCorrectionInvoice.BackColor2 = System.Drawing.Color.Maroon
        Me.btnCorrectionInvoice.BorderHover = True
        Me.btnCorrectionInvoice.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnCorrectionInvoice.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCorrectionInvoice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCorrectionInvoice.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnCorrectionInvoice.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCorrectionInvoice.DrawBorder = True
        Me.btnCorrectionInvoice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCorrectionInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCorrectionInvoice.ForeColor = System.Drawing.Color.Navy
        Me.btnCorrectionInvoice.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnCorrectionInvoice.HoverColor2 = System.Drawing.Color.White
        Me.btnCorrectionInvoice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCorrectionInvoice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCorrectionInvoice.Location = New System.Drawing.Point(420, 14)
        Me.btnCorrectionInvoice.Name = "btnCorrectionInvoice"
        Me.btnCorrectionInvoice.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnCorrectionInvoice.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCorrectionInvoice.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCorrectionInvoice.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCorrectionInvoice.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnCorrectionInvoice.SelectedText = Nothing
        Me.btnCorrectionInvoice.Size = New System.Drawing.Size(133, 27)
        Me.btnCorrectionInvoice.TabIndex = 167
        Me.btnCorrectionInvoice.Text = "Correct  Invoice"
        Me.btnCorrectionInvoice.UseVisualStyleBackColor = False
        '
        'btnPreview
        '
        Me.btnPreview.AlternativeGroup = Nothing
        Me.btnPreview.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPreview.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPreview.BackColor1 = System.Drawing.Color.White
        Me.btnPreview.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPreview.BorderHover = True
        Me.btnPreview.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPreview.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPreview.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPreview.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPreview.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPreview.DrawBorder = True
        Me.btnPreview.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPreview.ForeColor = System.Drawing.Color.Navy
        Me.btnPreview.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.HoverColor2 = System.Drawing.Color.White
        Me.btnPreview.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPreview.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPreview.Location = New System.Drawing.Point(317, 13)
        Me.btnPreview.Name = "btnPreview"
        Me.btnPreview.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPreview.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPreview.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPreview.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.SelectedText = Nothing
        Me.btnPreview.Size = New System.Drawing.Size(99, 27)
        Me.btnPreview.TabIndex = 165
        Me.btnPreview.Text = "P r e v i e w"
        Me.btnPreview.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.AlternativeGroup = Nothing
        Me.btnDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDelete.BackColor = System.Drawing.Color.Maroon
        Me.btnDelete.BackColor1 = System.Drawing.Color.White
        Me.btnDelete.BackColor2 = System.Drawing.Color.Maroon
        Me.btnDelete.BorderHover = True
        Me.btnDelete.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnDelete.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDelete.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDelete.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnDelete.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDelete.DrawBorder = True
        Me.btnDelete.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnDelete.ForeColor = System.Drawing.Color.Navy
        Me.btnDelete.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnDelete.HoverColor2 = System.Drawing.Color.White
        Me.btnDelete.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDelete.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnDelete.Location = New System.Drawing.Point(214, 13)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnDelete.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnDelete.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDelete.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDelete.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnDelete.SelectedText = Nothing
        Me.btnDelete.Size = New System.Drawing.Size(99, 27)
        Me.btnDelete.TabIndex = 159
        Me.btnDelete.Text = "D e l e t e"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(880, 16)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(99, 27)
        Me.btnClose.TabIndex = 157
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.HoverColor2 = System.Drawing.Color.White
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNew.Location = New System.Drawing.Point(11, 13)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(99, 27)
        Me.btnNew.TabIndex = 156
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnEdit
        '
        Me.btnEdit.AlternativeGroup = Nothing
        Me.btnEdit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnEdit.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BackColor1 = System.Drawing.Color.White
        Me.btnEdit.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BorderHover = True
        Me.btnEdit.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEdit.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEdit.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnEdit.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEdit.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEdit.DrawBorder = True
        Me.btnEdit.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnEdit.ForeColor = System.Drawing.Color.Navy
        Me.btnEdit.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.HoverColor2 = System.Drawing.Color.White
        Me.btnEdit.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEdit.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnEdit.Location = New System.Drawing.Point(112, 13)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnEdit.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnEdit.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnEdit.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnEdit.SelectedText = Nothing
        Me.btnEdit.Size = New System.Drawing.Size(99, 27)
        Me.btnEdit.TabIndex = 158
        Me.btnEdit.Text = "O p e n"
        Me.btnEdit.UseVisualStyleBackColor = False
        '
        'btnAutoGenerateInvoice
        '
        Me.btnAutoGenerateInvoice.AlternativeGroup = Nothing
        Me.btnAutoGenerateInvoice.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnAutoGenerateInvoice.BackColor = System.Drawing.Color.Red
        Me.btnAutoGenerateInvoice.BackColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.BackColor2 = System.Drawing.Color.Red
        Me.btnAutoGenerateInvoice.BorderHover = True
        Me.btnAutoGenerateInvoice.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnAutoGenerateInvoice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnAutoGenerateInvoice.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnAutoGenerateInvoice.DrawBorder = True
        Me.btnAutoGenerateInvoice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnAutoGenerateInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAutoGenerateInvoice.ForeColor = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.HoverColor2 = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnAutoGenerateInvoice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnAutoGenerateInvoice.Location = New System.Drawing.Point(78, 13)
        Me.btnAutoGenerateInvoice.Name = "btnAutoGenerateInvoice"
        Me.btnAutoGenerateInvoice.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnAutoGenerateInvoice.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnAutoGenerateInvoice.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.SelectedText = Nothing
        Me.btnAutoGenerateInvoice.Size = New System.Drawing.Size(32, 27)
        Me.btnAutoGenerateInvoice.TabIndex = 164
        Me.btnAutoGenerateInvoice.Text = " Auto Generate Invoice"
        Me.btnAutoGenerateInvoice.UseVisualStyleBackColor = False
        '
        'cboStatus
        '
        Me.cboStatus.ForeColor = System.Drawing.Color.Navy
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Location = New System.Drawing.Point(713, 123)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(28, 21)
        Me.cboStatus.TabIndex = 17
        Me.cboStatus.Visible = False
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(1000, 40)
        Me.lblfrmTitle.TabIndex = 347
        Me.lblfrmTitle.Text = " Invoice List"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(1000, 3)
        Me.pnlTitle.TabIndex = 349
        '
        'grdInvoiceList
        '
        Me.grdInvoiceList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdInvoiceList.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdInvoiceList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdInvoiceList.Location = New System.Drawing.Point(2, 14)
        Me.grdInvoiceList.Name = "grdInvoiceList"
        Me.grdInvoiceList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdInvoiceList.Size = New System.Drawing.Size(986, 251)
        Me.grdInvoiceList.TabIndex = 152
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(5, 18)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 156
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grpPeriods
        '
        Me.grpPeriods.BackColor = System.Drawing.Color.Bisque
        Me.grpPeriods.Controls.Add(Me.btnCancel)
        Me.grpPeriods.Controls.Add(Me.btnOK)
        Me.grpPeriods.Controls.Add(Me.rdbAnnualy)
        Me.grpPeriods.Controls.Add(Me.rdbBiAnnualy)
        Me.grpPeriods.Controls.Add(Me.rdbQuarterly)
        Me.grpPeriods.Controls.Add(Me.rdbMonthly)
        Me.grpPeriods.Location = New System.Drawing.Point(345, 30)
        Me.grpPeriods.Name = "grpPeriods"
        Me.grpPeriods.Size = New System.Drawing.Size(236, 124)
        Me.grpPeriods.TabIndex = 350
        Me.grpPeriods.TabStop = False
        Me.grpPeriods.Visible = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.ForeColor = System.Drawing.Color.Blue
        Me.btnCancel.Location = New System.Drawing.Point(141, 93)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnOK
        '
        Me.btnOK.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnOK.ForeColor = System.Drawing.Color.Blue
        Me.btnOK.Location = New System.Drawing.Point(21, 93)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = False
        '
        'rdbAnnualy
        '
        Me.rdbAnnualy.AutoSize = True
        Me.rdbAnnualy.ForeColor = System.Drawing.Color.DeepPink
        Me.rdbAnnualy.Location = New System.Drawing.Point(118, 49)
        Me.rdbAnnualy.Name = "rdbAnnualy"
        Me.rdbAnnualy.Size = New System.Drawing.Size(64, 17)
        Me.rdbAnnualy.TabIndex = 3
        Me.rdbAnnualy.Text = "Annualy"
        Me.rdbAnnualy.UseVisualStyleBackColor = True
        '
        'rdbBiAnnualy
        '
        Me.rdbBiAnnualy.AutoSize = True
        Me.rdbBiAnnualy.ForeColor = System.Drawing.Color.SlateBlue
        Me.rdbBiAnnualy.Location = New System.Drawing.Point(118, 26)
        Me.rdbBiAnnualy.Name = "rdbBiAnnualy"
        Me.rdbBiAnnualy.Size = New System.Drawing.Size(72, 17)
        Me.rdbBiAnnualy.TabIndex = 2
        Me.rdbBiAnnualy.Text = "BiAnnualy"
        Me.rdbBiAnnualy.UseVisualStyleBackColor = True
        '
        'rdbQuarterly
        '
        Me.rdbQuarterly.AutoSize = True
        Me.rdbQuarterly.ForeColor = System.Drawing.Color.RoyalBlue
        Me.rdbQuarterly.Location = New System.Drawing.Point(21, 49)
        Me.rdbQuarterly.Name = "rdbQuarterly"
        Me.rdbQuarterly.Size = New System.Drawing.Size(71, 17)
        Me.rdbQuarterly.TabIndex = 1
        Me.rdbQuarterly.Text = "Quarterly"
        Me.rdbQuarterly.UseVisualStyleBackColor = True
        '
        'rdbMonthly
        '
        Me.rdbMonthly.AutoSize = True
        Me.rdbMonthly.Checked = True
        Me.rdbMonthly.ForeColor = System.Drawing.Color.Red
        Me.rdbMonthly.Location = New System.Drawing.Point(21, 28)
        Me.rdbMonthly.Name = "rdbMonthly"
        Me.rdbMonthly.Size = New System.Drawing.Size(63, 17)
        Me.rdbMonthly.TabIndex = 0
        Me.rdbMonthly.TabStop = True
        Me.rdbMonthly.Text = "Monthly"
        Me.rdbMonthly.UseVisualStyleBackColor = True
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(42, 18)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 224)
        Me.grpShowHideColumns.TabIndex = 155
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 195)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 22)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 154)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'grpGrid
        '
        Me.grpGrid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpGrid.Controls.Add(Me.lblCurrSymbol2)
        Me.grpGrid.Controls.Add(Me.Label2)
        Me.grpGrid.Controls.Add(Me.txtTotalCurr2)
        Me.grpGrid.Controls.Add(Me.lblCurrSymbol)
        Me.grpGrid.Controls.Add(Me.txtTotal)
        Me.grpGrid.Controls.Add(Me.grpShowHideColumns)
        Me.grpGrid.Controls.Add(Me.grpPeriods)
        Me.grpGrid.Controls.Add(Me.btnShowCol)
        Me.grpGrid.Controls.Add(Me.Label3)
        Me.grpGrid.Controls.Add(Me.grdInvoiceList)
        Me.grpGrid.Controls.Add(Me.cboStatus)
        Me.grpGrid.Location = New System.Drawing.Point(3, 142)
        Me.grpGrid.Name = "grpGrid"
        Me.grpGrid.Size = New System.Drawing.Size(994, 342)
        Me.grpGrid.TabIndex = 351
        Me.grpGrid.TabStop = False
        '
        'lblCurrSymbol2
        '
        Me.lblCurrSymbol2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCurrSymbol2.BackColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol2.ForeColor = System.Drawing.Color.White
        Me.lblCurrSymbol2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol2.Location = New System.Drawing.Point(642, 303)
        Me.lblCurrSymbol2.Name = "lblCurrSymbol2"
        Me.lblCurrSymbol2.Size = New System.Drawing.Size(34, 29)
        Me.lblCurrSymbol2.TabIndex = 363
        Me.lblCurrSymbol2.Text = "Curr"
        Me.lblCurrSymbol2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.BackColor = System.Drawing.Color.Maroon
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(602, 303)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 29)
        Me.Label2.TabIndex = 365
        Me.Label2.Text = "  Total"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTotalCurr2
        '
        Me.txtTotalCurr2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalCurr2.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalCurr2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalCurr2.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalCurr2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalCurr2.Location = New System.Drawing.Point(709, 304)
        Me.txtTotalCurr2.Multiline = True
        Me.txtTotalCurr2.Name = "txtTotalCurr2"
        Me.txtTotalCurr2.ReadOnly = True
        Me.txtTotalCurr2.Size = New System.Drawing.Size(273, 29)
        Me.txtTotalCurr2.TabIndex = 362
        Me.txtTotalCurr2.TabStop = False
        '
        'lblCurrSymbol
        '
        Me.lblCurrSymbol.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCurrSymbol.BackColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol.ForeColor = System.Drawing.Color.White
        Me.lblCurrSymbol.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol.Location = New System.Drawing.Point(642, 270)
        Me.lblCurrSymbol.Name = "lblCurrSymbol"
        Me.lblCurrSymbol.Size = New System.Drawing.Size(34, 29)
        Me.lblCurrSymbol.TabIndex = 360
        Me.lblCurrSymbol.Text = "Curr"
        Me.lblCurrSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTotal
        '
        Me.txtTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotal.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotal.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotal.Location = New System.Drawing.Point(709, 270)
        Me.txtTotal.Multiline = True
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(273, 29)
        Me.txtTotal.TabIndex = 359
        Me.txtTotal.TabStop = False
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.BackColor = System.Drawing.Color.Maroon
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label3.Location = New System.Drawing.Point(602, 270)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 29)
        Me.Label3.TabIndex = 364
        Me.Label3.Text = "  Total"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboClient
        '
        Me.cboClient.ForeColor = System.Drawing.Color.Maroon
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(53, 17)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(301, 21)
        Me.cboClient.TabIndex = 2
        '
        'lblClient
        '
        Me.lblClient.AutoSize = True
        Me.lblClient.ForeColor = System.Drawing.Color.Maroon
        Me.lblClient.Location = New System.Drawing.Point(19, 22)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(34, 13)
        Me.lblClient.TabIndex = 5
        Me.lblClient.Text = "Client"
        Me.lblClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDateTo
        '
        Me.lblDateTo.AutoSize = True
        Me.lblDateTo.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateTo.Location = New System.Drawing.Point(525, 22)
        Me.lblDateTo.Name = "lblDateTo"
        Me.lblDateTo.Size = New System.Drawing.Size(19, 13)
        Me.lblDateTo.TabIndex = 7
        Me.lblDateTo.Text = "To"
        Me.lblDateTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpDateFrom
        '
        Me.dtpDateFrom.CustomFormat = "dd MMM yyyy"
        Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateFrom.Location = New System.Drawing.Point(418, 17)
        Me.dtpDateFrom.Name = "dtpDateFrom"
        Me.dtpDateFrom.Size = New System.Drawing.Size(106, 20)
        Me.dtpDateFrom.TabIndex = 14
        '
        'lblDateFrom
        '
        Me.lblDateFrom.AutoSize = True
        Me.lblDateFrom.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateFrom.Location = New System.Drawing.Point(360, 22)
        Me.lblDateFrom.Name = "lblDateFrom"
        Me.lblDateFrom.Size = New System.Drawing.Size(57, 13)
        Me.lblDateFrom.TabIndex = 15
        Me.lblDateFrom.Text = "Date From"
        Me.lblDateFrom.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpDateTo
        '
        Me.dtpDateTo.CustomFormat = "dd MMM yyyy"
        Me.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateTo.Location = New System.Drawing.Point(550, 17)
        Me.dtpDateTo.Name = "dtpDateTo"
        Me.dtpDateTo.Size = New System.Drawing.Size(92, 20)
        Me.dtpDateTo.TabIndex = 16
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.ForeColor = System.Drawing.Color.Maroon
        Me.lblStatus.Location = New System.Drawing.Point(374, 61)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(38, 13)
        Me.lblStatus.TabIndex = 18
        Me.lblStatus.Text = "Status"
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCategory
        '
        Me.lblCategory.AutoSize = True
        Me.lblCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblCategory.ForeColor = System.Drawing.Color.Maroon
        Me.lblCategory.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCategory.Location = New System.Drawing.Point(648, 22)
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Size = New System.Drawing.Size(49, 13)
        Me.lblCategory.TabIndex = 153
        Me.lblCategory.Text = "Category"
        Me.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtInvoiceNum
        '
        Me.txtInvoiceNum.ForeColor = System.Drawing.Color.Navy
        Me.txtInvoiceNum.Location = New System.Drawing.Point(53, 58)
        Me.txtInvoiceNum.Name = "txtInvoiceNum"
        Me.txtInvoiceNum.Size = New System.Drawing.Size(89, 20)
        Me.txtInvoiceNum.TabIndex = 155
        Me.txtInvoiceNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblInvoiceNum
        '
        Me.lblInvoiceNum.AutoSize = True
        Me.lblInvoiceNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblInvoiceNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblInvoiceNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInvoiceNum.Location = New System.Drawing.Point(1, 61)
        Me.lblInvoiceNum.Name = "lblInvoiceNum"
        Me.lblInvoiceNum.Size = New System.Drawing.Size(52, 13)
        Me.lblInvoiceNum.TabIndex = 154
        Me.lblInvoiceNum.Text = "Invoice #"
        Me.lblInvoiceNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpStatus
        '
        Me.grpStatus.BackColor = System.Drawing.Color.Lavender
        Me.grpStatus.Controls.Add(Me.chkPartial)
        Me.grpStatus.Controls.Add(Me.chkCorrected)
        Me.grpStatus.Controls.Add(Me.chkPaid)
        Me.grpStatus.Controls.Add(Me.chkNew)
        Me.grpStatus.Controls.Add(Me.chkPosted)
        Me.grpStatus.Controls.Add(Me.chkNotPosted)
        Me.grpStatus.Location = New System.Drawing.Point(418, 52)
        Me.grpStatus.Name = "grpStatus"
        Me.grpStatus.Size = New System.Drawing.Size(391, 34)
        Me.grpStatus.TabIndex = 156
        Me.grpStatus.TabStop = False
        '
        'chkPartial
        '
        Me.chkPartial.AutoSize = True
        Me.chkPartial.Checked = True
        Me.chkPartial.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPartial.ForeColor = System.Drawing.Color.DarkGreen
        Me.chkPartial.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkPartial.Location = New System.Drawing.Point(311, 11)
        Me.chkPartial.Name = "chkPartial"
        Me.chkPartial.Size = New System.Drawing.Size(56, 17)
        Me.chkPartial.TabIndex = 5
        Me.chkPartial.Text = "Partial"
        Me.chkPartial.Visible = False
        '
        'chkCorrected
        '
        Me.chkCorrected.AutoSize = True
        Me.chkCorrected.Checked = True
        Me.chkCorrected.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkCorrected.ForeColor = System.Drawing.Color.Maroon
        Me.chkCorrected.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkCorrected.Location = New System.Drawing.Point(240, 11)
        Me.chkCorrected.Name = "chkCorrected"
        Me.chkCorrected.Size = New System.Drawing.Size(74, 17)
        Me.chkCorrected.TabIndex = 4
        Me.chkCorrected.Text = "Corrected"
        '
        'chkPaid
        '
        Me.chkPaid.AutoSize = True
        Me.chkPaid.Checked = True
        Me.chkPaid.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPaid.ForeColor = System.Drawing.Color.Blue
        Me.chkPaid.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkPaid.Location = New System.Drawing.Point(179, 11)
        Me.chkPaid.Name = "chkPaid"
        Me.chkPaid.Size = New System.Drawing.Size(60, 17)
        Me.chkPaid.TabIndex = 3
        Me.chkPaid.Text = "Settled"
        '
        'chkNew
        '
        Me.chkNew.AutoSize = True
        Me.chkNew.Checked = True
        Me.chkNew.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkNew.ForeColor = System.Drawing.Color.Red
        Me.chkNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkNew.Location = New System.Drawing.Point(5, 11)
        Me.chkNew.Name = "chkNew"
        Me.chkNew.Size = New System.Drawing.Size(47, 17)
        Me.chkNew.TabIndex = 1
        Me.chkNew.Text = "New"
        '
        'chkPosted
        '
        Me.chkPosted.AutoSize = True
        Me.chkPosted.Checked = True
        Me.chkPosted.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPosted.ForeColor = System.Drawing.Color.Navy
        Me.chkPosted.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkPosted.Location = New System.Drawing.Point(51, 11)
        Me.chkPosted.Name = "chkPosted"
        Me.chkPosted.Size = New System.Drawing.Size(59, 17)
        Me.chkPosted.TabIndex = 2
        Me.chkPosted.Text = "Posted"
        '
        'chkNotPosted
        '
        Me.chkNotPosted.AutoSize = True
        Me.chkNotPosted.Checked = True
        Me.chkNotPosted.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkNotPosted.ForeColor = System.Drawing.Color.LightCoral
        Me.chkNotPosted.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkNotPosted.Location = New System.Drawing.Point(109, 11)
        Me.chkNotPosted.Name = "chkNotPosted"
        Me.chkNotPosted.Size = New System.Drawing.Size(72, 17)
        Me.chkNotPosted.TabIndex = 0
        Me.chkNotPosted.Text = "Unposted"
        '
        'cboCategory
        '
        Me.cboCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCategory.FormattingEnabled = True
        Me.cboCategory.Location = New System.Drawing.Point(703, 17)
        Me.cboCategory.Name = "cboCategory"
        Me.cboCategory.Size = New System.Drawing.Size(106, 21)
        Me.cboCategory.TabIndex = 318
        '
        'cboTypeOfPreparation
        '
        Me.cboTypeOfPreparation.ForeColor = System.Drawing.Color.Maroon
        Me.cboTypeOfPreparation.FormattingEnabled = True
        Me.cboTypeOfPreparation.Items.AddRange(New Object() {"Manual", "Auto Generated"})
        Me.cboTypeOfPreparation.Location = New System.Drawing.Point(248, 59)
        Me.cboTypeOfPreparation.Name = "cboTypeOfPreparation"
        Me.cboTypeOfPreparation.Size = New System.Drawing.Size(106, 21)
        Me.cboTypeOfPreparation.TabIndex = 319
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Maroon
        Me.Label1.Location = New System.Drawing.Point(142, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(103, 13)
        Me.Label1.TabIndex = 320
        Me.Label1.Text = "Type of Preparation"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpDuePeriods
        '
        Me.grpDuePeriods.BackColor = System.Drawing.Color.AliceBlue
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue120)
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue90)
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue60)
        Me.grpDuePeriods.Controls.Add(Me.chkCurrent)
        Me.grpDuePeriods.Controls.Add(Me.chkDue)
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue30)
        Me.grpDuePeriods.Location = New System.Drawing.Point(12, 100)
        Me.grpDuePeriods.Name = "grpDuePeriods"
        Me.grpDuePeriods.Size = New System.Drawing.Size(656, 35)
        Me.grpDuePeriods.TabIndex = 158
        Me.grpDuePeriods.TabStop = False
        '
        'chkOverDue120
        '
        Me.chkOverDue120.Checked = True
        Me.chkOverDue120.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue120.ForeColor = System.Drawing.Color.Blue
        Me.chkOverDue120.Location = New System.Drawing.Point(537, 14)
        Me.chkOverDue120.Name = "chkOverDue120"
        Me.chkOverDue120.Size = New System.Drawing.Size(93, 19)
        Me.chkOverDue120.TabIndex = 5
        Me.chkOverDue120.Text = "OverDue120"
        Me.chkOverDue120.UseVisualStyleBackColor = True
        '
        'chkOverDue90
        '
        Me.chkOverDue90.Checked = True
        Me.chkOverDue90.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue90.ForeColor = System.Drawing.Color.SandyBrown
        Me.chkOverDue90.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkOverDue90.Location = New System.Drawing.Point(432, 14)
        Me.chkOverDue90.Name = "chkOverDue90"
        Me.chkOverDue90.Size = New System.Drawing.Size(86, 19)
        Me.chkOverDue90.TabIndex = 4
        Me.chkOverDue90.Text = "OverDue90"
        '
        'chkOverDue60
        '
        Me.chkOverDue60.Checked = True
        Me.chkOverDue60.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue60.ForeColor = System.Drawing.Color.DimGray
        Me.chkOverDue60.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkOverDue60.Location = New System.Drawing.Point(327, 14)
        Me.chkOverDue60.Name = "chkOverDue60"
        Me.chkOverDue60.Size = New System.Drawing.Size(86, 19)
        Me.chkOverDue60.TabIndex = 3
        Me.chkOverDue60.Text = "OverDue60"
        '
        'chkCurrent
        '
        Me.chkCurrent.Checked = True
        Me.chkCurrent.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkCurrent.ForeColor = System.Drawing.Color.Red
        Me.chkCurrent.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkCurrent.Location = New System.Drawing.Point(12, 14)
        Me.chkCurrent.Name = "chkCurrent"
        Me.chkCurrent.Size = New System.Drawing.Size(86, 19)
        Me.chkCurrent.TabIndex = 1
        Me.chkCurrent.Text = "Current"
        '
        'chkDue
        '
        Me.chkDue.Checked = True
        Me.chkDue.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkDue.ForeColor = System.Drawing.Color.Navy
        Me.chkDue.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkDue.Location = New System.Drawing.Point(117, 14)
        Me.chkDue.Name = "chkDue"
        Me.chkDue.Size = New System.Drawing.Size(86, 19)
        Me.chkDue.TabIndex = 2
        Me.chkDue.Text = "Due"
        '
        'chkOverDue30
        '
        Me.chkOverDue30.Checked = True
        Me.chkOverDue30.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue30.ForeColor = System.Drawing.Color.LightCoral
        Me.chkOverDue30.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkOverDue30.Location = New System.Drawing.Point(223, 14)
        Me.chkOverDue30.Name = "chkOverDue30"
        Me.chkOverDue30.Size = New System.Drawing.Size(86, 19)
        Me.chkOverDue30.TabIndex = 0
        Me.chkOverDue30.Text = "OverDue30"
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.grpDuePeriods)
        Me.grpFilter.Controls.Add(Me.Label1)
        Me.grpFilter.Controls.Add(Me.cboTypeOfPreparation)
        Me.grpFilter.Controls.Add(Me.cboCategory)
        Me.grpFilter.Controls.Add(Me.grpStatus)
        Me.grpFilter.Controls.Add(Me.lblInvoiceNum)
        Me.grpFilter.Controls.Add(Me.txtInvoiceNum)
        Me.grpFilter.Controls.Add(Me.lblCategory)
        Me.grpFilter.Controls.Add(Me.lblStatus)
        Me.grpFilter.Controls.Add(Me.dtpDateTo)
        Me.grpFilter.Controls.Add(Me.lblDateFrom)
        Me.grpFilter.Controls.Add(Me.dtpDateFrom)
        Me.grpFilter.Controls.Add(Me.lblDateTo)
        Me.grpFilter.Controls.Add(Me.lblClient)
        Me.grpFilter.Controls.Add(Me.cboClient)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(3, 42)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(994, 100)
        Me.grpFilter.TabIndex = 153
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Data Filter"
        '
        'frmInvoiceList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1000, 543)
        Me.Controls.Add(Me.grpFilter)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grpGrid)
        Me.KeyPreview = True
        Me.Name = "frmInvoiceList"
        Me.Text = "Invoice List"
        Me.grpButtons.ResumeLayout(False)
        CType(Me.grdInvoiceList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpPeriods.ResumeLayout(False)
        Me.grpPeriods.PerformLayout()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.grpGrid.ResumeLayout(False)
        Me.grpGrid.PerformLayout()
        Me.grpStatus.ResumeLayout(False)
        Me.grpStatus.PerformLayout()
        Me.grpDuePeriods.ResumeLayout(False)
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
	Friend WithEvents btnDelete As BHBut.BouncingHoverButton
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
	Friend WithEvents btnNew As BHBut.BouncingHoverButton
	Friend WithEvents btnEdit As BHBut.BouncingHoverButton
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents pnlTitle As System.Windows.Forms.Panel
	Friend WithEvents btnAutoGenerateInvoice As BHBut.BouncingHoverButton
	Friend WithEvents btnPreview As BHBut.BouncingHoverButton
	Friend WithEvents grdInvoiceList As System.Windows.Forms.DataGridView
	Friend WithEvents btnShowCol As System.Windows.Forms.Button
	Friend WithEvents grpPeriods As System.Windows.Forms.GroupBox
	Friend WithEvents btnCancel As System.Windows.Forms.Button
	Friend WithEvents btnOK As System.Windows.Forms.Button
	Friend WithEvents rdbAnnualy As System.Windows.Forms.RadioButton
	Friend WithEvents rdbBiAnnualy As System.Windows.Forms.RadioButton
	Friend WithEvents rdbQuarterly As System.Windows.Forms.RadioButton
	Friend WithEvents rdbMonthly As System.Windows.Forms.RadioButton
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
	Friend WithEvents grpGrid As System.Windows.Forms.GroupBox
	Friend WithEvents txtTotal As System.Windows.Forms.TextBox
	Friend WithEvents lblCurrSymbol As System.Windows.Forms.Label
	Friend WithEvents lblCurrSymbol2 As System.Windows.Forms.Label
	Friend WithEvents txtTotalCurr2 As System.Windows.Forms.TextBox
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents cboClient As System.Windows.Forms.ComboBox
	Friend WithEvents lblClient As System.Windows.Forms.Label
	Friend WithEvents lblDateTo As System.Windows.Forms.Label
	Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker
	Friend WithEvents lblDateFrom As System.Windows.Forms.Label
	Friend WithEvents dtpDateTo As System.Windows.Forms.DateTimePicker
	Friend WithEvents lblStatus As System.Windows.Forms.Label
	Friend WithEvents lblCategory As System.Windows.Forms.Label
	Friend WithEvents txtInvoiceNum As System.Windows.Forms.TextBox
	Friend WithEvents lblInvoiceNum As System.Windows.Forms.Label
	Friend WithEvents grpStatus As System.Windows.Forms.GroupBox
	Friend WithEvents chkPaid As System.Windows.Forms.CheckBox
	Friend WithEvents chkNew As System.Windows.Forms.CheckBox
	Friend WithEvents chkPosted As System.Windows.Forms.CheckBox
	Friend WithEvents chkNotPosted As System.Windows.Forms.CheckBox
	Friend WithEvents cboCategory As System.Windows.Forms.ComboBox
	Friend WithEvents cboTypeOfPreparation As System.Windows.Forms.ComboBox
	Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents grpDuePeriods As System.Windows.Forms.GroupBox
	Friend WithEvents chkOverDue120 As System.Windows.Forms.CheckBox
	Friend WithEvents chkOverDue90 As System.Windows.Forms.CheckBox
	Friend WithEvents chkOverDue60 As System.Windows.Forms.CheckBox
	Friend WithEvents chkCurrent As System.Windows.Forms.CheckBox
	Friend WithEvents chkDue As System.Windows.Forms.CheckBox
	Friend WithEvents chkOverDue30 As System.Windows.Forms.CheckBox
	Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
	Friend WithEvents chkCorrected As System.Windows.Forms.CheckBox
	Friend WithEvents btnCorrectionInvoice As BHBut.BouncingHoverButton
    Friend WithEvents btnPreviewList As BHBut.BouncingHoverButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents chkPartial As System.Windows.Forms.CheckBox
End Class
