<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmServiceGet
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing AndAlso components IsNot Nothing Then
			components.Dispose()
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.grpServices = New System.Windows.Forms.GroupBox
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.lblType = New System.Windows.Forms.Label
        Me.lblSubCat = New System.Windows.Forms.Label
        Me.cboType = New System.Windows.Forms.ComboBox
        Me.cboSubCat = New System.Windows.Forms.ComboBox
        Me.btnAddNewService = New System.Windows.Forms.Button
        Me.rdbContain = New System.Windows.Forms.RadioButton
        Me.rdbLike = New System.Windows.Forms.RadioButton
        Me.cboService = New System.Windows.Forms.ComboBox
        Me.grdServices = New System.Windows.Forms.DataGridView
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnOK = New BHBut.BouncingHoverButton
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.grpServices.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        CType(Me.grdServices, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpServices
        '
        Me.grpServices.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpServices.Controls.Add(Me.btnShowCol)
        Me.grpServices.Controls.Add(Me.grpShowHideColumns)
        Me.grpServices.Controls.Add(Me.lblType)
        Me.grpServices.Controls.Add(Me.lblSubCat)
        Me.grpServices.Controls.Add(Me.cboType)
        Me.grpServices.Controls.Add(Me.cboSubCat)
        Me.grpServices.Controls.Add(Me.btnAddNewService)
        Me.grpServices.Controls.Add(Me.rdbContain)
        Me.grpServices.Controls.Add(Me.rdbLike)
        Me.grpServices.Controls.Add(Me.cboService)
        Me.grpServices.Controls.Add(Me.grdServices)
        Me.grpServices.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpServices.Location = New System.Drawing.Point(17, 47)
        Me.grpServices.Name = "grpServices"
        Me.grpServices.Size = New System.Drawing.Size(504, 522)
        Me.grpServices.TabIndex = 122
        Me.grpServices.TabStop = False
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(8, 135)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 142
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(49, 136)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 320)
        Me.grpShowHideColumns.TabIndex = 141
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.UseCompatibleTextRendering = True
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 291)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 244)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'lblType
        '
        Me.lblType.AutoSize = True
        Me.lblType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblType.ForeColor = System.Drawing.Color.Maroon
        Me.lblType.Location = New System.Drawing.Point(58, 104)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(31, 13)
        Me.lblType.TabIndex = 140
        Me.lblType.Text = "Type"
        '
        'lblSubCat
        '
        Me.lblSubCat.AutoSize = True
        Me.lblSubCat.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubCat.ForeColor = System.Drawing.Color.Maroon
        Me.lblSubCat.Location = New System.Drawing.Point(16, 77)
        Me.lblSubCat.Name = "lblSubCat"
        Me.lblSubCat.Size = New System.Drawing.Size(73, 13)
        Me.lblSubCat.TabIndex = 139
        Me.lblSubCat.Text = "Sub Category"
        '
        'cboType
        '
        Me.cboType.FormattingEnabled = True
        Me.cboType.Location = New System.Drawing.Point(95, 100)
        Me.cboType.Name = "cboType"
        Me.cboType.Size = New System.Drawing.Size(257, 21)
        Me.cboType.TabIndex = 138
        '
        'cboSubCat
        '
        Me.cboSubCat.FormattingEnabled = True
        Me.cboSubCat.Location = New System.Drawing.Point(95, 73)
        Me.cboSubCat.Name = "cboSubCat"
        Me.cboSubCat.Size = New System.Drawing.Size(257, 21)
        Me.cboSubCat.TabIndex = 137
        '
        'btnAddNewService
        '
        Me.btnAddNewService.BackColor = System.Drawing.Color.IndianRed
        Me.btnAddNewService.ForeColor = System.Drawing.Color.White
        Me.btnAddNewService.Location = New System.Drawing.Point(356, 40)
        Me.btnAddNewService.Name = "btnAddNewService"
        Me.btnAddNewService.Size = New System.Drawing.Size(37, 23)
        Me.btnAddNewService.TabIndex = 135
        Me.btnAddNewService.Text = "New"
        Me.btnAddNewService.UseVisualStyleBackColor = False
        Me.btnAddNewService.Visible = False
        '
        'rdbContain
        '
        Me.rdbContain.AutoSize = True
        Me.rdbContain.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdbContain.ForeColor = System.Drawing.Color.Navy
        Me.rdbContain.Location = New System.Drawing.Point(254, 20)
        Me.rdbContain.Name = "rdbContain"
        Me.rdbContain.Size = New System.Drawing.Size(67, 17)
        Me.rdbContain.TabIndex = 127
        Me.rdbContain.Text = "Contains"
        Me.rdbContain.UseVisualStyleBackColor = True
        '
        'rdbLike
        '
        Me.rdbLike.AutoSize = True
        Me.rdbLike.Checked = True
        Me.rdbLike.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdbLike.ForeColor = System.Drawing.Color.Navy
        Me.rdbLike.Location = New System.Drawing.Point(94, 21)
        Me.rdbLike.Name = "rdbLike"
        Me.rdbLike.Size = New System.Drawing.Size(79, 17)
        Me.rdbLike.TabIndex = 126
        Me.rdbLike.TabStop = True
        Me.rdbLike.Text = "Starts With"
        Me.rdbLike.UseVisualStyleBackColor = True
        '
        'cboService
        '
        Me.cboService.FormattingEnabled = True
        Me.cboService.Location = New System.Drawing.Point(95, 41)
        Me.cboService.Name = "cboService"
        Me.cboService.Size = New System.Drawing.Size(257, 21)
        Me.cboService.TabIndex = 1
        '
        'grdServices
        '
        Me.grdServices.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdServices.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdServices.Location = New System.Drawing.Point(6, 133)
        Me.grdServices.Name = "grdServices"
        Me.grdServices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdServices.Size = New System.Drawing.Size(488, 373)
        Me.grdServices.TabIndex = 0
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Controls.Add(Me.btnOK)
        Me.grpButtons.Location = New System.Drawing.Point(17, 574)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(504, 53)
        Me.grpButtons.TabIndex = 130
        Me.grpButtons.TabStop = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.Orange
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.Orange
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCancel.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Location = New System.Drawing.Point(388, 15)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(105, 28)
        Me.btnCancel.TabIndex = 41
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnOK
        '
        Me.btnOK.AlternativeGroup = Nothing
        Me.btnOK.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnOK.BackColor1 = System.Drawing.Color.White
        Me.btnOK.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnOK.BorderHover = True
        Me.btnOK.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnOK.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnOK.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnOK.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnOK.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnOK.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOK.DrawBorder = True
        Me.btnOK.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.ForeColor = System.Drawing.Color.Navy
        Me.btnOK.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnOK.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnOK.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnOK.Location = New System.Drawing.Point(8, 15)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnOK.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnOK.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnOK.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnOK.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnOK.SelectedText = Nothing
        Me.btnOK.Size = New System.Drawing.Size(105, 28)
        Me.btnOK.TabIndex = 17
        Me.btnOK.Text = "O K"
        Me.btnOK.UseVisualStyleBackColor = False
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.Black
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 1)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(537, 43)
        Me.lblfrmTitle.TabIndex = 509
        Me.lblfrmTitle.Text = "  Service List"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlTitle
        '
        Me.pnlTitle.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 41)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(658, 3)
        Me.pnlTitle.TabIndex = 353
        '
        'frmServiceGet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(537, 638)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grpServices)
        Me.KeyPreview = True
        Me.Name = "frmServiceGet"
        Me.Text = "  Service List"
        Me.grpServices.ResumeLayout(False)
        Me.grpServices.PerformLayout()
        Me.grpShowHideColumns.ResumeLayout(False)
        CType(Me.grdServices, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpButtons.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents grpServices As System.Windows.Forms.GroupBox
	Friend WithEvents lblType As System.Windows.Forms.Label
	Friend WithEvents lblSubCat As System.Windows.Forms.Label
	Friend WithEvents cboType As System.Windows.Forms.ComboBox
	Friend WithEvents cboSubCat As System.Windows.Forms.ComboBox
	Friend WithEvents btnAddNewService As System.Windows.Forms.Button
	Friend WithEvents rdbContain As System.Windows.Forms.RadioButton
	Friend WithEvents rdbLike As System.Windows.Forms.RadioButton
	Friend WithEvents cboService As System.Windows.Forms.ComboBox
	Friend WithEvents grdServices As System.Windows.Forms.DataGridView
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnCancel As BHBut.BouncingHoverButton
	Friend WithEvents btnOK As BHBut.BouncingHoverButton
    Friend WithEvents btnShowCol As System.Windows.Forms.Button
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
    Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
End Class
