<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLogin
   Inherits System.Windows.Forms.Form

   'Form overrides dispose to clean up the component list.
   <System.Diagnostics.DebuggerNonUserCode()> _
   Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing AndAlso components IsNot Nothing Then
         components.Dispose()
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> _
   Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLogin))
		Me.txtPass = New System.Windows.Forms.TextBox
		Me.txtUser = New System.Windows.Forms.TextBox
		Me.lblPass = New System.Windows.Forms.Label
		Me.lblUser = New System.Windows.Forms.Label
		Me.btnCancel = New System.Windows.Forms.Button
		Me.btnOk = New System.Windows.Forms.Button
		Me.PictureBox3 = New System.Windows.Forms.PictureBox
		Me.PictureBox1 = New System.Windows.Forms.PictureBox
		Me.picTitle = New System.Windows.Forms.PictureBox
		Me.PictureBox2 = New System.Windows.Forms.PictureBox
		Me.Label8 = New System.Windows.Forms.Label
		Me.chkAr = New System.Windows.Forms.CheckBox
		CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picTitle, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'txtPass
		'
		Me.txtPass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
		Me.txtPass.Location = New System.Drawing.Point(126, 143)
		Me.txtPass.Name = "txtPass"
		Me.txtPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
		Me.txtPass.Size = New System.Drawing.Size(144, 22)
		Me.txtPass.TabIndex = 37
		'
		'txtUser
		'
		Me.txtUser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.txtUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
		Me.txtUser.Location = New System.Drawing.Point(126, 107)
		Me.txtUser.Name = "txtUser"
		Me.txtUser.Size = New System.Drawing.Size(144, 22)
		Me.txtUser.TabIndex = 36
		'
		'lblPass
		'
		Me.lblPass.BackColor = System.Drawing.Color.Transparent
		Me.lblPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
		Me.lblPass.ForeColor = System.Drawing.Color.Black
		Me.lblPass.Location = New System.Drawing.Point(42, 107)
		Me.lblPass.Name = "lblPass"
		Me.lblPass.Size = New System.Drawing.Size(84, 23)
		Me.lblPass.TabIndex = 41
		Me.lblPass.Text = "User Name"
		Me.lblPass.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'lblUser
		'
		Me.lblUser.BackColor = System.Drawing.Color.Transparent
		Me.lblUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
		Me.lblUser.ForeColor = System.Drawing.Color.Black
		Me.lblUser.Location = New System.Drawing.Point(42, 143)
		Me.lblUser.Name = "lblUser"
		Me.lblUser.Size = New System.Drawing.Size(84, 23)
		Me.lblUser.TabIndex = 40
		Me.lblUser.Text = "Password"
		Me.lblUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'btnCancel
		'
		Me.btnCancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
		Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
		Me.btnCancel.ForeColor = System.Drawing.Color.Black
		Me.btnCancel.Location = New System.Drawing.Point(300, 143)
		Me.btnCancel.Name = "btnCancel"
		Me.btnCancel.Size = New System.Drawing.Size(72, 24)
		Me.btnCancel.TabIndex = 39
		Me.btnCancel.Text = "Cancel"
		Me.btnCancel.UseVisualStyleBackColor = False
		'
		'btnOk
		'
		Me.btnOk.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
		Me.btnOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
		Me.btnOk.ForeColor = System.Drawing.Color.Black
		Me.btnOk.Location = New System.Drawing.Point(300, 107)
		Me.btnOk.Name = "btnOk"
		Me.btnOk.Size = New System.Drawing.Size(72, 24)
		Me.btnOk.TabIndex = 38
		Me.btnOk.Text = "Login"
		Me.btnOk.UseVisualStyleBackColor = False
		'
		'PictureBox3
		'
		Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
		Me.PictureBox3.Location = New System.Drawing.Point(364, 21)
		Me.PictureBox3.Name = "PictureBox3"
		Me.PictureBox3.Size = New System.Drawing.Size(48, 42)
		Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.PictureBox3.TabIndex = 48
		Me.PictureBox3.TabStop = False
		'
		'PictureBox1
		'
		Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
		Me.PictureBox1.Location = New System.Drawing.Point(-3, 0)
		Me.PictureBox1.Name = "PictureBox1"
		Me.PictureBox1.Size = New System.Drawing.Size(424, 12)
		Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.PictureBox1.TabIndex = 47
		Me.PictureBox1.TabStop = False
		'
		'picTitle
		'
		Me.picTitle.Image = CType(resources.GetObject("picTitle.Image"), System.Drawing.Image)
		Me.picTitle.Location = New System.Drawing.Point(-3, 11)
		Me.picTitle.Name = "picTitle"
		Me.picTitle.Size = New System.Drawing.Size(424, 72)
		Me.picTitle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picTitle.TabIndex = 46
		Me.picTitle.TabStop = False
		'
		'PictureBox2
		'
		Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
		Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
		Me.PictureBox2.Location = New System.Drawing.Point(12, 21)
		Me.PictureBox2.Name = "PictureBox2"
		Me.PictureBox2.Size = New System.Drawing.Size(66, 42)
		Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.PictureBox2.TabIndex = 50
		Me.PictureBox2.TabStop = False
		'
		'Label8
		'
		Me.Label8.AutoSize = True
		Me.Label8.BackColor = System.Drawing.Color.Transparent
		Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
		Me.Label8.ForeColor = System.Drawing.Color.Navy
		Me.Label8.Image = CType(resources.GetObject("Label8.Image"), System.Drawing.Image)
		Me.Label8.Location = New System.Drawing.Point(89, 29)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(264, 26)
		Me.Label8.TabIndex = 49
		Me.Label8.Text = "BITSolutions - Login Form"
		'
		'chkAr
		'
		Me.chkAr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.chkAr.ForeColor = System.Drawing.Color.Maroon
		Me.chkAr.ImeMode = System.Windows.Forms.ImeMode.NoControl
		Me.chkAr.Location = New System.Drawing.Point(289, 86)
		Me.chkAr.Name = "chkAr"
		Me.chkAr.RightToLeft = System.Windows.Forms.RightToLeft.Yes
		Me.chkAr.Size = New System.Drawing.Size(83, 15)
		Me.chkAr.TabIndex = 52
		Me.chkAr.Text = " ������"
		Me.chkAr.Visible = False
		'
		'frmLogin
		'
		Me.AcceptButton = Me.btnOk
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.CancelButton = Me.btnCancel
		Me.ClientSize = New System.Drawing.Size(422, 186)
		Me.Controls.Add(Me.chkAr)
		Me.Controls.Add(Me.PictureBox2)
		Me.Controls.Add(Me.Label8)
		Me.Controls.Add(Me.PictureBox3)
		Me.Controls.Add(Me.PictureBox1)
		Me.Controls.Add(Me.picTitle)
		Me.Controls.Add(Me.txtPass)
		Me.Controls.Add(Me.txtUser)
		Me.Controls.Add(Me.lblPass)
		Me.Controls.Add(Me.lblUser)
		Me.Controls.Add(Me.btnCancel)
		Me.Controls.Add(Me.btnOk)
		Me.Name = "frmLogin"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Login"
		CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picTitle, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
   Friend WithEvents txtPass As System.Windows.Forms.TextBox
   Friend WithEvents txtUser As System.Windows.Forms.TextBox
   Friend WithEvents lblPass As System.Windows.Forms.Label
   Friend WithEvents lblUser As System.Windows.Forms.Label
   Friend WithEvents btnCancel As System.Windows.Forms.Button
   Friend WithEvents btnOk As System.Windows.Forms.Button
   Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
   Friend WithEvents picTitle As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents chkAr As System.Windows.Forms.CheckBox

End Class
