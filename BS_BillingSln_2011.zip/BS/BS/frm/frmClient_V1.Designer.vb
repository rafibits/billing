<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmClient_V1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpDetail = New System.Windows.Forms.GroupBox
        Me.lblClientType = New System.Windows.Forms.Label
        Me.cboClientType = New System.Windows.Forms.ComboBox
        Me.lblIATA = New System.Windows.Forms.Label
        Me.txtIATA = New System.Windows.Forms.TextBox
        Me.lblICAO = New System.Windows.Forms.Label
        Me.txtICAO = New System.Windows.Forms.TextBox
        Me.lblPercent = New System.Windows.Forms.Label
        Me.txtNote = New System.Windows.Forms.TextBox
        Me.lblDiscount = New System.Windows.Forms.Label
        Me.txtDiscount = New System.Windows.Forms.TextBox
        Me.lblNote = New System.Windows.Forms.Label
        Me.chkNatAirLines = New System.Windows.Forms.CheckBox
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.lblEmail = New System.Windows.Forms.Label
        Me.txtWebSite = New System.Windows.Forms.TextBox
        Me.lblWebsite = New System.Windows.Forms.Label
        Me.txtCel = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtFax = New System.Windows.Forms.TextBox
        Me.lblFax = New System.Windows.Forms.Label
        Me.txtExt = New System.Windows.Forms.TextBox
        Me.lblExt = New System.Windows.Forms.Label
        Me.lblTel = New System.Windows.Forms.Label
        Me.txtTel = New System.Windows.Forms.TextBox
        Me.lblContactName = New System.Windows.Forms.Label
        Me.txtContactName = New System.Windows.Forms.TextBox
        Me.btnGetSign = New System.Windows.Forms.Button
        Me.picPersonnel = New System.Windows.Forms.PictureBox
        Me.txtClientName = New System.Windows.Forms.TextBox
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtLocation = New System.Windows.Forms.TextBox
        Me.lblPersonnelNumber = New System.Windows.Forms.Label
        Me.txtID = New System.Windows.Forms.TextBox
        Me.txtClient = New System.Windows.Forms.TextBox
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.tcAddress = New System.Windows.Forms.TabControl
        Me.tpViewAddress = New System.Windows.Forms.TabPage
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSetting = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnEditAddress = New System.Windows.Forms.Button
        Me.btnDeleteAddress = New System.Windows.Forms.Button
        Me.btnNewAddress = New System.Windows.Forms.Button
        Me.grdViewAddress = New System.Windows.Forms.DataGridView
        Me.tpNewAddress = New System.Windows.Forms.TabPage
        Me.txtAddID = New System.Windows.Forms.TextBox
        Me.btnSaveAddress = New System.Windows.Forms.Button
        Me.btnCancelAddress = New System.Windows.Forms.Button
        Me.btnNewAddress2 = New System.Windows.Forms.Button
        Me.lblAddType = New System.Windows.Forms.Label
        Me.lblStreet = New System.Windows.Forms.Label
        Me.lblCity = New System.Windows.Forms.Label
        Me.lblArea = New System.Windows.Forms.Label
        Me.lblState = New System.Windows.Forms.Label
        Me.lblAddID = New System.Windows.Forms.Label
        Me.cboState = New System.Windows.Forms.ComboBox
        Me.cboAddType = New System.Windows.Forms.ComboBox
        Me.CboCity = New System.Windows.Forms.ComboBox
        Me.cboArea = New System.Windows.Forms.ComboBox
        Me.CboStreet = New System.Windows.Forms.ComboBox
        Me.lblBNF = New System.Windows.Forms.Label
        Me.txtBNF = New System.Windows.Forms.TextBox
        Me.fbdDataFile = New System.Windows.Forms.FolderBrowserDialog
        Me.OFDGetPhoto = New System.Windows.Forms.OpenFileDialog
        Me.lblCurrency = New System.Windows.Forms.Label
        Me.cboCurrency = New System.Windows.Forms.ComboBox
        Me.grpFinancialInfo = New System.Windows.Forms.GroupBox
        Me.txtPendingBalance = New System.Windows.Forms.TextBox
        Me.lblPendingBalance = New System.Windows.Forms.Label
        Me.txtBalance = New System.Windows.Forms.TextBox
        Me.lblBalance = New System.Windows.Forms.Label
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.grpDetail.SuspendLayout()
        CType(Me.picPersonnel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpButtons.SuspendLayout()
        Me.tcAddress.SuspendLayout()
        Me.tpViewAddress.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        CType(Me.grdViewAddress, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpNewAddress.SuspendLayout()
        Me.grpFinancialInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpDetail
        '
        Me.grpDetail.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpDetail.Controls.Add(Me.lblClientType)
        Me.grpDetail.Controls.Add(Me.cboClientType)
        Me.grpDetail.Controls.Add(Me.lblIATA)
        Me.grpDetail.Controls.Add(Me.txtIATA)
        Me.grpDetail.Controls.Add(Me.lblICAO)
        Me.grpDetail.Controls.Add(Me.txtICAO)
        Me.grpDetail.Controls.Add(Me.lblPercent)
        Me.grpDetail.Controls.Add(Me.txtNote)
        Me.grpDetail.Controls.Add(Me.lblDiscount)
        Me.grpDetail.Controls.Add(Me.txtDiscount)
        Me.grpDetail.Controls.Add(Me.lblNote)
        Me.grpDetail.Controls.Add(Me.chkNatAirLines)
        Me.grpDetail.Controls.Add(Me.txtEmail)
        Me.grpDetail.Controls.Add(Me.lblEmail)
        Me.grpDetail.Controls.Add(Me.txtWebSite)
        Me.grpDetail.Controls.Add(Me.lblWebsite)
        Me.grpDetail.Controls.Add(Me.txtCel)
        Me.grpDetail.Controls.Add(Me.Label1)
        Me.grpDetail.Controls.Add(Me.txtFax)
        Me.grpDetail.Controls.Add(Me.lblFax)
        Me.grpDetail.Controls.Add(Me.txtExt)
        Me.grpDetail.Controls.Add(Me.lblExt)
        Me.grpDetail.Controls.Add(Me.lblTel)
        Me.grpDetail.Controls.Add(Me.txtTel)
        Me.grpDetail.Controls.Add(Me.lblContactName)
        Me.grpDetail.Controls.Add(Me.txtContactName)
        Me.grpDetail.Controls.Add(Me.btnGetSign)
        Me.grpDetail.Controls.Add(Me.picPersonnel)
        Me.grpDetail.Controls.Add(Me.txtClientName)
        Me.grpDetail.Controls.Add(Me.Label4)
        Me.grpDetail.Controls.Add(Me.txtLocation)
        Me.grpDetail.Controls.Add(Me.lblPersonnelNumber)
        Me.grpDetail.Controls.Add(Me.txtID)
        Me.grpDetail.Controls.Add(Me.txtClient)
        Me.grpDetail.Location = New System.Drawing.Point(7, 48)
        Me.grpDetail.Name = "grpDetail"
        Me.grpDetail.Size = New System.Drawing.Size(914, 207)
        Me.grpDetail.TabIndex = 2
        Me.grpDetail.TabStop = False
        '
        'lblClientType
        '
        Me.lblClientType.AutoSize = True
        Me.lblClientType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClientType.ForeColor = System.Drawing.Color.Maroon
        Me.lblClientType.Location = New System.Drawing.Point(21, 98)
        Me.lblClientType.Name = "lblClientType"
        Me.lblClientType.Size = New System.Drawing.Size(76, 16)
        Me.lblClientType.TabIndex = 12
        Me.lblClientType.Text = "Client Type"
        Me.lblClientType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cboClientType
        '
        Me.cboClientType.FormattingEnabled = True
        Me.cboClientType.Location = New System.Drawing.Point(99, 92)
        Me.cboClientType.Name = "cboClientType"
        Me.cboClientType.Size = New System.Drawing.Size(256, 21)
        Me.cboClientType.TabIndex = 13
        '
        'lblIATA
        '
        Me.lblIATA.AutoSize = True
        Me.lblIATA.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIATA.ForeColor = System.Drawing.Color.Maroon
        Me.lblIATA.Location = New System.Drawing.Point(610, 13)
        Me.lblIATA.Name = "lblIATA"
        Me.lblIATA.Size = New System.Drawing.Size(38, 16)
        Me.lblIATA.TabIndex = 6
        Me.lblIATA.Text = "IATA"
        Me.lblIATA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtIATA
        '
        Me.txtIATA.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIATA.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtIATA.Location = New System.Drawing.Point(571, 36)
        Me.txtIATA.Name = "txtIATA"
        Me.txtIATA.Size = New System.Drawing.Size(119, 22)
        Me.txtIATA.TabIndex = 7
        '
        'lblICAO
        '
        Me.lblICAO.AutoSize = True
        Me.lblICAO.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblICAO.ForeColor = System.Drawing.Color.Maroon
        Me.lblICAO.Location = New System.Drawing.Point(473, 13)
        Me.lblICAO.Name = "lblICAO"
        Me.lblICAO.Size = New System.Drawing.Size(39, 16)
        Me.lblICAO.TabIndex = 4
        Me.lblICAO.Text = "ICAO"
        Me.lblICAO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtICAO
        '
        Me.txtICAO.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtICAO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtICAO.Location = New System.Drawing.Point(429, 36)
        Me.txtICAO.Name = "txtICAO"
        Me.txtICAO.Size = New System.Drawing.Size(121, 22)
        Me.txtICAO.TabIndex = 5
        '
        'lblPercent
        '
        Me.lblPercent.AutoSize = True
        Me.lblPercent.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPercent.ForeColor = System.Drawing.Color.Maroon
        Me.lblPercent.Location = New System.Drawing.Point(531, 124)
        Me.lblPercent.Name = "lblPercent"
        Me.lblPercent.Size = New System.Drawing.Size(15, 13)
        Me.lblPercent.TabIndex = 22
        Me.lblPercent.Text = "%"
        Me.lblPercent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblPercent.Visible = False
        '
        'txtNote
        '
        Me.txtNote.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNote.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtNote.Location = New System.Drawing.Point(101, 175)
        Me.txtNote.Name = "txtNote"
        Me.txtNote.Size = New System.Drawing.Size(589, 22)
        Me.txtNote.TabIndex = 29
        '
        'lblDiscount
        '
        Me.lblDiscount.AutoSize = True
        Me.lblDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiscount.ForeColor = System.Drawing.Color.Maroon
        Me.lblDiscount.Location = New System.Drawing.Point(369, 122)
        Me.lblDiscount.Name = "lblDiscount"
        Me.lblDiscount.Size = New System.Drawing.Size(55, 15)
        Me.lblDiscount.TabIndex = 20
        Me.lblDiscount.Text = "Discount"
        Me.lblDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblDiscount.Visible = False
        '
        'txtDiscount
        '
        Me.txtDiscount.AcceptsReturn = True
        Me.txtDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDiscount.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtDiscount.Location = New System.Drawing.Point(429, 121)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(98, 20)
        Me.txtDiscount.TabIndex = 21
        Me.txtDiscount.Visible = False
        '
        'lblNote
        '
        Me.lblNote.AutoSize = True
        Me.lblNote.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNote.ForeColor = System.Drawing.Color.Maroon
        Me.lblNote.Location = New System.Drawing.Point(58, 178)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(37, 16)
        Me.lblNote.TabIndex = 28
        Me.lblNote.Text = "Note"
        Me.lblNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkNatAirLines
        '
        Me.chkNatAirLines.AutoSize = True
        Me.chkNatAirLines.Location = New System.Drawing.Point(572, 123)
        Me.chkNatAirLines.Name = "chkNatAirLines"
        Me.chkNatAirLines.Size = New System.Drawing.Size(120, 17)
        Me.chkNatAirLines.TabIndex = 23
        Me.chkNatAirLines.Text = "National Companies"
        Me.chkNatAirLines.UseVisualStyleBackColor = True
        '
        'txtEmail
        '
        Me.txtEmail.BackColor = System.Drawing.Color.LightYellow
        Me.txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtEmail.Location = New System.Drawing.Point(99, 147)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(256, 22)
        Me.txtEmail.TabIndex = 25
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.ForeColor = System.Drawing.Color.Maroon
        Me.lblEmail.Location = New System.Drawing.Point(55, 151)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(42, 16)
        Me.lblEmail.TabIndex = 24
        Me.lblEmail.Text = "Email"
        Me.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtWebSite
        '
        Me.txtWebSite.BackColor = System.Drawing.Color.LightYellow
        Me.txtWebSite.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWebSite.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtWebSite.Location = New System.Drawing.Point(429, 145)
        Me.txtWebSite.Name = "txtWebSite"
        Me.txtWebSite.Size = New System.Drawing.Size(261, 22)
        Me.txtWebSite.TabIndex = 27
        '
        'lblWebsite
        '
        Me.lblWebsite.AutoSize = True
        Me.lblWebsite.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWebsite.ForeColor = System.Drawing.Color.Maroon
        Me.lblWebsite.Location = New System.Drawing.Point(364, 148)
        Me.lblWebsite.Name = "lblWebsite"
        Me.lblWebsite.Size = New System.Drawing.Size(60, 16)
        Me.lblWebsite.TabIndex = 26
        Me.lblWebsite.Text = "WebSite"
        Me.lblWebsite.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtCel
        '
        Me.txtCel.AcceptsReturn = True
        Me.txtCel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCel.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtCel.Location = New System.Drawing.Point(429, 64)
        Me.txtCel.Name = "txtCel"
        Me.txtCel.Size = New System.Drawing.Size(262, 22)
        Me.txtCel.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Maroon
        Me.Label1.Location = New System.Drawing.Point(393, 70)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(31, 16)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Cell"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtFax
        '
        Me.txtFax.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFax.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtFax.Location = New System.Drawing.Point(429, 92)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(262, 22)
        Me.txtFax.TabIndex = 15
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFax.ForeColor = System.Drawing.Color.Maroon
        Me.lblFax.Location = New System.Drawing.Point(394, 94)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(30, 16)
        Me.lblFax.TabIndex = 14
        Me.lblFax.Text = "Fax"
        Me.lblFax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtExt
        '
        Me.txtExt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtExt.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtExt.Location = New System.Drawing.Point(273, 119)
        Me.txtExt.Name = "txtExt"
        Me.txtExt.Size = New System.Drawing.Size(82, 22)
        Me.txtExt.TabIndex = 19
        '
        'lblExt
        '
        Me.lblExt.AutoSize = True
        Me.lblExt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblExt.ForeColor = System.Drawing.Color.Maroon
        Me.lblExt.Location = New System.Drawing.Point(240, 120)
        Me.lblExt.Name = "lblExt"
        Me.lblExt.Size = New System.Drawing.Size(26, 16)
        Me.lblExt.TabIndex = 18
        Me.lblExt.Text = "Ext"
        Me.lblExt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTel
        '
        Me.lblTel.AutoSize = True
        Me.lblTel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTel.ForeColor = System.Drawing.Color.Maroon
        Me.lblTel.Location = New System.Drawing.Point(69, 120)
        Me.lblTel.Name = "lblTel"
        Me.lblTel.Size = New System.Drawing.Size(28, 16)
        Me.lblTel.TabIndex = 16
        Me.lblTel.Text = "Tel"
        Me.lblTel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTel
        '
        Me.txtTel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTel.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtTel.Location = New System.Drawing.Point(99, 119)
        Me.txtTel.Name = "txtTel"
        Me.txtTel.Size = New System.Drawing.Size(137, 22)
        Me.txtTel.TabIndex = 17
        '
        'lblContactName
        '
        Me.lblContactName.AutoSize = True
        Me.lblContactName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContactName.ForeColor = System.Drawing.Color.Maroon
        Me.lblContactName.Location = New System.Drawing.Point(4, 67)
        Me.lblContactName.Name = "lblContactName"
        Me.lblContactName.Size = New System.Drawing.Size(93, 16)
        Me.lblContactName.TabIndex = 8
        Me.lblContactName.Text = "Contact Name"
        Me.lblContactName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtContactName
        '
        Me.txtContactName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtContactName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtContactName.Location = New System.Drawing.Point(99, 64)
        Me.txtContactName.Name = "txtContactName"
        Me.txtContactName.Size = New System.Drawing.Size(256, 22)
        Me.txtContactName.TabIndex = 9
        '
        'btnGetSign
        '
        Me.btnGetSign.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnGetSign.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGetSign.Font = New System.Drawing.Font("Georgia", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetSign.ForeColor = System.Drawing.Color.Black
        Me.btnGetSign.Location = New System.Drawing.Point(794, 175)
        Me.btnGetSign.Name = "btnGetSign"
        Me.btnGetSign.Size = New System.Drawing.Size(115, 26)
        Me.btnGetSign.TabIndex = 30
        Me.btnGetSign.Text = "Get Sign"
        Me.btnGetSign.UseVisualStyleBackColor = True
        '
        'picPersonnel
        '
        Me.picPersonnel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picPersonnel.BackColor = System.Drawing.Color.Wheat
        Me.picPersonnel.Location = New System.Drawing.Point(794, 37)
        Me.picPersonnel.Name = "picPersonnel"
        Me.picPersonnel.Size = New System.Drawing.Size(115, 137)
        Me.picPersonnel.TabIndex = 133
        Me.picPersonnel.TabStop = False
        '
        'txtClientName
        '
        Me.txtClientName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtClientName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtClientName.Location = New System.Drawing.Point(99, 36)
        Me.txtClientName.Name = "txtClientName"
        Me.txtClientName.Size = New System.Drawing.Size(256, 22)
        Me.txtClientName.TabIndex = 3
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(852, 9)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(67, 23)
        Me.btnDataErr.TabIndex = 31
        Me.btnDataErr.Text = "Error"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Maroon
        Me.Label4.Location = New System.Drawing.Point(101, 13)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Client Name"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtLocation
        '
        Me.txtLocation.Location = New System.Drawing.Point(426, -23)
        Me.txtLocation.Name = "txtLocation"
        Me.txtLocation.Size = New System.Drawing.Size(40, 20)
        Me.txtLocation.TabIndex = 130
        '
        'lblPersonnelNumber
        '
        Me.lblPersonnelNumber.AutoSize = True
        Me.lblPersonnelNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPersonnelNumber.ForeColor = System.Drawing.Color.Maroon
        Me.lblPersonnelNumber.Location = New System.Drawing.Point(7, 13)
        Me.lblPersonnelNumber.Name = "lblPersonnelNumber"
        Me.lblPersonnelNumber.Size = New System.Drawing.Size(72, 16)
        Me.lblPersonnelNumber.TabIndex = 0
        Me.lblPersonnelNumber.Text = "Client Num"
        Me.lblPersonnelNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.Color.Tan
        Me.txtID.Enabled = False
        Me.txtID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtID.ForeColor = System.Drawing.Color.White
        Me.txtID.Location = New System.Drawing.Point(93, -27)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(62, 22)
        Me.txtID.TabIndex = 129
        Me.txtID.TabStop = False
        Me.txtID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtClient
        '
        Me.txtClient.BackColor = System.Drawing.Color.Maroon
        Me.txtClient.Enabled = False
        Me.txtClient.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtClient.ForeColor = System.Drawing.Color.White
        Me.txtClient.Location = New System.Drawing.Point(12, 36)
        Me.txtClient.Name = "txtClient"
        Me.txtClient.ReadOnly = True
        Me.txtClient.Size = New System.Drawing.Size(83, 22)
        Me.txtClient.TabIndex = 1
        Me.txtClient.TabStop = False
        Me.txtClient.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(663, 12)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(190, 17)
        Me.lstDataErr.TabIndex = 32
        Me.lstDataErr.Visible = False
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Location = New System.Drawing.Point(7, 466)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(914, 45)
        Me.grpButtons.TabIndex = 5
        Me.grpButtons.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.Location = New System.Drawing.Point(803, 11)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(105, 28)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnSave.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.Location = New System.Drawing.Point(6, 11)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(105, 28)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Edit"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCancel.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Location = New System.Drawing.Point(119, 11)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(105, 28)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNew.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.Location = New System.Drawing.Point(6, 11)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(105, 28)
        Me.btnNew.TabIndex = 0
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'tcAddress
        '
        Me.tcAddress.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tcAddress.Controls.Add(Me.tpViewAddress)
        Me.tcAddress.Controls.Add(Me.tpNewAddress)
        Me.tcAddress.Location = New System.Drawing.Point(7, 292)
        Me.tcAddress.Name = "tcAddress"
        Me.tcAddress.SelectedIndex = 0
        Me.tcAddress.Size = New System.Drawing.Size(914, 175)
        Me.tcAddress.TabIndex = 4
        '
        'tpViewAddress
        '
        Me.tpViewAddress.Controls.Add(Me.btnShowCol)
        Me.tpViewAddress.Controls.Add(Me.grpShowHideColumns)
        Me.tpViewAddress.Controls.Add(Me.btnEditAddress)
        Me.tpViewAddress.Controls.Add(Me.btnDeleteAddress)
        Me.tpViewAddress.Controls.Add(Me.btnNewAddress)
        Me.tpViewAddress.Controls.Add(Me.grdViewAddress)
        Me.tpViewAddress.Location = New System.Drawing.Point(4, 22)
        Me.tpViewAddress.Name = "tpViewAddress"
        Me.tpViewAddress.Padding = New System.Windows.Forms.Padding(3)
        Me.tpViewAddress.Size = New System.Drawing.Size(906, 149)
        Me.tpViewAddress.TabIndex = 0
        Me.tpViewAddress.Text = "Address"
        Me.tpViewAddress.UseVisualStyleBackColor = True
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(7, 7)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 0
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSetting)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(45, 7)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 136)
        Me.grpShowHideColumns.TabIndex = 1
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSetting
        '
        Me.btnSaveSetting.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSetting.Location = New System.Drawing.Point(7, 107)
        Me.btnSaveSetting.Name = "btnSaveSetting"
        Me.btnSaveSetting.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSetting.TabIndex = 1
        Me.btnSaveSetting.Text = "Save Settings"
        Me.btnSaveSetting.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(3, 15)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 64)
        Me.chkLstGridCol.TabIndex = 0
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnEditAddress
        '
        Me.btnEditAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEditAddress.ForeColor = System.Drawing.Color.Navy
        Me.btnEditAddress.Location = New System.Drawing.Point(833, 73)
        Me.btnEditAddress.Name = "btnEditAddress"
        Me.btnEditAddress.Size = New System.Drawing.Size(66, 23)
        Me.btnEditAddress.TabIndex = 4
        Me.btnEditAddress.Text = "Edit "
        Me.btnEditAddress.UseVisualStyleBackColor = True
        '
        'btnDeleteAddress
        '
        Me.btnDeleteAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDeleteAddress.ForeColor = System.Drawing.Color.Navy
        Me.btnDeleteAddress.Location = New System.Drawing.Point(556, 165)
        Me.btnDeleteAddress.Name = "btnDeleteAddress"
        Me.btnDeleteAddress.Size = New System.Drawing.Size(64, 23)
        Me.btnDeleteAddress.TabIndex = 2
        Me.btnDeleteAddress.Text = "Delete "
        Me.btnDeleteAddress.UseVisualStyleBackColor = True
        '
        'btnNewAddress
        '
        Me.btnNewAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNewAddress.ForeColor = System.Drawing.Color.Navy
        Me.btnNewAddress.Location = New System.Drawing.Point(832, 37)
        Me.btnNewAddress.Name = "btnNewAddress"
        Me.btnNewAddress.Size = New System.Drawing.Size(67, 23)
        Me.btnNewAddress.TabIndex = 3
        Me.btnNewAddress.Text = "New "
        Me.btnNewAddress.UseVisualStyleBackColor = True
        '
        'grdViewAddress
        '
        Me.grdViewAddress.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdViewAddress.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdViewAddress.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdViewAddress.Location = New System.Drawing.Point(5, 6)
        Me.grdViewAddress.Name = "grdViewAddress"
        Me.grdViewAddress.Size = New System.Drawing.Size(822, 143)
        Me.grdViewAddress.TabIndex = 0
        '
        'tpNewAddress
        '
        Me.tpNewAddress.Controls.Add(Me.txtAddID)
        Me.tpNewAddress.Controls.Add(Me.btnSaveAddress)
        Me.tpNewAddress.Controls.Add(Me.btnCancelAddress)
        Me.tpNewAddress.Controls.Add(Me.btnNewAddress2)
        Me.tpNewAddress.Controls.Add(Me.lblAddType)
        Me.tpNewAddress.Controls.Add(Me.lblStreet)
        Me.tpNewAddress.Controls.Add(Me.lblCity)
        Me.tpNewAddress.Controls.Add(Me.lblArea)
        Me.tpNewAddress.Controls.Add(Me.lblState)
        Me.tpNewAddress.Controls.Add(Me.lblAddID)
        Me.tpNewAddress.Controls.Add(Me.cboState)
        Me.tpNewAddress.Controls.Add(Me.cboAddType)
        Me.tpNewAddress.Controls.Add(Me.CboCity)
        Me.tpNewAddress.Controls.Add(Me.cboArea)
        Me.tpNewAddress.Controls.Add(Me.CboStreet)
        Me.tpNewAddress.Controls.Add(Me.lblBNF)
        Me.tpNewAddress.Controls.Add(Me.txtBNF)
        Me.tpNewAddress.Location = New System.Drawing.Point(4, 22)
        Me.tpNewAddress.Name = "tpNewAddress"
        Me.tpNewAddress.Padding = New System.Windows.Forms.Padding(3)
        Me.tpNewAddress.Size = New System.Drawing.Size(906, 149)
        Me.tpNewAddress.TabIndex = 1
        Me.tpNewAddress.Text = "NewAddress"
        Me.tpNewAddress.UseVisualStyleBackColor = True
        '
        'txtAddID
        '
        Me.txtAddID.Location = New System.Drawing.Point(119, 16)
        Me.txtAddID.Name = "txtAddID"
        Me.txtAddID.ReadOnly = True
        Me.txtAddID.Size = New System.Drawing.Size(100, 20)
        Me.txtAddID.TabIndex = 49
        '
        'btnSaveAddress
        '
        Me.btnSaveAddress.Location = New System.Drawing.Point(585, 59)
        Me.btnSaveAddress.Name = "btnSaveAddress"
        Me.btnSaveAddress.Size = New System.Drawing.Size(66, 23)
        Me.btnSaveAddress.TabIndex = 48
        Me.btnSaveAddress.Text = "Save "
        Me.btnSaveAddress.UseVisualStyleBackColor = True
        '
        'btnCancelAddress
        '
        Me.btnCancelAddress.Location = New System.Drawing.Point(585, 86)
        Me.btnCancelAddress.Name = "btnCancelAddress"
        Me.btnCancelAddress.Size = New System.Drawing.Size(66, 23)
        Me.btnCancelAddress.TabIndex = 47
        Me.btnCancelAddress.Text = "Cancel "
        Me.btnCancelAddress.UseVisualStyleBackColor = True
        '
        'btnNewAddress2
        '
        Me.btnNewAddress2.Location = New System.Drawing.Point(585, 32)
        Me.btnNewAddress2.Name = "btnNewAddress2"
        Me.btnNewAddress2.Size = New System.Drawing.Size(67, 23)
        Me.btnNewAddress2.TabIndex = 46
        Me.btnNewAddress2.Text = "New "
        Me.btnNewAddress2.UseVisualStyleBackColor = True
        Me.btnNewAddress2.Visible = False
        '
        'lblAddType
        '
        Me.lblAddType.AutoSize = True
        Me.lblAddType.Location = New System.Drawing.Point(288, 19)
        Me.lblAddType.Name = "lblAddType"
        Me.lblAddType.Size = New System.Drawing.Size(73, 13)
        Me.lblAddType.TabIndex = 45
        Me.lblAddType.Text = "Address Type"
        '
        'lblStreet
        '
        Me.lblStreet.AutoSize = True
        Me.lblStreet.Location = New System.Drawing.Point(325, 81)
        Me.lblStreet.Name = "lblStreet"
        Me.lblStreet.Size = New System.Drawing.Size(37, 13)
        Me.lblStreet.TabIndex = 44
        Me.lblStreet.Text = "Street"
        '
        'lblCity
        '
        Me.lblCity.AutoSize = True
        Me.lblCity.Location = New System.Drawing.Point(78, 80)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(26, 13)
        Me.lblCity.TabIndex = 43
        Me.lblCity.Text = "City"
        '
        'lblArea
        '
        Me.lblArea.AutoSize = True
        Me.lblArea.Location = New System.Drawing.Point(331, 50)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(30, 13)
        Me.lblArea.TabIndex = 42
        Me.lblArea.Text = "Area"
        '
        'lblState
        '
        Me.lblState.AutoSize = True
        Me.lblState.Location = New System.Drawing.Point(71, 48)
        Me.lblState.Name = "lblState"
        Me.lblState.Size = New System.Drawing.Size(46, 13)
        Me.lblState.TabIndex = 39
        Me.lblState.Text = "Country"
        '
        'lblAddID
        '
        Me.lblAddID.AutoSize = True
        Me.lblAddID.Location = New System.Drawing.Point(44, 18)
        Me.lblAddID.Name = "lblAddID"
        Me.lblAddID.Size = New System.Drawing.Size(60, 13)
        Me.lblAddID.TabIndex = 38
        Me.lblAddID.Text = "Address ID"
        '
        'cboState
        '
        Me.cboState.FormattingEnabled = True
        Me.cboState.Location = New System.Drawing.Point(119, 47)
        Me.cboState.Name = "cboState"
        Me.cboState.Size = New System.Drawing.Size(163, 21)
        Me.cboState.TabIndex = 2
        '
        'cboAddType
        '
        Me.cboAddType.FormattingEnabled = True
        Me.cboAddType.Location = New System.Drawing.Point(376, 16)
        Me.cboAddType.Name = "cboAddType"
        Me.cboAddType.Size = New System.Drawing.Size(163, 21)
        Me.cboAddType.TabIndex = 1
        '
        'CboCity
        '
        Me.CboCity.FormattingEnabled = True
        Me.CboCity.Location = New System.Drawing.Point(119, 77)
        Me.CboCity.Name = "CboCity"
        Me.CboCity.Size = New System.Drawing.Size(163, 21)
        Me.CboCity.TabIndex = 5
        '
        'cboArea
        '
        Me.cboArea.FormattingEnabled = True
        Me.cboArea.Location = New System.Drawing.Point(376, 47)
        Me.cboArea.Name = "cboArea"
        Me.cboArea.Size = New System.Drawing.Size(163, 21)
        Me.cboArea.TabIndex = 6
        '
        'CboStreet
        '
        Me.CboStreet.FormattingEnabled = True
        Me.CboStreet.Location = New System.Drawing.Point(376, 78)
        Me.CboStreet.Name = "CboStreet"
        Me.CboStreet.Size = New System.Drawing.Size(163, 21)
        Me.CboStreet.TabIndex = 7
        '
        'lblBNF
        '
        Me.lblBNF.AutoSize = True
        Me.lblBNF.Location = New System.Drawing.Point(12, 113)
        Me.lblBNF.Name = "lblBNF"
        Me.lblBNF.Size = New System.Drawing.Size(92, 13)
        Me.lblBNF.TabIndex = 7
        Me.lblBNF.Text = "Building And Floor"
        '
        'txtBNF
        '
        Me.txtBNF.Location = New System.Drawing.Point(118, 110)
        Me.txtBNF.Name = "txtBNF"
        Me.txtBNF.Size = New System.Drawing.Size(421, 20)
        Me.txtBNF.TabIndex = 8
        '
        'OFDGetPhoto
        '
        Me.OFDGetPhoto.FileName = "OFDGetPhoto"
        '
        'lblCurrency
        '
        Me.lblCurrency.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblCurrency.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrency.ForeColor = System.Drawing.Color.Tomato
        Me.lblCurrency.Location = New System.Drawing.Point(445, 13)
        Me.lblCurrency.Name = "lblCurrency"
        Me.lblCurrency.Size = New System.Drawing.Size(56, 19)
        Me.lblCurrency.TabIndex = 4
        Me.lblCurrency.Text = "Currency"
        Me.lblCurrency.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboCurrency
        '
        Me.cboCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCurrency.Enabled = False
        Me.cboCurrency.FormattingEnabled = True
        Me.cboCurrency.Location = New System.Drawing.Point(520, 11)
        Me.cboCurrency.Name = "cboCurrency"
        Me.cboCurrency.Size = New System.Drawing.Size(49, 21)
        Me.cboCurrency.TabIndex = 5
        '
        'grpFinancialInfo
        '
        Me.grpFinancialInfo.Controls.Add(Me.lblCurrency)
        Me.grpFinancialInfo.Controls.Add(Me.txtPendingBalance)
        Me.grpFinancialInfo.Controls.Add(Me.cboCurrency)
        Me.grpFinancialInfo.Controls.Add(Me.lblPendingBalance)
        Me.grpFinancialInfo.Controls.Add(Me.txtBalance)
        Me.grpFinancialInfo.Controls.Add(Me.lblBalance)
        Me.grpFinancialInfo.Location = New System.Drawing.Point(8, 251)
        Me.grpFinancialInfo.Name = "grpFinancialInfo"
        Me.grpFinancialInfo.Size = New System.Drawing.Size(575, 36)
        Me.grpFinancialInfo.TabIndex = 3
        Me.grpFinancialInfo.TabStop = False
        '
        'txtPendingBalance
        '
        Me.txtPendingBalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPendingBalance.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtPendingBalance.Location = New System.Drawing.Point(307, 12)
        Me.txtPendingBalance.Name = "txtPendingBalance"
        Me.txtPendingBalance.ReadOnly = True
        Me.txtPendingBalance.Size = New System.Drawing.Size(113, 20)
        Me.txtPendingBalance.TabIndex = 3
        Me.txtPendingBalance.TabStop = False
        '
        'lblPendingBalance
        '
        Me.lblPendingBalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPendingBalance.ForeColor = System.Drawing.Color.Maroon
        Me.lblPendingBalance.Location = New System.Drawing.Point(217, 11)
        Me.lblPendingBalance.Name = "lblPendingBalance"
        Me.lblPendingBalance.Size = New System.Drawing.Size(84, 20)
        Me.lblPendingBalance.TabIndex = 2
        Me.lblPendingBalance.Text = "Pending.B"
        Me.lblPendingBalance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtBalance
        '
        Me.txtBalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBalance.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.txtBalance.Location = New System.Drawing.Point(101, 11)
        Me.txtBalance.Name = "txtBalance"
        Me.txtBalance.ReadOnly = True
        Me.txtBalance.Size = New System.Drawing.Size(109, 20)
        Me.txtBalance.TabIndex = 1
        Me.txtBalance.TabStop = False
        '
        'lblBalance
        '
        Me.lblBalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBalance.ForeColor = System.Drawing.Color.Maroon
        Me.lblBalance.Location = New System.Drawing.Point(18, 7)
        Me.lblBalance.Name = "lblBalance"
        Me.lblBalance.Size = New System.Drawing.Size(61, 20)
        Me.lblBalance.TabIndex = 0
        Me.lblBalance.Text = "Balance"
        Me.lblBalance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(934, 3)
        Me.pnlTitle.TabIndex = 1
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(934, 40)
        Me.lblfrmTitle.TabIndex = 0
        Me.lblfrmTitle.Text = " Client"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmClient_V1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(934, 514)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.grpFinancialInfo)
        Me.Controls.Add(Me.grpDetail)
        Me.Controls.Add(Me.tcAddress)
        Me.Controls.Add(Me.grpButtons)
        Me.Name = "frmClient_V1"
        Me.Text = "Client"
        Me.grpDetail.ResumeLayout(False)
        Me.grpDetail.PerformLayout()
        CType(Me.picPersonnel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpButtons.ResumeLayout(False)
        Me.tcAddress.ResumeLayout(False)
        Me.tpViewAddress.ResumeLayout(False)
        Me.grpShowHideColumns.ResumeLayout(False)
        CType(Me.grdViewAddress, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpNewAddress.ResumeLayout(False)
        Me.tpNewAddress.PerformLayout()
        Me.grpFinancialInfo.ResumeLayout(False)
        Me.grpFinancialInfo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnNew As BHBut.BouncingHoverButton
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
	Friend WithEvents btnSave As BHBut.BouncingHoverButton
	Friend WithEvents btnCancel As BHBut.BouncingHoverButton
	Friend WithEvents grpDetail As System.Windows.Forms.GroupBox
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents txtClientName As System.Windows.Forms.TextBox
	Friend WithEvents txtClient As System.Windows.Forms.TextBox
	Friend WithEvents lblPersonnelNumber As System.Windows.Forms.Label
	Friend WithEvents txtID As System.Windows.Forms.TextBox
	Friend WithEvents btnDataErr As System.Windows.Forms.Button
	Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
	Friend WithEvents txtLocation As System.Windows.Forms.TextBox
	Friend WithEvents tcAddress As System.Windows.Forms.TabControl
	Friend WithEvents tpViewAddress As System.Windows.Forms.TabPage
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSetting As System.Windows.Forms.Button
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
   Friend WithEvents btnEditAddress As System.Windows.Forms.Button
	Friend WithEvents btnDeleteAddress As System.Windows.Forms.Button
	Friend WithEvents btnNewAddress As System.Windows.Forms.Button
	Friend WithEvents grdViewAddress As System.Windows.Forms.DataGridView
	Friend WithEvents tpNewAddress As System.Windows.Forms.TabPage
	Friend WithEvents txtAddID As System.Windows.Forms.TextBox
	Friend WithEvents btnSaveAddress As System.Windows.Forms.Button
	Friend WithEvents btnCancelAddress As System.Windows.Forms.Button
	Friend WithEvents btnNewAddress2 As System.Windows.Forms.Button
	Friend WithEvents lblAddType As System.Windows.Forms.Label
	Friend WithEvents lblStreet As System.Windows.Forms.Label
	Friend WithEvents lblCity As System.Windows.Forms.Label
	Friend WithEvents lblArea As System.Windows.Forms.Label
	Friend WithEvents lblState As System.Windows.Forms.Label
	Friend WithEvents lblAddID As System.Windows.Forms.Label
	Friend WithEvents cboState As System.Windows.Forms.ComboBox
	Friend WithEvents cboAddType As System.Windows.Forms.ComboBox
	Friend WithEvents CboCity As System.Windows.Forms.ComboBox
	Friend WithEvents cboArea As System.Windows.Forms.ComboBox
	Friend WithEvents CboStreet As System.Windows.Forms.ComboBox
	Friend WithEvents lblBNF As System.Windows.Forms.Label
	Friend WithEvents txtBNF As System.Windows.Forms.TextBox
	Friend WithEvents fbdDataFile As System.Windows.Forms.FolderBrowserDialog
	Friend WithEvents btnGetSign As System.Windows.Forms.Button
	Friend WithEvents picPersonnel As System.Windows.Forms.PictureBox
	Friend WithEvents OFDGetPhoto As System.Windows.Forms.OpenFileDialog
	Friend WithEvents lblTel As System.Windows.Forms.Label
	Friend WithEvents txtTel As System.Windows.Forms.TextBox
	Friend WithEvents lblContactName As System.Windows.Forms.Label
	Friend WithEvents txtContactName As System.Windows.Forms.TextBox
	Friend WithEvents lblExt As System.Windows.Forms.Label
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents txtFax As System.Windows.Forms.TextBox
	Friend WithEvents lblFax As System.Windows.Forms.Label
	Friend WithEvents txtExt As System.Windows.Forms.TextBox
	Friend WithEvents txtEmail As System.Windows.Forms.TextBox
	Friend WithEvents lblEmail As System.Windows.Forms.Label
	Friend WithEvents txtWebSite As System.Windows.Forms.TextBox
	Friend WithEvents lblWebsite As System.Windows.Forms.Label
	Friend WithEvents txtCel As System.Windows.Forms.TextBox
	Friend WithEvents lblNote As System.Windows.Forms.Label
	Friend WithEvents txtNote As System.Windows.Forms.TextBox
	Friend WithEvents chkNatAirLines As System.Windows.Forms.CheckBox
	Friend WithEvents lblPercent As System.Windows.Forms.Label
	Friend WithEvents txtDiscount As System.Windows.Forms.TextBox
	Friend WithEvents lblDiscount As System.Windows.Forms.Label
	Friend WithEvents lblCurrency As System.Windows.Forms.Label
	Friend WithEvents cboCurrency As System.Windows.Forms.ComboBox
	Friend WithEvents grpFinancialInfo As System.Windows.Forms.GroupBox
	Friend WithEvents txtPendingBalance As System.Windows.Forms.TextBox
	Friend WithEvents lblPendingBalance As System.Windows.Forms.Label
	Friend WithEvents txtBalance As System.Windows.Forms.TextBox
	Friend WithEvents lblBalance As System.Windows.Forms.Label
	Friend WithEvents lblIATA As System.Windows.Forms.Label
	Friend WithEvents txtIATA As System.Windows.Forms.TextBox
	Friend WithEvents lblICAO As System.Windows.Forms.Label
	Friend WithEvents txtICAO As System.Windows.Forms.TextBox
	Friend WithEvents pnlTitle As System.Windows.Forms.Panel
   Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
    Friend WithEvents btnShowCol As System.Windows.Forms.Button
    Friend WithEvents lblClientType As System.Windows.Forms.Label
    Friend WithEvents cboClientType As System.Windows.Forms.ComboBox
End Class
