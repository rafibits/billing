<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmService
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.grpService = New System.Windows.Forms.GroupBox
        Me.lblServiceName = New System.Windows.Forms.Label
        Me.txtServiceName = New System.Windows.Forms.TextBox
        Me.txtServiceID = New System.Windows.Forms.TextBox
        Me.txtCode = New System.Windows.Forms.TextBox
        Me.lblCode = New System.Windows.Forms.Label
        Me.grpPrice = New System.Windows.Forms.GroupBox
        Me.CboAdditionalChargeUnit = New System.Windows.Forms.ComboBox
        Me.CboSubCategory = New System.Windows.Forms.ComboBox
        Me.txtAdditionalCharge = New System.Windows.Forms.TextBox
        Me.CboServiceType = New System.Windows.Forms.ComboBox
        Me.lblAdditionalCharge = New System.Windows.Forms.Label
        Me.CboCategory = New System.Windows.Forms.ComboBox
        Me.lblAdditionalChargeUnit = New System.Windows.Forms.Label
        Me.lblPercent = New System.Windows.Forms.Label
        Me.txtPrice = New System.Windows.Forms.TextBox
        Me.CboPriceUnit = New System.Windows.Forms.ComboBox
        Me.lblSubCategory = New System.Windows.Forms.Label
        Me.lblPrice = New System.Windows.Forms.Label
        Me.lblType = New System.Windows.Forms.Label
        Me.lblPriceUnit = New System.Windows.Forms.Label
        Me.txtVAT = New System.Windows.Forms.TextBox
        Me.lblCategory = New System.Windows.Forms.Label
        Me.lblVAT = New System.Windows.Forms.Label
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.grpService.SuspendLayout()
        Me.grpPrice.SuspendLayout()
        Me.grpButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(575, 11)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(56, 23)
        Me.btnDataErr.TabIndex = 4
        Me.btnDataErr.Text = " E r r o r"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(352, 17)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(223, 17)
        Me.lstDataErr.TabIndex = 5
        Me.lstDataErr.Visible = False
        '
        'grpService
        '
        Me.grpService.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpService.BackColor = System.Drawing.Color.Lavender
        Me.grpService.Controls.Add(Me.lblServiceName)
        Me.grpService.Controls.Add(Me.txtServiceName)
        Me.grpService.Controls.Add(Me.txtServiceID)
        Me.grpService.Controls.Add(Me.txtCode)
        Me.grpService.Controls.Add(Me.lblCode)
        Me.grpService.Location = New System.Drawing.Point(12, 59)
        Me.grpService.Name = "grpService"
        Me.grpService.Size = New System.Drawing.Size(634, 60)
        Me.grpService.TabIndex = 0
        Me.grpService.TabStop = False
        '
        'lblServiceName
        '
        Me.lblServiceName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblServiceName.ForeColor = System.Drawing.Color.Maroon
        Me.lblServiceName.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblServiceName.Location = New System.Drawing.Point(6, 21)
        Me.lblServiceName.Name = "lblServiceName"
        Me.lblServiceName.Size = New System.Drawing.Size(85, 20)
        Me.lblServiceName.TabIndex = 0
        Me.lblServiceName.Text = "Service Name"
        Me.lblServiceName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtServiceName
        '
        Me.txtServiceName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtServiceName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.txtServiceName.ForeColor = System.Drawing.Color.Maroon
        Me.txtServiceName.Location = New System.Drawing.Point(94, 20)
        Me.txtServiceName.Name = "txtServiceName"
        Me.txtServiceName.Size = New System.Drawing.Size(237, 22)
        Me.txtServiceName.TabIndex = 1
        '
        'txtServiceID
        '
        Me.txtServiceID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtServiceID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.txtServiceID.ForeColor = System.Drawing.Color.Red
        Me.txtServiceID.Location = New System.Drawing.Point(106, 20)
        Me.txtServiceID.Name = "txtServiceID"
        Me.txtServiceID.ReadOnly = True
        Me.txtServiceID.Size = New System.Drawing.Size(47, 22)
        Me.txtServiceID.TabIndex = 4
        '
        'txtCode
        '
        Me.txtCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.txtCode.ForeColor = System.Drawing.Color.Maroon
        Me.txtCode.Location = New System.Drawing.Point(386, 20)
        Me.txtCode.MaxLength = 10
        Me.txtCode.Name = "txtCode"
        Me.txtCode.Size = New System.Drawing.Size(149, 22)
        Me.txtCode.TabIndex = 3
        Me.txtCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblCode
        '
        Me.lblCode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCode.ForeColor = System.Drawing.Color.Maroon
        Me.lblCode.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCode.Location = New System.Drawing.Point(337, 21)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(43, 20)
        Me.lblCode.TabIndex = 2
        Me.lblCode.Text = "Code"
        Me.lblCode.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpPrice
        '
        Me.grpPrice.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpPrice.BackColor = System.Drawing.Color.LightYellow
        Me.grpPrice.Controls.Add(Me.CboAdditionalChargeUnit)
        Me.grpPrice.Controls.Add(Me.CboSubCategory)
        Me.grpPrice.Controls.Add(Me.txtAdditionalCharge)
        Me.grpPrice.Controls.Add(Me.CboServiceType)
        Me.grpPrice.Controls.Add(Me.lblAdditionalCharge)
        Me.grpPrice.Controls.Add(Me.CboCategory)
        Me.grpPrice.Controls.Add(Me.lblAdditionalChargeUnit)
        Me.grpPrice.Controls.Add(Me.lblPercent)
        Me.grpPrice.Controls.Add(Me.txtPrice)
        Me.grpPrice.Controls.Add(Me.CboPriceUnit)
        Me.grpPrice.Controls.Add(Me.lblSubCategory)
        Me.grpPrice.Controls.Add(Me.lblPrice)
        Me.grpPrice.Controls.Add(Me.lblType)
        Me.grpPrice.Controls.Add(Me.lblPriceUnit)
        Me.grpPrice.Controls.Add(Me.txtVAT)
        Me.grpPrice.Controls.Add(Me.lblCategory)
        Me.grpPrice.Controls.Add(Me.lblVAT)
        Me.grpPrice.ForeColor = System.Drawing.SystemColors.ControlText
        Me.grpPrice.Location = New System.Drawing.Point(12, 134)
        Me.grpPrice.Name = "grpPrice"
        Me.grpPrice.Size = New System.Drawing.Size(634, 176)
        Me.grpPrice.TabIndex = 2
        Me.grpPrice.TabStop = False
        '
        'CboAdditionalChargeUnit
        '
        Me.CboAdditionalChargeUnit.ForeColor = System.Drawing.Color.Sienna
        Me.CboAdditionalChargeUnit.ItemHeight = 13
        Me.CboAdditionalChargeUnit.Location = New System.Drawing.Point(368, 94)
        Me.CboAdditionalChargeUnit.Name = "CboAdditionalChargeUnit"
        Me.CboAdditionalChargeUnit.Size = New System.Drawing.Size(84, 21)
        Me.CboAdditionalChargeUnit.TabIndex = 17
        '
        'CboSubCategory
        '
        Me.CboSubCategory.ForeColor = System.Drawing.Color.Sienna
        Me.CboSubCategory.ItemHeight = 13
        Me.CboSubCategory.Location = New System.Drawing.Point(368, 18)
        Me.CboSubCategory.Name = "CboSubCategory"
        Me.CboSubCategory.Size = New System.Drawing.Size(84, 21)
        Me.CboSubCategory.TabIndex = 3
        '
        'txtAdditionalCharge
        '
        Me.txtAdditionalCharge.ForeColor = System.Drawing.Color.Sienna
        Me.txtAdditionalCharge.Location = New System.Drawing.Point(115, 89)
        Me.txtAdditionalCharge.Name = "txtAdditionalCharge"
        Me.txtAdditionalCharge.Size = New System.Drawing.Size(104, 20)
        Me.txtAdditionalCharge.TabIndex = 14
        '
        'CboServiceType
        '
        Me.CboServiceType.ForeColor = System.Drawing.Color.Sienna
        Me.CboServiceType.ItemHeight = 13
        Me.CboServiceType.Location = New System.Drawing.Point(520, 18)
        Me.CboServiceType.Name = "CboServiceType"
        Me.CboServiceType.Size = New System.Drawing.Size(69, 21)
        Me.CboServiceType.TabIndex = 5
        '
        'lblAdditionalCharge
        '
        Me.lblAdditionalCharge.AutoSize = True
        Me.lblAdditionalCharge.ForeColor = System.Drawing.Color.Black
        Me.lblAdditionalCharge.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAdditionalCharge.Location = New System.Drawing.Point(7, 89)
        Me.lblAdditionalCharge.Name = "lblAdditionalCharge"
        Me.lblAdditionalCharge.Size = New System.Drawing.Size(92, 13)
        Me.lblAdditionalCharge.TabIndex = 13
        Me.lblAdditionalCharge.Text = "Additional Charge"
        Me.lblAdditionalCharge.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CboCategory
        '
        Me.CboCategory.ForeColor = System.Drawing.Color.Sienna
        Me.CboCategory.ItemHeight = 13
        Me.CboCategory.Location = New System.Drawing.Point(115, 18)
        Me.CboCategory.Name = "CboCategory"
        Me.CboCategory.Size = New System.Drawing.Size(104, 21)
        Me.CboCategory.TabIndex = 1
        '
        'lblAdditionalChargeUnit
        '
        Me.lblAdditionalChargeUnit.AutoSize = True
        Me.lblAdditionalChargeUnit.ForeColor = System.Drawing.Color.Black
        Me.lblAdditionalChargeUnit.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAdditionalChargeUnit.Location = New System.Drawing.Point(235, 94)
        Me.lblAdditionalChargeUnit.Name = "lblAdditionalChargeUnit"
        Me.lblAdditionalChargeUnit.Size = New System.Drawing.Size(114, 13)
        Me.lblAdditionalChargeUnit.TabIndex = 15
        Me.lblAdditionalChargeUnit.Text = "Additional Charge Unit"
        Me.lblAdditionalChargeUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPercent
        '
        Me.lblPercent.AutoSize = True
        Me.lblPercent.ForeColor = System.Drawing.Color.Black
        Me.lblPercent.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPercent.Location = New System.Drawing.Point(571, 55)
        Me.lblPercent.Name = "lblPercent"
        Me.lblPercent.Size = New System.Drawing.Size(18, 13)
        Me.lblPercent.TabIndex = 12
        Me.lblPercent.Text = "%"
        Me.lblPercent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtPrice
        '
        Me.txtPrice.ForeColor = System.Drawing.Color.Sienna
        Me.txtPrice.Location = New System.Drawing.Point(115, 54)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(104, 20)
        Me.txtPrice.TabIndex = 7
        '
        'CboPriceUnit
        '
        Me.CboPriceUnit.ForeColor = System.Drawing.Color.Sienna
        Me.CboPriceUnit.ItemHeight = 13
        Me.CboPriceUnit.Location = New System.Drawing.Point(368, 53)
        Me.CboPriceUnit.Name = "CboPriceUnit"
        Me.CboPriceUnit.Size = New System.Drawing.Size(84, 21)
        Me.CboPriceUnit.TabIndex = 9
        '
        'lblSubCategory
        '
        Me.lblSubCategory.AutoSize = True
        Me.lblSubCategory.ForeColor = System.Drawing.Color.Black
        Me.lblSubCategory.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSubCategory.Location = New System.Drawing.Point(276, 18)
        Me.lblSubCategory.Name = "lblSubCategory"
        Me.lblSubCategory.Size = New System.Drawing.Size(73, 13)
        Me.lblSubCategory.TabIndex = 2
        Me.lblSubCategory.Text = "Sub Category"
        Me.lblSubCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.ForeColor = System.Drawing.Color.Black
        Me.lblPrice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPrice.Location = New System.Drawing.Point(69, 54)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(30, 13)
        Me.lblPrice.TabIndex = 6
        Me.lblPrice.Text = "Price"
        Me.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblType
        '
        Me.lblType.AutoSize = True
        Me.lblType.ForeColor = System.Drawing.Color.Black
        Me.lblType.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lblType.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblType.Location = New System.Drawing.Point(483, 18)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(31, 13)
        Me.lblType.TabIndex = 4
        Me.lblType.Text = "Type"
        Me.lblType.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPriceUnit
        '
        Me.lblPriceUnit.AutoSize = True
        Me.lblPriceUnit.ForeColor = System.Drawing.Color.Black
        Me.lblPriceUnit.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPriceUnit.Location = New System.Drawing.Point(297, 53)
        Me.lblPriceUnit.Name = "lblPriceUnit"
        Me.lblPriceUnit.Size = New System.Drawing.Size(52, 13)
        Me.lblPriceUnit.TabIndex = 8
        Me.lblPriceUnit.Text = "Price Unit"
        Me.lblPriceUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtVAT
        '
        Me.txtVAT.ForeColor = System.Drawing.Color.Sienna
        Me.txtVAT.Location = New System.Drawing.Point(520, 54)
        Me.txtVAT.Name = "txtVAT"
        Me.txtVAT.Size = New System.Drawing.Size(44, 20)
        Me.txtVAT.TabIndex = 11
        Me.txtVAT.Text = "0"
        Me.txtVAT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblCategory
        '
        Me.lblCategory.AutoSize = True
        Me.lblCategory.ForeColor = System.Drawing.Color.Black
        Me.lblCategory.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCategory.Location = New System.Drawing.Point(47, 18)
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Size = New System.Drawing.Size(52, 13)
        Me.lblCategory.TabIndex = 0
        Me.lblCategory.Text = "Category"
        Me.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblVAT
        '
        Me.lblVAT.AutoSize = True
        Me.lblVAT.ForeColor = System.Drawing.Color.Black
        Me.lblVAT.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblVAT.Location = New System.Drawing.Point(485, 55)
        Me.lblVAT.Name = "lblVAT"
        Me.lblVAT.Size = New System.Drawing.Size(29, 13)
        Me.lblVAT.TabIndex = 10
        Me.lblVAT.Text = "VAT "
        Me.lblVAT.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Location = New System.Drawing.Point(12, 316)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(634, 54)
        Me.grpButtons.TabIndex = 3
        Me.grpButtons.TabStop = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.Azure
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCancel.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Location = New System.Drawing.Point(220, 16)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(99, 27)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(520, 16)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(99, 27)
        Me.btnClose.TabIndex = 4
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(115, 16)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(99, 27)
        Me.btnSave.TabIndex = 1
        Me.btnSave.Text = "E d i t"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.HoverColor2 = System.Drawing.Color.White
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNew.Location = New System.Drawing.Point(10, 16)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(99, 27)
        Me.btnNew.TabIndex = 0
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(658, 40)
        Me.lblfrmTitle.TabIndex = 351
        Me.lblfrmTitle.Text = " Service"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(658, 3)
        Me.pnlTitle.TabIndex = 352
        '
        'frmService
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(658, 382)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grpService)
        Me.Controls.Add(Me.grpPrice)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.KeyPreview = True
        Me.Name = "frmService"
        Me.Text = "Service"
        Me.grpService.ResumeLayout(False)
        Me.grpService.PerformLayout()
        Me.grpPrice.ResumeLayout(False)
        Me.grpPrice.PerformLayout()
        Me.grpButtons.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
   Friend WithEvents lblPercent As System.Windows.Forms.Label
   Friend WithEvents CboPriceUnit As System.Windows.Forms.ComboBox
   Friend WithEvents lblPriceUnit As System.Windows.Forms.Label
   Friend WithEvents CboSubCategory As System.Windows.Forms.ComboBox
   Friend WithEvents CboServiceType As System.Windows.Forms.ComboBox
   Friend WithEvents txtPrice As System.Windows.Forms.TextBox
   Friend WithEvents CboCategory As System.Windows.Forms.ComboBox
   Friend WithEvents txtServiceName As System.Windows.Forms.TextBox
   Friend WithEvents lblCode As System.Windows.Forms.Label
   Friend WithEvents txtCode As System.Windows.Forms.TextBox
   Friend WithEvents lblVAT As System.Windows.Forms.Label
   Friend WithEvents txtVAT As System.Windows.Forms.TextBox
   Friend WithEvents lblSubCategory As System.Windows.Forms.Label
   Friend WithEvents lblType As System.Windows.Forms.Label
   Friend WithEvents lblPrice As System.Windows.Forms.Label
   Friend WithEvents lblServiceName As System.Windows.Forms.Label
   Friend WithEvents lblCategory As System.Windows.Forms.Label
   Friend WithEvents txtServiceID As System.Windows.Forms.TextBox
   Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
   Friend WithEvents btnClose As BHBut.BouncingHoverButton
   Friend WithEvents btnSave As BHBut.BouncingHoverButton
   Friend WithEvents btnNew As BHBut.BouncingHoverButton
   Friend WithEvents grpPrice As System.Windows.Forms.GroupBox
   Friend WithEvents btnCancel As BHBut.BouncingHoverButton
   Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
   Friend WithEvents btnDataErr As System.Windows.Forms.Button
   Friend WithEvents txtAdditionalCharge As System.Windows.Forms.TextBox
   Friend WithEvents lblAdditionalCharge As System.Windows.Forms.Label
   Friend WithEvents lblAdditionalChargeUnit As System.Windows.Forms.Label
   Friend WithEvents grpService As System.Windows.Forms.GroupBox
   Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
   Friend WithEvents pnlTitle As System.Windows.Forms.Panel
   Friend WithEvents CboAdditionalChargeUnit As System.Windows.Forms.ComboBox
End Class
