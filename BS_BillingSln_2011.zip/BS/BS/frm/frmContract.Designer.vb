<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmContract
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.grpContractInfo = New System.Windows.Forms.GroupBox
        Me.BouncingHoverButton1 = New BHBut.BouncingHoverButton
        Me.Label1 = New System.Windows.Forms.Label
        Me.cboContractTitle = New System.Windows.Forms.ComboBox
        Me.lblContNum = New System.Windows.Forms.Label
        Me.txtContNum = New System.Windows.Forms.TextBox
        Me.txtInvoiceID = New System.Windows.Forms.TextBox
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.grpPermit = New System.Windows.Forms.GroupBox
        Me.txtPhoneFee = New System.Windows.Forms.TextBox
        Me.lblAnnualPhone = New System.Windows.Forms.Label
        Me.txtOffice = New System.Windows.Forms.TextBox
        Me.lblOffice = New System.Windows.Forms.Label
        Me.dtpStartingDay = New System.Windows.Forms.DateTimePicker
        Me.lblStartingDay = New System.Windows.Forms.Label
        Me.dtpContractDate = New System.Windows.Forms.DateTimePicker
        Me.lblContractDate = New System.Windows.Forms.Label
        Me.cboContractType = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnPrint = New BHBut.BouncingHoverButton
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.txtContractID = New System.Windows.Forms.TextBox
        Me.llblAreaNote = New System.Windows.Forms.Label
        Me.txtAreaNote = New System.Windows.Forms.TextBox
        Me.txtLawSection = New System.Windows.Forms.TextBox
        Me.grpArea = New System.Windows.Forms.GroupBox
        Me.txtEquipment = New System.Windows.Forms.TextBox
        Me.lblEquipment = New System.Windows.Forms.Label
        Me.txtAreaFeeTotal = New System.Windows.Forms.TextBox
        Me.lblAreaTotFree = New System.Windows.Forms.Label
        Me.txtAreaFee = New System.Windows.Forms.TextBox
        Me.lblAreaFee = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.chkStatus = New System.Windows.Forms.CheckBox
        Me.cboAreaName = New System.Windows.Forms.ComboBox
        Me.lblArea = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtAreaSqm = New System.Windows.Forms.TextBox
        Me.grdArea = New System.Windows.Forms.DataGridView
        Me.Label7 = New System.Windows.Forms.Label
        Me.grpContractInfo.SuspendLayout()
        Me.grpPermit.SuspendLayout()
        Me.grpButtons.SuspendLayout()
        Me.grpArea.SuspendLayout()
        CType(Me.grdArea, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(723, 3)
        Me.pnlTitle.TabIndex = 353
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(723, 40)
        Me.lblfrmTitle.TabIndex = 352
        Me.lblfrmTitle.Text = "  Contract "
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grpContractInfo
        '
        Me.grpContractInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpContractInfo.BackColor = System.Drawing.Color.Lavender
        Me.grpContractInfo.Controls.Add(Me.BouncingHoverButton1)
        Me.grpContractInfo.Controls.Add(Me.Label1)
        Me.grpContractInfo.Controls.Add(Me.cboContractTitle)
        Me.grpContractInfo.Controls.Add(Me.lblContNum)
        Me.grpContractInfo.Controls.Add(Me.txtContNum)
        Me.grpContractInfo.Controls.Add(Me.txtInvoiceID)
        Me.grpContractInfo.Location = New System.Drawing.Point(0, 43)
        Me.grpContractInfo.Name = "grpContractInfo"
        Me.grpContractInfo.Size = New System.Drawing.Size(720, 65)
        Me.grpContractInfo.TabIndex = 354
        Me.grpContractInfo.TabStop = False
        '
        'BouncingHoverButton1
        '
        Me.BouncingHoverButton1.AlternativeGroup = Nothing
        Me.BouncingHoverButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BouncingHoverButton1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton1.BackColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton1.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.BouncingHoverButton1.BorderHover = True
        Me.BouncingHoverButton1.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton1.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BouncingHoverButton1.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.BouncingHoverButton1.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BouncingHoverButton1.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BouncingHoverButton1.DrawBorder = True
        Me.BouncingHoverButton1.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BouncingHoverButton1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.BouncingHoverButton1.ForeColor = System.Drawing.Color.Navy
        Me.BouncingHoverButton1.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.BouncingHoverButton1.HoverColor2 = System.Drawing.Color.White
        Me.BouncingHoverButton1.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BouncingHoverButton1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.BouncingHoverButton1.Location = New System.Drawing.Point(-109, -23)
        Me.BouncingHoverButton1.Name = "BouncingHoverButton1"
        Me.BouncingHoverButton1.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.BouncingHoverButton1.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.BouncingHoverButton1.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BouncingHoverButton1.SelectedHoverColor1 = System.Drawing.Color.White
        Me.BouncingHoverButton1.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.BouncingHoverButton1.SelectedText = Nothing
        Me.BouncingHoverButton1.Size = New System.Drawing.Size(99, 27)
        Me.BouncingHoverButton1.TabIndex = 159
        Me.BouncingHoverButton1.Text = "N e w"
        Me.BouncingHoverButton1.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(188, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 18)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Contract Title"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboContractTitle
        '
        Me.cboContractTitle.BackColor = System.Drawing.SystemColors.Window
        Me.cboContractTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboContractTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cboContractTitle.FormattingEnabled = True
        Me.cboContractTitle.Location = New System.Drawing.Point(314, 24)
        Me.cboContractTitle.Name = "cboContractTitle"
        Me.cboContractTitle.Size = New System.Drawing.Size(325, 24)
        Me.cboContractTitle.TabIndex = 11
        '
        'lblContNum
        '
        Me.lblContNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContNum.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblContNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblContNum.Location = New System.Drawing.Point(8, 24)
        Me.lblContNum.Name = "lblContNum"
        Me.lblContNum.Size = New System.Drawing.Size(72, 18)
        Me.lblContNum.TabIndex = 0
        Me.lblContNum.Text = "Number"
        Me.lblContNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtContNum
        '
        Me.txtContNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtContNum.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtContNum.Location = New System.Drawing.Point(85, 23)
        Me.txtContNum.Name = "txtContNum"
        Me.txtContNum.ReadOnly = True
        Me.txtContNum.Size = New System.Drawing.Size(88, 22)
        Me.txtContNum.TabIndex = 1
        Me.txtContNum.TabStop = False
        Me.txtContNum.Text = "000"
        Me.txtContNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtInvoiceID
        '
        Me.txtInvoiceID.Location = New System.Drawing.Point(142, 24)
        Me.txtInvoiceID.Name = "txtInvoiceID"
        Me.txtInvoiceID.ReadOnly = True
        Me.txtInvoiceID.Size = New System.Drawing.Size(24, 20)
        Me.txtInvoiceID.TabIndex = 2
        Me.txtInvoiceID.TabStop = False
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(664, 12)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(52, 25)
        Me.btnDataErr.TabIndex = 158
        Me.btnDataErr.TabStop = False
        Me.btnDataErr.Text = "E r r o r"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(465, 17)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(198, 17)
        Me.lstDataErr.TabIndex = 157
        Me.lstDataErr.Visible = False
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(297, 225)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(113, 16)
        Me.Label2.TabIndex = 356
        Me.Label2.Text = "Permits For"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpPermit
        '
        Me.grpPermit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpPermit.Controls.Add(Me.txtPhoneFee)
        Me.grpPermit.Controls.Add(Me.lblAnnualPhone)
        Me.grpPermit.Controls.Add(Me.txtOffice)
        Me.grpPermit.Controls.Add(Me.lblOffice)
        Me.grpPermit.Controls.Add(Me.dtpStartingDay)
        Me.grpPermit.Controls.Add(Me.lblStartingDay)
        Me.grpPermit.Controls.Add(Me.dtpContractDate)
        Me.grpPermit.Controls.Add(Me.lblContractDate)
        Me.grpPermit.Controls.Add(Me.cboContractType)
        Me.grpPermit.Controls.Add(Me.Label8)
        Me.grpPermit.Controls.Add(Me.cboClient)
        Me.grpPermit.Controls.Add(Me.Label9)
        Me.grpPermit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPermit.Location = New System.Drawing.Point(7, 241)
        Me.grpPermit.Name = "grpPermit"
        Me.grpPermit.Size = New System.Drawing.Size(373, 221)
        Me.grpPermit.TabIndex = 358
        Me.grpPermit.TabStop = False
        '
        'txtPhoneFee
        '
        Me.txtPhoneFee.AcceptsReturn = True
        Me.txtPhoneFee.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPhoneFee.ForeColor = System.Drawing.Color.Black
        Me.txtPhoneFee.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtPhoneFee.Location = New System.Drawing.Point(114, 188)
        Me.txtPhoneFee.Multiline = True
        Me.txtPhoneFee.Name = "txtPhoneFee"
        Me.txtPhoneFee.Size = New System.Drawing.Size(156, 23)
        Me.txtPhoneFee.TabIndex = 376
        '
        'lblAnnualPhone
        '
        Me.lblAnnualPhone.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblAnnualPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAnnualPhone.ForeColor = System.Drawing.Color.Purple
        Me.lblAnnualPhone.Location = New System.Drawing.Point(23, 183)
        Me.lblAnnualPhone.Name = "lblAnnualPhone"
        Me.lblAnnualPhone.Size = New System.Drawing.Size(82, 23)
        Me.lblAnnualPhone.TabIndex = 375
        Me.lblAnnualPhone.Text = " Phone Fee"
        Me.lblAnnualPhone.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtOffice
        '
        Me.txtOffice.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOffice.ForeColor = System.Drawing.Color.Black
        Me.txtOffice.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtOffice.Location = New System.Drawing.Point(114, 156)
        Me.txtOffice.Multiline = True
        Me.txtOffice.Name = "txtOffice"
        Me.txtOffice.Size = New System.Drawing.Size(69, 23)
        Me.txtOffice.TabIndex = 374
        '
        'lblOffice
        '
        Me.lblOffice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblOffice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOffice.ForeColor = System.Drawing.Color.Purple
        Me.lblOffice.Location = New System.Drawing.Point(10, 153)
        Me.lblOffice.Name = "lblOffice"
        Me.lblOffice.Size = New System.Drawing.Size(95, 23)
        Me.lblOffice.TabIndex = 373
        Me.lblOffice.Text = "Office"
        Me.lblOffice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dtpStartingDay
        '
        Me.dtpStartingDay.CustomFormat = "dd MMM yyyy"
        Me.dtpStartingDay.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpStartingDay.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpStartingDay.Location = New System.Drawing.Point(114, 122)
        Me.dtpStartingDay.Name = "dtpStartingDay"
        Me.dtpStartingDay.Size = New System.Drawing.Size(216, 21)
        Me.dtpStartingDay.TabIndex = 372
        '
        'lblStartingDay
        '
        Me.lblStartingDay.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblStartingDay.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStartingDay.ForeColor = System.Drawing.Color.Purple
        Me.lblStartingDay.Location = New System.Drawing.Point(10, 122)
        Me.lblStartingDay.Name = "lblStartingDay"
        Me.lblStartingDay.Size = New System.Drawing.Size(95, 23)
        Me.lblStartingDay.TabIndex = 371
        Me.lblStartingDay.Text = "Starting Day"
        Me.lblStartingDay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dtpContractDate
        '
        Me.dtpContractDate.CustomFormat = "dd MMM yyyy"
        Me.dtpContractDate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpContractDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpContractDate.Location = New System.Drawing.Point(114, 88)
        Me.dtpContractDate.Name = "dtpContractDate"
        Me.dtpContractDate.Size = New System.Drawing.Size(215, 21)
        Me.dtpContractDate.TabIndex = 361
        '
        'lblContractDate
        '
        Me.lblContractDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblContractDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContractDate.ForeColor = System.Drawing.Color.Purple
        Me.lblContractDate.Location = New System.Drawing.Point(10, 88)
        Me.lblContractDate.Name = "lblContractDate"
        Me.lblContractDate.Size = New System.Drawing.Size(95, 27)
        Me.lblContractDate.TabIndex = 360
        Me.lblContractDate.Text = "Contract Date"
        Me.lblContractDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboContractType
        '
        Me.cboContractType.BackColor = System.Drawing.SystemColors.Window
        Me.cboContractType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboContractType.ForeColor = System.Drawing.Color.Black
        Me.cboContractType.FormattingEnabled = True
        Me.cboContractType.Location = New System.Drawing.Point(114, 54)
        Me.cboContractType.Name = "cboContractType"
        Me.cboContractType.Size = New System.Drawing.Size(215, 21)
        Me.cboContractType.TabIndex = 11
        '
        'Label8
        '
        Me.Label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Purple
        Me.Label8.Location = New System.Drawing.Point(10, 54)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(95, 27)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Contract Type"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboClient
        '
        Me.cboClient.BackColor = System.Drawing.SystemColors.Window
        Me.cboClient.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboClient.ForeColor = System.Drawing.Color.Maroon
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(114, 20)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(215, 21)
        Me.cboClient.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Purple
        Me.Label9.Location = New System.Drawing.Point(57, 25)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 18)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Client"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnPrint)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Location = New System.Drawing.Point(6, 606)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(710, 48)
        Me.grpButtons.TabIndex = 359
        Me.grpButtons.TabStop = False
        '
        'btnPrint
        '
        Me.btnPrint.AlternativeGroup = Nothing
        Me.btnPrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPrint.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPrint.BackColor1 = System.Drawing.Color.White
        Me.btnPrint.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPrint.BorderHover = True
        Me.btnPrint.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPrint.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPrint.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPrint.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPrint.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPrint.DrawBorder = True
        Me.btnPrint.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPrint.ForeColor = System.Drawing.Color.Navy
        Me.btnPrint.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.HoverColor2 = System.Drawing.Color.White
        Me.btnPrint.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPrint.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPrint.Location = New System.Drawing.Point(417, 14)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPrint.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPrint.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPrint.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.SelectedText = Nothing
        Me.btnPrint.Size = New System.Drawing.Size(99, 27)
        Me.btnPrint.TabIndex = 163
        Me.btnPrint.Text = "P r e v i e w "
        Me.btnPrint.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.HoverColor2 = System.Drawing.Color.White
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCancel.Location = New System.Drawing.Point(295, 14)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCancel.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(99, 27)
        Me.btnCancel.TabIndex = 162
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(606, 14)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(99, 27)
        Me.btnClose.TabIndex = 157
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.HoverColor2 = System.Drawing.Color.White
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNew.Location = New System.Drawing.Point(5, 14)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(99, 27)
        Me.btnNew.TabIndex = 156
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(124, 14)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(99, 27)
        Me.btnSave.TabIndex = 158
        Me.btnSave.Text = "Edit"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'txtContractID
        '
        Me.txtContractID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtContractID.ForeColor = System.Drawing.Color.Maroon
        Me.txtContractID.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtContractID.Location = New System.Drawing.Point(389, 12)
        Me.txtContractID.Multiline = True
        Me.txtContractID.Name = "txtContractID"
        Me.txtContractID.Size = New System.Drawing.Size(69, 23)
        Me.txtContractID.TabIndex = 360
        '
        'llblAreaNote
        '
        Me.llblAreaNote.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.llblAreaNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.llblAreaNote.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblAreaNote.ForeColor = System.Drawing.Color.DarkBlue
        Me.llblAreaNote.Location = New System.Drawing.Point(4, 465)
        Me.llblAreaNote.Name = "llblAreaNote"
        Me.llblAreaNote.Size = New System.Drawing.Size(117, 18)
        Me.llblAreaNote.TabIndex = 361
        Me.llblAreaNote.Text = "With Respect To Area"
        Me.llblAreaNote.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtAreaNote
        '
        Me.txtAreaNote.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAreaNote.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtAreaNote.ForeColor = System.Drawing.Color.Maroon
        Me.txtAreaNote.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtAreaNote.Location = New System.Drawing.Point(8, 486)
        Me.txtAreaNote.Multiline = True
        Me.txtAreaNote.Name = "txtAreaNote"
        Me.txtAreaNote.Size = New System.Drawing.Size(712, 114)
        Me.txtAreaNote.TabIndex = 362
        '
        'txtLawSection
        '
        Me.txtLawSection.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLawSection.Location = New System.Drawing.Point(4, 114)
        Me.txtLawSection.Multiline = True
        Me.txtLawSection.Name = "txtLawSection"
        Me.txtLawSection.Size = New System.Drawing.Size(716, 105)
        Me.txtLawSection.TabIndex = 363
        '
        'grpArea
        '
        Me.grpArea.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpArea.Controls.Add(Me.txtEquipment)
        Me.grpArea.Controls.Add(Me.lblEquipment)
        Me.grpArea.Controls.Add(Me.txtAreaFeeTotal)
        Me.grpArea.Controls.Add(Me.lblAreaTotFree)
        Me.grpArea.Controls.Add(Me.txtAreaFee)
        Me.grpArea.Controls.Add(Me.lblAreaFee)
        Me.grpArea.Controls.Add(Me.Label3)
        Me.grpArea.Controls.Add(Me.chkStatus)
        Me.grpArea.Controls.Add(Me.cboAreaName)
        Me.grpArea.Controls.Add(Me.lblArea)
        Me.grpArea.Controls.Add(Me.Label6)
        Me.grpArea.Controls.Add(Me.txtAreaSqm)
        Me.grpArea.Controls.Add(Me.grdArea)
        Me.grpArea.Controls.Add(Me.Label7)
        Me.grpArea.Location = New System.Drawing.Point(384, 242)
        Me.grpArea.Name = "grpArea"
        Me.grpArea.Size = New System.Drawing.Size(335, 221)
        Me.grpArea.TabIndex = 364
        Me.grpArea.TabStop = False
        '
        'txtEquipment
        '
        Me.txtEquipment.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEquipment.ForeColor = System.Drawing.Color.Black
        Me.txtEquipment.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtEquipment.Location = New System.Drawing.Point(5, 174)
        Me.txtEquipment.Multiline = True
        Me.txtEquipment.Name = "txtEquipment"
        Me.txtEquipment.Size = New System.Drawing.Size(326, 23)
        Me.txtEquipment.TabIndex = 384
        '
        'lblEquipment
        '
        Me.lblEquipment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblEquipment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEquipment.ForeColor = System.Drawing.Color.Purple
        Me.lblEquipment.Location = New System.Drawing.Point(7, 150)
        Me.lblEquipment.Name = "lblEquipment"
        Me.lblEquipment.Size = New System.Drawing.Size(170, 23)
        Me.lblEquipment.TabIndex = 383
        Me.lblEquipment.Text = "Equipment used By Area"
        Me.lblEquipment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtAreaFeeTotal
        '
        Me.txtAreaFeeTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAreaFeeTotal.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAreaFeeTotal.ForeColor = System.Drawing.Color.Black
        Me.txtAreaFeeTotal.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtAreaFeeTotal.Location = New System.Drawing.Point(220, 125)
        Me.txtAreaFeeTotal.Multiline = True
        Me.txtAreaFeeTotal.Name = "txtAreaFeeTotal"
        Me.txtAreaFeeTotal.ReadOnly = True
        Me.txtAreaFeeTotal.Size = New System.Drawing.Size(106, 23)
        Me.txtAreaFeeTotal.TabIndex = 382
        '
        'lblAreaTotFree
        '
        Me.lblAreaTotFree.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblAreaTotFree.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAreaTotFree.ForeColor = System.Drawing.Color.Purple
        Me.lblAreaTotFree.Location = New System.Drawing.Point(222, 102)
        Me.lblAreaTotFree.Name = "lblAreaTotFree"
        Me.lblAreaTotFree.Size = New System.Drawing.Size(106, 19)
        Me.lblAreaTotFree.TabIndex = 381
        Me.lblAreaTotFree.Text = "Area Total Fee "
        Me.lblAreaTotFree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtAreaFee
        '
        Me.txtAreaFee.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAreaFee.ForeColor = System.Drawing.Color.Black
        Me.txtAreaFee.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtAreaFee.Location = New System.Drawing.Point(4, 124)
        Me.txtAreaFee.Multiline = True
        Me.txtAreaFee.Name = "txtAreaFee"
        Me.txtAreaFee.Size = New System.Drawing.Size(70, 23)
        Me.txtAreaFee.TabIndex = 380
        '
        'lblAreaFee
        '
        Me.lblAreaFee.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblAreaFee.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAreaFee.ForeColor = System.Drawing.Color.Purple
        Me.lblAreaFee.Location = New System.Drawing.Point(10, 104)
        Me.lblAreaFee.Name = "lblAreaFee"
        Me.lblAreaFee.Size = New System.Drawing.Size(69, 19)
        Me.lblAreaFee.TabIndex = 379
        Me.lblAreaFee.Text = "Area  Fee"
        Me.lblAreaFee.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(279, 196)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 23)
        Me.Label3.TabIndex = 378
        Me.Label3.Text = "Status"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkStatus
        '
        Me.chkStatus.AutoSize = True
        Me.chkStatus.ForeColor = System.Drawing.Color.Firebrick
        Me.chkStatus.Location = New System.Drawing.Point(261, 200)
        Me.chkStatus.Name = "chkStatus"
        Me.chkStatus.Size = New System.Drawing.Size(15, 14)
        Me.chkStatus.TabIndex = 377
        Me.chkStatus.UseVisualStyleBackColor = True
        '
        'cboAreaName
        '
        Me.cboAreaName.BackColor = System.Drawing.SystemColors.Window
        Me.cboAreaName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboAreaName.ForeColor = System.Drawing.Color.Black
        Me.cboAreaName.FormattingEnabled = True
        Me.cboAreaName.ItemHeight = 13
        Me.cboAreaName.Location = New System.Drawing.Point(98, 11)
        Me.cboAreaName.Name = "cboAreaName"
        Me.cboAreaName.Size = New System.Drawing.Size(233, 21)
        Me.cboAreaName.TabIndex = 376
        '
        'lblArea
        '
        Me.lblArea.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblArea.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblArea.ForeColor = System.Drawing.Color.Purple
        Me.lblArea.Location = New System.Drawing.Point(7, 11)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(83, 18)
        Me.lblArea.TabIndex = 375
        Me.lblArea.Text = "Area Name"
        Me.lblArea.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Purple
        Me.Label6.Location = New System.Drawing.Point(190, 122)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(26, 27)
        Me.Label6.TabIndex = 373
        Me.Label6.Text = "m�"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtAreaSqm
        '
        Me.txtAreaSqm.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAreaSqm.ForeColor = System.Drawing.Color.Black
        Me.txtAreaSqm.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtAreaSqm.Location = New System.Drawing.Point(81, 124)
        Me.txtAreaSqm.Multiline = True
        Me.txtAreaSqm.Name = "txtAreaSqm"
        Me.txtAreaSqm.Size = New System.Drawing.Size(106, 23)
        Me.txtAreaSqm.TabIndex = 372
        '
        'grdArea
        '
        Me.grdArea.AllowUserToAddRows = False
        Me.grdArea.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdArea.BackgroundColor = System.Drawing.Color.LightYellow
        Me.grdArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.grdArea.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdArea.Location = New System.Drawing.Point(4, 34)
        Me.grdArea.Name = "grdArea"
        Me.grdArea.ReadOnly = True
        Me.grdArea.Size = New System.Drawing.Size(326, 68)
        Me.grdArea.TabIndex = 374
        '
        'Label7
        '
        Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Purple
        Me.Label7.Location = New System.Drawing.Point(85, 102)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 19)
        Me.Label7.TabIndex = 371
        Me.Label7.Text = "Area "
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmContract
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(723, 659)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.grpArea)
        Me.Controls.Add(Me.txtLawSection)
        Me.Controls.Add(Me.txtAreaNote)
        Me.Controls.Add(Me.llblAreaNote)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grpPermit)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.grpContractInfo)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.txtContractID)
        Me.KeyPreview = True
        Me.Name = "frmContract"
        Me.Text = "Contract"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.grpContractInfo.ResumeLayout(False)
        Me.grpContractInfo.PerformLayout()
        Me.grpPermit.ResumeLayout(False)
        Me.grpPermit.PerformLayout()
        Me.grpButtons.ResumeLayout(False)
        Me.grpArea.ResumeLayout(False)
        Me.grpArea.PerformLayout()
        CType(Me.grdArea, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
   Friend WithEvents pnlTitle As System.Windows.Forms.Panel
   Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
   Friend WithEvents grpContractInfo As System.Windows.Forms.GroupBox
   Friend WithEvents lblContNum As System.Windows.Forms.Label
   Friend WithEvents txtContNum As System.Windows.Forms.TextBox
   Friend WithEvents txtInvoiceID As System.Windows.Forms.TextBox
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents cboContractTitle As System.Windows.Forms.ComboBox
   Friend WithEvents Label2 As System.Windows.Forms.Label
   Friend WithEvents grpPermit As System.Windows.Forms.GroupBox
   Friend WithEvents cboContractType As System.Windows.Forms.ComboBox
   Friend WithEvents Label8 As System.Windows.Forms.Label
   Friend WithEvents cboClient As System.Windows.Forms.ComboBox
   Friend WithEvents Label9 As System.Windows.Forms.Label
   Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
   Friend WithEvents btnClose As BHBut.BouncingHoverButton
   Friend WithEvents btnNew As BHBut.BouncingHoverButton
   Friend WithEvents btnSave As BHBut.BouncingHoverButton
   Friend WithEvents txtContractID As System.Windows.Forms.TextBox
   Friend WithEvents lblContractDate As System.Windows.Forms.Label
   Friend WithEvents dtpContractDate As System.Windows.Forms.DateTimePicker
   Friend WithEvents llblAreaNote As System.Windows.Forms.Label
   Friend WithEvents txtAreaNote As System.Windows.Forms.TextBox
   Friend WithEvents btnDataErr As System.Windows.Forms.Button
   Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
   Friend WithEvents BouncingHoverButton1 As BHBut.BouncingHoverButton
   Friend WithEvents btnCancel As BHBut.BouncingHoverButton
   Friend WithEvents txtLawSection As System.Windows.Forms.TextBox
   Friend WithEvents dtpStartingDay As System.Windows.Forms.DateTimePicker
   Friend WithEvents lblStartingDay As System.Windows.Forms.Label
   Friend WithEvents txtOffice As System.Windows.Forms.TextBox
   Friend WithEvents lblOffice As System.Windows.Forms.Label
   Friend WithEvents txtPhoneFee As System.Windows.Forms.TextBox
   Friend WithEvents lblAnnualPhone As System.Windows.Forms.Label
   Friend WithEvents grpArea As System.Windows.Forms.GroupBox
   Friend WithEvents txtEquipment As System.Windows.Forms.TextBox
   Friend WithEvents lblEquipment As System.Windows.Forms.Label
   Friend WithEvents txtAreaFeeTotal As System.Windows.Forms.TextBox
   Friend WithEvents lblAreaTotFree As System.Windows.Forms.Label
   Friend WithEvents txtAreaFee As System.Windows.Forms.TextBox
   Friend WithEvents lblAreaFee As System.Windows.Forms.Label
   Friend WithEvents Label3 As System.Windows.Forms.Label
   Friend WithEvents chkStatus As System.Windows.Forms.CheckBox
   Friend WithEvents cboAreaName As System.Windows.Forms.ComboBox
   Friend WithEvents lblArea As System.Windows.Forms.Label
   Friend WithEvents Label6 As System.Windows.Forms.Label
   Friend WithEvents txtAreaSqm As System.Windows.Forms.TextBox
   Friend WithEvents grdArea As System.Windows.Forms.DataGridView
   Friend WithEvents Label7 As System.Windows.Forms.Label
   Friend WithEvents btnPrint As BHBut.BouncingHoverButton
End Class
