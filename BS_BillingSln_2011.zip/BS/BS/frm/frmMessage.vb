Imports BITSConn
Imports System.Data.SqlClient

''' <Used DB Components>
''' vwInvoiceMessage
''' tblClient
''' tblMessage
''' tblInvoice
''' tblInvoiceDetail
''' tblTafkeet
''' </Used DB Components>

Public Class frmMessage

	
#Region "Form-Declaration..."
	''
	Private dsdata As DataSet
	Private dapMessage As SqlDataAdapter
	Private daInvoice As SqlDataAdapter
	Private daInvoiceDetail As SqlDataAdapter
	Private daTafkeet As SqlDataAdapter
	Private clsMr As ClsMain
	Private blnLoading As Boolean = True
	Private mstrCurrentGridName As String
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Message\Settings"
	Private dblInvoiceTotal As Double = 0
	Private intClientID As Integer
	Private dblAmount As Double
	Private total As Double = 0
	Private CurrID2 As Integer
#End Region


#Region "Form-Initialisation..."

	Private Sub frmMessage_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		SaveProfile(mStrSubKeyName, Me.grdMessageList)
    End Sub

    Private Sub frmMessage_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

	Private Sub frmMessage_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		clsMr = New ClsMain(conSql)
		''
		blnLoading = True
		MakeDataAdapter()
		FillComboBox()
		DrawGrid()
		GetCompanyCurrencies()
		blnLoading = False
		''set defaults
		cboClient.SelectedIndex = -1
		lblCurrSymbol2.Text = GetCompanyCurrencySymbol2()
		Me.nupYear.Value = Now.Year
		filterGrid()
		SetAutoNumber()
		If Me.rdbEnterNewCBM.Checked Then
			Me.grdMessageList.ReadOnly = False
			grdMessageList.Columns("InvoiceNumber").ReadOnly = True
			Me.btnAutoGenerateInvoice.Enabled = False
			Me.grdMessageList.Columns("Day").Visible = True
			Me.grdMessageList.Columns("MessageDate").Visible = False
		Else
			Me.cboClient.Enabled = True
			Me.grdMessageList.ReadOnly = True
			Me.grdMessageList.Columns("Day").Visible = False
			Me.grdMessageList.Columns("MessageDate").Visible = True
			'Me.btnAutoGenerateInvoice.Enabled = True
		End If
		Me.btnSave.Enabled = False
		Me.btnSaveClear.Enabled = False
		btnAutoGenerateInvoice.Enabled = False
		updateGridMessage()
		If cboMonth.SelectedIndex <> -1 Then
			grdMessageList.ReadOnly = False
			grdMessageList.Columns("InvoiceNumber").ReadOnly = True
		Else
			grdMessageList.ReadOnly = True
		End If

		btnPreviewAllInMsgs.Enabled = False
		btnPrint.Enabled = False
		dsdata.Tables("vwInvoiceMessage").Clear()
	End Sub

	Private Sub MakeDataAdapter()
		''
		'' set SQL for selecting active emp recs...
		clsMr.BuildSqlAdapter("SELECT ClientID,ClientName FROM tblClient WHERE Del=0 ORDER BY ClientName ", "ClientName")
		clsMr.BuildSqlAdapter("SELECT  MessageDate, RegCode, FlightNumber, Amount, InvoiceNumber,MessageID, ClientID, InvoiceID FROM vwInvoiceMessage", "vwInvoiceMessage")
		dapMessage = clsMr.BuildSqlAdapter("Select * FROM tblMessage ", "tblMessage")
		daInvoice = clsMr.BuildSqlAdapter("SELECT * FROM tblInvoice WHERE InvoiceID=0 ", "tblInvoice")
		daInvoiceDetail = clsMr.BuildSqlAdapter("SELECT * FROM tblInvoiceDetail WHERE InvoiceID=0 ", "tblInvoiceDetail")
		daTafkeet = clsMr.BuildSqlAdapter("SELECT * FROM tblTafkeet", "tblTafkeet")
		''
		dsdata = clsMr.getDataSet
	End Sub

	Private Sub FillComboBox()
		''
		clsMr.FillComboBox("ClientName", cboClient, "ClientName", "ClientID")
		''
	End Sub

	Public Sub SetAutoNumber()
		''
		Dim lngMax As Long
		lngMax = clsMr.GetMaxNumber("SELECT MAX(MessageID) FROM tblMessage ") + 1
		clsMr.SetAutoNumber("tblMessage", "MessageID", lngMax)
	End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

#End Region


#Region "Form-Functions..."

	Private Sub GetCompanyCurrencies()


		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand
		''
		strSQL = "select * FROM  dbo.tblCompany  WHERE dbo.tblCompany.companyID=  " & gIntCompanyID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text

		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			CurrID2 = dRdr("CurrID2")
		End If
		dRdr.Close()
		conSql.Close()
	End Sub

	Private Sub SetDataSource(ByRef comboboxColumn As DataGridViewComboBoxColumn, ByRef pdt As DataTable, ByVal pStrValueMember As String, ByVal pStrDisplayMember As String)
		''
		With comboboxColumn
			' Dim dt As DataTable = pdt
			.DataSource = pdt
			.ValueMember = pStrValueMember '"ComplexityLevelID"
			.DisplayMember = pStrDisplayMember '"ComplexityLevelCode" '.ValueMember
		End With
	End Sub

	Private Sub UpdateTotal()
		Dim dv As DataView = dsdata.Tables("vwInvoiceMessage").DefaultView
		Dim drv As DataRowView
		Dim total As Double

		For Each drv In dv
			If IsDBNull(drv("Amount")) Then
				drv("Amount") = 0
			End If
			total += drv("Amount")
		Next
		txtTotalAmount.Text = total.ToString()
	End Sub

	Private Function filterStringMessage() As String

		Dim s As String = String.Empty
		Dim sd As Date
		Dim ed As Date

		If cboClient.SelectedIndex <> -1 Then
			s = " ({vwInvoiceMessage.ClientID} = " & cboClient.SelectedValue & ")"
		ElseIf cboClient.Text <> "" Then
			s = " ({vwInvoiceMessage.ClientID} = " & -1 & ")"
		End If

		'If IsNothing(cboClient) Then
		'	s = " ({tblClient.ClientID} = " & -1 & ")"
		'Else
		'	s = " ({tblClient.ClientID} = " & cboClient.SelectedValue & ")"
		'End If

		'If (Me.chkShowAll.Checked = False) Then
		'	If s <> String.Empty Then
		'		s = s & " AND "
		'	End If
		'	s = s & " ({tblMessage.MessageID}=)"

		'End If

		If cboMonth.SelectedIndex = -1 Then
			sd = New Date(nupYear.Value, 1, 1)
			ed = sd.AddYears(1)
			If s <> String.Empty Then
				s = s & " AND "
			End If
			s = s & " ({vwInvoiceMessage.MessageDate} >= #" & sd.ToString("yyyy-M-d") & "# AND {vwInvoiceMessage.MessageDate} < #" & ed.ToString("yyyy-M-d") & "#)"
		Else
			sd = New Date(nupYear.Value, cboMonth.SelectedIndex + 1, 1)
			ed = sd.AddMonths(1)
			If s <> String.Empty Then
				s = s & " AND "
			End If

			''
			s = s & " ({vwInvoiceMessage.MessageDate} >= #" & sd.ToString("yyyy-M-d") & "# AND {vwInvoiceMessage.MessageDate} < #" & ed.ToString("yyyy-M-d") & "# )"
		End If
		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				If s = "" Then
					s &= "   ({vwInvoiceMessage.InvoiceNumber} = " & tn & ")"
				Else
					s &= " AND  ({vwInvoiceMessage.InvoiceNumber} = " & tn & ")"
				End If

			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		If Me.chkShowAll.Checked = False And Me.chkShowInvoice.Checked = False Then
			If s <> String.Empty Then
				s = s & " AND "
			End If
			s = s & " ISNULL({vwInvoiceMessage.InvoiceID}) "

		End If

		If Me.chkShowAll.Checked = False And Me.chkShowInvoice.Checked = True Then
			If s <> String.Empty Then
				s = s & " AND "
			End If
			s = s & " Not ISNULL({vwInvoiceMessage.InvoiceID}) "

		End If

		''
		filterStringMessage = s


		''
		Return filterStringMessage

	End Function

	Private Sub GetClient()
		Dim frmClient As New frmClientGet()
		'appMain.addTabPage(frmClient, frmApplicationMain.eFormType.ClientGet)
		'AddHandler frmClient.Closed, AddressOf RefreshClient
		frmClient.ShowDialog()
		cboClient.SelectedValue = frmClient.CboValue
	End Sub

	Private Function GetBranchBillingInfo()
		Dim intDGID As Integer

		Try
			Dim cmd As New SqlClient.SqlCommand("SELECT DGID FROM tblBranchBillingInfo WHERE BranchID=" & gIntBranchID, conSql)
			conSql.Open()
			intDGID = cmd.ExecuteScalar()
			conSql.Close()
			Return intDGID
		Catch ex As Exception
			conSql.Close()
			Return 0
		End Try

	End Function

	Private Sub UpdateInvoiceDetail(ByVal pInvoiceID As Integer, ByVal pTotal As Double, ByVal pServiceID As Integer)	', Optional ByVal pQty As Integer = 1)
		''
		Dim drInvoiceDetail As DataRow = dsdata.Tables("tblInvoiceDetail").NewRow
		drInvoiceDetail("InvoiceID") = pInvoiceID
		drInvoiceDetail("InvoiceDetailID") = clsMr.GetMaxNumber("InvoiceDetailID", "tblInvoiceDetail") + 1
		drInvoiceDetail("ServiceID") = pServiceID
		drInvoiceDetail("Price") = pTotal
		' drInvoiceDetail("Price")=GetServicePrice(pServiceID)
		drInvoiceDetail("Quantity") = 1
		dblInvoiceTotal += drInvoiceDetail("Price")
		drInvoiceDetail("Discount") = 0
		drInvoiceDetail("VATAmount") = 0
		drInvoiceDetail("Del") = 0
		drInvoiceDetail("PriceUnitID") = 1
		drInvoiceDetail("TotalCurr2") = GetExchangeValue(gIntCompanyCurrID, CurrID2, Now.Date, pTotal)
		dsdata.Tables("tblInvoiceDetail").Rows.Add(drInvoiceDetail)
		daInvoiceDetail.Update(dsdata, "tblInvoiceDetail")

	End Sub

	Private Sub EnableButtonsMessage()
		''
		If (Me.cboMonth.SelectedIndex <> -1) And (Me.grdMessageList.RowCount > 1) And Me.chkShowAll.Checked = False And rdbCBMInvoice.Checked Then
			Me.btnAutoGenerateInvoice.Enabled = True
			'Me.btnPrint.Enabled = True
		Else : Me.btnAutoGenerateInvoice.Enabled = False
			'Me.btnPrint.Enabled = False
		End If

		If rdbCBMInvoice.Checked And grdMessageList.RowCount > 1 And cboMonth.SelectedIndex <> -1 Then
			btnPreviewAllInMsgs.Enabled = True
			btnPrint.Enabled = True
		Else
			btnPreviewAllInMsgs.Enabled = False
			btnPrint.Enabled = False
		End If

		If chkShowAll.Checked Or chkShowInvoice.Checked Then
			btnAutoGenerateInvoice.Enabled = False
		End If
	End Sub

	Private Sub PrepareMSGTafkeet()
		''
		'' Get the SUM for a Client/for ea. Client Grp By ClientID AS tblMessageInv...
		''
		'' Fill table...
		''
		strSQL = "SELECT ClientID, "
		strSQL &= "Sum(Amount)As Amount, "
		strSQL &= " Count(MessageID)As Count"
		'strSQL &= " From TblMessage "
		strSQL &= " From vwInvoiceMessage "
		''
		If cboClient.SelectedIndex <> -1 Then
			'strSQL = "SELECT ClientID, "
			'strSQL &= "Sum(Amount)As Amount, "
			'strSQL &= " Count(MessageID)As Count"
			'strSQL &= " From TblMessage "
			strSQL &= "WHERE ClientID=" & cboClient.SelectedValue
			strSQL &= " AND MONTH(MessageDate)= " & cboMonth.SelectedIndex + 1
			'strSQL &= " And Year(MessageDate)=" & nupYear.Value
			'If chkShowInvoice.Checked = False And chkShowAll.Checked = False Then
			'	strSQL &= "And InvoiceID IS NULL"
			'ElseIf chkShowInvoice.Checked Then
			'	strSQL &= "And InvoiceID IS NOT NULL"
			'End If
			'strSQL &= " Group By ClientID"
			'clsMr.BuildSqlAdapter(strSQL, "tblMessageInv")
		Else
			'strSQL = "SELECT ClientID,"
			'strSQL &= "Sum(Amount)As Amount "
			'strSQL &= ",count(MessageID) As Count"
			'strSQL &= " From TblMessage "
			strSQL &= " WHERE  MONTH(MessageDate)= " & cboMonth.SelectedIndex + 1
			'strSQL &= " And Year(MessageDate)=" & nupYear.Value
			'If chkShowInvoice.Checked = False And chkShowAll.Checked = False Then
			'	strSQL &= "And InvoiceID IS NULL"
			'ElseIf chkShowInvoice.Checked Then
			'	strSQL &= "And InvoiceID IS NOT NULL"
			'End If
			'strSQL &= " Group By ClientID"
			'clsMr.BuildSqlAdapter(strSQL, "tblMessageInv")
		End If
		''
		strSQL &= " And Year(MessageDate)=" & nupYear.Value
		''
		If chkShowInvoice.Checked = False And chkShowAll.Checked = False Then
			strSQL &= " And InvoiceID IS NULL"
		ElseIf chkShowInvoice.Checked Then
			strSQL &= " And InvoiceID IS NOT NULL"
		End If
		''
		If txtInvoiceNum.Text <> String.Empty Then
			strSQL &= " AND  (InvoiceNumber = " & txtInvoiceNum.Text & ")"
		End If
		''		
		strSQL &= " Group By ClientID"
		''
		clsMr.BuildSqlAdapter(strSQL, "tblMessageInv")
		''
		'' DEL tblTafkeet prepare for the NEW Selection...
		''
		Dim cmd As New SqlCommand("DELETE FROM tblTafkeet", conSql)
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''
		'' Insert New Row for ea. Selected Client in(tblMessageInv) into tblTafkeet IF ANY.
		''
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		Dim dv As DataView = dsdata.Tables("tblMessageInv").DefaultView
		Dim drv As DataRowView
		''
		'' dim tafKeet vars...
		Dim dRdr As SqlClient.SqlDataReader
		Dim cmdX As SqlClient.SqlCommand
		''
		Dim strUnitName As String
		Dim strPartUnitName As String
		Dim strSymbol As String
		Dim strUnitNameEn As String
		Dim strPartUnitNameEn As String
		Dim strSymbolEn As String
		'Dim Amount As Double

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' Get Company Currency Symbols...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' ??? COULD USE:  strSymbol = getCompanyCurrencySymbol()
		'' 
		'' GET Curr1 Info...
		''
		strSQL = "SELECT * FROM dbo.tblCurrency WHERE DEL=0 AND CurrID=  " & gIntCompanyCurrID
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text
		''
		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			strUnitName = dRdr("UnitName")
			strPartUnitName = dRdr("PartUnitName")
			strSymbol = dRdr("Symbol")
		End If
		dRdr.Close()
		conSql.Close()
		'' 
		'' GET Curr2 Info...
		''
		strSQL = "SELECT * FROM dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID2
		''
		cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		cmdX.CommandType = CommandType.Text
		''
		conSql.Open()
		dRdr = cmdX.ExecuteReader()
		If dRdr.Read Then
			'strUnitNameEn = dRdr("UnitName")
			'strPartUnitNameEn = dRdr("PartUnitName")
			'strSymbolEn = dRdr("Symbol")
			strUnitNameEn = "Lebanese Pound"
			strPartUnitNameEn = ""
			strSymbolEn = ""
		End If
		dRdr.Close()
		conSql.Close()

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' GO for ea. Rec (Client Invoice)...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		For Each drv In dv
			''
			Dim strWord As String
			Dim strWordEn As String
			'strWord = ToWords(JobCards.Current()("Total"), strUnitName, strPartUnitName)
			'rpt.SetParameterValue("Words", strWord)

			'for rounding
			If (drv("Amount") Mod 1000) > 0 Then
				drv("Amount") = (drv("Amount") - (drv("Amount") Mod 1000)) + 1000
			End If
			strWordEn = ToWordsEn(drv("Amount"), strUnitNameEn, strPartUnitNameEn)
			strWord = ToWords(drv("Amount"), strUnitName, strPartUnitName)

			Dim drNew As DataRow = dsdata.Tables("tblTafkeet").NewRow
			drNew("Tafkeet") = strWord
			drNew("TafkeetEn") = strWordEn
			drNew("InvoiceID") = drv("ClientID")
			dsdata.Tables("tblTafkeet").Rows.Add(drNew)
			daTafkeet.Update(dsdata, "tblTafkeet")
		Next
		'' Clear table...
		''

		dsdata.Tables("tblMessageInv").Clear()

		''		

	End Sub

	Private Sub checkValues()
		''
		If blnLoading = True Then Exit Sub
		''
		'dataChange = True
		'btnCancel.Enabled = True
		''
		'' clear entir list & start fresh check...
		''
		lstDataErr.Items.Clear()
		Dim intErrCount As Int16 = 0

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' check Error - Mandatory Data Objects...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''

		If Me.rdbEnterNewCBM.Checked Then
			If Me.cboMonth.SelectedIndex = -1 Then
				lstDataErr.Items.Add("Error: Missing month  Name  ")
				intErrCount += 1
			End If
			If dsdata.Tables("vwInvoiceMessage").DefaultView.Count > 0 Then
				If Me.grdMessageList.CurrentRow.Cells("RegCode").Value Is DBNull.Value And Me.grdMessageList.CurrentRow.Cells("FlightNumber").Value Is DBNull.Value Then
					lstDataErr.Items.Add("Error: Enter A/c Reg or Flight Number ")
					intErrCount += 1
				End If
				' day
				If grdMessageList.CurrentRow.Cells("Day").Value > 31 Or grdMessageList.CurrentRow.Cells("Day").Value < 1 Or grdMessageList.CurrentRow.Cells("Day").Value Is DBNull.Value Then
					lstDataErr.Items.Add("Error: the Day  between 1 and 31 ")
					intErrCount += 1
				End If
			End If
			If (cboClient.SelectedIndex = -1 Or cboClient.Text = String.Empty) And rdbEnterNewCBM.Checked Then
				lstDataErr.Items.Add("Error: Missing Client Name ")
				intErrCount += 1
			End If
			'Amount

			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			'' Set appropriate controls based on errors check results...
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			If lstDataErr.Items.Count = 0 Then
				lstDataErr.Visible = False
				btnDataErr.Visible = False
				'lblHelpErr.Visible = False
			Else
				btnDataErr.Visible = True
				'lblHelpErr.Visible = True
			End If
			''
			If intErrCount = 0 Then
				btnSave.Enabled = True
				Me.btnSaveClear.Enabled = True
				'Me.btnPrint.Enabled = True

			Else
				btnSave.Enabled = False
				Me.btnSaveClear.Enabled = False
				'btnPrint.Enabled = False
			End If
		Else
			''for generateInvoice

			If Me.cboMonth.SelectedIndex = -1 Then
				lstDataErr.Items.Add("Error: Missing month  Name  ")
				intErrCount += 1
			End If
			If lstDataErr.Items.Count = 0 Then
				lstDataErr.Visible = False
				btnDataErr.Visible = False
				'lblHelpErr.Visible = False
			Else
				btnDataErr.Visible = True
				'lblHelpErr.Visible = True
			End If
			''
			If intErrCount = 0 Then
				btnAutoGenerateInvoice.Enabled = True
				'Me.btnPrint.Enabled = True

			Else
				btnAutoGenerateInvoice.Enabled = False
				'	btnPrint.Enabled = False
			End If
		End If

		If chkShowAll.Checked Or chkShowInvoice.Checked Then
			Me.btnAutoGenerateInvoice.Enabled = False
		End If
	End Sub

	Private Sub save()
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		Dim intCounter As Integer
		Dim drUpdate() As DataRow
		Dim dt As DataTable
		Dim drAdd As DataRow
		'Try
		''check if new rows are added
		dt = dsdata.Tables("vwInvoiceMessage").GetChanges(DataRowState.Added)

		If Not (dt Is Nothing) Then
			For intCounter = 0 To dt.Rows.Count - 1
				drAdd = dsdata.Tables("tblMessage").NewRow()
				drAdd("ClientID") = dt.Rows(intCounter)("ClientID")
				drAdd("MessageDate") = dt.Rows(intCounter)("MessageDate")
				drAdd("RegCode") = dt.Rows(intCounter)("RegCode")
				drAdd("FlightNumber") = dt.Rows(intCounter)("FlightNumber")
				drAdd("Amount") = dt.Rows(intCounter)("Amount")
				drAdd("InvoiceID") = dt.Rows(intCounter)("InvoiceID")
				dsdata.Tables("tblMessage").Rows.Add(drAdd)
			Next
		End If

		dt = dsdata.Tables("vwInvoiceMessage").GetChanges(DataRowState.Modified)

		If Not (dt Is Nothing) Then

			For intCounter = 0 To dt.Rows.Count - 1
				drUpdate = dsdata.Tables("tblMessage").Select("MessageID=" & dt.Rows(intCounter)("MessageID"))

				drUpdate(0).BeginEdit()

				drUpdate(0)("ClientID") = dt.Rows(intCounter)("ClientID")
				drUpdate(0)("MessageDate") = dt.Rows(intCounter)("MessageDate")
				drUpdate(0)("RegCode") = dt.Rows(intCounter)("RegCode")
				drUpdate(0)("FlightNumber") = dt.Rows(intCounter)("FlightNumber")
				drUpdate(0)("Amount") = dt.Rows(intCounter)("Amount")
				drUpdate(0)("InvoiceID") = dt.Rows(intCounter)("InvoiceID")
				''
				drUpdate(0).EndEdit()
			Next
		End If

		dt = dsdata.Tables("tblMessage").GetChanges

		If Not (dt Is Nothing) Then
			dapMessage.Update(dt)
			dsdata.Tables("tblMessage").AcceptChanges()
			dsdata.Tables("vwInvoiceMessage").AcceptChanges()
		End If
		updateGridMessage()
		Me.btnSave.Enabled = False
		Me.btnSaveClear.Enabled = False
		Windows.Forms.Cursor.Current = Cursors.Default()

	End Sub

	Private Sub RefreshGrid()
		''
		dsdata.Tables("vwInvoiceMessage").Clear()
		clsMr.BuildSqlAdapter("SELECT  MessageDate, RegCode, FlightNumber, Amount, InvoiceNumber,MessageID, ClientID, InvoiceID FROM vwInvoiceMessage", "vwInvoiceMessage")
		filterGrid()
	End Sub

	Private Function CheckUserGenInvoice() As Integer
		''
		Dim IntUserGenInvoice As Integer
		''
		Dim cmd As New SqlCommand("Select UserGenInvoiceID from tblUserGenInvoice ", conSql)
		Try
			conSql.Open()
			IntUserGenInvoice = cmd.ExecuteScalar
			conSql.Close()
		Catch ex As Exception
			conSql.Close()
		End Try
		''
		If IntUserGenInvoice > 0 Then
			Return IntUserGenInvoice
		Else
			Return -1
		End If
		''
	End Function

	Private Sub SetUserGenInvoice()
		''
		Dim strUserName As String
		''
		Dim cmd As New SqlCommand("SELECT UserName FROM vwUsers WHERE EmployeeID=" & gIntUserID, conSql)
		Try
			conSql.Open()
			strUserName = cmd.ExecuteScalar
			conSql.Close()
		Catch ex As Exception
			conSql.Close()
			''
		End Try
		''
		Dim cmdInsert As New SqlCommand("INSERT INTO tblUserGenInvoice(UserGenInvoiceID, UserGenInvoiceName, Del)VALUES(" & gIntUserID & " ,'" & strUserName & "',1)", conSql)
		Try
			conSql.Open()
			cmdInsert.ExecuteScalar()
			conSql.Close()
		Catch ex As Exception
			conSql.Close()
		End Try
		''
	End Sub

#End Region


#Region "Form-UI/Methods..."

	'Private Sub cboClient_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyDown
	'	If e.KeyCode = Keys.F3 Then
	'		GetClient()
	'		If e.KeyCode = Keys.Delete Then
	'			filterGrid()
	'			btnPrint.Enabled = True
	'		End If
	'	End If
	'End Sub

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		Me.Close()
	End Sub

	Private Sub cboClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
		AutoComplete(cboClient, e)

	End Sub

	Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
		''
		'preview
		If Me.grdMessageList.RowCount = 0 Then Exit Sub
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()

		Dim frm As New frmQuickReport
		Dim rpt As New rptMessage
		Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
		Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
		Dim totalAmount As String = String.Empty

		''
		For Each tbCurrent In rpt.Database.Tables
			tliCurrent = tbCurrent.LogOnInfo			''
			With tliCurrent.ConnectionInfo
				.ServerName = gStrServerName
				.DatabaseName = gStrDataBaseName
				.UserID = "" 'gStrUserName
				.Password = ""	 'gStrPassword
			End With

			tbCurrent.ApplyLogOnInfo(tliCurrent)
		Next tbCurrent
		'for tafkeet
		'
		'Dim dRdr As SqlClient.SqlDataReader
		'Dim cmdX As SqlClient.SqlCommand

		'Dim strUnitName As String
		'Dim strPartUnitName As String
		'Dim strSymbol As String
		'Dim strUnitNameEn As String
		'Dim strPartUnitNameEn As String
		'Dim strSymbolEn As String
		' ''
		'strSQL = "select *   FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID
		' ''
		'cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		'cmdX.CommandType = CommandType.Text

		'conSql.Open()
		'dRdr = cmdX.ExecuteReader()
		'If dRdr.Read Then
		'	strUnitName = dRdr("UnitName")
		'	strPartUnitName = dRdr("PartUnitName")
		'	strSymbol = dRdr("Symbol")
		'End If
		'dRdr.Close()
		'conSql.Close()

		'strSQL = "select * FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID2
		' ''
		'cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		'cmdX.CommandType = CommandType.Text

		'conSql.Open()
		'dRdr = cmdX.ExecuteReader()
		'If dRdr.Read Then
		'	strUnitNameEn = dRdr("UnitName")
		'	strPartUnitNameEn = dRdr("PartUnitName")
		'	strSymbolEn = dRdr("Symbol")
		'End If
		'dRdr.Close()
		'conSql.Close()

		''
		PrepareMSGTafkeet()
		''
		frm.crvInstantViewer.SelectionFormula = filterStringMessage()
		''
		rpt.SetParameterValue("Month", Me.cboMonth.Text)
		rpt.SetParameterValue("year", Me.nupYear.Value)
		rpt.SetParameterValue("CurrSybl1", GetCompanyCurrencySymbol())
		rpt.SetParameterValue("CurrSybl2", GetCompanyCurrencySymbol2())
		frm.crvInstantViewer.ReportSource = rpt
		frm.crvInstantViewer.Refresh()
		frm.Show()
		frm.crvInstantViewer.DisplayToolbar = True

		Windows.Forms.Cursor.Current = Cursors.Default()


		'end preview
	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		save()
	End Sub

	Private Sub btnAutoGenerateInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAutoGenerateInvoice.Click
        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ''
        Dim strMsg As String = "Are you sure you want to Generate "
        Dim strComputerName As String = ""
        ''
        If grdMessageList.Rows.Count > 1 Then
            ''
            strMsg &= "these Transactions "
        Else
            strMsg &= "this Transaction"
        End If
        ''
        If MsgBox(strMsg & "?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            If CheckUserGenInvoice() <> -1 And CheckDate() Then
                strComputerName = GetComputerName()
                MsgBox("You Cannot Generate an Invoice At this Time ,Another User Generate Invoice At Computer: <" & strComputerName & ">", , "Try Again Later")
                Exit Sub
            Else
                DeleteUserGenInvoice()
                SetUserGenInvoice()
            End If
            ''
            dsdata.Tables("vwInvoiceMessage").Clear()
            clsMr.BuildSqlAdapter("SELECT  MessageDate, RegCode, FlightNumber, Amount, InvoiceNumber,MessageID, ClientID, InvoiceID FROM vwInvoiceMessage", "vwInvoiceMessage")
            ''
            If MsgBox(" Are You sure You Want To Generate Invoices ? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Class-B Messages") = MsgBoxResult.Yes Then
                ''
                Dim sd As Date
                Dim ed As Date
                Dim strsqlSort As String = ""
                ''
                sd = New Date(nupYear.Value, cboMonth.SelectedIndex + 1, 1)
                ed = sd.AddMonths(1)
                ed = ed.AddDays(-1)

                ''''''''''''''''''''''''''''''''''''''''''''''
                strsqlSort = "SELECT TOP 100 PERCENT dbo.tblMessage.ClientID, SUM(dbo.tblMessage.Amount) AS Amount, COUNT(dbo.tblMessage.MessageID) AS Count, "
                strsqlSort &= " dbo.tblClient.ClientName FROM dbo.tblMessage LEFT OUTER JOIN dbo.tblClient ON dbo.tblMessage.ClientID = dbo.tblClient.ClientID"
                strsqlSort &= " WHERE(dbo.tblMessage.InvoiceID Is NULL)"
                '''''''''''''''''''''''''''''''''''''''''''
                If cboClient.SelectedIndex <> -1 Then
                    strSQL = "SELECT ClientID, "
                    strSQL &= "Sum(Amount)As Amount, "
                    strSQL &= " count(MessageID)As Count"
                    strSQL &= " From TblMessage "
                    strSQL &= " WHERE InvoiceID IS NULL "
                    strSQL &= "AND ClientID=" & cboClient.SelectedValue
                    strSQL &= " AND MONTH(MessageDate)= " & cboMonth.SelectedIndex + 1
                    strSQL &= " And Year(MessageDate)=" & nupYear.Value
                    strSQL &= " Group By ClientID"
                    'clsMr.BuildSqlAdapter(strSQL, "tblMessageInv")
                Else
                    strSQL = "SELECT ClientID,"
                    strSQL &= "Sum(Amount)As Amount "
                    strSQL &= ",count(MessageID) As Count"
                    strSQL &= " From TblMessage "
                    strSQL &= " WHERE InvoiceID IS NULL "
                    strSQL &= " AND MONTH(MessageDate)= " & cboMonth.SelectedIndex + 1
                    strSQL &= " And Year(MessageDate)=" & nupYear.Value
                    strSQL &= " Group By ClientID"
                    'clsMr.BuildSqlAdapter(strSQL, "tblMessageInv")
                End If
                ''
                If cboClient.SelectedIndex <> -1 Then
                    strsqlSort &= "AND dbo.tblMessage.ClientID=" & cboClient.SelectedValue
                End If
                ''
                strsqlSort &= " AND MONTH(MessageDate)= " & cboMonth.SelectedIndex + 1
                strsqlSort &= " And Year(MessageDate)=" & nupYear.Value
                ''
                strsqlSort &= " GROUP BY dbo.tblMessage.ClientID, dbo.tblClient.ClientName"
                strsqlSort &= " HAVING(dbo.tblMessage.ClientID Is Not NULL)"
                strsqlSort &= " ORDER BY dbo.tblClient.ClientName"
                ''
                clsMr.BuildSqlAdapter(strsqlSort, "tblMessageInv")
                ''
                Dim dv As DataView = dsdata.Tables("tblMessageInv").DefaultView
                ''
                Dim drv As DataRowView
                For Each drv In dv

                    ''Create Invoice

                    Dim drInvoice As DataRow = dsdata.Tables("tblInvoice").NewRow
                    drInvoice("InvoiceID") = clsMr.GetMaxNumber("InvoiceID", "tblInvoice") + 1
                    drInvoice("CatID") = 3
                    drInvoice("InvoiceNumber") = clsMr.GetMaxNumber("InvoiceNumber", "tblInvoice") + 1
                    drInvoice("InvoiceFrom") = sd
                    Dim strYear As String = Now.Date.Year
                    strYear = strYear.Substring(2, 2)
                    drInvoice("InvoiceYY") = strYear
                    Dim intDG As Integer = GetBranchBillingInfo()
                    If intDG <> 0 Then
                        drInvoice("DGID") = intDG
                    End If
                    drInvoice("InvoiceTo") = ed
                    drInvoice("InvoiceDate") = Now.Date
                    drInvoice("CurrencyID") = gIntCompanyCurrID
                    drInvoice("Rate") = GetRate(gIntCompanyCurrID, CurrID2, Now.Date)

                    drInvoice("StatusID") = 1
                    drInvoice("BilledDate") = Now.Date

                    drInvoice("EmployeeID") = gIntUserID
                    drInvoice("BranchID") = gIntBranchID
                    drInvoice("Del") = 0
                    drInvoice("Description") = "Class-B Messages For " & cboMonth.Text & " " & nupYear.Value
                    drInvoice("CreateByID") = gIntUserID
                    drInvoice("CreateDate") = Now.Date
                    drInvoice("AutoGel") = 1
                    drInvoice("ClientID") = drv("ClientID")
                    drInvoice("Total") = drv("Amount")
                    dsdata.Tables("tblInvoice").Rows.Add(drInvoice)
                    ''
                    'Dim drv As DataRowView
                    'Dim total As Decimal
                    'Dim i As Integer

                    ' ''update tblMessage
                    'For i = dv.Count - 1 To 0 Step -1
                    '	drv = dv.Item(0)
                    '	total += drv("Amount")
                    '	drv("InvoiceID") = drInvoice("InvoiceID")
                    '	drv.EndEdit()
                    'Next
                    ''

                    Dim dvMsg As DataView = dsdata.Tables("vwInvoiceMessage").DefaultView
                    Dim drvMsg As DataRowView
                    For Each drvMsg In dvMsg
                        Dim cmd As New SqlCommand("Update tblmessage set InvoiceID =" & drInvoice("InvoiceID") & " WHERE  tblMessage.MessageID =" & drvMsg("MessageID") & " AND tblMessage.ClientID=" & drv("ClientID"), conSql)

                        conSql.Open()
                        cmd.ExecuteNonQuery()
                        conSql.Close()

                    Next
                    ''Create invoiceDetail
                    ''continue for all services

                    ''update invocce Details
                    Dim drInvoiceDetail As DataRow = dsdata.Tables("tblInvoiceDetail").NewRow
                    drInvoiceDetail("InvoiceID") = drInvoice("InvoiceID")
                    drInvoiceDetail("InvoiceDetailID") = clsMr.GetMaxNumber("InvoiceDetailID", "tblInvoiceDetail") + 1
                    drInvoiceDetail("ServiceID") = 8
                    drInvoiceDetail("Price") = drv("Amount")
                    ' drInvoiceDetail("Price")=GetServicePrice(pServiceID)
                    drInvoiceDetail("Quantity") = drv("Count")
                    drInvoiceDetail("Discount") = 0
                    drInvoiceDetail("VATAmount") = 0
                    drInvoiceDetail("Del") = 0
                    drInvoiceDetail("PriceUnitID") = 1
                    drInvoiceDetail("TotalCurr2") = GetExchangeValue(gIntCompanyCurrID, CurrID2, Now.Date, drv("Amount"))
                    dsdata.Tables("tblInvoiceDetail").Rows.Add(drInvoiceDetail)
                    drInvoice("TotalCurr2") = GetExchangeValue(gIntCompanyCurrID, CurrID2, Now.Date, drInvoice("Total"))
                    ''
                    daInvoice.Update(dsdata, "tblInvoice")
                    daInvoiceDetail.Update(dsdata, "tblInvoiceDetail")
                    ''
                Next
                ''
                dsdata.Tables("vwInvoiceMessage").Rows.Clear()
                'refrech 
                clsMr.BuildSqlAdapter("SELECT  MessageDate, RegCode, FlightNumber, Amount, InvoiceNumber,MessageID, ClientID, InvoiceID FROM vwInvoiceMessage", "vwInvoiceMessage")
                filterGrid()
                ''
                Dim intUserID As Integer
                ''
                intUserID = CheckUserGenInvoice()
                If intUserID = gIntUserID Then
                    ''
                    Dim cmd As New SqlCommand("DELETE from tblUserGenInvoice ", conSql)
                    Try
                        conSql.Open()
                        cmd.ExecuteNonQuery()
                        conSql.Close()
                    Catch ex As Exception
                        conSql.Close()
                    End Try
                    ''
                End If
                ''
                btnAutoGenerateInvoice.Enabled = False
                If cboClient.SelectedIndex <> -1 Then
                    MsgBox("You Are Trying To Generate Invoice For Company " & cboClient.Text & " Of The Month " & cboMonth.Text & "-" & nupYear.Value)
                Else
                    MsgBox("Invoices Successefully Generated  For All Companies  Of The Month " & cboMonth.Text & "-" & nupYear.Value)

                End If
            End If
        End If

    End Sub

	Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
		''
		'' Show/Hide error list...
		If lstDataErr.Visible = True Then
			lstDataErr.Visible = False
		Else
			lstDataErr.Visible = True
			lstDataErr.Height = 100
			lstDataErr.BringToFront()
		End If
	End Sub

	Private Sub btnPreviewAllInMsgs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviewAllInMsgs.Click
		''
		Dim frm As New frmQuickReport
		Dim rpt As New rptStatisticsForMessages
		Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
		Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
		Dim totalAmount As String = String.Empty
		''
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		''
		For Each tbCurrent In rpt.Database.Tables
			tliCurrent = tbCurrent.LogOnInfo			''
			With tliCurrent.ConnectionInfo
				.ServerName = gStrServerName
				.DatabaseName = gStrDataBaseName
				.UserID = "" 'gStrUserName
				.Password = ""	 'gStrPassword
			End With

			tbCurrent.ApplyLogOnInfo(tliCurrent)
		Next tbCurrent
		'for tafkeet
		'
		'Dim dRdr As SqlClient.SqlDataReader
		'Dim cmdX As SqlClient.SqlCommand

		'Dim strUnitName As String
		'Dim strPartUnitName As String
		'Dim strSymbol As String
		'Dim strUnitNameEn As String
		'Dim strPartUnitNameEn As String
		'Dim strSymbolEn As String
		' ''
		'strSQL = "select *   FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID
		' ''
		'cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		'cmdX.CommandType = CommandType.Text

		'conSql.Open()
		'dRdr = cmdX.ExecuteReader()
		'If dRdr.Read Then
		'	strUnitName = dRdr("UnitName")
		'	strPartUnitName = dRdr("PartUnitName")
		'	strSymbol = dRdr("Symbol")
		'End If
		'dRdr.Close()
		'conSql.Close()

		'strSQL = "select * FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID2
		' ''
		'cmdX = New SqlClient.SqlCommand(strSQL, conSql)
		'cmdX.CommandType = CommandType.Text

		'conSql.Open()
		'dRdr = cmdX.ExecuteReader()
		'If dRdr.Read Then
		'	strUnitNameEn = dRdr("UnitName")
		'	strPartUnitNameEn = dRdr("PartUnitName")
		'	strSymbolEn = dRdr("Symbol")
		'End If
		'dRdr.Close()
		'conSql.Close()
		frm.crvInstantViewer.SelectionFormula = filterStringMessage()
		frm.crvInstantViewer.ReportSource = rpt
		rpt.SetParameterValue("Month", Me.cboMonth.Text)
		rpt.SetParameterValue("year", Me.nupYear.Value)
		rpt.SetParameterValue("CurrSybl1", GetCompanyCurrencySymbol())
		rpt.SetParameterValue("CurrSybl2", GetCompanyCurrencySymbol2())
		frm.crvInstantViewer.Refresh()
		frm.Show()
		frm.crvInstantViewer.DisplayToolbar = True
		Windows.Forms.Cursor.Current = Cursors.Default()
		'end preview


	End Sub

	Private Sub btnSaveClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveClear.Click
		Windows.Forms.Cursor.Current = Cursors.WaitCursor()
		save()
		dsdata.Tables("vwInvoiceMessage").Clear()
	End Sub

	Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
		dsdata.Tables("vwInvoiceMessage").Clear()
		btnPreviewAllInMsgs.Enabled = False
		btnPrint.Enabled = False
	End Sub

	Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
		''
		RefreshGrid()
	End Sub

	Private Sub LockGrid()
		''
		If cboClient.SelectedIndex = -1 Or cboClient.Text = String.Empty Then
			grdMessageList.ReadOnly = True
		Else
			grdMessageList.ReadOnly = False
		End If
	End Sub

	Private Sub txtInvoiceNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInvoiceNum.TextChanged
		''
		filterGrid()
	End Sub

#End Region


#Region "Form-Grid Settings..."

	Private Sub DrawGrid()
		''
		grdMessageList.DataSource = dsdata.Tables("vwInvoiceMessage").DefaultView
		dsdata.Tables("vwInvoiceMessage").DefaultView.AllowNew = True
		''
		With grdMessageList
			''
			.Columns("MessageID").Visible = False
			.Columns("ClientID").Visible = False
			.Columns("InvoiceID").Visible = False
			''
			'.Columns("InvoiceNumber").Visible = False
			''
			'remove the column to add cbo
			''
			'.Columns.Remove("ClientID")
			'.Columns.Remove("MessageID")
			''
			.Columns("InvoiceNumber").ReadOnly = True
			.Columns("Amount").DefaultCellStyle.Format = "###,###,###"
			.Columns("MessageDate").HeaderText = "Msg Sending Date"
			.Columns("FlightNumber").HeaderText = "Flight Number"
			.Columns("InvoiceNumber").HeaderText = "Invoice Number"
			.Columns("RegCode").HeaderText = "A/c Reg"
			.ColumnHeadersHeight = btnShowCol.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		End With
		''
		AddComboBoxColumns()
		LoadProfile(mStrSubKeyName, Me.grdMessageList)
		''
		AddHandler dsdata.Tables("vwInvoiceMessage").ColumnChanged, AddressOf Column_Changed

	End Sub

	Private Sub updateGridMessage()
		Dim i As Integer
		''
		With grdMessageList
			For i = 0 To .RowCount - 1
				If Not IsDBNull(.Rows(i).Cells("MessageDate").Value) Then
					.Rows(i).Cells("Day").Value = CDate(.Rows(i).Cells("MessageDate").Value).Day
				End If
			Next
		End With
	End Sub

	Private Sub AddComboBoxColumns()
		Dim comboboxColumnClient As New DataGridViewComboBoxColumn()
		comboboxColumnClient = CreateComboBoxColumn("ClientID", "ClientID")
		SetDataSource(comboboxColumnClient, dsdata.Tables("ClientName"), "ClientID", "ClientName")
		comboboxColumnClient.HeaderText = "Client Name"
		comboboxColumnClient.Name = "ClientName"
		grdMessageList.Columns.Insert(0, comboboxColumnClient)

	End Sub

	Private Function CreateComboBoxColumn(ByRef pDataPropertyName As String, ByRef pHeaderText As String) As DataGridViewComboBoxColumn
		''
		Dim column As New DataGridViewComboBoxColumn()
		''
		With column
			.DataPropertyName = pDataPropertyName 'ColumnName.RefID.ToString()
			.HeaderText = pHeaderText 'ColumnName.RefID.ToString()
			.DropDownWidth = 120
			.Width = 90
			'.MaxDropDownItems = 3
			.FlatStyle = FlatStyle.Standard
		End With
		Return column
	End Function

	Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
		Dim i As Integer

		For i = 0 To Me.chkLstGridCol.Items.Count - 1
			Me.grdMessageList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
		Next

		''
		Me.grpShowHideColumns.Visible = False

	End Sub

	Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
		If Me.grpShowHideColumns.Visible = False Then
			Me.grpShowHideColumns.Visible = True
			Me.grpShowHideColumns.BringToFront()
			mstrCurrentGridName = "Message"
			''
			'' populate list with grid's dataSource fields...
			''

			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridCol.Items.Clear()
			For Each col In Me.grdMessageList.Columns
				Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
			Next
			chkLstGridCol.Items.Remove("MessageID")
			chkLstGridCol.Items.Remove("ClientID")
			chkLstGridCol.Items.Remove("InvoiceID")
		Else
			Me.grpShowHideColumns.Visible = False
			Me.grpShowHideColumns.SendToBack()
		End If
	End Sub

	Private Sub grdMessageList_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdMessageList.CellEndEdit
		If blnLoading = True Then Exit Sub
		checkValues()
		If Me.cboMonth.SelectedIndex <> -1 And (Not IsDBNull(Me.grdMessageList.CurrentRow.Cells("Day").Value) OrElse Me.grdMessageList.CurrentRow.Cells("Day").Value <> "") Then

			If grdMessageList.CurrentRow.Cells("Day").Value < 1 Or grdMessageList.CurrentRow.Cells("Day").Value > 31 Then
				grdMessageList.CurrentRow.Cells("Day").Value = 1
				MsgBox("Error: The Day  between 1 and 31 ")
			End If

			If grdMessageList.CurrentRow.Cells("Day").Value < 1 Or grdMessageList.CurrentRow.Cells("Day").Value > 29 And cboMonth.SelectedIndex = 1 Then
				grdMessageList.CurrentRow.Cells("Day").Value = 1
				MsgBox("Error: The Day  between 1 and 29 ")
			End If
			Me.grdMessageList.CurrentRow.Cells("MessageDate").Value = Me.grdMessageList.CurrentRow.Cells("Day").Value & "/" & cboMonth.SelectedIndex + 1 & "/" & nupYear.Value
		End If
	End Sub

	Private Sub grdMessageList_UserDeletedRow(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowEventArgs) Handles grdMessageList.UserDeletedRow
		UpdateTotal()
	End Sub

	Private Sub grdMessageList_CellValidated(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grdMessageList.CellValidated
		If blnLoading Then Exit Sub

		checkValues()
		If e.ColumnIndex = grdMessageList.Columns("Amount").Index Then
			UpdateTotal()

		End If
	End Sub

	Private Sub grdMessageList_UserAddedRow(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowEventArgs) Handles grdMessageList.UserAddedRow

		grdMessageList.CurrentRow.Cells("Day").Value = 1
		Me.grdMessageList.CurrentRow.Cells("ClientName").Value = cboClient.SelectedValue
	End Sub

	Private Sub grdMessageList_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdMessageList.Enter
		If rdbEnterNewCBM.Checked And cboMonth.SelectedIndex = -1 Then
			MsgBox("choose Month And Client")
		End If
		If rdbCBMInvoice.Checked And cboMonth.SelectedIndex = -1 Then
			MsgBox("choose Month")
		End If

	End Sub

	Private Sub Column_Changed(ByVal sender As Object, ByVal e As System.Data.DataColumnChangeEventArgs)
		''
		If blnLoading Then Exit Sub
		''
		If grdMessageList.Rows.Count = 0 Then Exit Sub
		''
		If (grdMessageList.CurrentRow) Is Nothing Then
			Exit Sub
		End If
		''
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'Save the value of ClientID & Amount Before Update ClientName . . . . . . . . 
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''
		'Try
		'	Dim dRdr As SqlClient.SqlDataReader
		'	Dim cmdClient As New SqlCommand("SELECT ClientID, Amount From tblMessage WHERE MessageID =" & grdMessageList.Item("MessageID", grdMessageList.CurrentRow.Index).Value, conSql)
		'	''
		'	conSql.Open()
		'	dRdr = cmdClient.ExecuteReader()
		'	If dRdr.Read Then
		'		intClientID = dRdr("ClientID")
		'		dblAmount = dRdr("Amount")
		'	End If
		'	dRdr.Close()
		'	conSql.Close()
		'Catch ex As Exception
		'	conSql.Close()
		'End Try
		'UpdateClientBalance()
		''
		If e.Column.ColumnName = "ClientID" And Not IsDBNull(grdMessageList.Item("InvoiceID", grdMessageList.CurrentRow.Index).Value) Then
			''
			'grdMessageList.Item("InvoiceNumber", grdMessageList.CurrentRow.Index).Value = Nothing
			''
			'''''''''''''''''''''''''''''''''''
			'Remove InvoiceID For This Message 
			'''''''''''''''''''''''''''''''''''
			''
			Try
				Dim cmd As New SqlCommand("Update tblMessage SET InvoiceID = NULL, ClientID = " & grdMessageList.Item("ClientID", grdMessageList.CurrentRow.Index).Value & "  WHERE MessageID = " & grdMessageList.Item("MessageID", grdMessageList.CurrentRow.Index).Value, conSql)
				conSql.Open()
				cmd.ExecuteNonQuery()
				conSql.Close()
			Catch ex As Exception
				conSql.Close()
			End Try
			''
			''
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			'Update tblMessage Set InvoiceID = NULL WHERE InvoiceID = InvoiceID for Message Corrected 
			'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			''
			'Try
			'	Dim cmdInvoice As New SqlCommand("Update tblMessage SET InvoiceID = NULL WHERE InvoiceID = " & grdMessageList.Item("InvoiceID", grdMessageList.CurrentRow.Index).Value, conSql)
			'	conSql.Open()
			'	cmdInvoice.ExecuteNonQuery()
			'	conSql.Close()
			'Catch ex As Exception
			'	conSql.Close()
			'End Try
			''
			'filterGrid()
			RefreshGrid()
			btnSave.Enabled = True
		End If
	End Sub

	'Private Sub UpdateClientBalance()
	'	''
	'	'Dim TotalCharge As Decimal
	'	'Dim AcctCurrID As Integer = GetAcctCurrency(cboClient.SelectedValue)

	'	'If GetOperation(cboCurrency.SelectedValue, AcctCurrID, dtpInvoiceDate.Value) = "/" Then

	'	'	TotalCharge = Decimal.Parse(txtTotal.Text) / GetRate(cboCurrency.SelectedValue, AcctCurrID, dtpInvoiceDate.Value)
	'	'Else
	'	'	If txtTotal.Text <> String.Empty Then
	'	'		TotalCharge = Decimal.Parse(txtTotal.Text) * GetRate(cboCurrency.SelectedValue, AcctCurrID, dtpInvoiceDate.Value)
	'	'	End If
	'	'End If

	'	'Return TotalCharge

	'	Dim command As New SqlClient.SqlCommand
	'	command.CommandText = "SpUpdateClientBalance"

	'	Try
	'		command.Connection = conSql
	'		command.CommandType = CommandType.StoredProcedure
	'		''
	'		'If cboStatus.SelectedValue = 2 Then	''close --> add balance
	'		'	command.Parameters.AddWithValue("@balance", TotalCharge)
	'		'Else
	'		'If cboStatus.SelectedValue = 3 Then
	'		command.Parameters.AddWithValue("@balance", -dblAmount)
	'		'End If
	'		'End If
	'		''
	'		'If mCorrectInvoice Then
	'		'	command.Parameters.AddWithValue("@balance", -TotalCharge)
	'		'End If
	'		' ''
	'		command.Parameters.AddWithValue("@ClientID", intClientID)
	'		conSql.Open()
	'		command.ExecuteNonQuery()
	'		conSql.Close()
	'	Catch ex As Exception
	'		conSql.Close()
	'	End Try


	'End Sub

#End Region


#Region " Grid-Filter..."

	Private Sub cboClient_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyUp
		filterGrid()
	End Sub

	Private Sub cboClient_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
		''
		If blnLoading = True Then Exit Sub
		''
		filterGrid()
		EnableButtonsMessage()
		checkValues()
		LockGrid()
	End Sub

	Private Sub cboClient_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboClient.TextChanged
		If blnLoading = True Then Exit Sub
		filterGrid()
		EnableButtonsMessage()
		checkValues()
		LockGrid()
	End Sub

	Private Sub cboMonth_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.TextChanged
		''
		If cboMonth.Text = "" Then
			grdMessageList.ReadOnly = True
		Else
			grdMessageList.ReadOnly = False
			'InvoiceNumber Read Only
			grdMessageList.Columns("InvoiceNumber").ReadOnly = True
		End If
	End Sub

	Private Sub cboMonth_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboMonth.KeyUp
		filterGrid()
	End Sub

	Private Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
		If blnLoading = True Then Exit Sub
		''
		filterGrid()
		''
		If cboMonth.SelectedIndex <> -1 And rdbEnterNewCBM.Checked Then
			grdMessageList.ReadOnly = False
			grdMessageList.Columns("InvoiceNumber").ReadOnly = True
		Else
			grdMessageList.ReadOnly = True
		End If
		''
		EnableButtonsMessage()
		''
		checkValues()
	End Sub

	Private Sub nupYear_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles nupYear.ValueChanged
		filterGrid()
	End Sub

	Private Sub chkShowAll_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkShowAll.CheckStateChanged
		chkShowInvoice.Checked = False
		If Me.chkShowAll.Checked Then
			Me.btnAutoGenerateInvoice.Enabled = False
			grdMessageList.Columns("InvoiceNumber").Visible = True
			grdMessageList.Columns("InvoiceNumber").ReadOnly = True
		Else
			grdMessageList.Columns("InvoiceNumber").Visible = False
		End If
		filterGrid()

	End Sub

	Private Sub rdbCBMInvoice_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbCBMInvoice.CheckedChanged
		''
		If blnLoading = True Then Exit Sub

		If Me.rdbEnterNewCBM.Checked Then
			'	Me.cboClient.Enabled = False
			grdMessageList.ReadOnly = False
			grdMessageList.Columns("InvoiceNumber").ReadOnly = True
			btnAutoGenerateInvoice.Enabled = False
			grdMessageList.Columns("Day").Visible = True
			grdMessageList.Columns("MessageDate").Visible = False
		Else
			cboClient.Enabled = True
			grdMessageList.ReadOnly = True
			'Me.btnAutoGenerateInvoice.Enabled = True
			grdMessageList.Columns("Day").Visible = False
			grdMessageList.Columns("MessageDate").Visible = True
		End If
		EnableButtonsMessage()
		checkValues()
	End Sub

	Private Sub rdbEnterNewCBM_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbEnterNewCBM.CheckedChanged
		''
		If blnLoading = True Then Exit Sub
		''
		If Me.rdbEnterNewCBM.Checked Then
			'Me.cboClient.Enabled = False
			If chkShowAll.Checked Or chkShowInvoice.Checked Then
				btnAutoGenerateInvoice.Enabled = False
			End If
			If cboMonth.SelectedIndex <> -1 Then
				grdMessageList.ReadOnly = False
				grdMessageList.Columns("InvoiceNumber").ReadOnly = True
			Else
				grdMessageList.ReadOnly = True
			End If
			btnAutoGenerateInvoice.Enabled = False
			grdMessageList.Columns("Day").Visible = True
			grdMessageList.Columns("MessageDate").Visible = False
		Else
			cboClient.Enabled = True
			grdMessageList.ReadOnly = True
			grdMessageList.Columns("Day").Visible = False
			grdMessageList.Columns("MessageDate").Visible = True
			save()
			filterGrid()
		End If
		EnableButtonsMessage()
		checkValues()
		''
		LockGrid()
	End Sub

	Private Sub chkShowInvoice_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkShowInvoice.CheckStateChanged
		chkShowAll.Checked = False
		grdMessageList.Columns("InvoiceNumber").Visible = True
		grdMessageList.Columns("InvoiceNumber").ReadOnly = True
		filterGrid()
		btnAutoGenerateInvoice.Enabled = False
	End Sub

	Private Sub filterGrid()
		''
		If blnLoading = True Then Exit Sub
		''
		Dim s As String = String.Empty
		Dim sd As Date
		Dim ed As Date

		If rdbCBMInvoice.Checked Then
			If cboClient.SelectedIndex <> -1 Then
				s = " (ClientID = " & cboClient.SelectedValue & ")"
			Else
				If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
					s = " (ClientID = " & -1 & ")"
				End If
			End If
		End If
		If cboMonth.SelectedIndex = -1 Then
			sd = New Date(nupYear.Value, 1, 1)
			ed = sd.AddYears(1)
			If s <> String.Empty Then
				s = s & " AND "
			End If
			s = s & " (MessageDate >='" & sd.ToString("yyyy-M-d") & "' AND MessageDate <'" & ed.ToString("yyyy-M-d") & "')"
		Else
			sd = New Date(nupYear.Value, cboMonth.SelectedIndex + 1, 1)
			ed = sd.AddMonths(1)
			If s <> String.Empty Then
				s = s & " AND "
			End If
			s = s & " (MessageDate >='" & sd.ToString("yyyy-M-d") & "' AND MessageDate <'" & ed.ToString("yyyy-M-d") & "')"
		End If
		''
		If txtInvoiceNum.Text <> String.Empty Then
			Dim tn As Integer
			Try
				tn = Convert.ToInt32(txtInvoiceNum.Text)
				s = s & " AND  (InvoiceNumber = " & tn & ")"
			Catch ex As Exception
				txtInvoiceNum.Text = ""
			End Try
		End If
		''
		If (Me.chkShowAll.Checked = False) And Me.chkShowInvoice.Checked = False Then
			If s <> String.Empty Then
				s = s & " AND "
			End If
			s = s & " (InvoiceID IS NULL)"

		End If
		If (Me.chkShowInvoice.Checked = True) And chkShowAll.Checked = False Then
			If s <> String.Empty Then
				s = s & " AND "
			End If
			s = s & " (InvoiceID IS Not NULL)"

		End If

		dsdata.Tables("vwInvoiceMessage").DefaultView.RowFilter = s
		UpdateTotal()
		updateGridMessage()
		EnableButtonsMessage()
	End Sub


#End Region


End Class