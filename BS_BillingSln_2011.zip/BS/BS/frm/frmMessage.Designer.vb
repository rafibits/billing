<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMessage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.lblInvoiceNum = New System.Windows.Forms.Label
        Me.txtInvoiceNum = New System.Windows.Forms.TextBox
        Me.chkShowInvoice = New System.Windows.Forms.CheckBox
        Me.chkShowAll = New System.Windows.Forms.CheckBox
        Me.nupYear = New System.Windows.Forms.NumericUpDown
        Me.cboMonth = New System.Windows.Forms.ComboBox
        Me.lblMonth = New System.Windows.Forms.Label
        Me.lblYear = New System.Windows.Forms.Label
        Me.lblClient = New System.Windows.Forms.Label
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.lblTotal = New System.Windows.Forms.Label
        Me.txtTotal = New System.Windows.Forms.TextBox
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.grpGrid = New System.Windows.Forms.GroupBox
        Me.grdMessageList = New System.Windows.Forms.DataGridView
        Me.Day = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.lblCurrSymbol2 = New System.Windows.Forms.Label
        Me.lblTotalCurr2 = New System.Windows.Forms.Label
        Me.txtTotalCurr2 = New System.Windows.Forms.TextBox
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnRefresh = New BHBut.BouncingHoverButton
        Me.btnClear = New BHBut.BouncingHoverButton
        Me.btnSaveClear = New BHBut.BouncingHoverButton
        Me.btnPreviewAllInMsgs = New BHBut.BouncingHoverButton
        Me.lblTotalAmount = New System.Windows.Forms.Label
        Me.txtTotalAmount = New System.Windows.Forms.TextBox
        Me.btnAutoGenerateInvoice = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnPrint = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.rdbEnterNewCBM = New System.Windows.Forms.RadioButton
        Me.rdbCBMInvoice = New System.Windows.Forms.RadioButton
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.grpFilter.SuspendLayout()
        CType(Me.nupYear, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpShowHideColumns.SuspendLayout()
        Me.grpGrid.SuspendLayout()
        CType(Me.grdMessageList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(959, 3)
        Me.pnlTitle.TabIndex = 0
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(959, 40)
        Me.lblfrmTitle.TabIndex = 350
        Me.lblfrmTitle.Text = "Class-B Messages"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.lblInvoiceNum)
        Me.grpFilter.Controls.Add(Me.txtInvoiceNum)
        Me.grpFilter.Controls.Add(Me.chkShowInvoice)
        Me.grpFilter.Controls.Add(Me.chkShowAll)
        Me.grpFilter.Controls.Add(Me.nupYear)
        Me.grpFilter.Controls.Add(Me.cboMonth)
        Me.grpFilter.Controls.Add(Me.lblMonth)
        Me.grpFilter.Controls.Add(Me.lblYear)
        Me.grpFilter.Controls.Add(Me.lblClient)
        Me.grpFilter.Controls.Add(Me.cboClient)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(2, 49)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(945, 46)
        Me.grpFilter.TabIndex = 1
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Data Filter"
        '
        'lblInvoiceNum
        '
        Me.lblInvoiceNum.AutoSize = True
        Me.lblInvoiceNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblInvoiceNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblInvoiceNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInvoiceNum.Location = New System.Drawing.Point(551, 19)
        Me.lblInvoiceNum.Name = "lblInvoiceNum"
        Me.lblInvoiceNum.Size = New System.Drawing.Size(52, 13)
        Me.lblInvoiceNum.TabIndex = 156
        Me.lblInvoiceNum.Text = "Invoice #"
        Me.lblInvoiceNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtInvoiceNum
        '
        Me.txtInvoiceNum.ForeColor = System.Drawing.Color.Navy
        Me.txtInvoiceNum.Location = New System.Drawing.Point(607, 17)
        Me.txtInvoiceNum.Name = "txtInvoiceNum"
        Me.txtInvoiceNum.Size = New System.Drawing.Size(89, 20)
        Me.txtInvoiceNum.TabIndex = 157
        Me.txtInvoiceNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkShowInvoice
        '
        Me.chkShowInvoice.AutoSize = True
        Me.chkShowInvoice.ForeColor = System.Drawing.Color.Maroon
        Me.chkShowInvoice.Location = New System.Drawing.Point(788, 19)
        Me.chkShowInvoice.Name = "chkShowInvoice"
        Me.chkShowInvoice.Size = New System.Drawing.Size(103, 17)
        Me.chkShowInvoice.TabIndex = 16
        Me.chkShowInvoice.Text = "chkShowInvoice"
        Me.chkShowInvoice.UseVisualStyleBackColor = True
        '
        'chkShowAll
        '
        Me.chkShowAll.AutoSize = True
        Me.chkShowAll.ForeColor = System.Drawing.Color.Maroon
        Me.chkShowAll.Location = New System.Drawing.Point(707, 19)
        Me.chkShowAll.Name = "chkShowAll"
        Me.chkShowAll.Size = New System.Drawing.Size(66, 17)
        Me.chkShowAll.TabIndex = 3
        Me.chkShowAll.Text = "Show All"
        Me.chkShowAll.UseVisualStyleBackColor = True
        '
        'nupYear
        '
        Me.nupYear.Location = New System.Drawing.Point(495, 17)
        Me.nupYear.Maximum = New Decimal(New Integer() {2100, 0, 0, 0})
        Me.nupYear.Minimum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.nupYear.Name = "nupYear"
        Me.nupYear.Size = New System.Drawing.Size(51, 20)
        Me.nupYear.TabIndex = 2
        Me.nupYear.Value = New Decimal(New Integer() {2000, 0, 0, 0})
        '
        'cboMonth
        '
        Me.cboMonth.FormattingEnabled = True
        Me.cboMonth.Items.AddRange(New Object() {"Januray", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"})
        Me.cboMonth.Location = New System.Drawing.Point(340, 17)
        Me.cboMonth.Name = "cboMonth"
        Me.cboMonth.Size = New System.Drawing.Size(121, 21)
        Me.cboMonth.TabIndex = 6
        '
        'lblMonth
        '
        Me.lblMonth.AutoSize = True
        Me.lblMonth.ForeColor = System.Drawing.Color.Maroon
        Me.lblMonth.Location = New System.Drawing.Point(301, 19)
        Me.lblMonth.Name = "lblMonth"
        Me.lblMonth.Size = New System.Drawing.Size(37, 13)
        Me.lblMonth.TabIndex = 15
        Me.lblMonth.Text = "Month"
        Me.lblMonth.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.ForeColor = System.Drawing.Color.Maroon
        Me.lblYear.Location = New System.Drawing.Point(464, 19)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(29, 13)
        Me.lblYear.TabIndex = 7
        Me.lblYear.Text = "Year"
        Me.lblYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblClient
        '
        Me.lblClient.AutoSize = True
        Me.lblClient.ForeColor = System.Drawing.Color.Maroon
        Me.lblClient.Location = New System.Drawing.Point(2, 19)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(34, 13)
        Me.lblClient.TabIndex = 5
        Me.lblClient.Text = "Client"
        Me.lblClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboClient
        '
        Me.cboClient.ForeColor = System.Drawing.Color.Maroon
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(37, 17)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(256, 21)
        Me.cboClient.TabIndex = 0
        '
        'lblTotal
        '
        Me.lblTotal.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotal.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblTotal.Location = New System.Drawing.Point(380, 62)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(57, 20)
        Me.lblTotal.TabIndex = 358
        Me.lblTotal.Text = "Total"
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTotal
        '
        Me.txtTotal.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotal.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotal.Location = New System.Drawing.Point(449, 61)
        Me.txtTotal.Multiline = True
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(105, 23)
        Me.txtTotal.TabIndex = 359
        Me.txtTotal.TabStop = False
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(52, 21)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(180, 306)
        Me.grpShowHideColumns.TabIndex = 2
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 276)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(167, 27)
        Me.btnSaveSettings.TabIndex = 1
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(167, 259)
        Me.chkLstGridCol.TabIndex = 0
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(12, 19)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 1
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'grpGrid
        '
        Me.grpGrid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpGrid.Controls.Add(Me.grpShowHideColumns)
        Me.grpGrid.Controls.Add(Me.btnShowCol)
        Me.grpGrid.Controls.Add(Me.grdMessageList)
        Me.grpGrid.Location = New System.Drawing.Point(2, 92)
        Me.grpGrid.Name = "grpGrid"
        Me.grpGrid.Size = New System.Drawing.Size(945, 409)
        Me.grpGrid.TabIndex = 2
        Me.grpGrid.TabStop = False
        '
        'grdMessageList
        '
        Me.grdMessageList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdMessageList.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdMessageList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdMessageList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Day})
        Me.grdMessageList.Location = New System.Drawing.Point(10, 16)
        Me.grdMessageList.Name = "grdMessageList"
        Me.grdMessageList.Size = New System.Drawing.Size(928, 381)
        Me.grdMessageList.TabIndex = 152
        '
        'Day
        '
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.Format = "N0"
        DataGridViewCellStyle1.NullValue = Nothing
        Me.Day.DefaultCellStyle = DataGridViewCellStyle1
        Me.Day.HeaderText = "Day"
        Me.Day.Name = "Day"
        Me.Day.Width = 90
        '
        'lblCurrSymbol2
        '
        Me.lblCurrSymbol2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol2.ForeColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol2.Location = New System.Drawing.Point(556, 124)
        Me.lblCurrSymbol2.Name = "lblCurrSymbol2"
        Me.lblCurrSymbol2.Size = New System.Drawing.Size(45, 20)
        Me.lblCurrSymbol2.TabIndex = 363
        Me.lblCurrSymbol2.Text = "Curr"
        Me.lblCurrSymbol2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTotalCurr2
        '
        Me.lblTotalCurr2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalCurr2.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotalCurr2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblTotalCurr2.Location = New System.Drawing.Point(380, 124)
        Me.lblTotalCurr2.Name = "lblTotalCurr2"
        Me.lblTotalCurr2.Size = New System.Drawing.Size(57, 20)
        Me.lblTotalCurr2.TabIndex = 361
        Me.lblTotalCurr2.Text = "Total"
        Me.lblTotalCurr2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTotalCurr2
        '
        Me.txtTotalCurr2.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalCurr2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalCurr2.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalCurr2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalCurr2.Location = New System.Drawing.Point(443, 121)
        Me.txtTotalCurr2.Multiline = True
        Me.txtTotalCurr2.Name = "txtTotalCurr2"
        Me.txtTotalCurr2.ReadOnly = True
        Me.txtTotalCurr2.Size = New System.Drawing.Size(105, 23)
        Me.txtTotalCurr2.TabIndex = 362
        Me.txtTotalCurr2.TabStop = False
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnRefresh)
        Me.grpButtons.Controls.Add(Me.btnClear)
        Me.grpButtons.Controls.Add(Me.btnSaveClear)
        Me.grpButtons.Controls.Add(Me.btnPreviewAllInMsgs)
        Me.grpButtons.Controls.Add(Me.lblTotalAmount)
        Me.grpButtons.Controls.Add(Me.txtTotalAmount)
        Me.grpButtons.Controls.Add(Me.btnAutoGenerateInvoice)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnPrint)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Location = New System.Drawing.Point(2, 507)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(945, 53)
        Me.grpButtons.TabIndex = 3
        Me.grpButtons.TabStop = False
        '
        'btnRefresh
        '
        Me.btnRefresh.AlternativeGroup = Nothing
        Me.btnRefresh.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnRefresh.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnRefresh.BackColor1 = System.Drawing.Color.White
        Me.btnRefresh.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnRefresh.BorderHover = True
        Me.btnRefresh.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnRefresh.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnRefresh.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnRefresh.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnRefresh.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnRefresh.DrawBorder = True
        Me.btnRefresh.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnRefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnRefresh.ForeColor = System.Drawing.Color.Navy
        Me.btnRefresh.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnRefresh.HoverColor2 = System.Drawing.Color.White
        Me.btnRefresh.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnRefresh.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnRefresh.Location = New System.Drawing.Point(716, 16)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnRefresh.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnRefresh.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnRefresh.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnRefresh.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnRefresh.SelectedText = Nothing
        Me.btnRefresh.Size = New System.Drawing.Size(88, 27)
        Me.btnRefresh.TabIndex = 367
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.AlternativeGroup = Nothing
        Me.btnClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnClear.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnClear.BackColor1 = System.Drawing.Color.White
        Me.btnClear.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnClear.BorderHover = True
        Me.btnClear.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClear.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClear.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClear.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClear.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClear.DrawBorder = True
        Me.btnClear.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClear.ForeColor = System.Drawing.Color.Navy
        Me.btnClear.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnClear.HoverColor2 = System.Drawing.Color.White
        Me.btnClear.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClear.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClear.Location = New System.Drawing.Point(626, 16)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnClear.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnClear.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnClear.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClear.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnClear.SelectedText = Nothing
        Me.btnClear.Size = New System.Drawing.Size(88, 27)
        Me.btnClear.TabIndex = 366
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnSaveClear
        '
        Me.btnSaveClear.AlternativeGroup = Nothing
        Me.btnSaveClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSaveClear.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSaveClear.BackColor1 = System.Drawing.Color.White
        Me.btnSaveClear.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSaveClear.BorderHover = True
        Me.btnSaveClear.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSaveClear.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSaveClear.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSaveClear.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSaveClear.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSaveClear.DrawBorder = True
        Me.btnSaveClear.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSaveClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSaveClear.ForeColor = System.Drawing.Color.Navy
        Me.btnSaveClear.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSaveClear.HoverColor2 = System.Drawing.Color.White
        Me.btnSaveClear.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSaveClear.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSaveClear.Location = New System.Drawing.Point(96, 16)
        Me.btnSaveClear.Name = "btnSaveClear"
        Me.btnSaveClear.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSaveClear.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSaveClear.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSaveClear.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSaveClear.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSaveClear.SelectedText = Nothing
        Me.btnSaveClear.Size = New System.Drawing.Size(88, 27)
        Me.btnSaveClear.TabIndex = 153
        Me.btnSaveClear.Text = "Save&Clear"
        Me.btnSaveClear.UseVisualStyleBackColor = False
        '
        'btnPreviewAllInMsgs
        '
        Me.btnPreviewAllInMsgs.AlternativeGroup = Nothing
        Me.btnPreviewAllInMsgs.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPreviewAllInMsgs.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPreviewAllInMsgs.BackColor1 = System.Drawing.Color.White
        Me.btnPreviewAllInMsgs.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPreviewAllInMsgs.BorderHover = True
        Me.btnPreviewAllInMsgs.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPreviewAllInMsgs.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPreviewAllInMsgs.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPreviewAllInMsgs.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPreviewAllInMsgs.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPreviewAllInMsgs.DrawBorder = True
        Me.btnPreviewAllInMsgs.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPreviewAllInMsgs.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPreviewAllInMsgs.ForeColor = System.Drawing.Color.Navy
        Me.btnPreviewAllInMsgs.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreviewAllInMsgs.HoverColor2 = System.Drawing.Color.White
        Me.btnPreviewAllInMsgs.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPreviewAllInMsgs.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPreviewAllInMsgs.Location = New System.Drawing.Point(536, 16)
        Me.btnPreviewAllInMsgs.Name = "btnPreviewAllInMsgs"
        Me.btnPreviewAllInMsgs.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreviewAllInMsgs.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPreviewAllInMsgs.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPreviewAllInMsgs.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPreviewAllInMsgs.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPreviewAllInMsgs.SelectedText = Nothing
        Me.btnPreviewAllInMsgs.Size = New System.Drawing.Size(88, 27)
        Me.btnPreviewAllInMsgs.TabIndex = 3
        Me.btnPreviewAllInMsgs.Text = "Report"
        Me.btnPreviewAllInMsgs.UseVisualStyleBackColor = False
        '
        'lblTotalAmount
        '
        Me.lblTotalAmount.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblTotalAmount.AutoSize = True
        Me.lblTotalAmount.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotalAmount.Location = New System.Drawing.Point(798, 5)
        Me.lblTotalAmount.Name = "lblTotalAmount"
        Me.lblTotalAmount.Size = New System.Drawing.Size(71, 13)
        Me.lblTotalAmount.TabIndex = 371
        Me.lblTotalAmount.Text = "Total Amount"
        Me.lblTotalAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblTotalAmount.Visible = False
        '
        'txtTotalAmount
        '
        Me.txtTotalAmount.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtTotalAmount.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalAmount.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalAmount.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalAmount.Location = New System.Drawing.Point(810, 21)
        Me.txtTotalAmount.Multiline = True
        Me.txtTotalAmount.Name = "txtTotalAmount"
        Me.txtTotalAmount.ReadOnly = True
        Me.txtTotalAmount.Size = New System.Drawing.Size(35, 22)
        Me.txtTotalAmount.TabIndex = 368
        Me.txtTotalAmount.TabStop = False
        Me.txtTotalAmount.Visible = False
        '
        'btnAutoGenerateInvoice
        '
        Me.btnAutoGenerateInvoice.AlternativeGroup = Nothing
        Me.btnAutoGenerateInvoice.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnAutoGenerateInvoice.BackColor = System.Drawing.Color.Red
        Me.btnAutoGenerateInvoice.BackColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.BackColor2 = System.Drawing.Color.Red
        Me.btnAutoGenerateInvoice.BorderHover = True
        Me.btnAutoGenerateInvoice.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnAutoGenerateInvoice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnAutoGenerateInvoice.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnAutoGenerateInvoice.DrawBorder = True
        Me.btnAutoGenerateInvoice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnAutoGenerateInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAutoGenerateInvoice.ForeColor = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.HoverColor2 = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnAutoGenerateInvoice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnAutoGenerateInvoice.Location = New System.Drawing.Point(277, 16)
        Me.btnAutoGenerateInvoice.Name = "btnAutoGenerateInvoice"
        Me.btnAutoGenerateInvoice.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnAutoGenerateInvoice.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnAutoGenerateInvoice.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.SelectedText = Nothing
        Me.btnAutoGenerateInvoice.Size = New System.Drawing.Size(257, 28)
        Me.btnAutoGenerateInvoice.TabIndex = 2
        Me.btnAutoGenerateInvoice.Text = "Generate Invoice for Above Selection"
        Me.btnAutoGenerateInvoice.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(5, 16)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(88, 27)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "S a v e"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnPrint
        '
        Me.btnPrint.AlternativeGroup = Nothing
        Me.btnPrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPrint.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPrint.BackColor1 = System.Drawing.Color.White
        Me.btnPrint.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPrint.BorderHover = True
        Me.btnPrint.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPrint.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPrint.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPrint.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPrint.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPrint.DrawBorder = True
        Me.btnPrint.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPrint.ForeColor = System.Drawing.Color.Navy
        Me.btnPrint.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.HoverColor2 = System.Drawing.Color.White
        Me.btnPrint.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPrint.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPrint.Location = New System.Drawing.Point(186, 16)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPrint.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPrint.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPrint.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.SelectedText = Nothing
        Me.btnPrint.Size = New System.Drawing.Size(88, 27)
        Me.btnPrint.TabIndex = 1
        Me.btnPrint.Text = "Preview"
        Me.btnPrint.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(854, 16)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(88, 27)
        Me.btnClose.TabIndex = 4
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'rdbEnterNewCBM
        '
        Me.rdbEnterNewCBM.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar
        Me.rdbEnterNewCBM.AutoSize = True
        Me.rdbEnterNewCBM.BackColor = System.Drawing.Color.LightSteelBlue
        Me.rdbEnterNewCBM.Checked = True
        Me.rdbEnterNewCBM.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdbEnterNewCBM.ForeColor = System.Drawing.Color.LightYellow
        Me.rdbEnterNewCBM.Location = New System.Drawing.Point(186, 16)
        Me.rdbEnterNewCBM.Name = "rdbEnterNewCBM"
        Me.rdbEnterNewCBM.Size = New System.Drawing.Size(191, 20)
        Me.rdbEnterNewCBM.TabIndex = 364
        Me.rdbEnterNewCBM.TabStop = True
        Me.rdbEnterNewCBM.Text = "Enter New Class-B Messages"
        Me.rdbEnterNewCBM.UseVisualStyleBackColor = False
        '
        'rdbCBMInvoice
        '
        Me.rdbCBMInvoice.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar
        Me.rdbCBMInvoice.AutoSize = True
        Me.rdbCBMInvoice.BackColor = System.Drawing.Color.LightSteelBlue
        Me.rdbCBMInvoice.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdbCBMInvoice.ForeColor = System.Drawing.Color.LightYellow
        Me.rdbCBMInvoice.Location = New System.Drawing.Point(407, 16)
        Me.rdbCBMInvoice.Name = "rdbCBMInvoice"
        Me.rdbCBMInvoice.Size = New System.Drawing.Size(172, 20)
        Me.rdbCBMInvoice.TabIndex = 365
        Me.rdbCBMInvoice.Text = "Invoice Class-B Messages"
        Me.rdbCBMInvoice.UseVisualStyleBackColor = False
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(896, 9)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(52, 25)
        Me.btnDataErr.TabIndex = 5
        Me.btnDataErr.TabStop = False
        Me.btnDataErr.Text = "E r r o r"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(697, 14)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(198, 17)
        Me.lstDataErr.TabIndex = 4
        Me.lstDataErr.TabStop = False
        Me.lstDataErr.Visible = False
        '
        'frmMessage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(959, 572)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.rdbCBMInvoice)
        Me.Controls.Add(Me.rdbEnterNewCBM)
        Me.Controls.Add(Me.grpFilter)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grpGrid)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.txtTotalCurr2)
        Me.Controls.Add(Me.lblCurrSymbol2)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.lblTotalCurr2)
        Me.Controls.Add(Me.lblTotal)
        Me.KeyPreview = True
        Me.Name = "frmMessage"
        Me.Text = "Class-B  Messages"
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        CType(Me.nupYear, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.grpGrid.ResumeLayout(False)
        CType(Me.grdMessageList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpButtons.ResumeLayout(False)
        Me.grpButtons.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
	Friend WithEvents pnlTitle As System.Windows.Forms.Panel
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
	Friend WithEvents lblYear As System.Windows.Forms.Label
	Friend WithEvents lblClient As System.Windows.Forms.Label
	Friend WithEvents cboClient As System.Windows.Forms.ComboBox
	Friend WithEvents lblTotal As System.Windows.Forms.Label
	Friend WithEvents txtTotal As System.Windows.Forms.TextBox
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
	Friend WithEvents btnShowCol As System.Windows.Forms.Button
	Friend WithEvents grpGrid As System.Windows.Forms.GroupBox
	Friend WithEvents lblCurrSymbol2 As System.Windows.Forms.Label
	Friend WithEvents lblTotalCurr2 As System.Windows.Forms.Label
	Friend WithEvents txtTotalCurr2 As System.Windows.Forms.TextBox
	Friend WithEvents grdMessageList As System.Windows.Forms.DataGridView
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
	Friend WithEvents btnPrint As BHBut.BouncingHoverButton
	Friend WithEvents btnSave As BHBut.BouncingHoverButton
	Friend WithEvents lblMonth As System.Windows.Forms.Label
	Friend WithEvents cboMonth As System.Windows.Forms.ComboBox
	Friend WithEvents nupYear As System.Windows.Forms.NumericUpDown
	Friend WithEvents btnAutoGenerateInvoice As BHBut.BouncingHoverButton
	Friend WithEvents txtTotalAmount As System.Windows.Forms.TextBox
	Friend WithEvents lblTotalAmount As System.Windows.Forms.Label
	Friend WithEvents chkShowAll As System.Windows.Forms.CheckBox
	Friend WithEvents rdbEnterNewCBM As System.Windows.Forms.RadioButton
	Friend WithEvents rdbCBMInvoice As System.Windows.Forms.RadioButton
	Friend WithEvents btnDataErr As System.Windows.Forms.Button
	Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
	Friend WithEvents btnPreviewAllInMsgs As BHBut.BouncingHoverButton
	Friend WithEvents Day As System.Windows.Forms.DataGridViewTextBoxColumn
	Friend WithEvents chkShowInvoice As System.Windows.Forms.CheckBox
	Friend WithEvents btnSaveClear As BHBut.BouncingHoverButton
	Friend WithEvents btnClear As BHBut.BouncingHoverButton
	Friend WithEvents btnRefresh As BHBut.BouncingHoverButton
	Friend WithEvents lblInvoiceNum As System.Windows.Forms.Label
	Friend WithEvents txtInvoiceNum As System.Windows.Forms.TextBox
End Class
