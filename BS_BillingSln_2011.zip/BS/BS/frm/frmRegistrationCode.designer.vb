<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRegistrationCode
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing AndAlso components IsNot Nothing Then
			components.Dispose()
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.txt6 = New System.Windows.Forms.TextBox
		Me.txt4 = New System.Windows.Forms.TextBox
		Me.txt5 = New System.Windows.Forms.TextBox
		Me.txt3 = New System.Windows.Forms.TextBox
		Me.txt1 = New System.Windows.Forms.TextBox
		Me.txt2 = New System.Windows.Forms.TextBox
		Me.grpHDDData = New System.Windows.Forms.GroupBox
		Me.lblMsg = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me.txt6OK = New System.Windows.Forms.TextBox
		Me.txt4OK = New System.Windows.Forms.TextBox
		Me.txt5OK = New System.Windows.Forms.TextBox
		Me.txt3OK = New System.Windows.Forms.TextBox
		Me.txt1OK = New System.Windows.Forms.TextBox
		Me.txt2OK = New System.Windows.Forms.TextBox
		Me.btnNext = New System.Windows.Forms.Button
		Me.grpHDDData.SuspendLayout()
		Me.SuspendLayout()
		'
		'txt6
		'
		Me.txt6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt6.ForeColor = System.Drawing.Color.Maroon
		Me.txt6.Location = New System.Drawing.Point(552, 52)
		Me.txt6.Name = "txt6"
		Me.txt6.Size = New System.Drawing.Size(101, 23)
		Me.txt6.TabIndex = 6
		Me.txt6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'txt4
		'
		Me.txt4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt4.ForeColor = System.Drawing.Color.Maroon
		Me.txt4.Location = New System.Drawing.Point(338, 52)
		Me.txt4.Name = "txt4"
		Me.txt4.Size = New System.Drawing.Size(101, 23)
		Me.txt4.TabIndex = 4
		Me.txt4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'txt5
		'
		Me.txt5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt5.ForeColor = System.Drawing.Color.Maroon
		Me.txt5.Location = New System.Drawing.Point(445, 52)
		Me.txt5.Name = "txt5"
		Me.txt5.Size = New System.Drawing.Size(101, 23)
		Me.txt5.TabIndex = 5
		Me.txt5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'txt3
		'
		Me.txt3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt3.ForeColor = System.Drawing.Color.Maroon
		Me.txt3.Location = New System.Drawing.Point(231, 52)
		Me.txt3.Name = "txt3"
		Me.txt3.Size = New System.Drawing.Size(101, 23)
		Me.txt3.TabIndex = 3
		Me.txt3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'txt1
		'
		Me.txt1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt1.ForeColor = System.Drawing.Color.Maroon
		Me.txt1.Location = New System.Drawing.Point(17, 52)
		Me.txt1.Name = "txt1"
		Me.txt1.Size = New System.Drawing.Size(101, 23)
		Me.txt1.TabIndex = 1
		Me.txt1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'txt2
		'
		Me.txt2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt2.ForeColor = System.Drawing.Color.Maroon
		Me.txt2.Location = New System.Drawing.Point(124, 52)
		Me.txt2.Name = "txt2"
		Me.txt2.Size = New System.Drawing.Size(101, 23)
		Me.txt2.TabIndex = 2
		Me.txt2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'grpHDDData
		'
		Me.grpHDDData.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
		Me.grpHDDData.Controls.Add(Me.lblMsg)
		Me.grpHDDData.Controls.Add(Me.Label1)
		Me.grpHDDData.Controls.Add(Me.txt6)
		Me.grpHDDData.Controls.Add(Me.txt2)
		Me.grpHDDData.Controls.Add(Me.txt1)
		Me.grpHDDData.Controls.Add(Me.txt3)
		Me.grpHDDData.Controls.Add(Me.txt5)
		Me.grpHDDData.Controls.Add(Me.txt4)
		Me.grpHDDData.Location = New System.Drawing.Point(28, 111)
		Me.grpHDDData.Name = "grpHDDData"
		Me.grpHDDData.Size = New System.Drawing.Size(677, 136)
		Me.grpHDDData.TabIndex = 1
		Me.grpHDDData.TabStop = False
		'
		'lblMsg
		'
		Me.lblMsg.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblMsg.ForeColor = System.Drawing.Color.Snow
		Me.lblMsg.Location = New System.Drawing.Point(17, 90)
		Me.lblMsg.Name = "lblMsg"
		Me.lblMsg.Size = New System.Drawing.Size(636, 28)
		Me.lblMsg.TabIndex = 7
		Me.lblMsg.Text = "Please enter a valid registration code"
		Me.lblMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Label1
		'
		Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.ForeColor = System.Drawing.Color.Maroon
		Me.Label1.Location = New System.Drawing.Point(17, 26)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(636, 25)
		Me.Label1.TabIndex = 0
		Me.Label1.Text = "Registration Code"
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'Label4
		'
		Me.Label4.BackColor = System.Drawing.Color.Sienna
		Me.Label4.Dock = System.Windows.Forms.DockStyle.Top
		Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.ForeColor = System.Drawing.Color.WhiteSmoke
		Me.Label4.Location = New System.Drawing.Point(0, 0)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(746, 55)
		Me.Label4.TabIndex = 0
		Me.Label4.Text = " BIT Solutions Security Check - Registration Code"
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'txt6OK
		'
		Me.txt6OK.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.txt6OK.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.txt6OK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt6OK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
		Me.txt6OK.Location = New System.Drawing.Point(583, 31)
		Me.txt6OK.Name = "txt6OK"
		Me.txt6OK.Size = New System.Drawing.Size(101, 16)
		Me.txt6OK.TabIndex = 8
		Me.txt6OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'txt4OK
		'
		Me.txt4OK.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.txt4OK.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.txt4OK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt4OK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
		Me.txt4OK.Location = New System.Drawing.Point(369, 31)
		Me.txt4OK.Name = "txt4OK"
		Me.txt4OK.Size = New System.Drawing.Size(101, 16)
		Me.txt4OK.TabIndex = 6
		Me.txt4OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'txt5OK
		'
		Me.txt5OK.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.txt5OK.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.txt5OK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt5OK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
		Me.txt5OK.Location = New System.Drawing.Point(476, 31)
		Me.txt5OK.Name = "txt5OK"
		Me.txt5OK.Size = New System.Drawing.Size(101, 16)
		Me.txt5OK.TabIndex = 7
		Me.txt5OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'txt3OK
		'
		Me.txt3OK.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.txt3OK.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.txt3OK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt3OK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
		Me.txt3OK.Location = New System.Drawing.Point(262, 31)
		Me.txt3OK.Name = "txt3OK"
		Me.txt3OK.Size = New System.Drawing.Size(101, 16)
		Me.txt3OK.TabIndex = 5
		Me.txt3OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'txt1OK
		'
		Me.txt1OK.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.txt1OK.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.txt1OK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt1OK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
		Me.txt1OK.Location = New System.Drawing.Point(48, 31)
		Me.txt1OK.Name = "txt1OK"
		Me.txt1OK.Size = New System.Drawing.Size(101, 16)
		Me.txt1OK.TabIndex = 3
		Me.txt1OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'txt2OK
		'
		Me.txt2OK.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.txt2OK.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.txt2OK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txt2OK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
		Me.txt2OK.Location = New System.Drawing.Point(155, 31)
		Me.txt2OK.Name = "txt2OK"
		Me.txt2OK.Size = New System.Drawing.Size(101, 16)
		Me.txt2OK.TabIndex = 4
		Me.txt2OK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		'
		'btnNext
		'
		Me.btnNext.Enabled = False
		Me.btnNext.Location = New System.Drawing.Point(626, 269)
		Me.btnNext.Name = "btnNext"
		Me.btnNext.Size = New System.Drawing.Size(79, 30)
		Me.btnNext.TabIndex = 2
		Me.btnNext.Text = ">>"
		Me.btnNext.UseVisualStyleBackColor = True
		'
		'frmRegistrationCode
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(746, 346)
		Me.Controls.Add(Me.Label4)
		Me.Controls.Add(Me.btnNext)
		Me.Controls.Add(Me.grpHDDData)
		Me.Controls.Add(Me.txt6OK)
		Me.Controls.Add(Me.txt4OK)
		Me.Controls.Add(Me.txt5OK)
		Me.Controls.Add(Me.txt3OK)
		Me.Controls.Add(Me.txt1OK)
		Me.Controls.Add(Me.txt2OK)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.Name = "frmRegistrationCode"
		Me.Text = "Security Check"
		Me.grpHDDData.ResumeLayout(False)
		Me.grpHDDData.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents txt6 As System.Windows.Forms.TextBox
	Friend WithEvents txt4 As System.Windows.Forms.TextBox
	Friend WithEvents txt5 As System.Windows.Forms.TextBox
	Friend WithEvents txt3 As System.Windows.Forms.TextBox
	Friend WithEvents txt1 As System.Windows.Forms.TextBox
	Friend WithEvents txt2 As System.Windows.Forms.TextBox
	Friend WithEvents grpHDDData As System.Windows.Forms.GroupBox
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents txt6OK As System.Windows.Forms.TextBox
	Friend WithEvents txt4OK As System.Windows.Forms.TextBox
	Friend WithEvents txt5OK As System.Windows.Forms.TextBox
	Friend WithEvents txt3OK As System.Windows.Forms.TextBox
	Friend WithEvents txt1OK As System.Windows.Forms.TextBox
	Friend WithEvents txt2OK As System.Windows.Forms.TextBox
	Friend WithEvents btnNext As System.Windows.Forms.Button
	Friend WithEvents lblMsg As System.Windows.Forms.Label
End Class
