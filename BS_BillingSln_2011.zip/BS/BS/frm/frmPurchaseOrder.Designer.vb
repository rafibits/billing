<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPurchaseOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tcPurchaseOrder = New System.Windows.Forms.TabControl
        Me.tpPurchaseOrder = New System.Windows.Forms.TabPage
        Me.btnShowColPO = New System.Windows.Forms.Button
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnPreview = New BHBut.BouncingHoverButton
        Me.btnOpen = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnDelete = New BHBut.BouncingHoverButton
        Me.grdPO = New System.Windows.Forms.DataGridView
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.txtFilterPONum = New System.Windows.Forms.TextBox
        Me.grpFilterStatus = New System.Windows.Forms.GroupBox
        Me.chkFilterPosted = New System.Windows.Forms.CheckBox
        Me.chkFilterNew = New System.Windows.Forms.CheckBox
        Me.chkFilterUnposted = New System.Windows.Forms.CheckBox
        Me.lblPODate = New System.Windows.Forms.Label
        Me.dtpFilterFrom = New System.Windows.Forms.DateTimePicker
        Me.lblFrom = New System.Windows.Forms.Label
        Me.dtpFilterTo = New System.Windows.Forms.DateTimePicker
        Me.lblTo = New System.Windows.Forms.Label
        Me.cboFilterSupplier = New System.Windows.Forms.ComboBox
        Me.lblSupplier = New System.Windows.Forms.Label
        Me.pnlInvisibleFields = New System.Windows.Forms.Panel
        Me.txtPOVehExp = New System.Windows.Forms.TextBox
        Me.lblPOVehExp = New System.Windows.Forms.Label
        Me.txtPOExp = New System.Windows.Forms.TextBox
        Me.lblPOExp = New System.Windows.Forms.Label
        Me.txtPOID = New System.Windows.Forms.TextBox
        Me.lblPOID = New System.Windows.Forms.Label
        Me.tpPurchaseOrderDetail = New System.Windows.Forms.TabPage
        Me.btnShowColPODetails = New System.Windows.Forms.Button
        Me.grdPODetails = New System.Windows.Forms.DataGridView
        Me.grpTotals = New System.Windows.Forms.GroupBox
        Me.lblCompCurr = New System.Windows.Forms.Label
        Me.lblPOTotal = New System.Windows.Forms.Label
        Me.txtPOTotal = New System.Windows.Forms.TextBox
        Me.lblQuantity = New System.Windows.Forms.Label
        Me.lblTotal = New System.Windows.Forms.Label
        Me.txtExTotal = New System.Windows.Forms.TextBox
        Me.txtQuantity = New System.Windows.Forms.TextBox
        Me.lblTotalExpense = New System.Windows.Forms.Label
        Me.txtTotal = New System.Windows.Forms.TextBox
        Me.grpDetails = New System.Windows.Forms.GroupBox
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.txtPORate = New System.Windows.Forms.TextBox
        Me.lblRate = New System.Windows.Forms.Label
        Me.lblAcctCurrency = New System.Windows.Forms.Label
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.cboEmployee = New System.Windows.Forms.ComboBox
        Me.cboStatus = New System.Windows.Forms.ComboBox
        Me.lblStatus = New System.Windows.Forms.Label
        Me.dtpPODate = New System.Windows.Forms.DateTimePicker
        Me.lblDate = New System.Windows.Forms.Label
        Me.txtPONum = New System.Windows.Forms.TextBox
        Me.lblPONum = New System.Windows.Forms.Label
        Me.grpRefInvoice = New System.Windows.Forms.GroupBox
        Me.txtInvoiceNum = New System.Windows.Forms.TextBox
        Me.lblRedDate = New System.Windows.Forms.Label
        Me.lblRefNum = New System.Windows.Forms.Label
        Me.dtpInvDate = New System.Windows.Forms.DateTimePicker
        Me.cboAcctID = New System.Windows.Forms.ComboBox
        Me.lblPODetailSupplier = New System.Windows.Forms.Label
        Me.txtDescription = New System.Windows.Forms.TextBox
        Me.lblDescription = New System.Windows.Forms.Label
        Me.lblSalesPerson = New System.Windows.Forms.Label
        Me.grpPODetailsButtons = New System.Windows.Forms.GroupBox
        Me.btnRemoveVehicle = New BHBut.BouncingHoverButton
        Me.btnPOvehExpense = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.txtDiscount = New System.Windows.Forms.TextBox
        Me.lblDiscount = New System.Windows.Forms.Label
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnExpense = New BHBut.BouncingHoverButton
        Me.btnPost = New BHBut.BouncingHoverButton
        Me.btnVehicle = New BHBut.BouncingHoverButton
        Me.btnDetailClose = New BHBut.BouncingHoverButton
        Me.btnDeleteVeh = New BHBut.BouncingHoverButton
        Me.grpFindSupplier = New System.Windows.Forms.GroupBox
        Me.btnFindSupplier = New BHBut.BouncingHoverButton
        Me.btnSelect = New BHBut.BouncingHoverButton
        Me.lstAccountName = New System.Windows.Forms.ListBox
        Me.txtSearch = New System.Windows.Forms.TextBox
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label6 = New System.Windows.Forms.Label
        Me.lblHotKeys = New System.Windows.Forms.Label
        Me.tcPurchaseOrder.SuspendLayout()
        Me.tpPurchaseOrder.SuspendLayout()
        Me.grpButtons.SuspendLayout()
        CType(Me.grdPO, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpFilter.SuspendLayout()
        Me.grpFilterStatus.SuspendLayout()
        Me.pnlInvisibleFields.SuspendLayout()
        Me.tpPurchaseOrderDetail.SuspendLayout()
        CType(Me.grdPODetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpTotals.SuspendLayout()
        Me.grpDetails.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        Me.grpRefInvoice.SuspendLayout()
        Me.grpPODetailsButtons.SuspendLayout()
        Me.grpFindSupplier.SuspendLayout()
        Me.SuspendLayout()
        '
        'tcPurchaseOrder
        '
        Me.tcPurchaseOrder.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tcPurchaseOrder.Controls.Add(Me.tpPurchaseOrder)
        Me.tcPurchaseOrder.Controls.Add(Me.tpPurchaseOrderDetail)
        Me.tcPurchaseOrder.Location = New System.Drawing.Point(2, 43)
        Me.tcPurchaseOrder.Name = "tcPurchaseOrder"
        Me.tcPurchaseOrder.SelectedIndex = 0
        Me.tcPurchaseOrder.Size = New System.Drawing.Size(891, 366)
        Me.tcPurchaseOrder.TabIndex = 0
        '
        'tpPurchaseOrder
        '
        Me.tpPurchaseOrder.Controls.Add(Me.btnShowColPO)
        Me.tpPurchaseOrder.Controls.Add(Me.grpButtons)
        Me.tpPurchaseOrder.Controls.Add(Me.grdPO)
        Me.tpPurchaseOrder.Controls.Add(Me.grpFilter)
        Me.tpPurchaseOrder.Controls.Add(Me.pnlInvisibleFields)
        Me.tpPurchaseOrder.Location = New System.Drawing.Point(4, 22)
        Me.tpPurchaseOrder.Name = "tpPurchaseOrder"
        Me.tpPurchaseOrder.Padding = New System.Windows.Forms.Padding(3)
        Me.tpPurchaseOrder.Size = New System.Drawing.Size(883, 340)
        Me.tpPurchaseOrder.TabIndex = 0
        Me.tpPurchaseOrder.Text = "Purchase Order"
        Me.tpPurchaseOrder.UseVisualStyleBackColor = True
        '
        'btnShowColPO
        '
        Me.btnShowColPO.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowColPO.BackColor = System.Drawing.Color.Linen
        Me.btnShowColPO.BackgroundImage = Global.carzTrack.My.Resources.Resources.docNArrwa
        Me.btnShowColPO.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowColPO.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowColPO.FlatAppearance.BorderSize = 2
        Me.btnShowColPO.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColPO.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColPO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowColPO.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowColPO.ForeColor = System.Drawing.Color.White
        Me.btnShowColPO.Location = New System.Drawing.Point(11, 66)
        Me.btnShowColPO.Name = "btnShowColPO"
        Me.btnShowColPO.Size = New System.Drawing.Size(36, 30)
        Me.btnShowColPO.TabIndex = 339
        Me.btnShowColPO.UseVisualStyleBackColor = False
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnPreview)
        Me.grpButtons.Controls.Add(Me.btnOpen)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnDelete)
        Me.grpButtons.Location = New System.Drawing.Point(6, 283)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(871, 53)
        Me.grpButtons.TabIndex = 259
        Me.grpButtons.TabStop = False
        '
        'btnPreview
        '
        Me.btnPreview.AlternativeGroup = Nothing
        Me.btnPreview.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPreview.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPreview.BackColor1 = System.Drawing.Color.White
        Me.btnPreview.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPreview.BorderHover = True
        Me.btnPreview.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPreview.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPreview.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPreview.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPreview.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPreview.DrawBorder = True
        Me.btnPreview.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPreview.ForeColor = System.Drawing.Color.Navy
        Me.btnPreview.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.HoverColor2 = System.Drawing.Color.White
        Me.btnPreview.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPreview.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPreview.Location = New System.Drawing.Point(387, 16)
        Me.btnPreview.Name = "btnPreview"
        Me.btnPreview.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPreview.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPreview.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPreview.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.SelectedText = Nothing
        Me.btnPreview.Size = New System.Drawing.Size(120, 28)
        Me.btnPreview.TabIndex = 10
        Me.btnPreview.Text = "P r e v i e w"
        Me.btnPreview.UseVisualStyleBackColor = False
        '
        'btnOpen
        '
        Me.btnOpen.AlternativeGroup = Nothing
        Me.btnOpen.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnOpen.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnOpen.BackColor1 = System.Drawing.Color.White
        Me.btnOpen.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnOpen.BorderHover = True
        Me.btnOpen.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnOpen.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnOpen.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnOpen.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnOpen.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnOpen.DrawBorder = True
        Me.btnOpen.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnOpen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnOpen.ForeColor = System.Drawing.Color.Navy
        Me.btnOpen.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnOpen.HoverColor2 = System.Drawing.Color.White
        Me.btnOpen.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnOpen.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnOpen.Location = New System.Drawing.Point(134, 16)
        Me.btnOpen.Name = "btnOpen"
        Me.btnOpen.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnOpen.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnOpen.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnOpen.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnOpen.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnOpen.SelectedText = Nothing
        Me.btnOpen.Size = New System.Drawing.Size(120, 28)
        Me.btnOpen.TabIndex = 0
        Me.btnOpen.Text = "O p e n"
        Me.btnOpen.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.HoverColor2 = System.Drawing.Color.White
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNew.Location = New System.Drawing.Point(7, 16)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(120, 28)
        Me.btnNew.TabIndex = 3
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(742, 16)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(120, 28)
        Me.btnClose.TabIndex = 9
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.AlternativeGroup = Nothing
        Me.btnDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDelete.BackColor = System.Drawing.Color.Maroon
        Me.btnDelete.BackColor1 = System.Drawing.Color.White
        Me.btnDelete.BackColor2 = System.Drawing.Color.Maroon
        Me.btnDelete.BorderHover = True
        Me.btnDelete.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnDelete.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDelete.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDelete.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnDelete.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDelete.DrawBorder = True
        Me.btnDelete.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnDelete.ForeColor = System.Drawing.Color.Navy
        Me.btnDelete.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnDelete.HoverColor2 = System.Drawing.Color.White
        Me.btnDelete.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDelete.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnDelete.Location = New System.Drawing.Point(261, 16)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnDelete.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnDelete.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDelete.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDelete.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnDelete.SelectedText = Nothing
        Me.btnDelete.Size = New System.Drawing.Size(120, 28)
        Me.btnDelete.TabIndex = 5
        Me.btnDelete.Text = "D e l e t e"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'grdPO
        '
        Me.grdPO.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdPO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdPO.Location = New System.Drawing.Point(6, 65)
        Me.grdPO.MultiSelect = False
        Me.grdPO.Name = "grdPO"
        Me.grdPO.ReadOnly = True
        Me.grdPO.Size = New System.Drawing.Size(871, 218)
        Me.grdPO.TabIndex = 0
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grpFilter.Controls.Add(Me.txtFilterPONum)
        Me.grpFilter.Controls.Add(Me.grpFilterStatus)
        Me.grpFilter.Controls.Add(Me.lblPODate)
        Me.grpFilter.Controls.Add(Me.dtpFilterFrom)
        Me.grpFilter.Controls.Add(Me.lblFrom)
        Me.grpFilter.Controls.Add(Me.dtpFilterTo)
        Me.grpFilter.Controls.Add(Me.lblTo)
        Me.grpFilter.Controls.Add(Me.cboFilterSupplier)
        Me.grpFilter.Controls.Add(Me.lblSupplier)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(6, 2)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(871, 60)
        Me.grpFilter.TabIndex = 1
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Purchase Order Filter"
        '
        'txtFilterPONum
        '
        Me.txtFilterPONum.BackColor = System.Drawing.Color.White
        Me.txtFilterPONum.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFilterPONum.ForeColor = System.Drawing.Color.Navy
        Me.txtFilterPONum.Location = New System.Drawing.Point(49, 25)
        Me.txtFilterPONum.Name = "txtFilterPONum"
        Me.txtFilterPONum.Size = New System.Drawing.Size(76, 23)
        Me.txtFilterPONum.TabIndex = 318
        '
        'grpFilterStatus
        '
        Me.grpFilterStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilterStatus.Controls.Add(Me.chkFilterPosted)
        Me.grpFilterStatus.Controls.Add(Me.chkFilterNew)
        Me.grpFilterStatus.Controls.Add(Me.chkFilterUnposted)
        Me.grpFilterStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpFilterStatus.Location = New System.Drawing.Point(639, 12)
        Me.grpFilterStatus.Name = "grpFilterStatus"
        Me.grpFilterStatus.Size = New System.Drawing.Size(223, 41)
        Me.grpFilterStatus.TabIndex = 317
        Me.grpFilterStatus.TabStop = False
        '
        'chkFilterPosted
        '
        Me.chkFilterPosted.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkFilterPosted.AutoSize = True
        Me.chkFilterPosted.Checked = True
        Me.chkFilterPosted.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkFilterPosted.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkFilterPosted.ForeColor = System.Drawing.Color.SlateBlue
        Me.chkFilterPosted.Location = New System.Drawing.Point(69, 18)
        Me.chkFilterPosted.Name = "chkFilterPosted"
        Me.chkFilterPosted.Size = New System.Drawing.Size(59, 17)
        Me.chkFilterPosted.TabIndex = 8
        Me.chkFilterPosted.Text = "Posted"
        Me.chkFilterPosted.UseVisualStyleBackColor = True
        '
        'chkFilterNew
        '
        Me.chkFilterNew.Checked = True
        Me.chkFilterNew.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkFilterNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkFilterNew.ForeColor = System.Drawing.Color.SlateBlue
        Me.chkFilterNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkFilterNew.Location = New System.Drawing.Point(9, 16)
        Me.chkFilterNew.Name = "chkFilterNew"
        Me.chkFilterNew.Size = New System.Drawing.Size(57, 21)
        Me.chkFilterNew.TabIndex = 314
        Me.chkFilterNew.Text = "New"
        '
        'chkFilterUnposted
        '
        Me.chkFilterUnposted.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkFilterUnposted.AutoSize = True
        Me.chkFilterUnposted.Checked = True
        Me.chkFilterUnposted.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkFilterUnposted.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkFilterUnposted.ForeColor = System.Drawing.Color.SlateBlue
        Me.chkFilterUnposted.Location = New System.Drawing.Point(137, 18)
        Me.chkFilterUnposted.Name = "chkFilterUnposted"
        Me.chkFilterUnposted.Size = New System.Drawing.Size(79, 17)
        Me.chkFilterUnposted.TabIndex = 9
        Me.chkFilterUnposted.Text = "Not Posted"
        Me.chkFilterUnposted.UseVisualStyleBackColor = True
        '
        'lblPODate
        '
        Me.lblPODate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblPODate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPODate.ForeColor = System.Drawing.Color.SlateBlue
        Me.lblPODate.Location = New System.Drawing.Point(6, 24)
        Me.lblPODate.Name = "lblPODate"
        Me.lblPODate.Size = New System.Drawing.Size(40, 22)
        Me.lblPODate.TabIndex = 11
        Me.lblPODate.Text = "PO #"
        Me.lblPODate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpFilterFrom
        '
        Me.dtpFilterFrom.CalendarForeColor = System.Drawing.Color.Navy
        Me.dtpFilterFrom.CustomFormat = "dd MMM yyyy"
        Me.dtpFilterFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpFilterFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFilterFrom.Location = New System.Drawing.Point(177, 26)
        Me.dtpFilterFrom.Name = "dtpFilterFrom"
        Me.dtpFilterFrom.Size = New System.Drawing.Size(107, 21)
        Me.dtpFilterFrom.TabIndex = 0
        '
        'lblFrom
        '
        Me.lblFrom.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFrom.ForeColor = System.Drawing.Color.SlateBlue
        Me.lblFrom.Location = New System.Drawing.Point(143, 27)
        Me.lblFrom.Name = "lblFrom"
        Me.lblFrom.Size = New System.Drawing.Size(33, 19)
        Me.lblFrom.TabIndex = 2
        Me.lblFrom.Text = "From"
        Me.lblFrom.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpFilterTo
        '
        Me.dtpFilterTo.CalendarForeColor = System.Drawing.Color.Navy
        Me.dtpFilterTo.CustomFormat = "dd MMM yyyy"
        Me.dtpFilterTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpFilterTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFilterTo.Location = New System.Drawing.Point(308, 26)
        Me.dtpFilterTo.Name = "dtpFilterTo"
        Me.dtpFilterTo.Size = New System.Drawing.Size(107, 21)
        Me.dtpFilterTo.TabIndex = 1
        '
        'lblTo
        '
        Me.lblTo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTo.ForeColor = System.Drawing.Color.SlateBlue
        Me.lblTo.Location = New System.Drawing.Point(286, 27)
        Me.lblTo.Name = "lblTo"
        Me.lblTo.Size = New System.Drawing.Size(20, 19)
        Me.lblTo.TabIndex = 3
        Me.lblTo.Text = "To"
        Me.lblTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboFilterSupplier
        '
        Me.cboFilterSupplier.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboFilterSupplier.BackColor = System.Drawing.SystemColors.Window
        Me.cboFilterSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboFilterSupplier.ForeColor = System.Drawing.Color.Navy
        Me.cboFilterSupplier.FormattingEnabled = True
        Me.cboFilterSupplier.Location = New System.Drawing.Point(465, 25)
        Me.cboFilterSupplier.Name = "cboFilterSupplier"
        Me.cboFilterSupplier.Size = New System.Drawing.Size(155, 24)
        Me.cboFilterSupplier.TabIndex = 5
        '
        'lblSupplier
        '
        Me.lblSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSupplier.ForeColor = System.Drawing.Color.SlateBlue
        Me.lblSupplier.Location = New System.Drawing.Point(414, 27)
        Me.lblSupplier.Name = "lblSupplier"
        Me.lblSupplier.Size = New System.Drawing.Size(49, 19)
        Me.lblSupplier.TabIndex = 4
        Me.lblSupplier.Text = "Supplier"
        Me.lblSupplier.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'pnlInvisibleFields
        '
        Me.pnlInvisibleFields.BackColor = System.Drawing.Color.LightSteelBlue
        Me.pnlInvisibleFields.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlInvisibleFields.Controls.Add(Me.txtPOVehExp)
        Me.pnlInvisibleFields.Controls.Add(Me.lblPOVehExp)
        Me.pnlInvisibleFields.Controls.Add(Me.txtPOExp)
        Me.pnlInvisibleFields.Controls.Add(Me.lblPOExp)
        Me.pnlInvisibleFields.Controls.Add(Me.txtPOID)
        Me.pnlInvisibleFields.Controls.Add(Me.lblPOID)
        Me.pnlInvisibleFields.Location = New System.Drawing.Point(53, 68)
        Me.pnlInvisibleFields.Name = "pnlInvisibleFields"
        Me.pnlInvisibleFields.Size = New System.Drawing.Size(222, 107)
        Me.pnlInvisibleFields.TabIndex = 368
        '
        'txtPOVehExp
        '
        Me.txtPOVehExp.Location = New System.Drawing.Point(72, 70)
        Me.txtPOVehExp.Name = "txtPOVehExp"
        Me.txtPOVehExp.Size = New System.Drawing.Size(143, 20)
        Me.txtPOVehExp.TabIndex = 164
        '
        'lblPOVehExp
        '
        Me.lblPOVehExp.AutoSize = True
        Me.lblPOVehExp.Location = New System.Drawing.Point(2, 74)
        Me.lblPOVehExp.Name = "lblPOVehExp"
        Me.lblPOVehExp.Size = New System.Drawing.Size(69, 13)
        Me.lblPOVehExp.TabIndex = 163
        Me.lblPOVehExp.Text = "lblPOVehExp"
        '
        'txtPOExp
        '
        Me.txtPOExp.Location = New System.Drawing.Point(72, 40)
        Me.txtPOExp.Name = "txtPOExp"
        Me.txtPOExp.Size = New System.Drawing.Size(143, 20)
        Me.txtPOExp.TabIndex = 162
        '
        'lblPOExp
        '
        Me.lblPOExp.AutoSize = True
        Me.lblPOExp.Location = New System.Drawing.Point(26, 43)
        Me.lblPOExp.Name = "lblPOExp"
        Me.lblPOExp.Size = New System.Drawing.Size(40, 13)
        Me.lblPOExp.TabIndex = 161
        Me.lblPOExp.Text = "POExp"
        '
        'txtPOID
        '
        Me.txtPOID.Location = New System.Drawing.Point(72, 7)
        Me.txtPOID.Name = "txtPOID"
        Me.txtPOID.Size = New System.Drawing.Size(143, 20)
        Me.txtPOID.TabIndex = 160
        '
        'lblPOID
        '
        Me.lblPOID.AutoSize = True
        Me.lblPOID.Location = New System.Drawing.Point(33, 10)
        Me.lblPOID.Name = "lblPOID"
        Me.lblPOID.Size = New System.Drawing.Size(33, 13)
        Me.lblPOID.TabIndex = 159
        Me.lblPOID.Text = "POID"
        '
        'tpPurchaseOrderDetail
        '
        Me.tpPurchaseOrderDetail.Controls.Add(Me.Label6)
        Me.tpPurchaseOrderDetail.Controls.Add(Me.lblHotKeys)
        Me.tpPurchaseOrderDetail.Controls.Add(Me.btnShowColPODetails)
        Me.tpPurchaseOrderDetail.Controls.Add(Me.grdPODetails)
        Me.tpPurchaseOrderDetail.Controls.Add(Me.grpTotals)
        Me.tpPurchaseOrderDetail.Controls.Add(Me.grpDetails)
        Me.tpPurchaseOrderDetail.Controls.Add(Me.grpPODetailsButtons)
        Me.tpPurchaseOrderDetail.Controls.Add(Me.grpFindSupplier)
        Me.tpPurchaseOrderDetail.Location = New System.Drawing.Point(4, 22)
        Me.tpPurchaseOrderDetail.Name = "tpPurchaseOrderDetail"
        Me.tpPurchaseOrderDetail.Size = New System.Drawing.Size(883, 340)
        Me.tpPurchaseOrderDetail.TabIndex = 1
        Me.tpPurchaseOrderDetail.Text = "Purchase Order Details"
        Me.tpPurchaseOrderDetail.UseVisualStyleBackColor = True
        '
        'btnShowColPODetails
        '
        Me.btnShowColPODetails.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowColPODetails.BackColor = System.Drawing.Color.Linen
        Me.btnShowColPODetails.BackgroundImage = Global.carzTrack.My.Resources.Resources.docNArrwa
        Me.btnShowColPODetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowColPODetails.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowColPODetails.FlatAppearance.BorderSize = 2
        Me.btnShowColPODetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColPODetails.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColPODetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowColPODetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowColPODetails.ForeColor = System.Drawing.Color.White
        Me.btnShowColPODetails.Location = New System.Drawing.Point(9, 137)
        Me.btnShowColPODetails.Name = "btnShowColPODetails"
        Me.btnShowColPODetails.Size = New System.Drawing.Size(36, 30)
        Me.btnShowColPODetails.TabIndex = 367
        Me.btnShowColPODetails.UseVisualStyleBackColor = False
        '
        'grdPODetails
        '
        Me.grdPODetails.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdPODetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdPODetails.Location = New System.Drawing.Point(6, 134)
        Me.grdPODetails.MultiSelect = False
        Me.grdPODetails.Name = "grdPODetails"
        Me.grdPODetails.ReadOnly = True
        Me.grdPODetails.Size = New System.Drawing.Size(870, 81)
        Me.grdPODetails.TabIndex = 2
        '
        'grpTotals
        '
        Me.grpTotals.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpTotals.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grpTotals.Controls.Add(Me.lblCompCurr)
        Me.grpTotals.Controls.Add(Me.lblPOTotal)
        Me.grpTotals.Controls.Add(Me.txtPOTotal)
        Me.grpTotals.Controls.Add(Me.lblQuantity)
        Me.grpTotals.Controls.Add(Me.lblTotal)
        Me.grpTotals.Controls.Add(Me.txtExTotal)
        Me.grpTotals.Controls.Add(Me.txtQuantity)
        Me.grpTotals.Controls.Add(Me.lblTotalExpense)
        Me.grpTotals.Controls.Add(Me.txtTotal)
        Me.grpTotals.Location = New System.Drawing.Point(6, 214)
        Me.grpTotals.Name = "grpTotals"
        Me.grpTotals.Size = New System.Drawing.Size(870, 46)
        Me.grpTotals.TabIndex = 366
        Me.grpTotals.TabStop = False
        '
        'lblCompCurr
        '
        Me.lblCompCurr.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCompCurr.BackColor = System.Drawing.Color.Khaki
        Me.lblCompCurr.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lblCompCurr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.lblCompCurr.ForeColor = System.Drawing.Color.Black
        Me.lblCompCurr.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCompCurr.Location = New System.Drawing.Point(834, 14)
        Me.lblCompCurr.Name = "lblCompCurr"
        Me.lblCompCurr.Size = New System.Drawing.Size(30, 23)
        Me.lblCompCurr.TabIndex = 362
        '
        'lblPOTotal
        '
        Me.lblPOTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblPOTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblPOTotal.ForeColor = System.Drawing.Color.Maroon
        Me.lblPOTotal.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPOTotal.Location = New System.Drawing.Point(638, 16)
        Me.lblPOTotal.Name = "lblPOTotal"
        Me.lblPOTotal.Size = New System.Drawing.Size(49, 23)
        Me.lblPOTotal.TabIndex = 360
        Me.lblPOTotal.Text = "PO Total"
        Me.lblPOTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtPOTotal
        '
        Me.txtPOTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPOTotal.BackColor = System.Drawing.Color.Khaki
        Me.txtPOTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPOTotal.ForeColor = System.Drawing.Color.Maroon
        Me.txtPOTotal.Location = New System.Drawing.Point(690, 14)
        Me.txtPOTotal.Name = "txtPOTotal"
        Me.txtPOTotal.ReadOnly = True
        Me.txtPOTotal.Size = New System.Drawing.Size(141, 23)
        Me.txtPOTotal.TabIndex = 365
        Me.txtPOTotal.Text = "0"
        Me.txtPOTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblQuantity
        '
        Me.lblQuantity.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblQuantity.AutoSize = True
        Me.lblQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity.ForeColor = System.Drawing.Color.Maroon
        Me.lblQuantity.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblQuantity.Location = New System.Drawing.Point(7, 18)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(46, 13)
        Me.lblQuantity.TabIndex = 277
        Me.lblQuantity.Text = "Quantity"
        Me.lblQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTotal
        '
        Me.lblTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblTotal.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotal.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblTotal.Location = New System.Drawing.Point(197, 15)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(31, 23)
        Me.lblTotal.TabIndex = 358
        Me.lblTotal.Text = "Total"
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtExTotal
        '
        Me.txtExTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtExTotal.BackColor = System.Drawing.Color.Khaki
        Me.txtExTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtExTotal.ForeColor = System.Drawing.Color.Maroon
        Me.txtExTotal.Location = New System.Drawing.Point(476, 15)
        Me.txtExTotal.Name = "txtExTotal"
        Me.txtExTotal.ReadOnly = True
        Me.txtExTotal.Size = New System.Drawing.Size(156, 23)
        Me.txtExTotal.TabIndex = 364
        Me.txtExTotal.Text = "0"
        Me.txtExTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtQuantity
        '
        Me.txtQuantity.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuantity.ForeColor = System.Drawing.Color.Maroon
        Me.txtQuantity.Location = New System.Drawing.Point(66, 14)
        Me.txtQuantity.Name = "txtQuantity"
        Me.txtQuantity.ReadOnly = True
        Me.txtQuantity.Size = New System.Drawing.Size(85, 22)
        Me.txtQuantity.TabIndex = 157
        '
        'lblTotalExpense
        '
        Me.lblTotalExpense.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTotalExpense.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblTotalExpense.ForeColor = System.Drawing.Color.Maroon
        Me.lblTotalExpense.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblTotalExpense.Location = New System.Drawing.Point(395, 15)
        Me.lblTotalExpense.Name = "lblTotalExpense"
        Me.lblTotalExpense.Size = New System.Drawing.Size(75, 23)
        Me.lblTotalExpense.TabIndex = 356
        Me.lblTotalExpense.Text = "Total Expense"
        Me.lblTotalExpense.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTotal
        '
        Me.txtTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotal.BackColor = System.Drawing.Color.Khaki
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotal.Location = New System.Drawing.Point(233, 14)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(156, 23)
        Me.txtTotal.TabIndex = 363
        Me.txtTotal.Text = "0"
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'grpDetails
        '
        Me.grpDetails.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpDetails.Controls.Add(Me.grpShowHideColumns)
        Me.grpDetails.Controls.Add(Me.txtPORate)
        Me.grpDetails.Controls.Add(Me.lblRate)
        Me.grpDetails.Controls.Add(Me.lblAcctCurrency)
        Me.grpDetails.Controls.Add(Me.lstDataErr)
        Me.grpDetails.Controls.Add(Me.btnDataErr)
        Me.grpDetails.Controls.Add(Me.cboEmployee)
        Me.grpDetails.Controls.Add(Me.cboStatus)
        Me.grpDetails.Controls.Add(Me.lblStatus)
        Me.grpDetails.Controls.Add(Me.dtpPODate)
        Me.grpDetails.Controls.Add(Me.lblDate)
        Me.grpDetails.Controls.Add(Me.txtPONum)
        Me.grpDetails.Controls.Add(Me.lblPONum)
        Me.grpDetails.Controls.Add(Me.grpRefInvoice)
        Me.grpDetails.Controls.Add(Me.cboAcctID)
        Me.grpDetails.Controls.Add(Me.lblPODetailSupplier)
        Me.grpDetails.Controls.Add(Me.txtDescription)
        Me.grpDetails.Controls.Add(Me.lblDescription)
        Me.grpDetails.Controls.Add(Me.lblSalesPerson)
        Me.grpDetails.Location = New System.Drawing.Point(6, 4)
        Me.grpDetails.Name = "grpDetails"
        Me.grpDetails.Size = New System.Drawing.Size(870, 128)
        Me.grpDetails.TabIndex = 261
        Me.grpDetails.TabStop = False
        Me.grpDetails.Tag = "m "
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(33, 55)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 149)
        Me.grpShowHideColumns.TabIndex = 338
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Show/Hide Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(6, 119)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 94
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(6, 17)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 109)
        Me.chkLstGridCol.TabIndex = 93
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'txtPORate
        '
        Me.txtPORate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPORate.ForeColor = System.Drawing.Color.Navy
        Me.txtPORate.Location = New System.Drawing.Point(352, 56)
        Me.txtPORate.Name = "txtPORate"
        Me.txtPORate.Size = New System.Drawing.Size(85, 22)
        Me.txtPORate.TabIndex = 270
        '
        'lblRate
        '
        Me.lblRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRate.ForeColor = System.Drawing.Color.Navy
        Me.lblRate.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblRate.Location = New System.Drawing.Point(351, 42)
        Me.lblRate.Name = "lblRate"
        Me.lblRate.Size = New System.Drawing.Size(84, 13)
        Me.lblRate.TabIndex = 365
        Me.lblRate.Text = "R a t e"
        '
        'lblAcctCurrency
        '
        Me.lblAcctCurrency.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblAcctCurrency.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lblAcctCurrency.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
        Me.lblAcctCurrency.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblAcctCurrency.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAcctCurrency.Location = New System.Drawing.Point(319, 55)
        Me.lblAcctCurrency.Name = "lblAcctCurrency"
        Me.lblAcctCurrency.Size = New System.Drawing.Size(30, 25)
        Me.lblAcctCurrency.TabIndex = 363
        Me.lblAcctCurrency.Text = "$"
        Me.lblAcctCurrency.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(685, 2)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(153, 17)
        Me.lstDataErr.TabIndex = 340
        Me.lstDataErr.Visible = False
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(837, 0)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(33, 25)
        Me.btnDataErr.TabIndex = 339
        Me.btnDataErr.Text = "Error"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'cboEmployee
        '
        Me.cboEmployee.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboEmployee.BackColor = System.Drawing.SystemColors.Window
        Me.cboEmployee.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboEmployee.FormattingEnabled = True
        Me.cboEmployee.Location = New System.Drawing.Point(510, 23)
        Me.cboEmployee.Name = "cboEmployee"
        Me.cboEmployee.Size = New System.Drawing.Size(116, 24)
        Me.cboEmployee.TabIndex = 276
        '
        'cboStatus
        '
        Me.cboStatus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple
        Me.cboStatus.Enabled = False
        Me.cboStatus.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cboStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cboStatus.Location = New System.Drawing.Point(510, 57)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(115, 21)
        Me.cboStatus.TabIndex = 275
        Me.cboStatus.TabStop = False
        '
        'lblStatus
        '
        Me.lblStatus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.ForeColor = System.Drawing.Color.Maroon
        Me.lblStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblStatus.Location = New System.Drawing.Point(443, 61)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(55, 13)
        Me.lblStatus.TabIndex = 274
        Me.lblStatus.Text = "PO Status"
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'dtpPODate
        '
        Me.dtpPODate.CustomFormat = "dd MMM yyyy"
        Me.dtpPODate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpPODate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpPODate.Location = New System.Drawing.Point(200, 23)
        Me.dtpPODate.Name = "dtpPODate"
        Me.dtpPODate.Size = New System.Drawing.Size(114, 22)
        Me.dtpPODate.TabIndex = 267
        '
        'lblDate
        '
        Me.lblDate.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.ForeColor = System.Drawing.Color.Maroon
        Me.lblDate.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDate.Location = New System.Drawing.Point(165, 22)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(34, 23)
        Me.lblDate.TabIndex = 264
        Me.lblDate.Text = " Date"
        Me.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtPONum
        '
        Me.txtPONum.BackColor = System.Drawing.Color.White
        Me.txtPONum.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPONum.Location = New System.Drawing.Point(88, 23)
        Me.txtPONum.Name = "txtPONum"
        Me.txtPONum.ReadOnly = True
        Me.txtPONum.Size = New System.Drawing.Size(77, 23)
        Me.txtPONum.TabIndex = 266
        '
        'lblPONum
        '
        Me.lblPONum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPONum.ForeColor = System.Drawing.Color.Maroon
        Me.lblPONum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPONum.Location = New System.Drawing.Point(11, 21)
        Me.lblPONum.Name = "lblPONum"
        Me.lblPONum.Size = New System.Drawing.Size(74, 23)
        Me.lblPONum.TabIndex = 262
        Me.lblPONum.Text = "PO Number"
        Me.lblPONum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grpRefInvoice
        '
        Me.grpRefInvoice.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpRefInvoice.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grpRefInvoice.Controls.Add(Me.txtInvoiceNum)
        Me.grpRefInvoice.Controls.Add(Me.lblRedDate)
        Me.grpRefInvoice.Controls.Add(Me.lblRefNum)
        Me.grpRefInvoice.Controls.Add(Me.dtpInvDate)
        Me.grpRefInvoice.ForeColor = System.Drawing.Color.DarkGray
        Me.grpRefInvoice.Location = New System.Drawing.Point(631, 16)
        Me.grpRefInvoice.Name = "grpRefInvoice"
        Me.grpRefInvoice.Size = New System.Drawing.Size(215, 100)
        Me.grpRefInvoice.TabIndex = 273
        Me.grpRefInvoice.TabStop = False
        Me.grpRefInvoice.Text = "Reference Invoice"
        '
        'txtInvoiceNum
        '
        Me.txtInvoiceNum.BackColor = System.Drawing.Color.White
        Me.txtInvoiceNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInvoiceNum.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtInvoiceNum.Location = New System.Drawing.Point(56, 29)
        Me.txtInvoiceNum.Name = "txtInvoiceNum"
        Me.txtInvoiceNum.Size = New System.Drawing.Size(152, 20)
        Me.txtInvoiceNum.TabIndex = 275
        '
        'lblRedDate
        '
        Me.lblRedDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRedDate.ForeColor = System.Drawing.Color.DimGray
        Me.lblRedDate.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblRedDate.Location = New System.Drawing.Point(3, 72)
        Me.lblRedDate.Name = "lblRedDate"
        Me.lblRedDate.Size = New System.Drawing.Size(44, 18)
        Me.lblRedDate.TabIndex = 272
        Me.lblRedDate.Text = "Date"
        Me.lblRedDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblRefNum
        '
        Me.lblRefNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRefNum.ForeColor = System.Drawing.Color.DimGray
        Me.lblRefNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblRefNum.Location = New System.Drawing.Point(7, 31)
        Me.lblRefNum.Name = "lblRefNum"
        Me.lblRefNum.Size = New System.Drawing.Size(44, 18)
        Me.lblRefNum.TabIndex = 271
        Me.lblRefNum.Text = "Number"
        Me.lblRefNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpInvDate
        '
        Me.dtpInvDate.AccessibleDescription = ""
        Me.dtpInvDate.CustomFormat = "dd MMM yyyy"
        Me.dtpInvDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpInvDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpInvDate.Location = New System.Drawing.Point(60, 70)
        Me.dtpInvDate.Name = "dtpInvDate"
        Me.dtpInvDate.Size = New System.Drawing.Size(148, 20)
        Me.dtpInvDate.TabIndex = 3
        Me.dtpInvDate.Value = New Date(2006, 11, 24, 0, 0, 0, 0)
        '
        'cboAcctID
        '
        Me.cboAcctID.BackColor = System.Drawing.SystemColors.Window
        Me.cboAcctID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboAcctID.FormattingEnabled = True
        Me.cboAcctID.Location = New System.Drawing.Point(88, 55)
        Me.cboAcctID.Name = "cboAcctID"
        Me.cboAcctID.Size = New System.Drawing.Size(226, 24)
        Me.cboAcctID.TabIndex = 269
        '
        'lblPODetailSupplier
        '
        Me.lblPODetailSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblPODetailSupplier.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPODetailSupplier.ForeColor = System.Drawing.Color.Maroon
        Me.lblPODetailSupplier.Location = New System.Drawing.Point(11, 56)
        Me.lblPODetailSupplier.Name = "lblPODetailSupplier"
        Me.lblPODetailSupplier.Size = New System.Drawing.Size(74, 23)
        Me.lblPODetailSupplier.TabIndex = 268
        Me.lblPODetailSupplier.Text = "Supplier"
        Me.lblPODetailSupplier.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDescription
        '
        Me.txtDescription.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDescription.ForeColor = System.Drawing.Color.Maroon
        Me.txtDescription.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtDescription.Location = New System.Drawing.Point(88, 89)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDescription.Size = New System.Drawing.Size(538, 28)
        Me.txtDescription.TabIndex = 271
        '
        'lblDescription
        '
        Me.lblDescription.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescription.ForeColor = System.Drawing.Color.Maroon
        Me.lblDescription.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDescription.Location = New System.Drawing.Point(10, 83)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(74, 23)
        Me.lblDescription.TabIndex = 259
        Me.lblDescription.Text = "Description"
        Me.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSalesPerson
        '
        Me.lblSalesPerson.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblSalesPerson.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSalesPerson.ForeColor = System.Drawing.Color.Maroon
        Me.lblSalesPerson.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSalesPerson.Location = New System.Drawing.Point(443, 26)
        Me.lblSalesPerson.Name = "lblSalesPerson"
        Me.lblSalesPerson.Size = New System.Drawing.Size(2, 18)
        Me.lblSalesPerson.TabIndex = 257
        Me.lblSalesPerson.Text = "Employee"
        Me.lblSalesPerson.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grpPODetailsButtons
        '
        Me.grpPODetailsButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpPODetailsButtons.Controls.Add(Me.btnRemoveVehicle)
        Me.grpPODetailsButtons.Controls.Add(Me.btnPOvehExpense)
        Me.grpPODetailsButtons.Controls.Add(Me.btnSave)
        Me.grpPODetailsButtons.Controls.Add(Me.txtDiscount)
        Me.grpPODetailsButtons.Controls.Add(Me.lblDiscount)
        Me.grpPODetailsButtons.Controls.Add(Me.btnCancel)
        Me.grpPODetailsButtons.Controls.Add(Me.btnExpense)
        Me.grpPODetailsButtons.Controls.Add(Me.btnPost)
        Me.grpPODetailsButtons.Controls.Add(Me.btnVehicle)
        Me.grpPODetailsButtons.Controls.Add(Me.btnDetailClose)
        Me.grpPODetailsButtons.Controls.Add(Me.btnDeleteVeh)
        Me.grpPODetailsButtons.Location = New System.Drawing.Point(6, 278)
        Me.grpPODetailsButtons.Name = "grpPODetailsButtons"
        Me.grpPODetailsButtons.Size = New System.Drawing.Size(870, 54)
        Me.grpPODetailsButtons.TabIndex = 260
        Me.grpPODetailsButtons.TabStop = False
        '
        'btnRemoveVehicle
        '
        Me.btnRemoveVehicle.AlternativeGroup = Nothing
        Me.btnRemoveVehicle.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnRemoveVehicle.BackColor = System.Drawing.Color.Maroon
        Me.btnRemoveVehicle.BackColor1 = System.Drawing.Color.White
        Me.btnRemoveVehicle.BackColor2 = System.Drawing.Color.Maroon
        Me.btnRemoveVehicle.BorderHover = True
        Me.btnRemoveVehicle.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnRemoveVehicle.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnRemoveVehicle.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnRemoveVehicle.ClickColor1 = System.Drawing.Color.DarkRed
        Me.btnRemoveVehicle.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnRemoveVehicle.DrawBorder = True
        Me.btnRemoveVehicle.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnRemoveVehicle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnRemoveVehicle.ForeColor = System.Drawing.Color.Navy
        Me.btnRemoveVehicle.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnRemoveVehicle.HoverColor2 = System.Drawing.Color.White
        Me.btnRemoveVehicle.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnRemoveVehicle.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnRemoveVehicle.Location = New System.Drawing.Point(434, 17)
        Me.btnRemoveVehicle.Name = "btnRemoveVehicle"
        Me.btnRemoveVehicle.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnRemoveVehicle.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnRemoveVehicle.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnRemoveVehicle.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnRemoveVehicle.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnRemoveVehicle.SelectedText = Nothing
        Me.btnRemoveVehicle.Size = New System.Drawing.Size(105, 28)
        Me.btnRemoveVehicle.TabIndex = 370
        Me.btnRemoveVehicle.Text = "Remove Vehicle"
        Me.btnRemoveVehicle.UseVisualStyleBackColor = False
        '
        'btnPOvehExpense
        '
        Me.btnPOvehExpense.AlternativeGroup = Nothing
        Me.btnPOvehExpense.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPOvehExpense.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPOvehExpense.BackColor1 = System.Drawing.Color.White
        Me.btnPOvehExpense.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPOvehExpense.BorderHover = True
        Me.btnPOvehExpense.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPOvehExpense.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPOvehExpense.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPOvehExpense.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPOvehExpense.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPOvehExpense.DrawBorder = True
        Me.btnPOvehExpense.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPOvehExpense.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPOvehExpense.ForeColor = System.Drawing.Color.Navy
        Me.btnPOvehExpense.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPOvehExpense.HoverColor2 = System.Drawing.Color.White
        Me.btnPOvehExpense.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPOvehExpense.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPOvehExpense.Location = New System.Drawing.Point(652, 17)
        Me.btnPOvehExpense.Name = "btnPOvehExpense"
        Me.btnPOvehExpense.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPOvehExpense.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPOvehExpense.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPOvehExpense.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPOvehExpense.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPOvehExpense.SelectedText = Nothing
        Me.btnPOvehExpense.Size = New System.Drawing.Size(105, 28)
        Me.btnPOvehExpense.TabIndex = 369
        Me.btnPOvehExpense.Text = "Vehicle Expense"
        Me.btnPOvehExpense.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(113, 17)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(105, 28)
        Me.btnSave.TabIndex = 368
        Me.btnSave.TabStop = False
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'txtDiscount
        '
        Me.txtDiscount.BackColor = System.Drawing.Color.White
        Me.txtDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDiscount.ForeColor = System.Drawing.Color.Maroon
        Me.txtDiscount.Location = New System.Drawing.Point(739, -89)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(18, 23)
        Me.txtDiscount.TabIndex = 367
        Me.txtDiscount.Text = "0"
        Me.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblDiscount
        '
        Me.lblDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.lblDiscount.ForeColor = System.Drawing.Color.Maroon
        Me.lblDiscount.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDiscount.Location = New System.Drawing.Point(763, -89)
        Me.lblDiscount.Name = "lblDiscount"
        Me.lblDiscount.Size = New System.Drawing.Size(34, 23)
        Me.lblDiscount.TabIndex = 366
        Me.lblDiscount.Text = "Discount"
        Me.lblDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.HoverColor2 = System.Drawing.Color.White
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCancel.Location = New System.Drawing.Point(220, 17)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCancel.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(105, 28)
        Me.btnCancel.TabIndex = 277
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnExpense
        '
        Me.btnExpense.AlternativeGroup = Nothing
        Me.btnExpense.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnExpense.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnExpense.BackColor1 = System.Drawing.Color.White
        Me.btnExpense.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnExpense.BorderHover = True
        Me.btnExpense.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnExpense.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnExpense.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnExpense.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnExpense.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnExpense.DrawBorder = True
        Me.btnExpense.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnExpense.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnExpense.ForeColor = System.Drawing.Color.Navy
        Me.btnExpense.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnExpense.HoverColor2 = System.Drawing.Color.White
        Me.btnExpense.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnExpense.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnExpense.Location = New System.Drawing.Point(543, 17)
        Me.btnExpense.Name = "btnExpense"
        Me.btnExpense.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnExpense.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnExpense.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnExpense.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnExpense.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnExpense.SelectedText = Nothing
        Me.btnExpense.Size = New System.Drawing.Size(105, 28)
        Me.btnExpense.TabIndex = 276
        Me.btnExpense.Text = "Expense"
        Me.btnExpense.UseVisualStyleBackColor = False
        '
        'btnPost
        '
        Me.btnPost.AlternativeGroup = Nothing
        Me.btnPost.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPost.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPost.BackColor1 = System.Drawing.Color.White
        Me.btnPost.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPost.BorderHover = True
        Me.btnPost.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPost.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPost.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPost.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPost.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPost.DrawBorder = True
        Me.btnPost.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPost.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPost.ForeColor = System.Drawing.Color.Navy
        Me.btnPost.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPost.HoverColor2 = System.Drawing.Color.White
        Me.btnPost.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPost.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPost.Location = New System.Drawing.Point(326, 17)
        Me.btnPost.Name = "btnPost"
        Me.btnPost.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPost.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPost.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPost.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPost.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPost.SelectedText = Nothing
        Me.btnPost.Size = New System.Drawing.Size(105, 28)
        Me.btnPost.TabIndex = 12
        Me.btnPost.Text = "Post"
        Me.btnPost.UseVisualStyleBackColor = False
        '
        'btnVehicle
        '
        Me.btnVehicle.AlternativeGroup = Nothing
        Me.btnVehicle.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnVehicle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnVehicle.BackColor1 = System.Drawing.Color.White
        Me.btnVehicle.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnVehicle.BorderHover = True
        Me.btnVehicle.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnVehicle.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnVehicle.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnVehicle.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnVehicle.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnVehicle.DrawBorder = True
        Me.btnVehicle.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnVehicle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnVehicle.ForeColor = System.Drawing.Color.Navy
        Me.btnVehicle.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnVehicle.HoverColor2 = System.Drawing.Color.White
        Me.btnVehicle.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnVehicle.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnVehicle.Location = New System.Drawing.Point(7, 17)
        Me.btnVehicle.Name = "btnVehicle"
        Me.btnVehicle.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnVehicle.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnVehicle.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnVehicle.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnVehicle.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnVehicle.SelectedText = Nothing
        Me.btnVehicle.Size = New System.Drawing.Size(105, 28)
        Me.btnVehicle.TabIndex = 11
        Me.btnVehicle.TabStop = False
        Me.btnVehicle.Text = "Vehicle ( s )"
        Me.btnVehicle.UseVisualStyleBackColor = False
        '
        'btnDetailClose
        '
        Me.btnDetailClose.AlternativeGroup = Nothing
        Me.btnDetailClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDetailClose.BackColor = System.Drawing.Color.Orange
        Me.btnDetailClose.BackColor1 = System.Drawing.Color.White
        Me.btnDetailClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnDetailClose.BorderHover = True
        Me.btnDetailClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDetailClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDetailClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDetailClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDetailClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDetailClose.DrawBorder = True
        Me.btnDetailClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDetailClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.btnDetailClose.ForeColor = System.Drawing.Color.Navy
        Me.btnDetailClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnDetailClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnDetailClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDetailClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnDetailClose.Location = New System.Drawing.Point(759, 17)
        Me.btnDetailClose.Name = "btnDetailClose"
        Me.btnDetailClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnDetailClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnDetailClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnDetailClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDetailClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnDetailClose.SelectedText = Nothing
        Me.btnDetailClose.Size = New System.Drawing.Size(105, 28)
        Me.btnDetailClose.TabIndex = 9
        Me.btnDetailClose.Text = "C l o s e"
        Me.btnDetailClose.UseVisualStyleBackColor = False
        '
        'btnDeleteVeh
        '
        Me.btnDeleteVeh.AlternativeGroup = Nothing
        Me.btnDeleteVeh.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDeleteVeh.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnDeleteVeh.BackColor1 = System.Drawing.Color.White
        Me.btnDeleteVeh.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnDeleteVeh.BorderHover = True
        Me.btnDeleteVeh.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDeleteVeh.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDeleteVeh.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnDeleteVeh.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDeleteVeh.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDeleteVeh.DrawBorder = True
        Me.btnDeleteVeh.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDeleteVeh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnDeleteVeh.ForeColor = System.Drawing.Color.Navy
        Me.btnDeleteVeh.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDeleteVeh.HoverColor2 = System.Drawing.Color.White
        Me.btnDeleteVeh.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDeleteVeh.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnDeleteVeh.Location = New System.Drawing.Point(146, -40)
        Me.btnDeleteVeh.Name = "btnDeleteVeh"
        Me.btnDeleteVeh.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnDeleteVeh.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnDeleteVeh.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDeleteVeh.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnDeleteVeh.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnDeleteVeh.SelectedText = Nothing
        Me.btnDeleteVeh.Size = New System.Drawing.Size(118, 28)
        Me.btnDeleteVeh.TabIndex = 278
        Me.btnDeleteVeh.Text = "Remove Vehicle"
        Me.btnDeleteVeh.UseVisualStyleBackColor = False
        '
        'grpFindSupplier
        '
        Me.grpFindSupplier.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grpFindSupplier.Controls.Add(Me.btnFindSupplier)
        Me.grpFindSupplier.Controls.Add(Me.btnSelect)
        Me.grpFindSupplier.Controls.Add(Me.lstAccountName)
        Me.grpFindSupplier.Controls.Add(Me.txtSearch)
        Me.grpFindSupplier.Location = New System.Drawing.Point(96, 76)
        Me.grpFindSupplier.Name = "grpFindSupplier"
        Me.grpFindSupplier.Size = New System.Drawing.Size(253, 139)
        Me.grpFindSupplier.TabIndex = 270
        Me.grpFindSupplier.TabStop = False
        Me.grpFindSupplier.Visible = False
        '
        'btnFindSupplier
        '
        Me.btnFindSupplier.AlternativeGroup = Nothing
        Me.btnFindSupplier.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnFindSupplier.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnFindSupplier.BackColor1 = System.Drawing.Color.White
        Me.btnFindSupplier.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnFindSupplier.BorderHover = True
        Me.btnFindSupplier.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnFindSupplier.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnFindSupplier.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnFindSupplier.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnFindSupplier.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnFindSupplier.DrawBorder = True
        Me.btnFindSupplier.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnFindSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnFindSupplier.ForeColor = System.Drawing.Color.Navy
        Me.btnFindSupplier.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnFindSupplier.HoverColor2 = System.Drawing.Color.White
        Me.btnFindSupplier.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnFindSupplier.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnFindSupplier.Location = New System.Drawing.Point(181, 74)
        Me.btnFindSupplier.Name = "btnFindSupplier"
        Me.btnFindSupplier.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnFindSupplier.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnFindSupplier.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnFindSupplier.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnFindSupplier.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnFindSupplier.SelectedText = Nothing
        Me.btnFindSupplier.Size = New System.Drawing.Size(28, 21)
        Me.btnFindSupplier.TabIndex = 271
        Me.btnFindSupplier.Text = ". . ."
        Me.btnFindSupplier.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnFindSupplier.UseVisualStyleBackColor = False
        '
        'btnSelect
        '
        Me.btnSelect.AlternativeGroup = Nothing
        Me.btnSelect.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSelect.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSelect.BackColor1 = System.Drawing.Color.White
        Me.btnSelect.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSelect.BorderHover = True
        Me.btnSelect.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSelect.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSelect.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSelect.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSelect.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSelect.DrawBorder = True
        Me.btnSelect.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSelect.ForeColor = System.Drawing.Color.Navy
        Me.btnSelect.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSelect.HoverColor2 = System.Drawing.Color.White
        Me.btnSelect.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelect.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSelect.Location = New System.Drawing.Point(166, 16)
        Me.btnSelect.Name = "btnSelect"
        Me.btnSelect.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSelect.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSelect.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSelect.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSelect.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSelect.SelectedText = Nothing
        Me.btnSelect.Size = New System.Drawing.Size(75, 27)
        Me.btnSelect.TabIndex = 1
        Me.btnSelect.Text = "Select"
        Me.btnSelect.UseVisualStyleBackColor = False
        '
        'lstAccountName
        '
        Me.lstAccountName.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstAccountName.Location = New System.Drawing.Point(6, 36)
        Me.lstAccountName.Name = "lstAccountName"
        Me.lstAccountName.Size = New System.Drawing.Size(151, 82)
        Me.lstAccountName.TabIndex = 1
        '
        'txtSearch
        '
        Me.txtSearch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSearch.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtSearch.ForeColor = System.Drawing.Color.Maroon
        Me.txtSearch.Location = New System.Drawing.Point(6, 15)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(151, 22)
        Me.txtSearch.TabIndex = 0
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Comic Sans MS", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(894, 40)
        Me.lblfrmTitle.TabIndex = 159
        Me.lblfrmTitle.Text = " Purchase Order Form"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Panel1.Location = New System.Drawing.Point(0, 40)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(894, 3)
        Me.Panel1.TabIndex = 339
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label6.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label6.Location = New System.Drawing.Point(6, 262)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 21)
        Me.Label6.TabIndex = 369
        Me.Label6.Text = "Hot Keys:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblHotKeys
        '
        Me.lblHotKeys.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblHotKeys.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblHotKeys.ForeColor = System.Drawing.Color.Black
        Me.lblHotKeys.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblHotKeys.Location = New System.Drawing.Point(69, 262)
        Me.lblHotKeys.Name = "lblHotKeys"
        Me.lblHotKeys.Size = New System.Drawing.Size(246, 21)
        Me.lblHotKeys.TabIndex = 368
        Me.lblHotKeys.Text = " F3= Account Search"
        Me.lblHotKeys.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmPurchaseOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(894, 410)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.tcPurchaseOrder)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Name = "frmPurchaseOrder"
        Me.Tag = ""
        Me.Text = "Purchase Order"
        Me.tcPurchaseOrder.ResumeLayout(False)
        Me.tpPurchaseOrder.ResumeLayout(False)
        Me.grpButtons.ResumeLayout(False)
        CType(Me.grdPO, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        Me.grpFilterStatus.ResumeLayout(False)
        Me.grpFilterStatus.PerformLayout()
        Me.pnlInvisibleFields.ResumeLayout(False)
        Me.pnlInvisibleFields.PerformLayout()
        Me.tpPurchaseOrderDetail.ResumeLayout(False)
        CType(Me.grdPODetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpTotals.ResumeLayout(False)
        Me.grpTotals.PerformLayout()
        Me.grpDetails.ResumeLayout(False)
        Me.grpDetails.PerformLayout()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.grpRefInvoice.ResumeLayout(False)
        Me.grpRefInvoice.PerformLayout()
        Me.grpPODetailsButtons.ResumeLayout(False)
        Me.grpPODetailsButtons.PerformLayout()
        Me.grpFindSupplier.ResumeLayout(False)
        Me.grpFindSupplier.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents tcPurchaseOrder As System.Windows.Forms.TabControl
	Friend WithEvents tpPurchaseOrder As System.Windows.Forms.TabPage
    Friend WithEvents grdPO As System.Windows.Forms.DataGridView
	Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
	Friend WithEvents lblTo As System.Windows.Forms.Label
	Friend WithEvents lblFrom As System.Windows.Forms.Label
	Friend WithEvents dtpFilterTo As System.Windows.Forms.DateTimePicker
	Friend WithEvents dtpFilterFrom As System.Windows.Forms.DateTimePicker
	Friend WithEvents cboFilterSupplier As System.Windows.Forms.ComboBox
	Friend WithEvents lblSupplier As System.Windows.Forms.Label
	Friend WithEvents chkFilterUnposted As System.Windows.Forms.CheckBox
	Friend WithEvents chkFilterPosted As System.Windows.Forms.CheckBox
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnOpen As BHBut.BouncingHoverButton
	Friend WithEvents btnNew As BHBut.BouncingHoverButton
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
	Friend WithEvents btnDelete As BHBut.BouncingHoverButton
	Friend WithEvents tpPurchaseOrderDetail As System.Windows.Forms.TabPage
	Friend WithEvents grdPODetails As System.Windows.Forms.DataGridView
	Friend WithEvents grpDetails As System.Windows.Forms.GroupBox
	Friend WithEvents grpPODetailsButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnDetailClose As BHBut.BouncingHoverButton
	Friend WithEvents lblPOTotal As System.Windows.Forms.Label
	Friend WithEvents lblTotalExpense As System.Windows.Forms.Label
	Friend WithEvents lblTotal As System.Windows.Forms.Label
	Friend WithEvents lblPODate As System.Windows.Forms.Label
	Friend WithEvents txtDescription As System.Windows.Forms.TextBox
	Friend WithEvents lblSalesPerson As System.Windows.Forms.Label
	Friend WithEvents lblDescription As System.Windows.Forms.Label
	Friend WithEvents dtpPODate As System.Windows.Forms.DateTimePicker
	Friend WithEvents txtPONum As System.Windows.Forms.TextBox
	Friend WithEvents lblDate As System.Windows.Forms.Label
	Friend WithEvents lblPONum As System.Windows.Forms.Label
	Friend WithEvents cboAcctID As System.Windows.Forms.ComboBox
	Friend WithEvents lblPODetailSupplier As System.Windows.Forms.Label
	Friend WithEvents btnFindSupplier As BHBut.BouncingHoverButton
	Friend WithEvents grpFindSupplier As System.Windows.Forms.GroupBox
	Friend WithEvents btnSelect As BHBut.BouncingHoverButton
	Friend WithEvents lstAccountName As System.Windows.Forms.ListBox
	Friend WithEvents txtSearch As System.Windows.Forms.TextBox
	Friend WithEvents dtpInvDate As System.Windows.Forms.DateTimePicker
	Friend WithEvents lblRefNum As System.Windows.Forms.Label
	Friend WithEvents lblRedDate As System.Windows.Forms.Label
	Friend WithEvents grpRefInvoice As System.Windows.Forms.GroupBox
	Friend WithEvents txtInvoiceNum As System.Windows.Forms.TextBox
	Friend WithEvents txtTotal As System.Windows.Forms.TextBox
	Friend WithEvents txtPOTotal As System.Windows.Forms.TextBox
	Friend WithEvents txtExTotal As System.Windows.Forms.TextBox
	Friend WithEvents btnVehicle As BHBut.BouncingHoverButton
	Friend WithEvents txtQuantity As System.Windows.Forms.TextBox
	Friend WithEvents grpFilterStatus As System.Windows.Forms.GroupBox
	Friend WithEvents chkFilterNew As System.Windows.Forms.CheckBox
	Friend WithEvents grpTotals As System.Windows.Forms.GroupBox
	Friend WithEvents txtFilterPONum As System.Windows.Forms.TextBox
	Friend WithEvents btnShowColPO As System.Windows.Forms.Button
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents btnShowColPODetails As System.Windows.Forms.Button
	Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
	Friend WithEvents lblStatus As System.Windows.Forms.Label
	Friend WithEvents cboEmployee As System.Windows.Forms.ComboBox
	Friend WithEvents lblQuantity As System.Windows.Forms.Label
	Friend WithEvents btnDeleteVeh As BHBut.BouncingHoverButton
	Friend WithEvents txtDiscount As System.Windows.Forms.TextBox
	Friend WithEvents lblDiscount As System.Windows.Forms.Label
	Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
	Friend WithEvents btnDataErr As System.Windows.Forms.Button
	Friend WithEvents btnExpense As BHBut.BouncingHoverButton
	Friend WithEvents pnlInvisibleFields As System.Windows.Forms.Panel
	Friend WithEvents txtPOVehExp As System.Windows.Forms.TextBox
	Friend WithEvents lblPOVehExp As System.Windows.Forms.Label
	Friend WithEvents txtPOExp As System.Windows.Forms.TextBox
	Friend WithEvents lblPOExp As System.Windows.Forms.Label
	Friend WithEvents txtPOID As System.Windows.Forms.TextBox
	Friend WithEvents lblPOID As System.Windows.Forms.Label
	Friend WithEvents btnSave As BHBut.BouncingHoverButton
	Friend WithEvents btnPOvehExpense As BHBut.BouncingHoverButton
	Friend WithEvents btnPost As BHBut.BouncingHoverButton
	Friend WithEvents lblCompCurr As System.Windows.Forms.Label
	Friend WithEvents btnCancel As BHBut.BouncingHoverButton
	Friend WithEvents txtPORate As System.Windows.Forms.TextBox
	Friend WithEvents lblAcctCurrency As System.Windows.Forms.Label
	Friend WithEvents lblRate As System.Windows.Forms.Label
	Friend WithEvents btnRemoveVehicle As BHBut.BouncingHoverButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnPreview As BHBut.BouncingHoverButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblHotKeys As System.Windows.Forms.Label
End Class
