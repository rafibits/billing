<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUserPreferences
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUserPreferences))
        Me.lbltitle = New System.Windows.Forms.Label
        Me.lblpath = New System.Windows.Forms.Label
        Me.txtSharedDataPath = New System.Windows.Forms.TextBox
        Me.btnGetPath = New System.Windows.Forms.Button
        Me.ofdGetPath = New System.Windows.Forms.OpenFileDialog
        Me.chkUseComma = New System.Windows.Forms.CheckBox
        Me.lbldecdigits = New System.Windows.Forms.Label
        Me.cboDecDigit = New System.Windows.Forms.ComboBox
        Me.ColorDialog = New System.Windows.Forms.ColorDialog
        Me.lblfcolor = New System.Windows.Forms.Label
        Me.lblbkcolor = New System.Windows.Forms.Label
        Me.lblgrdcolor = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.txtTitleForeColor = New System.Windows.Forms.TextBox
        Me.txtGridBackColor = New System.Windows.Forms.TextBox
        Me.txtTitleBackColor = New System.Windows.Forms.TextBox
        Me.lblUserID = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.grpUserInput = New System.Windows.Forms.GroupBox
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpUserInput.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbltitle
        '
        Me.lbltitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lbltitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lbltitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltitle.ForeColor = System.Drawing.Color.LightYellow
        Me.lbltitle.Location = New System.Drawing.Point(0, 0)
        Me.lbltitle.Name = "lbltitle"
        Me.lbltitle.Size = New System.Drawing.Size(581, 45)
        Me.lbltitle.TabIndex = 0
        Me.lbltitle.Text = "  User Preferences"
        Me.lbltitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblpath
        '
        Me.lblpath.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblpath.ForeColor = System.Drawing.Color.Maroon
        Me.lblpath.Location = New System.Drawing.Point(15, 64)
        Me.lblpath.Name = "lblpath"
        Me.lblpath.Size = New System.Drawing.Size(100, 20)
        Me.lblpath.TabIndex = 3
        Me.lblpath.Text = "Shared Data Path"
        Me.lblpath.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtSharedDataPath
        '
        Me.txtSharedDataPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtSharedDataPath.Location = New System.Drawing.Point(15, 85)
        Me.txtSharedDataPath.Name = "txtSharedDataPath"
        Me.txtSharedDataPath.Size = New System.Drawing.Size(472, 20)
        Me.txtSharedDataPath.TabIndex = 4
        '
        'btnGetPath
        '
        Me.btnGetPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnGetPath.Location = New System.Drawing.Point(493, 84)
        Me.btnGetPath.Name = "btnGetPath"
        Me.btnGetPath.Size = New System.Drawing.Size(61, 21)
        Me.btnGetPath.TabIndex = 5
        Me.btnGetPath.Text = "Get Path"
        Me.btnGetPath.UseVisualStyleBackColor = True
        '
        'ofdGetPath
        '
        Me.ofdGetPath.FileName = "get path"
        '
        'chkUseComma
        '
        Me.chkUseComma.AutoSize = True
        Me.chkUseComma.Location = New System.Drawing.Point(167, 25)
        Me.chkUseComma.Name = "chkUseComma"
        Me.chkUseComma.Size = New System.Drawing.Size(82, 17)
        Me.chkUseComma.TabIndex = 6
        Me.chkUseComma.Text = "Use Comma"
        Me.chkUseComma.UseVisualStyleBackColor = True
        '
        'lbldecdigits
        '
        Me.lbldecdigits.ForeColor = System.Drawing.Color.Maroon
        Me.lbldecdigits.Location = New System.Drawing.Point(12, 23)
        Me.lbldecdigits.Name = "lbldecdigits"
        Me.lbldecdigits.Size = New System.Drawing.Size(71, 20)
        Me.lbldecdigits.TabIndex = 7
        Me.lbldecdigits.Text = "Decimal Digit"
        Me.lbldecdigits.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboDecDigit
        '
        Me.cboDecDigit.DisplayMember = "0"
        Me.cboDecDigit.FormattingEnabled = True
        Me.cboDecDigit.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8"})
        Me.cboDecDigit.Location = New System.Drawing.Point(89, 23)
        Me.cboDecDigit.Name = "cboDecDigit"
        Me.cboDecDigit.Size = New System.Drawing.Size(53, 21)
        Me.cboDecDigit.TabIndex = 8
        Me.cboDecDigit.ValueMember = "0"
        '
        'lblfcolor
        '
        Me.lblfcolor.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblfcolor.ForeColor = System.Drawing.Color.Maroon
        Me.lblfcolor.Location = New System.Drawing.Point(32, 222)
        Me.lblfcolor.Name = "lblfcolor"
        Me.lblfcolor.Size = New System.Drawing.Size(205, 16)
        Me.lblfcolor.TabIndex = 9
        Me.lblfcolor.Text = "Title Fore Color"
        Me.lblfcolor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblfcolor.Visible = False
        '
        'lblbkcolor
        '
        Me.lblbkcolor.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblbkcolor.ForeColor = System.Drawing.Color.Maroon
        Me.lblbkcolor.Location = New System.Drawing.Point(283, 222)
        Me.lblbkcolor.Name = "lblbkcolor"
        Me.lblbkcolor.Size = New System.Drawing.Size(205, 16)
        Me.lblbkcolor.TabIndex = 11
        Me.lblbkcolor.Text = "Title Back Color"
        Me.lblbkcolor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblbkcolor.Visible = False
        '
        'lblgrdcolor
        '
        Me.lblgrdcolor.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblgrdcolor.ForeColor = System.Drawing.Color.Maroon
        Me.lblgrdcolor.Location = New System.Drawing.Point(35, 334)
        Me.lblgrdcolor.Name = "lblgrdcolor"
        Me.lblgrdcolor.Size = New System.Drawing.Size(205, 16)
        Me.lblgrdcolor.TabIndex = 13
        Me.lblgrdcolor.Text = "Grid Back Color"
        Me.lblgrdcolor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblgrdcolor.Visible = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox2.Controls.Add(Me.btnCancel)
        Me.GroupBox2.Controls.Add(Me.btnClose)
        Me.GroupBox2.Controls.Add(Me.btnSave)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 453)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(557, 53)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.HoverColor2 = System.Drawing.Color.White
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCancel.Location = New System.Drawing.Point(121, 16)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCancel.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(99, 27)
        Me.btnCancel.TabIndex = 4
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(447, 16)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(99, 27)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(8, 16)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(99, 27)
        Me.btnSave.TabIndex = 1
        Me.btnSave.Text = "E d i t"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'txtTitleForeColor
        '
        Me.txtTitleForeColor.AcceptsReturn = True
        Me.txtTitleForeColor.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtTitleForeColor.BackColor = System.Drawing.Color.LightYellow
        Me.txtTitleForeColor.Font = New System.Drawing.Font("Tahoma", 48.0!)
        Me.txtTitleForeColor.ForeColor = System.Drawing.Color.LightYellow
        Me.txtTitleForeColor.Location = New System.Drawing.Point(32, 240)
        Me.txtTitleForeColor.Name = "txtTitleForeColor"
        Me.txtTitleForeColor.ReadOnly = True
        Me.txtTitleForeColor.Size = New System.Drawing.Size(205, 85)
        Me.txtTitleForeColor.TabIndex = 17
        Me.txtTitleForeColor.Visible = False
        '
        'txtGridBackColor
        '
        Me.txtGridBackColor.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtGridBackColor.BackColor = System.Drawing.Color.Lavender
        Me.txtGridBackColor.Font = New System.Drawing.Font("Tahoma", 48.0!)
        Me.txtGridBackColor.Location = New System.Drawing.Point(32, 352)
        Me.txtGridBackColor.Name = "txtGridBackColor"
        Me.txtGridBackColor.ReadOnly = True
        Me.txtGridBackColor.Size = New System.Drawing.Size(205, 85)
        Me.txtGridBackColor.TabIndex = 18
        Me.txtGridBackColor.Visible = False
        '
        'txtTitleBackColor
        '
        Me.txtTitleBackColor.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtTitleBackColor.BackColor = System.Drawing.Color.LightSteelBlue
        Me.txtTitleBackColor.Font = New System.Drawing.Font("Tahoma", 48.0!)
        Me.txtTitleBackColor.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.txtTitleBackColor.Location = New System.Drawing.Point(286, 240)
        Me.txtTitleBackColor.Name = "txtTitleBackColor"
        Me.txtTitleBackColor.ReadOnly = True
        Me.txtTitleBackColor.Size = New System.Drawing.Size(218, 85)
        Me.txtTitleBackColor.TabIndex = 19
        Me.txtTitleBackColor.Visible = False
        '
        'lblUserID
        '
        Me.lblUserID.BackColor = System.Drawing.Color.White
        Me.lblUserID.Location = New System.Drawing.Point(363, 9)
        Me.lblUserID.Name = "lblUserID"
        Me.lblUserID.Size = New System.Drawing.Size(100, 23)
        Me.lblUserID.TabIndex = 15
        Me.lblUserID.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PictureBox1.Location = New System.Drawing.Point(0, 45)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(581, 3)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 247
        Me.PictureBox1.TabStop = False
        '
        'grpUserInput
        '
        Me.grpUserInput.Controls.Add(Me.cboDecDigit)
        Me.grpUserInput.Controls.Add(Me.lbldecdigits)
        Me.grpUserInput.Controls.Add(Me.chkUseComma)
        Me.grpUserInput.Controls.Add(Me.btnGetPath)
        Me.grpUserInput.Controls.Add(Me.txtSharedDataPath)
        Me.grpUserInput.Controls.Add(Me.lblpath)
        Me.grpUserInput.Location = New System.Drawing.Point(10, 58)
        Me.grpUserInput.Name = "grpUserInput"
        Me.grpUserInput.Size = New System.Drawing.Size(563, 139)
        Me.grpUserInput.TabIndex = 248
        Me.grpUserInput.TabStop = False
        '
        'frmUserPreferences
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(581, 518)
        Me.Controls.Add(Me.grpUserInput)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtTitleBackColor)
        Me.Controls.Add(Me.txtGridBackColor)
        Me.Controls.Add(Me.txtTitleForeColor)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.lblUserID)
        Me.Controls.Add(Me.lblgrdcolor)
        Me.Controls.Add(Me.lblbkcolor)
        Me.Controls.Add(Me.lblfcolor)
        Me.Controls.Add(Me.lbltitle)
        Me.KeyPreview = True
        Me.Name = "frmUserPreferences"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "User Preferences"
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpUserInput.ResumeLayout(False)
        Me.grpUserInput.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbltitle As System.Windows.Forms.Label
    Friend WithEvents lblpath As System.Windows.Forms.Label
    Friend WithEvents txtSharedDataPath As System.Windows.Forms.TextBox
    Friend WithEvents btnGetPath As System.Windows.Forms.Button
    Friend WithEvents ofdGetPath As System.Windows.Forms.OpenFileDialog
    Friend WithEvents chkUseComma As System.Windows.Forms.CheckBox
    Friend WithEvents lbldecdigits As System.Windows.Forms.Label
    Friend WithEvents cboDecDigit As System.Windows.Forms.ComboBox
    Friend WithEvents ColorDialog As System.Windows.Forms.ColorDialog
    Friend WithEvents lblfcolor As System.Windows.Forms.Label
    Friend WithEvents lblbkcolor As System.Windows.Forms.Label
    Friend WithEvents lblgrdcolor As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents btnSave As BHBut.BouncingHoverButton
    Friend WithEvents txtTitleForeColor As System.Windows.Forms.TextBox
    Friend WithEvents txtGridBackColor As System.Windows.Forms.TextBox
    Friend WithEvents txtTitleBackColor As System.Windows.Forms.TextBox
    Friend WithEvents lblUserID As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents grpUserInput As System.Windows.Forms.GroupBox
    Friend WithEvents btnCancel As BHBut.BouncingHoverButton
End Class
