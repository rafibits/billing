<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmClientGet
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing AndAlso components IsNot Nothing Then
			components.Dispose()
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.grpAccSearch = New System.Windows.Forms.GroupBox
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.txtFilterName = New System.Windows.Forms.TextBox
        Me.txtFilterNum = New System.Windows.Forms.TextBox
        Me.lblNumberSearch = New System.Windows.Forms.Label
        Me.lblNameSearch = New System.Windows.Forms.Label
        Me.grdClientSearch = New System.Windows.Forms.DataGridView
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnOK = New BHBut.BouncingHoverButton
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.grpAccSearch.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        CType(Me.grdClientSearch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpAccSearch
        '
        Me.grpAccSearch.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpAccSearch.BackColor = System.Drawing.Color.Transparent
        Me.grpAccSearch.Controls.Add(Me.grpShowHideColumns)
        Me.grpAccSearch.Controls.Add(Me.btnShowCol)
        Me.grpAccSearch.Controls.Add(Me.txtFilterName)
        Me.grpAccSearch.Controls.Add(Me.txtFilterNum)
        Me.grpAccSearch.Controls.Add(Me.lblNumberSearch)
        Me.grpAccSearch.Controls.Add(Me.lblNameSearch)
        Me.grpAccSearch.Controls.Add(Me.grdClientSearch)
        Me.grpAccSearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.grpAccSearch.Location = New System.Drawing.Point(12, 47)
        Me.grpAccSearch.Name = "grpAccSearch"
        Me.grpAccSearch.Size = New System.Drawing.Size(457, 409)
        Me.grpAccSearch.TabIndex = 347
        Me.grpAccSearch.TabStop = False
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(49, 45)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 232)
        Me.grpShowHideColumns.TabIndex = 353
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 200)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 169)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(7, 45)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 352
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'txtFilterName
        '
        Me.txtFilterName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFilterName.Location = New System.Drawing.Point(169, 18)
        Me.txtFilterName.Name = "txtFilterName"
        Me.txtFilterName.Size = New System.Drawing.Size(282, 20)
        Me.txtFilterName.TabIndex = 348
        '
        'txtFilterNum
        '
        Me.txtFilterNum.Location = New System.Drawing.Point(49, 18)
        Me.txtFilterNum.Name = "txtFilterNum"
        Me.txtFilterNum.Size = New System.Drawing.Size(85, 20)
        Me.txtFilterNum.TabIndex = 349
        '
        'lblNumberSearch
        '
        Me.lblNumberSearch.Location = New System.Drawing.Point(6, 19)
        Me.lblNumberSearch.Name = "lblNumberSearch"
        Me.lblNumberSearch.Size = New System.Drawing.Size(47, 18)
        Me.lblNumberSearch.TabIndex = 351
        Me.lblNumberSearch.Text = "Number"
        '
        'lblNameSearch
        '
        Me.lblNameSearch.Location = New System.Drawing.Point(134, 21)
        Me.lblNameSearch.Name = "lblNameSearch"
        Me.lblNameSearch.Size = New System.Drawing.Size(35, 15)
        Me.lblNameSearch.TabIndex = 350
        Me.lblNameSearch.Text = "Name"
        '
        'grdClientSearch
        '
        Me.grdClientSearch.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdClientSearch.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdClientSearch.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.grdClientSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdClientSearch.Location = New System.Drawing.Point(6, 44)
        Me.grdClientSearch.Name = "grdClientSearch"
        Me.grdClientSearch.Size = New System.Drawing.Size(445, 359)
        Me.grdClientSearch.TabIndex = 347
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Controls.Add(Me.btnOK)
        Me.grpButtons.Location = New System.Drawing.Point(12, 462)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(457, 52)
        Me.grpButtons.TabIndex = 130
        Me.grpButtons.TabStop = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.Orange
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.Orange
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCancel.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Location = New System.Drawing.Point(341, 15)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(105, 28)
        Me.btnCancel.TabIndex = 41
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnOK
        '
        Me.btnOK.AlternativeGroup = Nothing
        Me.btnOK.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnOK.BackColor1 = System.Drawing.Color.White
        Me.btnOK.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnOK.BorderHover = True
        Me.btnOK.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnOK.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnOK.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnOK.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnOK.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnOK.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOK.DrawBorder = True
        Me.btnOK.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.ForeColor = System.Drawing.Color.Navy
        Me.btnOK.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnOK.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnOK.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnOK.Location = New System.Drawing.Point(9, 15)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnOK.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnOK.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnOK.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnOK.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnOK.SelectedText = Nothing
        Me.btnOK.Size = New System.Drawing.Size(105, 28)
        Me.btnOK.TabIndex = 17
        Me.btnOK.Text = "O K"
        Me.btnOK.UseVisualStyleBackColor = False
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.Black
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 1)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(481, 43)
        Me.lblfrmTitle.TabIndex = 509
        Me.lblfrmTitle.Text = "  Client List"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlTitle
        '
        Me.pnlTitle.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 41)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(934, 3)
        Me.pnlTitle.TabIndex = 510
        '
        'frmClientGet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(481, 526)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.grpAccSearch)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.grpButtons)
        Me.KeyPreview = True
        Me.Name = "frmClientGet"
        Me.Text = "  Client List"
        Me.grpAccSearch.ResumeLayout(False)
        Me.grpAccSearch.PerformLayout()
        Me.grpShowHideColumns.ResumeLayout(False)
        CType(Me.grdClientSearch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpButtons.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
	Friend WithEvents btnCancel As BHBut.BouncingHoverButton
	Friend WithEvents btnOK As BHBut.BouncingHoverButton
	Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
	Friend WithEvents grpAccSearch As System.Windows.Forms.GroupBox
	Friend WithEvents lblNumberSearch As System.Windows.Forms.Label
	Friend WithEvents lblNameSearch As System.Windows.Forms.Label
	Friend WithEvents txtFilterNum As System.Windows.Forms.TextBox
	Friend WithEvents txtFilterName As System.Windows.Forms.TextBox
	Friend WithEvents grdClientSearch As System.Windows.Forms.DataGridView
	Friend WithEvents btnShowCol As System.Windows.Forms.Button
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
    Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
End Class
