Imports BITSConn
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Public Class frmClient_V1

#Region "Form - Declaration..."
   Dim clsMr As ClsMain
   Dim dsdata As New DataSet
   Private WithEvents Nav As BitsNav
   Private daClient As SqlDataAdapter
   Dim daStreet As SqlClient.SqlDataAdapter
   Private daAddress As SqlDataAdapter
   Private blnLoading As Boolean   '' Used to flag when loading form (T/F)...
   Private AddMode As Boolean
   Private AddressAddMode As Boolean
   Dim mStrTableName As String = "tblClient"
   Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Address\Settings"
   Dim StrSql As String
   Dim dataChange As Boolean = False
   Dim mID As Integer
   Dim blnPic As Boolean = False ' Pic Boolean 
   Dim mStrPicSource As String '' Pic source path 
   Dim ifSave As Boolean = False
    Private mStrCurrentState As String
    Public frmClient As frmClientList
#End Region

#Region "Form - Load..."

   Private Sub frmClient_V1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

      clsMr = New ClsMain(conSql)
      Nav = New BitsNav

      blnLoading = True
      ''
      MakeDataAdapter()
      FillComboBox()
      SetAutoNumber()
      SetDataBinding()
      SetCurrencyManager()
      SetDefaultValue()


      If mID = 0 Then
         NewRecord()
      Else
         Nav.CurrentPosition = GetRowIndex(mID)
         setState("Browse")
         BringPicFromDataBase()
         If dsdata.Tables("tblClient").DefaultView.Item(Nav.CurrentPosition)("Discount") <> 0 Then
            lblDiscount.Visible = True
            txtDiscount.Visible = True
            lblPercent.Visible = True
            chkNatAirLines.Checked = True
         End If
         dataChange = False
      End If

      DrawGrid()
      FilterAddress()
      ''
      tcAddress.TabPages.Remove(tpNewAddress)
        blnLoading = False
   End Sub

   Private Sub frmImages_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
      '' Save User Grid Setting...
      SaveProfile(mStrSubKeyName, Me.grdViewAddress)
   End Sub

#End Region

#Region " Form - Global Shared Methods..."

    Private Sub MakeDataAdapter()

        daClient = clsMr.BuildSqlAdapter("SELECT * FROM tblClient WHERE Del = 0 And ClientID=" & mID & " AND  DepartmentID=" & gIntDepartment, "tblClient")
        clsMr.BuildSqlAdapter("SELECT ClEmployeeID,(FName_En +''+ MName_En +''+ LName_En)AS Name from tblClientEmployee where ClEmployeeTitleID=1 And Del =0 ", "ClEmpName")
        ''Address
        daAddress = clsMr.BuildSqlAdapter("SELECT *  FROM tblAddress WHERE del =0", "tblAddress")
        daStreet = clsMr.BuildSqlAdapter("SELECT StreetID,AreaID,CityID,Street_en,Del FROM tblAddStreet WHERE del=0", "Street")
        clsMr.BuildSqlAdapter("SELECT *  FROM vwAddress WHERE del =0", "vwAddress")
        clsMr.BuildSqlAdapter("SELECT CityID,City_en,Del,StateID FROM tblAddCity WHERE del =0", "City")

        clsMr.BuildSqlAdapter("SELECT CityID,AreaID,Area_en  FROM tblAddArea WHERE del =0", "Area")
        clsMr.BuildSqlAdapter("SELECT * FROM tblAddressType ", "AddressType")
        clsMr.BuildSqlAdapter("SELECT StateID,State_en FROM tblAddState WHERE del=0", "State")
        clsMr.BuildSqlAdapter("SELECT StateID,State_en FROM tblAddState WHERE del=0", "StateOfBirth")
        clsMr.BuildSqlAdapter("SELECT * FROM tblAddressType ", "AddressType")
        clsMr.BuildSqlAdapter("SELECT CurrID,Symbol FROM tblCurrency WHERE Del=0 ", "tblCurrency")
        clsMr.BuildSqlAdapter("SELECT ClientTypeID, ClientType FROM tblClientType WHERE Del =0", "tblClientType")

        dsdata = clsMr.getDataSet()


    End Sub

    Private Sub FillComboBox()
        ''
        'clsMr.FillComboBox("ClEmpName", Me.cboManagerName, "Name", "ClEmployeeID")
        clsMr.FillComboBox("State", Me.cboState, "State_en", "StateID")
        clsMr.FillComboBox("City", Me.CboCity, "City_en", "CityID")
        clsMr.FillComboBox("Street", Me.CboStreet, "Street_en", "StreetID")



        clsMr.FillComboBox("Area", Me.cboArea, "Area_en", "AreaID")
        clsMr.FillComboBox("AddressType", Me.cboAddType, "AddType", "AddTypeID")
        clsMr.FillComboBox("tblCurrency", cboCurrency, "Symbol", "CurrID")
        clsMr.FillComboBox("tblClientType", cboClientType, "ClientType", "ClientTypeID")
        ''
    End Sub

   Private Sub SetAutoNumber()
      Dim lngMaxClient As Long
      clsMr.SetAutoNumber("tblClient", "ClientID")
      lngMaxClient = clsMr.GetMaxNumber("select max(ClientNum) from tblClient") + 1
      clsMr.SetAutoNumber("tblClient", "ClientNum", lngMaxClient)

   End Sub

    Private Sub SetDataBinding()
        '' tblClient
        clsMr.BindTextBox(Me.txtID, "tblClient", "ClientID")
        clsMr.BindTextBox(Me.txtClient, "tblClient", "ClientNum")
        clsMr.BindTextBox(Me.txtClientName, "tblClient", "ClientName")
        clsMr.BindTextBox(Me.txtContactName, "tblClient", "ContactName")
        clsMr.BindTextBox(Me.txtTel, "tblClient", "Tel")
        clsMr.BindTextBox(Me.txtFax, "tblClient", "Fax")
        clsMr.BindTextBox(Me.txtCel, "tblClient", "Cell")
        clsMr.BindTextBox(Me.txtExt, "tblClient", "Ext")
        clsMr.BindTextBox(Me.txtEmail, "tblClient", "Email")
        clsMr.BindTextBox(Me.txtWebSite, "tblClient", "WebSite")
        clsMr.BindTextBox(Me.txtNote, "tblClient", "Note")
        clsMr.BindTextBox(Me.txtDiscount, "tblClient", "Discount")
        clsMr.BindTextBox(Me.txtICAO, "tblClient", "ICAO")
        clsMr.BindTextBox(Me.txtIATA, "tblClient", "IATA")
        clsMr.BindTextBox(Me.txtBalance, "tblClient", "balance")
        clsMr.BindTextBox(Me.txtPendingBalance, "tblClient", "PendingBal")
        clsMr.BindComboBox(cboCurrency, "tblClient", "CurrencyID")
        clsMr.BindComboBox(cboClientType, "tblClient", "ClientTypeID")
        ''
    End Sub

   Private Sub SetCurrencyManager()
      Nav.SetCurrency(Me, clsMr.getDataSet(), "tblClient")
   End Sub


   Public Sub SetDefaultValue()
		clsMr.SetDefaults("tblClient", "Del", 0, "CreateBy", gIntUserID, "CreateDate", Now.Date, "DepartmentID", gIntDepartment, "Discount", 0, "CurrencyID", gIntCompanyCurrID, "Balance", 0, "PendingBal", 0)

   End Sub


#End Region

#Region "Form - Functions..."

   Public Function GetRowIndex(ByVal PClientID As Long) As Integer
      ''
      Dim i As Integer
      For i = 0 To dsdata.Tables(mStrTableName).Rows.Count - 1
         If dsdata.Tables(mStrTableName).DefaultView.Item(i)("ClientID") = mID Then
            Return i
         End If
      Next
      ''
   End Function

   Private Sub DrawGrid()
      ''
      With grdViewAddress
         .DataSource = dsdata.Tables("vwAddress").DefaultView
         .ColumnHeadersHeight = btnShowCol.Height + 2
         .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
      End With
      dsdata.Tables("vwAddress").DefaultView.AllowNew = False
      grdViewAddress.ReadOnly = True
      grdViewAddress.Columns("AddType").HeaderText = "Type"

      ''change column header
      If gStrLang = "en" Then
			grdViewAddress.Columns("State_en").HeaderText = "Country"
         grdViewAddress.Columns("Street_en").HeaderText = "Street"
         grdViewAddress.Columns("Area_en").HeaderText = "Area"
         grdViewAddress.Columns("City_en").HeaderText = "City"
      Else
         grdViewAddress.Columns("State_ar").HeaderText = "�����"
         grdViewAddress.Columns("Street_ar").HeaderText = "������"
         grdViewAddress.Columns("Area_ar").HeaderText = "�������"
         grdViewAddress.Columns("City_ar").HeaderText = "�������"
      End If

      LoadProfile(mStrSubKeyName, Me.grdViewAddress)
      AddressNotVisibleFields()
      ''
   End Sub

   Private Sub setState(ByRef pStrMode As String)
      ''
      mStrCurrentState = UCase(pStrMode)
      '' 
      Select Case mStrCurrentState

         Case Is = "NEW"
            btnSave.Enabled = False
            btnCancel.Enabled = True
            btnNew.Enabled = False
            grpDetail.Enabled = True
            tcAddress.Enabled = True
            btnSave.Text = "S a v e"
            AddMode = True

         Case Is = "EDIT"
            btnSave.Enabled = False
            btnCancel.Enabled = True
            btnNew.Enabled = False
            grpDetail.Enabled = True
            tcAddress.Enabled = True
            btnSave.Text = "S a v e"

         Case Is = "SAVE"
            btnSave.Enabled = True
            btnCancel.Enabled = False
            btnNew.Enabled = True
            btnSave.Text = "E d i t"
            grpDetail.Enabled = False
            tcAddress.Enabled = False
            AddMode = False

         Case Is = "BROWSE"
            btnSave.Enabled = True
            btnCancel.Enabled = False
            btnNew.Enabled = True
            btnSave.Text = "E d i t"
            grpDetail.Enabled = False
            tcAddress.Enabled = False
      End Select
      ''
   End Sub

   Private Sub NewRecord()
      ''
      Nav.AddNew()
      setState("New")
      CheckValues()
      FilterAddress()
      chkNatAirLines.Visible = True
      cboCurrency.Enabled = True
      ''
   End Sub

   Private Sub save()
      ''
      dataChange = False
      If blnPic Then SavePicToDB()
      Nav.EndCurrentEdit()
		daClient.Update(dsdata, "tblClient")
      cboCurrency.Enabled = False
      ''
   End Sub

#End Region

#Region " Form - Check Values..."
   Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
      '' Show/Hide error list...
      If lstDataErr.Visible = True Then
         lstDataErr.Visible = False
      Else
         lstDataErr.Visible = True
         lstDataErr.Height = 30

         lstDataErr.BringToFront()
      End If
   End Sub


   Private Sub CheckValues()
      If blnLoading = True Then Exit Sub

      ''
      dataChange = True

      '' clear entir list & start fresh check...
      ''
      lstDataErr.Items.Clear()
      Dim intErrCount As Int16 = 0


      intErrCount += 1

		If txtClientName.Text = String.Empty Then
			lstDataErr.Items.Add("Please Enter Client Name")
			intErrCount += 1
		End If
		'If txtTel.Text = String.Empty And txtCel.Text = String.Empty Then
		'   lstDataErr.Items.Add("Please Enter Telephone Number")
		'   intErrCount += 1
		'End If
		'If txtEmail.Text = String.Empty And txtWebSite.Text = String.Empty Then
		'   lstDataErr.Items.Add("Please Enter Email or Website Address")
		'   intErrCount += 1
		'End If
 

      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      '' Set appropriate controls based on errors check results...
      '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
      If lstDataErr.Items.Count = 0 Then
         lstDataErr.Visible = False
         btnDataErr.Visible = False
         btnSave.Enabled = True
      Else
         btnDataErr.Visible = True
         btnSave.Enabled = False
      End If
   End Sub

   Private Sub clearList()
      Dim i As Integer

      For i = 0 To lstDataErr.Items.Count - 1
         lstDataErr.Items.RemoveAt(lstDataErr.Items.Count - 1)
      Next

   End Sub



#End Region

#Region "Form - Address - Functions..."
   Private Sub BringPicFromDataBase()

      'Bring picture from data base 

      ' ask if there is any records in the db 
      If dsdata.Tables("tblClient").Rows.Count = 0 Then Exit Sub

      ' ask if the field Photo is null in the database 
      If IsDBNull(dsdata.Tables("tblClient").Rows(GetRowIndex())("ClientImage")) Then picPersonnel.Image = Nothing : Exit Sub
      Dim arrPicture() As Byte = _
      CType(dsdata.Tables("tblClient").Rows(GetRowIndex())("ClientImage"), Byte())
      Dim ms As New System.IO.MemoryStream(arrPicture)
      With picPersonnel
         .Image = Image.FromStream(ms)
         .SizeMode = PictureBoxSizeMode.StretchImage
         .BorderStyle = BorderStyle.Fixed3D
      End With
      ''''''''''
   End Sub
   Public Function GetRowIndex() As Integer
      Dim i As Integer
      For i = 0 To dsdata.Tables("tblClient").DefaultView.Count - 1
         If dsdata.Tables("tblClient").DefaultView.Item(i)("ClientID") = txtID.text Then
            Return i
         End If
      Next
      Return -1
   End Function
   Private Sub FilterAddress()
      blnLoading = False
      Dim vw As DataView
      If txtID.Text = String.Empty Then
         txtID.Text = -1
      End If
      If txtID.Text <> "" Then
         vw = dsdata.Tables("vwAddress").DefaultView
         vw.RowFilter = "ClientID=" & txtID.Text & " "
      End If
      If grdViewAddress.Rows.Count = 0 Then
         btnDeleteAddress.Visible = False
         btnEditAddress.Visible = False
      Else
         btnEditAddress.Visible = True
         btnDeleteAddress.Visible = True
      End If

   End Sub

   Private Sub NewAddress()
      ''Add tab Page if not found
      If Not tcAddress.TabPages.Contains(tpNewAddress) Then
         tcAddress.TabPages.Add(tpNewAddress)
         tpNewAddress.Text = "New"
      End If


      tcAddress.SelectedTab = tpNewAddress

      ''Get Auto Number for AddressID
      Dim AddressID As Long
      Try
         Dim cmdAddressID As New SqlClient.SqlCommand("SELECT CASE WHEN MAX(AddressID) IS NULL THEN 1 ELSE MAX(AddressID)+1 END FROM tblAddress", conSql)
         conSql.Open()
         AddressID = cmdAddressID.ExecuteScalar
         conSql.Close()
      Catch ex As Exception
         conSql.Close()
      End Try

      txtAddID.Text = AddressID
      btnSaveAddress.Enabled = True
      tpNewAddress.Visible = True

      ''clear address combos
      If cboAddType.Items.Count <> 0 Then
         cboAddType.SelectedIndex = 0
      End If

      cboArea.SelectedIndex = -1
      CboCity.SelectedIndex = -1
      CboStreet.SelectedIndex = -1
      If cboState.Items.Count <> 0 Then
         cboState.SelectedIndex = 0
      End If

      cboArea.Text = ""
      CboCity.Text = ""
      CboStreet.Text = ""

      btnSaveAddress.Enabled = True
      AddressAddMode = True
   End Sub

   Private Function CheckAddressValues() As Boolean
      strMsg = ""

      If cboAddType.Text = "" Then
         strMsg = "Please insert AddressType " & vbCrLf
      End If

      If CboCity.Text = "" Then
         strMsg = strMsg & "Please enter City  " & vbCrLf
      End If
      If CboStreet.Text = "" Then
         strMsg = strMsg & "Please enter  Street  " & vbCrLf
      End If
      If strMsg <> "" Then
         strMsg = "The following value(s) is/are not valid: " & vbCrLf & strMsg
			MsgBox(strMsg)
         Return False
      Else
         Return True
      End If

   End Function

   Private Sub SaveAddress()

      If CheckAddressValues() = False Then Exit Sub

      If lstDataErr.Items.Count <> 0 Then
         MsgBox("Cannot save. Please check error list")
         Exit Sub
      Else
         save()
      End If

      If AddressAddMode = True Then
         dsdata.Tables("vwAddress").DefaultView.AllowNew = True
         ''adding new Address
         Dim drAddress As DataRow
         Dim drNew As DataRow

         ''add new row
         drAddress = dsdata.Tables("vwAddress").NewRow
         drNew = dsdata.Tables("tblAddress").NewRow

         drAddress("ClientID") = txtID.Text
         drNew("ClientID") = txtID.Text
         '' add values to fields
         UpdateAddressDataRow(drAddress)
         UpdateAddressDataRow(drNew)

         drAddress("AddType") = cboAddType.Text
         drAddress("State_en") = cboState.Text
         ' drAddress("Region_en") = cboRegion.Text
         ' drAddress("Qadaa_en") = cboQadaa.Text
         drAddress("City_en") = CboCity.Text
         drAddress("Area_en") = cboArea.Text
         drAddress("Street_en") = CboStreet.Text

         drAddress("Del") = 0
         drNew("Del") = 0
         ''add the created row
         dsdata.Tables("vwAddress").Rows.Add(drAddress)
         drAddress.EndEdit()
         dsdata.Tables("tblAddress").Rows.Add(drNew)
         clsMr.Update(daAddress, "tblAddress")

         dsdata.Tables("vwAddress").DefaultView.AllowNew = False

         AddressAddMode = False
      Else
         Dim drAddress() As DataRow
         Dim drUpdate() As DataRow
         drUpdate = dsdata.Tables("tblAddress").Select("AddressID = " & txtAddID.Text)
         drAddress = dsdata.Tables("vwAddress").Select("AddressID = " & txtAddID.Text)

         UpdateAddressDataRow(drAddress(0))
         UpdateAddressDataRow(drUpdate(0))
         drAddress(0)("AddType") = cboAddType.Text
         drAddress(0)("State_en") = cboState.Text
         drAddress(0)("City_en") = CboCity.Text
         drAddress(0)("Area_en") = cboArea.Text
         drAddress(0)("Street_en") = CboStreet.Text
         drAddress(0).EndEdit()
         clsMr.Update(daAddress, "tblAddress")
         dsdata.Tables("vwAddress").DefaultView.AllowNew = False

      End If
      btnEditAddress.Visible = True
      tcAddress.TabPages.Remove(tpNewAddress)
   End Sub

   Private Sub UpdateAddressDataRow(ByVal pDr As DataRow)

      pDr("AddressID") = txtAddID.Text

      If cboAddType.SelectedIndex = -1 Then
         pDr("AddTypeID") = DBNull.Value
      Else
         pDr("AddTypeID") = cboAddType.SelectedValue
         'pDr("AddType") = cboAddType.Text
      End If

      If cboState.SelectedIndex = -1 Then
         pDr("StateID") = DBNull.Value
      Else
         pDr("StateID") = cboState.SelectedValue
         'pDr("State_en") = cboState.Text
      End If



      If CboCity.SelectedIndex = -1 Then
         pDr("CityID") = DBNull.Value
      Else
         pDr("CityID") = CboCity.SelectedValue

      End If

      If cboArea.SelectedIndex = -1 Then
         pDr("AreaID") = DBNull.Value
      Else
         pDr("AreaID") = cboArea.SelectedValue

      End If


      If CboStreet.SelectedIndex = -1 Then
         pDr("StreetID") = DBNull.Value
      Else
         pDr("StreetID") = CboStreet.SelectedValue

      End If

      If txtBNF.Text <> "" Then
         pDr("BNF") = txtBNF.Text & ""
      End If
   End Sub

   Private Sub filterCity()

      If blnLoading = True Then
         Exit Sub
      End If

      If cboState.Text = "" Then
         cboState.SelectedIndex = -1
         dsdata.Tables("city").DefaultView.RowFilter = String.Empty
      Else
         dsdata.Tables("city").DefaultView.RowFilter = " StateID =" & cboState.SelectedValue
      End If
   End Sub

   Private Sub filterAreaANDStreet()

      If blnLoading = True Then
         Exit Sub
      End If
      If CboCity.Text = "" Then
         CboCity.SelectedIndex = -1
         dsdata.Tables("Area").DefaultView.RowFilter = String.Empty
         dsdata.Tables("Street").DefaultView.RowFilter = String.Empty
      Else
         dsdata.Tables("Area").DefaultView.RowFilter = "cityID =" & CboCity.SelectedValue
         dsdata.Tables("Street").DefaultView.RowFilter = "CityID =" & CboCity.SelectedValue
      End If

   End Sub

   Private Sub filterStreet()
      If blnLoading = True Then
         Exit Sub
      End If
      If cboArea.Text = "" Then
         cboArea.SelectedIndex = -1
         dsdata.Tables("Street").DefaultView.RowFilter = String.Empty
      Else

         dsdata.Tables("Street").DefaultView.RowFilter = "AreaID =" & cboArea.SelectedValue

      End If
   End Sub

   Private Sub EditAddress()
      If grdViewAddress.Rows.Count = 0 Then
         Exit Sub
      End If

      If Not tcAddress.TabPages.Contains(tpNewAddress) Then
         tcAddress.TabPages.Add(tpNewAddress)
         tpNewAddress.Text = "Edit Address"
      End If

      tcAddress.SelectedTab = tpNewAddress
      Dim drAddress As DataView
      drAddress = dsdata.Tables("vwAddress").DefaultView

      txtAddID.Text = drAddress(grdViewAddress.CurrentRow.Index)("AddressID") & ""
      If Not (drAddress(grdViewAddress.CurrentRow.Index)("AddTypeID") Is DBNull.Value) Then
         cboAddType.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("AddTypeID") & ""
      Else
         cboAddType.SelectedValue = DBNull.Value
         cboAddType.SelectedIndex = -1
      End If

      If Not (drAddress(grdViewAddress.CurrentRow.Index)("StateID") Is DBNull.Value) Then
         cboState.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("StateID") & ""
      Else
         cboState.SelectedValue = DBNull.Value
         cboState.SelectedIndex = -1
      End If

      If Not (drAddress(grdViewAddress.CurrentRow.Index)("CityID") Is DBNull.Value) Then
         CboCity.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("CityID")
      Else
         CboCity.SelectedValue = DBNull.Value
         CboCity.SelectedIndex = -1
      End If
      If Not (drAddress(grdViewAddress.CurrentRow.Index)("AreaID") Is DBNull.Value) Then
         cboArea.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("AreaID")
      Else
         cboArea.SelectedValue = DBNull.Value
         cboArea.SelectedIndex = -1
      End If

      If Not (drAddress(grdViewAddress.CurrentRow.Index)("StreetID") Is DBNull.Value) Then
         CboStreet.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("StreetID")
      Else
         CboStreet.SelectedValue = DBNull.Value
         CboStreet.SelectedIndex = -1
      End If
      If Not (drAddress(grdViewAddress.CurrentRow.Index)("BNF") Is DBNull.Value) Then
         txtBNF.Text = drAddress(grdViewAddress.CurrentRow.Index)("BNF")
      End If
   End Sub


   Private Sub cboStreet_Leave(ByVal sender As Object, ByVal e As System.EventArgs)
      If cboArea.Text = "" And CboCity.Text = "" Then Exit Sub
      AddStreet()
   End Sub

   Private Sub AddStreet()

      Dim drs As DataRow() = dsdata.Tables("Street").Select("Street_en = '" & CboStreet.Text & "'")
      If drs.Length = 0 Then
         MsgBox("Do you want To Add This Street", MsgBoxStyle.YesNo)

         If Windows.Forms.DialogResult.Yes Then
            Dim dr As DataRow = dsdata.Tables("Street").NewRow
            dr("StreetID") = clsMr.GetMaxNumber("StreetID", "tblAddStreet") + 1
            dr("Street_en") = CboStreet.Text
            If CboCity.SelectedValue Is Nothing Then
               dr("CityID") = DBNull.Value
            Else
               dr("CityID") = CboCity.SelectedValue
            End If

            If cboArea.SelectedValue Is Nothing Then
               dr("AreaID") = DBNull.Value
            Else
               dr("AreaID") = cboArea.SelectedValue
            End If
            dr("Del") = 0
            dsdata.Tables("Street").Rows.Add(dr)
            daStreet.Update(dsdata, "Street")
            CboStreet.SelectedValue = dr("StreetID")


         Else
            CboStreet.Text = String.Empty
            CboStreet.SelectedIndex = -1
         End If

      Else : Exit Sub

      End If
   End Sub

   Private Sub AddressNotVisibleFields()
      With grdViewAddress

         .Columns("AddressID").Visible = False
         .Columns("AddTypeID").Visible = False
         .Columns("StreetID").Visible = False
         .Columns("Del").Visible = False
         .Columns("AreaID").Visible = False
         '.Columns("RegionId").Visible = False
         '.Columns("QadaaID").Visible = False
         '.Columns("ClientID").Visible = False
			.Columns("AddressID").Visible = False
			.Columns("StreetID").Visible = False
			.Columns("StateID").Visible = False
			.Columns("AreaID").Visible = False
			.Columns("EmployeeID").Visible = False
			.Columns("AddTypeID").Visible = False
			.Columns("ClientID").Visible = False
			.Columns("CLEmpID").Visible = False
			.Columns("Del").Visible = False
			.Columns("CityID").Visible = False
         'If gStrLang = "en" Then
         '   .Columns("Street_ar").Visible = False
         '   .Columns("State_ar").Visible = False
         '   .Columns("Area_ar").Visible = False
         '   .Columns("City_ar").Visible = False

         'Else
         '   .Columns("Street").Visible = False
         '   .Columns("State").Visible = False
         '   .Columns("Area").Visible = False
         '   .Columns("City").Visible = False
         'End If
		
      End With

   End Sub

#End Region

#Region "Form - UI Methods..."

   Private Sub txtClientName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtClientName.TextChanged
      CheckValues()
   End Sub

   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      ''
      If dataChange Then
         If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            Try
               Nav.CancelCurrentEdit()
               If AddMode = True Then
                  Me.Close()
               End If
            Catch ex As Exception

            End Try

            dataChange = False
            AddMode = False
            setState("BROWSE")
         End If
      Else
         setState("BROWSE")
      End If
      ''
   End Sub


   Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
      NewRecord()
   End Sub

   Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
      ''
      If btnSave.Text = "E d i t" Then
         setState("EDIT")
         Exit Sub
      End If
      save()
      setState("SAVE")
      ''
   End Sub

   Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
      '' check OK to close...
      If dataChange Then
         Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
            Case MsgBoxResult.Yes
               '' call save...
               If lstDataErr.Items.Count <> 0 Then
                  MsgBox("Cannot save.Please check error list")
                  Exit Sub
               Else
                  save()
                  Me.Close()
               End If
            Case MsgBoxResult.No
               '' ignore changes...

               Try
                  Nav.CancelCurrentEdit()
               Catch ex As Exception

               End Try
               Me.Close()
            Case MsgBoxResult.Cancel
               '' ignore close press..
               '' do nothing...

         End Select
      Else
         Me.Close()
      End If



   End Sub

   Private Sub txtWebSite_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtWebSite.TextChanged
      CheckValues()
   End Sub

   Private Sub txtEmail_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEmail.TextChanged
      CheckValues()
   End Sub

   Private Sub txtTel_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTel.TextChanged
      CheckValues()
   End Sub

   Private Sub txtCel_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCel.TextChanged
      CheckValues()
   End Sub
#End Region

#Region " Form - Grid Settings..."

   

   Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSetting.Click
      Dim i As Integer

      For i = 0 To Me.chkLstGridCol.Items.Count - 1
         Me.grdViewAddress.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
      Next
      ''
      Me.grpShowHideColumns.Visible = False
   End Sub

#End Region

#Region "Form-Address"
   Private Sub btnNewAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewAddress.Click
      NewAddress()
      tpNewAddress.Text = "New"
   End Sub

   Private Sub btnEditAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditAddress.Click
      EditAddress()
   End Sub

   Private Sub btnDeleteAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteAddress.Click
      If grdViewAddress.Rows.Count = 0 Then
         Exit Sub
      End If

      Dim res As MsgBoxResult
      Dim Index As Integer = grdViewAddress.CurrentRow.Index
      Dim drAddress As DataView
      drAddress = dsdata.Tables("vwAddress").DefaultView

      res = MsgBox(" Are you sure you want to Delete? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution")
      If res = MsgBoxResult.Yes Then

         Dim drDel() As DataRow
         drDel = dsdata.Tables("tblAddress").Select("AddressID = " & drAddress(Index)("AddressID"))
         If drDel.Length > 0 Then
            drDel(0).Delete()
            Nav.EndCurrentEdit()
            clsMr.Update(daAddress, "tblAddress")
         End If
         dsdata.Tables("vwAddress").DefaultView(grdViewAddress.CurrentRow.Index).Delete()

         If grdViewAddress.Rows.Count = 0 Then
            btnDeleteAddress.Enabled = False
         End If
      End If


   End Sub

   Private Sub btnNewAddress2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewAddress2.Click
      NewAddress()
   End Sub

   Private Sub btnSaveAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveAddress.Click
      SaveAddress()
   End Sub

   Private Sub btnCancelAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAddress.Click
      tcAddress.TabPages.Remove(tpNewAddress)
      tcAddress.SelectedIndex = 1

      btnNewAddress.Enabled = True
      btnNewAddress.Enabled = True
      btnSaveAddress.Enabled = True

   End Sub

   Private Sub cboState_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboState.SelectedIndexChanged
      filterCity()
   End Sub

   Private Sub CboCity_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboCity.SelectedIndexChanged
      filterAreaANDStreet()
   End Sub

   Private Sub cboArea_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboArea.SelectedIndexChanged
      filterStreet()
   End Sub
#End Region

#Region "Constructor"

   Public Sub New(Optional ByVal PID As Long = -1)

      ' This call is required by the Windows Form Designer.
      InitializeComponent()
      mID = PID

      ' Add any initialization after the InitializeComponent() call.

   End Sub

#End Region

#Region "Form-Image"

   Private Sub btnGetSign_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetSign.Click

      blnPic = True
      OFDGetPhoto.Filter = "jpg (*.jpg)|*.jpg|bmp (*.bmp)|*.bmp|All files (*.*)|*.*"
      OFDGetPhoto.FilterIndex = 1
      OFDGetPhoto.RestoreDirectory = True

      ' OFDGetPhoto.ShowDialog()

      If OFDGetPhoto.ShowDialog() = Windows.Forms.DialogResult.OK Then
         txtLocation.Text = OFDGetPhoto.FileName
         mStrPicSource = OFDGetPhoto.FileName
         If Not mStrPicSource = "" Then picPersonnel.Image = Image.FromFile(txtLocation.Text)
         ifSave = True
         btnSave.Enabled = True
      End If

   End Sub

   Private Sub SavePicToDB() ''''''' Save Picture to data base 

      If mStrPicSource = "" Then Exit Sub
      Dim ms As New System.IO.MemoryStream

      ''read Picture and convert to bytes 
      picPersonnel.Image.Save(ms, picPersonnel.Image.RawFormat)
      Dim arrImage() As Byte = ms.GetBuffer

      ' Close the stream object to release the resource.
      ms.Close()

      Dim strSQL As String = _
          "update  tblClient  set  ClientImage = @Picture where ClientID= " & txtID.Text

      Dim cmd As New SqlClient.SqlCommand(strSQL, conSql)
      With cmd
         .Parameters.Add(New SqlClient.SqlParameter("@Picture", _
           SqlDbType.Image)).Value = arrImage
      End With
      conSql.Open()
      cmd.ExecuteNonQuery()
      conSql.Close()

      MsgBox("Picture Changes will appear next time you Login to Form")


      blnPic = False
   End Sub

#End Region

	Private Sub chkNatAirLines_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkNatAirLines.Click
        ''
        'If MsgBox("Are you sure you want to change Discount", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
        '    chkNatAirLines.Checked = Not blnCheck

        '    If chkNatAirLines.Checked = True Then
        '        lblDiscount.Visible = True
        '        txtDiscount.Visible = True
        '        lblPercent.Visible = True
        '        txtDiscount.Text = 50
        '    Else
        '        lblDiscount.Visible = False
        '        txtDiscount.Visible = False
        '        lblPercent.Visible = False
        '        txtDiscount.Text = 0
        '    End If
        'Else
        '    chkNatAirLines.Checked = blnCheck
        'End If
      
      ''
	End Sub

    Private Sub txtDiscount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDiscount.TextChanged
        ''
        If Integer.Parse(txtDiscount.Text) > 100 Then
            MsgBox("Invalid Discount")
            Exit Sub
        End If
        CheckValues()
        ''
    End Sub

	Private Sub txtExt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtExt.TextChanged
		CheckValues()
	End Sub

	Private Sub txtContactName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContactName.TextChanged
		CheckValues()
	End Sub

	Private Sub txtFax_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFax.TextChanged
		CheckValues()
	End Sub

	Private Sub txtNote_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNote.TextChanged
		CheckValues()
	End Sub

	Private Sub cboCurrency_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCurrency.SelectedIndexChanged
		CheckValues()
	End Sub

	Private Sub txtICAO_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtICAO.TextChanged
		CheckValues()
	End Sub

	Private Sub txtIATA_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtIATA.TextChanged
		CheckValues()
	End Sub

   Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click

      If Me.grpShowHideColumns.Visible = False Then
         Me.grpShowHideColumns.Visible = True
         Me.grpShowHideColumns.BringToFront()
         ''
         '' populate list with grid's dataSource fields...
         ''
         Dim col As Windows.Forms.DataGridViewColumn
         ''
         Me.chkLstGridCol.Items.Clear()
         For Each col In grdViewAddress.Columns
            Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
         Next
         Me.chkLstGridCol.Items.Remove("Del")
         Me.chkLstGridCol.Items.Remove("AddressID")
         Me.chkLstGridCol.Items.Remove("StreetID")
         Me.chkLstGridCol.Items.Remove("CityID")
         Me.chkLstGridCol.Items.Remove("StateID")
         Me.chkLstGridCol.Items.Remove("AreaID")
         Me.chkLstGridCol.Items.Remove("EmployeeID")
         Me.chkLstGridCol.Items.Remove("AddTypeID")
         Me.chkLstGridCol.Items.Remove("ClientID")
         Me.chkLstGridCol.Items.Remove("ClEmpID")
      Else
         Me.grpShowHideColumns.Visible = False
         Me.grpShowHideColumns.SendToBack()
      End If


   End Sub

    Private Sub chkNatAirLines_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNatAirLines.CheckedChanged

        If blnLoading Then Exit Sub

        Dim blnCheck As Boolean

        blnCheck = chkNatAirLines.Checked

        If MsgBox("Are you sure you want to change the Type of the Company?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            If chkNatAirLines.Checked = True Then
                lblDiscount.Visible = True
                txtDiscount.Visible = True
                lblPercent.Visible = True
                txtDiscount.Text = 50
            Else
                lblDiscount.Visible = False
                txtDiscount.Visible = False
                lblPercent.Visible = False
                txtDiscount.Text = 0
            End If
        Else
            blnLoading = True
            chkNatAirLines.Checked = Not blnCheck
            blnLoading = False
        End If

        '

    End Sub

    Private Sub cboClientType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClientType.SelectedIndexChanged
        CheckValues()
    End Sub

#Region "Permissions.."
    ''Done by Mohamad March, 2008''

    'Client Name'
    Private Sub txtClientName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtClientName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtClientName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Contact Name'
    Private Sub txtContactName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtContactName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtContactName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Telephone'
    Private Sub txtTel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtTel.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Extension'
    Private Sub txtExt_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtExt.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Fax'
    Private Sub txtFax_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFax.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Cell Phone'
    Private Sub txtCel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCel.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Website'
    Private Sub txtWebSite_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtWebSite.Leave
        Dim Pattern As String = "^[w][\w\.-]*[w]\.[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim EmailAddressMatch As Match = Regex.Match(txtWebSite.Text, Pattern)

        If EmailAddressMatch.Success = True Then
            'Do Nothing
        Else
            MsgBox("Invalid Website Name")
            txtWebSite.Text = ""
        End If
    End Sub

    'Email'
    Private Sub txtEmail_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEmail.Leave
        Dim Pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim EmailAddressMatch As Match = Regex.Match(txtEmail.Text, Pattern)

        If EmailAddressMatch.Success = True Then
            'Do Nothing
        Else
            MsgBox("Invalid Email Address")
            txtEmail.Text = ""
        End If
    End Sub

    'Discount'
    Private Sub txtDiscount_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDiscount.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Or e.KeyChar = "." Then
            Exit Sub
        End If

        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        '    ''
        '    Integers_KeyPress(txtDiscount, e)
        '    ''
    End Sub

#End Region

End Class