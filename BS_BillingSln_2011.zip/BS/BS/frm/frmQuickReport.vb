Public Class frmQuickReport

End Class