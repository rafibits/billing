<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReport))
        Me.tvReports = New System.Windows.Forms.TreeView
        Me.ilTreeIcons = New System.Windows.Forms.ImageList(Me.components)
        Me.tabReportMain = New System.Windows.Forms.TabControl
        Me.tabReportSelection = New System.Windows.Forms.TabPage
        Me.splitReportSelection = New System.Windows.Forms.SplitContainer
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.Label11 = New System.Windows.Forms.Label
        Me.PicPreview = New System.Windows.Forms.PictureBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.picPrint = New System.Windows.Forms.PictureBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.PicPdf = New System.Windows.Forms.PictureBox
        Me.grp = New System.Windows.Forms.GroupBox
        Me.grpGrid = New System.Windows.Forms.GroupBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Label3 = New System.Windows.Forms.Label
        Me.grpInvoiceList = New System.Windows.Forms.GroupBox
        Me.lblCurrSymbol2 = New System.Windows.Forms.Label
        Me.txtTotalCurr2 = New System.Windows.Forms.TextBox
        Me.lblCurrSymbol = New System.Windows.Forms.Label
        Me.txtTotal = New System.Windows.Forms.TextBox
        Me.grpShowHideColumnsInvoiceList = New System.Windows.Forms.GroupBox
        Me.btnSaveSettingsInvoiceList = New System.Windows.Forms.Button
        Me.chkLstGridColInvoiceList = New System.Windows.Forms.CheckedListBox
        Me.btnShowColInvoiceList = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.grdInvoiceList = New System.Windows.Forms.DataGridView
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.grpDuePeriods = New System.Windows.Forms.GroupBox
        Me.chkOverDue120 = New System.Windows.Forms.CheckBox
        Me.chkOverDue90 = New System.Windows.Forms.CheckBox
        Me.chkOverDue60 = New System.Windows.Forms.CheckBox
        Me.chkOverDue30 = New System.Windows.Forms.CheckBox
        Me.cboServices = New System.Windows.Forms.ComboBox
        Me.lblServices = New System.Windows.Forms.Label
        Me.btnGoDynamics = New BHBut.BouncingHoverButton
        Me.grpQuarter = New System.Windows.Forms.GroupBox
        Me.chkOther = New System.Windows.Forms.CheckBox
        Me.chkQuarter4 = New System.Windows.Forms.CheckBox
        Me.chkQuarter1 = New System.Windows.Forms.CheckBox
        Me.chkQuarter2 = New System.Windows.Forms.CheckBox
        Me.chkQuarter3 = New System.Windows.Forms.CheckBox
        Me.cboCategory = New System.Windows.Forms.ComboBox
        Me.grpCurrency = New System.Windows.Forms.GroupBox
        Me.rdbLBP = New System.Windows.Forms.RadioButton
        Me.rdbLBPAndUSD = New System.Windows.Forms.RadioButton
        Me.rdbUSD = New System.Windows.Forms.RadioButton
        Me.grpStatus = New System.Windows.Forms.GroupBox
        Me.chkCorrected = New System.Windows.Forms.CheckBox
        Me.chkPaid = New System.Windows.Forms.CheckBox
        Me.chkNew = New System.Windows.Forms.CheckBox
        Me.chkPosted = New System.Windows.Forms.CheckBox
        Me.chkNotPosted = New System.Windows.Forms.CheckBox
        Me.lblInvoiceNum = New System.Windows.Forms.Label
        Me.txtInvoiceNum = New System.Windows.Forms.TextBox
        Me.lblCategory = New System.Windows.Forms.Label
        Me.lblStatus = New System.Windows.Forms.Label
        Me.dtpDateTo = New System.Windows.Forms.DateTimePicker
        Me.lblDateFrom = New System.Windows.Forms.Label
        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker
        Me.lblDateTo = New System.Windows.Forms.Label
        Me.lblClient = New System.Windows.Forms.Label
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.lblReportTitle = New System.Windows.Forms.Label
        Me.tabPreview = New System.Windows.Forms.TabPage
        Me.btnClosePreview = New BHBut.BouncingHoverButton
        Me.crvReport = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.VwClientsAndServicesRptTableAdapter1 = New BS.dsRptTableAdapters.vwClientsAndServicesRptTableAdapter
        Me.tabReportMain.SuspendLayout()
        Me.tabReportSelection.SuspendLayout()
        Me.splitReportSelection.Panel1.SuspendLayout()
        Me.splitReportSelection.Panel2.SuspendLayout()
        Me.splitReportSelection.SuspendLayout()
        CType(Me.PicPreview, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPrint, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicPdf, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp.SuspendLayout()
        Me.grpGrid.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpInvoiceList.SuspendLayout()
        Me.grpShowHideColumnsInvoiceList.SuspendLayout()
        CType(Me.grdInvoiceList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpFilter.SuspendLayout()
        Me.grpDuePeriods.SuspendLayout()
        Me.grpQuarter.SuspendLayout()
        Me.grpCurrency.SuspendLayout()
        Me.grpStatus.SuspendLayout()
        Me.tabPreview.SuspendLayout()
        Me.SuspendLayout()
        '
        'tvReports
        '
        Me.tvReports.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tvReports.ImageIndex = 0
        Me.tvReports.ImageList = Me.ilTreeIcons
        Me.tvReports.Location = New System.Drawing.Point(4, 67)
        Me.tvReports.Name = "tvReports"
        Me.tvReports.SelectedImageIndex = 0
        Me.tvReports.Size = New System.Drawing.Size(185, 432)
        Me.tvReports.TabIndex = 0
        '
        'ilTreeIcons
        '
        Me.ilTreeIcons.ImageStream = CType(resources.GetObject("ilTreeIcons.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ilTreeIcons.TransparentColor = System.Drawing.Color.Transparent
        Me.ilTreeIcons.Images.SetKeyName(0, "reports_icon.bmp")
        Me.ilTreeIcons.Images.SetKeyName(1, "DESKTOP.PNG")
        '
        'tabReportMain
        '
        Me.tabReportMain.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabReportMain.Controls.Add(Me.tabReportSelection)
        Me.tabReportMain.Controls.Add(Me.tabPreview)
        Me.tabReportMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabReportMain.ItemSize = New System.Drawing.Size(88, 18)
        Me.tabReportMain.Location = New System.Drawing.Point(0, 0)
        Me.tabReportMain.Name = "tabReportMain"
        Me.tabReportMain.SelectedIndex = 0
        Me.tabReportMain.Size = New System.Drawing.Size(953, 569)
        Me.tabReportMain.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.tabReportMain.TabIndex = 1
        '
        'tabReportSelection
        '
        Me.tabReportSelection.Controls.Add(Me.splitReportSelection)
        Me.tabReportSelection.Location = New System.Drawing.Point(4, 22)
        Me.tabReportSelection.Name = "tabReportSelection"
        Me.tabReportSelection.Padding = New System.Windows.Forms.Padding(3)
        Me.tabReportSelection.Size = New System.Drawing.Size(945, 543)
        Me.tabReportSelection.TabIndex = 0
        Me.tabReportSelection.Text = "ReportSelection"
        Me.tabReportSelection.UseVisualStyleBackColor = True
        '
        'splitReportSelection
        '
        Me.splitReportSelection.Dock = System.Windows.Forms.DockStyle.Fill
        Me.splitReportSelection.Location = New System.Drawing.Point(3, 3)
        Me.splitReportSelection.Name = "splitReportSelection"
        '
        'splitReportSelection.Panel1
        '
        Me.splitReportSelection.Panel1.BackColor = System.Drawing.Color.LightYellow
        Me.splitReportSelection.Panel1.Controls.Add(Me.btnClose)
        Me.splitReportSelection.Panel1.Controls.Add(Me.tvReports)
        Me.splitReportSelection.Panel1.Controls.Add(Me.Label11)
        Me.splitReportSelection.Panel1.Controls.Add(Me.PicPreview)
        Me.splitReportSelection.Panel1.Controls.Add(Me.Label10)
        Me.splitReportSelection.Panel1.Controls.Add(Me.picPrint)
        Me.splitReportSelection.Panel1.Controls.Add(Me.Label7)
        Me.splitReportSelection.Panel1.Controls.Add(Me.PicPdf)
        '
        'splitReportSelection.Panel2
        '
        Me.splitReportSelection.Panel2.Controls.Add(Me.grp)
        Me.splitReportSelection.Panel2.Controls.Add(Me.grpFilter)
        Me.splitReportSelection.Panel2.Controls.Add(Me.pnlTitle)
        Me.splitReportSelection.Panel2.Controls.Add(Me.lblReportTitle)
        Me.splitReportSelection.Size = New System.Drawing.Size(939, 537)
        Me.splitReportSelection.SplitterDistance = 205
        Me.splitReportSelection.SplitterWidth = 6
        Me.splitReportSelection.TabIndex = 25
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(4, 505)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(185, 30)
        Me.btnClose.TabIndex = 40
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Maroon
        Me.Label11.Location = New System.Drawing.Point(76, 45)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(52, 15)
        Me.Label11.TabIndex = 23
        Me.Label11.Text = "P r i n t"
        '
        'PicPreview
        '
        Me.PicPreview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PicPreview.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PicPreview.Image = CType(resources.GetObject("PicPreview.Image"), System.Drawing.Image)
        Me.PicPreview.Location = New System.Drawing.Point(17, 10)
        Me.PicPreview.Name = "PicPreview"
        Me.PicPreview.Size = New System.Drawing.Size(32, 32)
        Me.PicPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicPreview.TabIndex = 18
        Me.PicPreview.TabStop = False
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Maroon
        Me.Label10.Location = New System.Drawing.Point(130, 45)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(63, 15)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "Print to pdf"
        '
        'picPrint
        '
        Me.picPrint.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picPrint.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picPrint.Image = CType(resources.GetObject("picPrint.Image"), System.Drawing.Image)
        Me.picPrint.Location = New System.Drawing.Point(79, 10)
        Me.picPrint.Name = "picPrint"
        Me.picPrint.Size = New System.Drawing.Size(32, 32)
        Me.picPrint.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPrint.TabIndex = 19
        Me.picPrint.TabStop = False
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Maroon
        Me.Label7.Location = New System.Drawing.Point(12, 45)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 15)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Preview"
        '
        'PicPdf
        '
        Me.PicPdf.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PicPdf.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PicPdf.Image = CType(resources.GetObject("PicPdf.Image"), System.Drawing.Image)
        Me.PicPdf.Location = New System.Drawing.Point(141, 10)
        Me.PicPdf.Name = "PicPdf"
        Me.PicPdf.Size = New System.Drawing.Size(32, 33)
        Me.PicPdf.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicPdf.TabIndex = 20
        Me.PicPdf.TabStop = False
        '
        'grp
        '
        Me.grp.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grp.Controls.Add(Me.grpGrid)
        Me.grp.Controls.Add(Me.grpInvoiceList)
        Me.grp.Location = New System.Drawing.Point(3, 189)
        Me.grp.Name = "grp"
        Me.grp.Size = New System.Drawing.Size(722, 343)
        Me.grp.TabIndex = 390
        Me.grp.TabStop = False
        '
        'grpGrid
        '
        Me.grpGrid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpGrid.Controls.Add(Me.Label1)
        Me.grpGrid.Controls.Add(Me.TextBox1)
        Me.grpGrid.Controls.Add(Me.Label2)
        Me.grpGrid.Controls.Add(Me.TextBox2)
        Me.grpGrid.Controls.Add(Me.grpShowHideColumns)
        Me.grpGrid.Controls.Add(Me.btnShowCol)
        Me.grpGrid.Controls.Add(Me.DataGridView1)
        Me.grpGrid.Controls.Add(Me.Label3)
        Me.grpGrid.Location = New System.Drawing.Point(6, 169)
        Me.grpGrid.Name = "grpGrid"
        Me.grpGrid.Size = New System.Drawing.Size(709, 155)
        Me.grpGrid.TabIndex = 357
        Me.grpGrid.TabStop = False
        Me.grpGrid.Visible = False
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.Maroon
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label1.Location = New System.Drawing.Point(555, 126)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 20)
        Me.Label1.TabIndex = 363
        Me.Label1.Text = "Curr"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.Maroon
        Me.TextBox1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.TextBox1.Location = New System.Drawing.Point(592, 125)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(105, 23)
        Me.TextBox1.TabIndex = 362
        Me.TextBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.BackColor = System.Drawing.Color.Maroon
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(405, 126)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(34, 20)
        Me.Label2.TabIndex = 360
        Me.Label2.Text = "Curr"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.Color.Maroon
        Me.TextBox2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.TextBox2.Location = New System.Drawing.Point(442, 125)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(105, 23)
        Me.TextBox2.TabIndex = 359
        Me.TextBox2.TabStop = False
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(43, 19)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 77)
        Me.grpShowHideColumns.TabIndex = 155
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 48)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 19)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(5, 17)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 156
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.Lavender
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(3, 16)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(700, 103)
        Me.DataGridView1.TabIndex = 152
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.BackColor = System.Drawing.Color.Maroon
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label3.Location = New System.Drawing.Point(353, 122)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(350, 29)
        Me.Label3.TabIndex = 364
        Me.Label3.Text = "  Total"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grpInvoiceList
        '
        Me.grpInvoiceList.Controls.Add(Me.lblCurrSymbol2)
        Me.grpInvoiceList.Controls.Add(Me.txtTotalCurr2)
        Me.grpInvoiceList.Controls.Add(Me.lblCurrSymbol)
        Me.grpInvoiceList.Controls.Add(Me.txtTotal)
        Me.grpInvoiceList.Controls.Add(Me.grpShowHideColumnsInvoiceList)
        Me.grpInvoiceList.Controls.Add(Me.btnShowColInvoiceList)
        Me.grpInvoiceList.Controls.Add(Me.Label4)
        Me.grpInvoiceList.Controls.Add(Me.grdInvoiceList)
        Me.grpInvoiceList.Location = New System.Drawing.Point(6, 12)
        Me.grpInvoiceList.Name = "grpInvoiceList"
        Me.grpInvoiceList.Size = New System.Drawing.Size(710, 151)
        Me.grpInvoiceList.TabIndex = 392
        Me.grpInvoiceList.TabStop = False
        '
        'lblCurrSymbol2
        '
        Me.lblCurrSymbol2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCurrSymbol2.AutoSize = True
        Me.lblCurrSymbol2.BackColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol2.ForeColor = System.Drawing.Color.White
        Me.lblCurrSymbol2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol2.Location = New System.Drawing.Point(663, 123)
        Me.lblCurrSymbol2.Name = "lblCurrSymbol2"
        Me.lblCurrSymbol2.Size = New System.Drawing.Size(28, 13)
        Me.lblCurrSymbol2.TabIndex = 363
        Me.lblCurrSymbol2.Text = "Curr"
        Me.lblCurrSymbol2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTotalCurr2
        '
        Me.txtTotalCurr2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalCurr2.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalCurr2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalCurr2.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalCurr2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalCurr2.Location = New System.Drawing.Point(553, 117)
        Me.txtTotalCurr2.Multiline = True
        Me.txtTotalCurr2.Name = "txtTotalCurr2"
        Me.txtTotalCurr2.ReadOnly = True
        Me.txtTotalCurr2.Size = New System.Drawing.Size(105, 23)
        Me.txtTotalCurr2.TabIndex = 362
        Me.txtTotalCurr2.TabStop = False
        '
        'lblCurrSymbol
        '
        Me.lblCurrSymbol.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCurrSymbol.AutoSize = True
        Me.lblCurrSymbol.BackColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol.ForeColor = System.Drawing.Color.White
        Me.lblCurrSymbol.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol.Location = New System.Drawing.Point(504, 123)
        Me.lblCurrSymbol.Name = "lblCurrSymbol"
        Me.lblCurrSymbol.Size = New System.Drawing.Size(28, 13)
        Me.lblCurrSymbol.TabIndex = 360
        Me.lblCurrSymbol.Text = "Curr"
        Me.lblCurrSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTotal
        '
        Me.txtTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotal.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotal.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotal.Location = New System.Drawing.Point(397, 117)
        Me.txtTotal.Multiline = True
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(105, 23)
        Me.txtTotal.TabIndex = 359
        Me.txtTotal.TabStop = False
        '
        'grpShowHideColumnsInvoiceList
        '
        Me.grpShowHideColumnsInvoiceList.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumnsInvoiceList.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumnsInvoiceList.Controls.Add(Me.btnSaveSettingsInvoiceList)
        Me.grpShowHideColumnsInvoiceList.Controls.Add(Me.chkLstGridColInvoiceList)
        Me.grpShowHideColumnsInvoiceList.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumnsInvoiceList.Location = New System.Drawing.Point(42, 23)
        Me.grpShowHideColumnsInvoiceList.Name = "grpShowHideColumnsInvoiceList"
        Me.grpShowHideColumnsInvoiceList.Size = New System.Drawing.Size(175, 86)
        Me.grpShowHideColumnsInvoiceList.TabIndex = 155
        Me.grpShowHideColumnsInvoiceList.TabStop = False
        Me.grpShowHideColumnsInvoiceList.Text = "Custom Columns"
        Me.grpShowHideColumnsInvoiceList.Visible = False
        '
        'btnSaveSettingsInvoiceList
        '
        Me.btnSaveSettingsInvoiceList.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettingsInvoiceList.Location = New System.Drawing.Point(7, 54)
        Me.btnSaveSettingsInvoiceList.Name = "btnSaveSettingsInvoiceList"
        Me.btnSaveSettingsInvoiceList.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettingsInvoiceList.TabIndex = 0
        Me.btnSaveSettingsInvoiceList.Text = "Save Settings"
        Me.btnSaveSettingsInvoiceList.UseVisualStyleBackColor = True
        '
        'chkLstGridColInvoiceList
        '
        Me.chkLstGridColInvoiceList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridColInvoiceList.CheckOnClick = True
        Me.chkLstGridColInvoiceList.FormattingEnabled = True
        Me.chkLstGridColInvoiceList.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridColInvoiceList.Name = "chkLstGridColInvoiceList"
        Me.chkLstGridColInvoiceList.Size = New System.Drawing.Size(162, 34)
        Me.chkLstGridColInvoiceList.TabIndex = 92
        Me.chkLstGridColInvoiceList.ThreeDCheckBoxes = True
        '
        'btnShowColInvoiceList
        '
        Me.btnShowColInvoiceList.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowColInvoiceList.BackColor = System.Drawing.Color.Linen
        Me.btnShowColInvoiceList.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowColInvoiceList.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowColInvoiceList.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowColInvoiceList.FlatAppearance.BorderSize = 2
        Me.btnShowColInvoiceList.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColInvoiceList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColInvoiceList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowColInvoiceList.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowColInvoiceList.ForeColor = System.Drawing.Color.White
        Me.btnShowColInvoiceList.Location = New System.Drawing.Point(5, 21)
        Me.btnShowColInvoiceList.Name = "btnShowColInvoiceList"
        Me.btnShowColInvoiceList.Size = New System.Drawing.Size(36, 30)
        Me.btnShowColInvoiceList.TabIndex = 156
        Me.btnShowColInvoiceList.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.BackColor = System.Drawing.Color.Maroon
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label4.Location = New System.Drawing.Point(350, 114)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(350, 29)
        Me.Label4.TabIndex = 364
        Me.Label4.Text = "  Total"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grdInvoiceList
        '
        Me.grdInvoiceList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdInvoiceList.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdInvoiceList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdInvoiceList.Location = New System.Drawing.Point(3, 19)
        Me.grdInvoiceList.Name = "grdInvoiceList"
        Me.grdInvoiceList.Size = New System.Drawing.Size(697, 90)
        Me.grdInvoiceList.TabIndex = 152
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.grpDuePeriods)
        Me.grpFilter.Controls.Add(Me.cboServices)
        Me.grpFilter.Controls.Add(Me.lblServices)
        Me.grpFilter.Controls.Add(Me.btnGoDynamics)
        Me.grpFilter.Controls.Add(Me.grpQuarter)
        Me.grpFilter.Controls.Add(Me.cboCategory)
        Me.grpFilter.Controls.Add(Me.grpCurrency)
        Me.grpFilter.Controls.Add(Me.grpStatus)
        Me.grpFilter.Controls.Add(Me.lblInvoiceNum)
        Me.grpFilter.Controls.Add(Me.txtInvoiceNum)
        Me.grpFilter.Controls.Add(Me.lblCategory)
        Me.grpFilter.Controls.Add(Me.lblStatus)
        Me.grpFilter.Controls.Add(Me.dtpDateTo)
        Me.grpFilter.Controls.Add(Me.lblDateFrom)
        Me.grpFilter.Controls.Add(Me.dtpDateFrom)
        Me.grpFilter.Controls.Add(Me.lblDateTo)
        Me.grpFilter.Controls.Add(Me.lblClient)
        Me.grpFilter.Controls.Add(Me.cboClient)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(3, 45)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(728, 138)
        Me.grpFilter.TabIndex = 391
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Data Filter"
        '
        'grpDuePeriods
        '
        Me.grpDuePeriods.BackColor = System.Drawing.Color.AliceBlue
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue120)
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue90)
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue60)
        Me.grpDuePeriods.Controls.Add(Me.chkOverDue30)
        Me.grpDuePeriods.Location = New System.Drawing.Point(403, 10)
        Me.grpDuePeriods.Name = "grpDuePeriods"
        Me.grpDuePeriods.Size = New System.Drawing.Size(322, 34)
        Me.grpDuePeriods.TabIndex = 390
        Me.grpDuePeriods.TabStop = False
        '
        'chkOverDue120
        '
        Me.chkOverDue120.AutoSize = True
        Me.chkOverDue120.Checked = True
        Me.chkOverDue120.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue120.ForeColor = System.Drawing.Color.Blue
        Me.chkOverDue120.Location = New System.Drawing.Point(235, 13)
        Me.chkOverDue120.Name = "chkOverDue120"
        Me.chkOverDue120.Size = New System.Drawing.Size(87, 17)
        Me.chkOverDue120.TabIndex = 5
        Me.chkOverDue120.Text = "OverDue120"
        Me.chkOverDue120.UseVisualStyleBackColor = True
        '
        'chkOverDue90
        '
        Me.chkOverDue90.AutoSize = True
        Me.chkOverDue90.Checked = True
        Me.chkOverDue90.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue90.ForeColor = System.Drawing.Color.SandyBrown
        Me.chkOverDue90.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkOverDue90.Location = New System.Drawing.Point(157, 13)
        Me.chkOverDue90.Name = "chkOverDue90"
        Me.chkOverDue90.Size = New System.Drawing.Size(81, 17)
        Me.chkOverDue90.TabIndex = 4
        Me.chkOverDue90.Text = "OverDue90"
        '
        'chkOverDue60
        '
        Me.chkOverDue60.AutoSize = True
        Me.chkOverDue60.Checked = True
        Me.chkOverDue60.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue60.ForeColor = System.Drawing.Color.DimGray
        Me.chkOverDue60.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkOverDue60.Location = New System.Drawing.Point(80, 13)
        Me.chkOverDue60.Name = "chkOverDue60"
        Me.chkOverDue60.Size = New System.Drawing.Size(81, 17)
        Me.chkOverDue60.TabIndex = 3
        Me.chkOverDue60.Text = "OverDue60"
        '
        'chkOverDue30
        '
        Me.chkOverDue30.AutoSize = True
        Me.chkOverDue30.Checked = True
        Me.chkOverDue30.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverDue30.ForeColor = System.Drawing.Color.LightCoral
        Me.chkOverDue30.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkOverDue30.Location = New System.Drawing.Point(3, 13)
        Me.chkOverDue30.Name = "chkOverDue30"
        Me.chkOverDue30.Size = New System.Drawing.Size(81, 17)
        Me.chkOverDue30.TabIndex = 0
        Me.chkOverDue30.Text = "OverDue30"
        '
        'cboServices
        '
        Me.cboServices.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboServices.FormattingEnabled = True
        Me.cboServices.Location = New System.Drawing.Point(52, 46)
        Me.cboServices.Name = "cboServices"
        Me.cboServices.Size = New System.Drawing.Size(172, 21)
        Me.cboServices.TabIndex = 389
        '
        'lblServices
        '
        Me.lblServices.AutoSize = True
        Me.lblServices.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblServices.ForeColor = System.Drawing.Color.Maroon
        Me.lblServices.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblServices.Location = New System.Drawing.Point(6, 49)
        Me.lblServices.Name = "lblServices"
        Me.lblServices.Size = New System.Drawing.Size(43, 13)
        Me.lblServices.TabIndex = 388
        Me.lblServices.Text = "Service"
        Me.lblServices.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnGoDynamics
        '
        Me.btnGoDynamics.AlternativeGroup = Nothing
        Me.btnGoDynamics.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnGoDynamics.BackColor1 = System.Drawing.Color.White
        Me.btnGoDynamics.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnGoDynamics.BorderHover = True
        Me.btnGoDynamics.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnGoDynamics.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnGoDynamics.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnGoDynamics.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnGoDynamics.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnGoDynamics.DrawBorder = True
        Me.btnGoDynamics.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnGoDynamics.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnGoDynamics.ForeColor = System.Drawing.Color.Navy
        Me.btnGoDynamics.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnGoDynamics.HoverColor2 = System.Drawing.Color.White
        Me.btnGoDynamics.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnGoDynamics.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnGoDynamics.Location = New System.Drawing.Point(670, 107)
        Me.btnGoDynamics.Name = "btnGoDynamics"
        Me.btnGoDynamics.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnGoDynamics.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnGoDynamics.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnGoDynamics.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnGoDynamics.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnGoDynamics.SelectedText = Nothing
        Me.btnGoDynamics.Size = New System.Drawing.Size(50, 27)
        Me.btnGoDynamics.TabIndex = 387
        Me.btnGoDynamics.Text = "G O"
        Me.btnGoDynamics.UseVisualStyleBackColor = False
        '
        'grpQuarter
        '
        Me.grpQuarter.BackColor = System.Drawing.Color.AliceBlue
        Me.grpQuarter.Controls.Add(Me.chkOther)
        Me.grpQuarter.Controls.Add(Me.chkQuarter4)
        Me.grpQuarter.Controls.Add(Me.chkQuarter1)
        Me.grpQuarter.Controls.Add(Me.chkQuarter2)
        Me.grpQuarter.Controls.Add(Me.chkQuarter3)
        Me.grpQuarter.Location = New System.Drawing.Point(403, 49)
        Me.grpQuarter.Name = "grpQuarter"
        Me.grpQuarter.Size = New System.Drawing.Size(317, 52)
        Me.grpQuarter.TabIndex = 159
        Me.grpQuarter.TabStop = False
        '
        'chkOther
        '
        Me.chkOther.AutoSize = True
        Me.chkOther.Checked = True
        Me.chkOther.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOther.ForeColor = System.Drawing.Color.Blue
        Me.chkOther.Location = New System.Drawing.Point(251, 8)
        Me.chkOther.Name = "chkOther"
        Me.chkOther.Size = New System.Drawing.Size(54, 17)
        Me.chkOther.TabIndex = 5
        Me.chkOther.Text = "Other"
        Me.chkOther.UseVisualStyleBackColor = True
        '
        'chkQuarter4
        '
        Me.chkQuarter4.AutoSize = True
        Me.chkQuarter4.ForeColor = System.Drawing.Color.DimGray
        Me.chkQuarter4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkQuarter4.Location = New System.Drawing.Point(126, 29)
        Me.chkQuarter4.Name = "chkQuarter4"
        Me.chkQuarter4.Size = New System.Drawing.Size(99, 17)
        Me.chkQuarter4.TabIndex = 3
        Me.chkQuarter4.Text = "Fourth Quarter"
        '
        'chkQuarter1
        '
        Me.chkQuarter1.AutoSize = True
        Me.chkQuarter1.ForeColor = System.Drawing.Color.Red
        Me.chkQuarter1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkQuarter1.Location = New System.Drawing.Point(5, 9)
        Me.chkQuarter1.Name = "chkQuarter1"
        Me.chkQuarter1.Size = New System.Drawing.Size(88, 17)
        Me.chkQuarter1.TabIndex = 1
        Me.chkQuarter1.Text = "First Quarter"
        '
        'chkQuarter2
        '
        Me.chkQuarter2.AutoSize = True
        Me.chkQuarter2.ForeColor = System.Drawing.Color.Navy
        Me.chkQuarter2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkQuarter2.Location = New System.Drawing.Point(5, 29)
        Me.chkQuarter2.Name = "chkQuarter2"
        Me.chkQuarter2.Size = New System.Drawing.Size(102, 17)
        Me.chkQuarter2.TabIndex = 2
        Me.chkQuarter2.Text = "Second Quarter"
        '
        'chkQuarter3
        '
        Me.chkQuarter3.AutoSize = True
        Me.chkQuarter3.ForeColor = System.Drawing.Color.LightCoral
        Me.chkQuarter3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkQuarter3.Location = New System.Drawing.Point(126, 8)
        Me.chkQuarter3.Name = "chkQuarter3"
        Me.chkQuarter3.Size = New System.Drawing.Size(91, 17)
        Me.chkQuarter3.TabIndex = 0
        Me.chkQuarter3.Text = "Third Quarter"
        '
        'cboCategory
        '
        Me.cboCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCategory.FormattingEnabled = True
        Me.cboCategory.Location = New System.Drawing.Point(52, 46)
        Me.cboCategory.Name = "cboCategory"
        Me.cboCategory.Size = New System.Drawing.Size(172, 21)
        Me.cboCategory.TabIndex = 318
        '
        'grpCurrency
        '
        Me.grpCurrency.BackColor = System.Drawing.Color.Ivory
        Me.grpCurrency.Controls.Add(Me.rdbLBP)
        Me.grpCurrency.Controls.Add(Me.rdbLBPAndUSD)
        Me.grpCurrency.Controls.Add(Me.rdbUSD)
        Me.grpCurrency.Location = New System.Drawing.Point(404, 103)
        Me.grpCurrency.Name = "grpCurrency"
        Me.grpCurrency.Size = New System.Drawing.Size(264, 31)
        Me.grpCurrency.TabIndex = 380
        Me.grpCurrency.TabStop = False
        '
        'rdbLBP
        '
        Me.rdbLBP.AutoSize = True
        Me.rdbLBP.Checked = True
        Me.rdbLBP.ForeColor = System.Drawing.Color.DimGray
        Me.rdbLBP.Location = New System.Drawing.Point(6, 10)
        Me.rdbLBP.Name = "rdbLBP"
        Me.rdbLBP.Size = New System.Drawing.Size(42, 17)
        Me.rdbLBP.TabIndex = 377
        Me.rdbLBP.TabStop = True
        Me.rdbLBP.Text = "LBP"
        Me.rdbLBP.UseVisualStyleBackColor = True
        '
        'rdbLBPAndUSD
        '
        Me.rdbLBPAndUSD.AutoSize = True
        Me.rdbLBPAndUSD.ForeColor = System.Drawing.Color.Red
        Me.rdbLBPAndUSD.Location = New System.Drawing.Point(188, 10)
        Me.rdbLBPAndUSD.Name = "rdbLBPAndUSD"
        Me.rdbLBPAndUSD.Size = New System.Drawing.Size(66, 17)
        Me.rdbLBPAndUSD.TabIndex = 376
        Me.rdbLBPAndUSD.Text = "LBP/USD"
        Me.rdbLBPAndUSD.UseVisualStyleBackColor = True
        '
        'rdbUSD
        '
        Me.rdbUSD.AutoSize = True
        Me.rdbUSD.ForeColor = System.Drawing.Color.SlateBlue
        Me.rdbUSD.Location = New System.Drawing.Point(102, 10)
        Me.rdbUSD.Name = "rdbUSD"
        Me.rdbUSD.Size = New System.Drawing.Size(45, 17)
        Me.rdbUSD.TabIndex = 375
        Me.rdbUSD.Text = "USD"
        Me.rdbUSD.UseVisualStyleBackColor = True
        '
        'grpStatus
        '
        Me.grpStatus.BackColor = System.Drawing.Color.Lavender
        Me.grpStatus.Controls.Add(Me.chkCorrected)
        Me.grpStatus.Controls.Add(Me.chkPaid)
        Me.grpStatus.Controls.Add(Me.chkNew)
        Me.grpStatus.Controls.Add(Me.chkPosted)
        Me.grpStatus.Controls.Add(Me.chkNotPosted)
        Me.grpStatus.Location = New System.Drawing.Point(403, 10)
        Me.grpStatus.Name = "grpStatus"
        Me.grpStatus.Size = New System.Drawing.Size(319, 34)
        Me.grpStatus.TabIndex = 156
        Me.grpStatus.TabStop = False
        '
        'chkCorrected
        '
        Me.chkCorrected.AutoSize = True
        Me.chkCorrected.Checked = True
        Me.chkCorrected.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkCorrected.ForeColor = System.Drawing.Color.Maroon
        Me.chkCorrected.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkCorrected.Location = New System.Drawing.Point(247, 11)
        Me.chkCorrected.Name = "chkCorrected"
        Me.chkCorrected.Size = New System.Drawing.Size(74, 17)
        Me.chkCorrected.TabIndex = 4
        Me.chkCorrected.Text = "Corrected"
        '
        'chkPaid
        '
        Me.chkPaid.AutoSize = True
        Me.chkPaid.Checked = True
        Me.chkPaid.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPaid.ForeColor = System.Drawing.Color.DimGray
        Me.chkPaid.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkPaid.Location = New System.Drawing.Point(189, 11)
        Me.chkPaid.Name = "chkPaid"
        Me.chkPaid.Size = New System.Drawing.Size(60, 17)
        Me.chkPaid.TabIndex = 3
        Me.chkPaid.Text = "Settled"
        '
        'chkNew
        '
        Me.chkNew.AutoSize = True
        Me.chkNew.Checked = True
        Me.chkNew.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkNew.ForeColor = System.Drawing.Color.Red
        Me.chkNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkNew.Location = New System.Drawing.Point(11, 11)
        Me.chkNew.Name = "chkNew"
        Me.chkNew.Size = New System.Drawing.Size(47, 17)
        Me.chkNew.TabIndex = 1
        Me.chkNew.Text = "New"
        '
        'chkPosted
        '
        Me.chkPosted.AutoSize = True
        Me.chkPosted.Checked = True
        Me.chkPosted.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPosted.ForeColor = System.Drawing.Color.Navy
        Me.chkPosted.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkPosted.Location = New System.Drawing.Point(59, 11)
        Me.chkPosted.Name = "chkPosted"
        Me.chkPosted.Size = New System.Drawing.Size(59, 17)
        Me.chkPosted.TabIndex = 2
        Me.chkPosted.Text = "Posted"
        '
        'chkNotPosted
        '
        Me.chkNotPosted.AutoSize = True
        Me.chkNotPosted.Checked = True
        Me.chkNotPosted.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkNotPosted.ForeColor = System.Drawing.Color.LightCoral
        Me.chkNotPosted.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkNotPosted.Location = New System.Drawing.Point(119, 11)
        Me.chkNotPosted.Name = "chkNotPosted"
        Me.chkNotPosted.Size = New System.Drawing.Size(72, 17)
        Me.chkNotPosted.TabIndex = 0
        Me.chkNotPosted.Text = "Unposted"
        '
        'lblInvoiceNum
        '
        Me.lblInvoiceNum.AutoSize = True
        Me.lblInvoiceNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblInvoiceNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblInvoiceNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInvoiceNum.Location = New System.Drawing.Point(224, 51)
        Me.lblInvoiceNum.Name = "lblInvoiceNum"
        Me.lblInvoiceNum.Size = New System.Drawing.Size(52, 13)
        Me.lblInvoiceNum.TabIndex = 154
        Me.lblInvoiceNum.Text = "Invoice #"
        Me.lblInvoiceNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtInvoiceNum
        '
        Me.txtInvoiceNum.ForeColor = System.Drawing.Color.Navy
        Me.txtInvoiceNum.Location = New System.Drawing.Point(277, 48)
        Me.txtInvoiceNum.Name = "txtInvoiceNum"
        Me.txtInvoiceNum.Size = New System.Drawing.Size(86, 20)
        Me.txtInvoiceNum.TabIndex = 155
        Me.txtInvoiceNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblCategory
        '
        Me.lblCategory.AutoSize = True
        Me.lblCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblCategory.ForeColor = System.Drawing.Color.Maroon
        Me.lblCategory.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCategory.Location = New System.Drawing.Point(3, 49)
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Size = New System.Drawing.Size(49, 13)
        Me.lblCategory.TabIndex = 153
        Me.lblCategory.Text = "Category"
        Me.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.ForeColor = System.Drawing.Color.Maroon
        Me.lblStatus.Location = New System.Drawing.Point(366, 22)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(38, 13)
        Me.lblStatus.TabIndex = 18
        Me.lblStatus.Text = "Status"
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpDateTo
        '
        Me.dtpDateTo.CustomFormat = "dd MMM yyyy"
        Me.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateTo.Location = New System.Drawing.Point(277, 74)
        Me.dtpDateTo.Name = "dtpDateTo"
        Me.dtpDateTo.Size = New System.Drawing.Size(86, 20)
        Me.dtpDateTo.TabIndex = 16
        '
        'lblDateFrom
        '
        Me.lblDateFrom.AutoSize = True
        Me.lblDateFrom.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateFrom.Location = New System.Drawing.Point(4, 78)
        Me.lblDateFrom.Name = "lblDateFrom"
        Me.lblDateFrom.Size = New System.Drawing.Size(57, 13)
        Me.lblDateFrom.TabIndex = 15
        Me.lblDateFrom.Text = "Date From"
        Me.lblDateFrom.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpDateFrom
        '
        Me.dtpDateFrom.CustomFormat = "dd MMM yyyy"
        Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateFrom.Location = New System.Drawing.Point(62, 75)
        Me.dtpDateFrom.Name = "dtpDateFrom"
        Me.dtpDateFrom.Size = New System.Drawing.Size(86, 20)
        Me.dtpDateFrom.TabIndex = 14
        '
        'lblDateTo
        '
        Me.lblDateTo.AutoSize = True
        Me.lblDateTo.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateTo.Location = New System.Drawing.Point(255, 78)
        Me.lblDateTo.Name = "lblDateTo"
        Me.lblDateTo.Size = New System.Drawing.Size(19, 13)
        Me.lblDateTo.TabIndex = 7
        Me.lblDateTo.Text = "To"
        Me.lblDateTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblClient
        '
        Me.lblClient.AutoSize = True
        Me.lblClient.ForeColor = System.Drawing.Color.Maroon
        Me.lblClient.Location = New System.Drawing.Point(13, 22)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(34, 13)
        Me.lblClient.TabIndex = 5
        Me.lblClient.Text = "Client"
        Me.lblClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboClient
        '
        Me.cboClient.ForeColor = System.Drawing.Color.Maroon
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(52, 19)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(311, 21)
        Me.cboClient.TabIndex = 2
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(-2, 39)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(800, 3)
        Me.pnlTitle.TabIndex = 390
        '
        'lblReportTitle
        '
        Me.lblReportTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblReportTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblReportTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.lblReportTitle.ForeColor = System.Drawing.Color.LightYellow
        Me.lblReportTitle.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblReportTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblReportTitle.Name = "lblReportTitle"
        Me.lblReportTitle.Size = New System.Drawing.Size(728, 39)
        Me.lblReportTitle.TabIndex = 389
        Me.lblReportTitle.Text = "Report Title"
        Me.lblReportTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblReportTitle.Visible = False
        '
        'tabPreview
        '
        Me.tabPreview.Controls.Add(Me.btnClosePreview)
        Me.tabPreview.Controls.Add(Me.crvReport)
        Me.tabPreview.Location = New System.Drawing.Point(4, 22)
        Me.tabPreview.Name = "tabPreview"
        Me.tabPreview.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPreview.Size = New System.Drawing.Size(945, 543)
        Me.tabPreview.TabIndex = 1
        Me.tabPreview.Text = "Preview"
        Me.tabPreview.UseVisualStyleBackColor = True
        '
        'btnClosePreview
        '
        Me.btnClosePreview.AlternativeGroup = Nothing
        Me.btnClosePreview.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClosePreview.BackColor = System.Drawing.Color.Orange
        Me.btnClosePreview.BackColor1 = System.Drawing.Color.White
        Me.btnClosePreview.BackColor2 = System.Drawing.Color.Orange
        Me.btnClosePreview.BorderHover = True
        Me.btnClosePreview.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClosePreview.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClosePreview.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClosePreview.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClosePreview.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClosePreview.DrawBorder = True
        Me.btnClosePreview.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClosePreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.btnClosePreview.ForeColor = System.Drawing.Color.Navy
        Me.btnClosePreview.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClosePreview.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClosePreview.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClosePreview.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClosePreview.Location = New System.Drawing.Point(863, 4)
        Me.btnClosePreview.Name = "btnClosePreview"
        Me.btnClosePreview.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClosePreview.SelectedColor2 = System.Drawing.Color.White
        Me.btnClosePreview.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClosePreview.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClosePreview.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClosePreview.SelectedText = Nothing
        Me.btnClosePreview.Size = New System.Drawing.Size(79, 28)
        Me.btnClosePreview.TabIndex = 39
        Me.btnClosePreview.Text = "C l o s e"
        Me.btnClosePreview.UseVisualStyleBackColor = False
        '
        'crvReport
        '
        Me.crvReport.ActiveViewIndex = -1
        Me.crvReport.AutoSize = True
        Me.crvReport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.crvReport.DisplayBackgroundEdge = False
        Me.crvReport.DisplayGroupTree = False
        Me.crvReport.DisplayStatusBar = False
        Me.crvReport.DisplayToolbar = False
        Me.crvReport.Dock = System.Windows.Forms.DockStyle.Fill
        Me.crvReport.Location = New System.Drawing.Point(3, 3)
        Me.crvReport.Name = "crvReport"
        Me.crvReport.SelectionFormula = ""
        Me.crvReport.ShowGotoPageButton = False
        Me.crvReport.ShowGroupTreeButton = False
        Me.crvReport.Size = New System.Drawing.Size(939, 537)
        Me.crvReport.TabIndex = 38
        Me.crvReport.ViewTimeSelectionFormula = ""
        '
        'VwClientsAndServicesRptTableAdapter1
        '
        Me.VwClientsAndServicesRptTableAdapter1.ClearBeforeFill = True
        '
        'frmReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(953, 569)
        Me.Controls.Add(Me.tabReportMain)
        Me.Name = "frmReport"
        Me.Text = "Report"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.tabReportMain.ResumeLayout(False)
        Me.tabReportSelection.ResumeLayout(False)
        Me.splitReportSelection.Panel1.ResumeLayout(False)
        Me.splitReportSelection.Panel2.ResumeLayout(False)
        Me.splitReportSelection.ResumeLayout(False)
        CType(Me.PicPreview, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPrint, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicPdf, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp.ResumeLayout(False)
        Me.grpGrid.ResumeLayout(False)
        Me.grpGrid.PerformLayout()
        Me.grpShowHideColumns.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpInvoiceList.ResumeLayout(False)
        Me.grpInvoiceList.PerformLayout()
        Me.grpShowHideColumnsInvoiceList.ResumeLayout(False)
        CType(Me.grdInvoiceList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        Me.grpDuePeriods.ResumeLayout(False)
        Me.grpDuePeriods.PerformLayout()
        Me.grpQuarter.ResumeLayout(False)
        Me.grpQuarter.PerformLayout()
        Me.grpCurrency.ResumeLayout(False)
        Me.grpCurrency.PerformLayout()
        Me.grpStatus.ResumeLayout(False)
        Me.grpStatus.PerformLayout()
        Me.tabPreview.ResumeLayout(False)
        Me.tabPreview.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents tvReports As System.Windows.Forms.TreeView
	Friend WithEvents tabReportMain As System.Windows.Forms.TabControl
	Friend WithEvents tabReportSelection As System.Windows.Forms.TabPage
	Friend WithEvents tabPreview As System.Windows.Forms.TabPage
	Friend WithEvents crvReport As CrystalDecisions.Windows.Forms.CrystalReportViewer
	Friend WithEvents Label11 As System.Windows.Forms.Label
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents PicPdf As System.Windows.Forms.PictureBox
	Friend WithEvents picPrint As System.Windows.Forms.PictureBox
	Friend WithEvents PicPreview As System.Windows.Forms.PictureBox
	Friend WithEvents splitReportSelection As System.Windows.Forms.SplitContainer
	Friend WithEvents btnClosePreview As BHBut.BouncingHoverButton
	Friend WithEvents btnClose As BHBut.BouncingHoverButton
	Friend WithEvents VwClientsAndServicesRptTableAdapter1 As BS.dsRptTableAdapters.vwClientsAndServicesRptTableAdapter
	Friend WithEvents pnlTitle As System.Windows.Forms.Panel
	Friend WithEvents lblReportTitle As System.Windows.Forms.Label
	Friend WithEvents grpInvoiceList As System.Windows.Forms.GroupBox
	Friend WithEvents lblCurrSymbol2 As System.Windows.Forms.Label
	Friend WithEvents txtTotalCurr2 As System.Windows.Forms.TextBox
	Friend WithEvents lblCurrSymbol As System.Windows.Forms.Label
	Friend WithEvents txtTotal As System.Windows.Forms.TextBox
	Friend WithEvents grpShowHideColumnsInvoiceList As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettingsInvoiceList As System.Windows.Forms.Button
	Friend WithEvents chkLstGridColInvoiceList As System.Windows.Forms.CheckedListBox
	Friend WithEvents btnShowColInvoiceList As System.Windows.Forms.Button
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents grdInvoiceList As System.Windows.Forms.DataGridView
	Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
	Friend WithEvents cboServices As System.Windows.Forms.ComboBox
	Friend WithEvents lblServices As System.Windows.Forms.Label
	Friend WithEvents btnGoDynamics As BHBut.BouncingHoverButton
	Friend WithEvents grpQuarter As System.Windows.Forms.GroupBox
	Friend WithEvents chkOther As System.Windows.Forms.CheckBox
	Friend WithEvents chkQuarter4 As System.Windows.Forms.CheckBox
	Friend WithEvents chkQuarter1 As System.Windows.Forms.CheckBox
	Friend WithEvents chkQuarter2 As System.Windows.Forms.CheckBox
	Friend WithEvents chkQuarter3 As System.Windows.Forms.CheckBox
	Friend WithEvents cboCategory As System.Windows.Forms.ComboBox
	Friend WithEvents grpCurrency As System.Windows.Forms.GroupBox
	Friend WithEvents rdbLBP As System.Windows.Forms.RadioButton
	Friend WithEvents rdbLBPAndUSD As System.Windows.Forms.RadioButton
	Friend WithEvents rdbUSD As System.Windows.Forms.RadioButton
	Friend WithEvents grpStatus As System.Windows.Forms.GroupBox
	Friend WithEvents chkCorrected As System.Windows.Forms.CheckBox
	Friend WithEvents chkPaid As System.Windows.Forms.CheckBox
	Friend WithEvents chkNew As System.Windows.Forms.CheckBox
	Friend WithEvents chkPosted As System.Windows.Forms.CheckBox
	Friend WithEvents chkNotPosted As System.Windows.Forms.CheckBox
	Friend WithEvents lblInvoiceNum As System.Windows.Forms.Label
	Friend WithEvents txtInvoiceNum As System.Windows.Forms.TextBox
	Friend WithEvents lblCategory As System.Windows.Forms.Label
	Friend WithEvents lblStatus As System.Windows.Forms.Label
	Friend WithEvents dtpDateTo As System.Windows.Forms.DateTimePicker
	Friend WithEvents lblDateFrom As System.Windows.Forms.Label
	Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker
	Friend WithEvents lblDateTo As System.Windows.Forms.Label
	Friend WithEvents lblClient As System.Windows.Forms.Label
	Friend WithEvents cboClient As System.Windows.Forms.ComboBox
	Friend WithEvents grp As System.Windows.Forms.GroupBox
	Friend WithEvents ilTreeIcons As System.Windows.Forms.ImageList
	Friend WithEvents grpGrid As System.Windows.Forms.GroupBox
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
	Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
	Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
	Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
	Friend WithEvents btnShowCol As System.Windows.Forms.Button
	Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents grpDuePeriods As System.Windows.Forms.GroupBox
	Friend WithEvents chkOverDue120 As System.Windows.Forms.CheckBox
	Friend WithEvents chkOverDue90 As System.Windows.Forms.CheckBox
	Friend WithEvents chkOverDue60 As System.Windows.Forms.CheckBox
	Friend WithEvents chkOverDue30 As System.Windows.Forms.CheckBox
End Class
