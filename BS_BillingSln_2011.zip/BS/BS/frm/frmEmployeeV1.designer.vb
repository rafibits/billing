<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEmployeeV1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtEmpID = New System.Windows.Forms.TextBox
        Me.txtAcctName = New System.Windows.Forms.TextBox
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.tbNewEmployee = New System.Windows.Forms.TabPage
        Me.grpEmployee = New System.Windows.Forms.GroupBox
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.lblJobGrade = New System.Windows.Forms.Label
        Me.cboJobGrade = New System.Windows.Forms.ComboBox
        Me.cboEmployeeType = New System.Windows.Forms.ComboBox
        Me.lblEmployeeType = New System.Windows.Forms.Label
        Me.tcAddress = New System.Windows.Forms.TabControl
        Me.tpViewAddress = New System.Windows.Forms.TabPage
        Me.grpShowHideColumnsAdd = New System.Windows.Forms.GroupBox
        Me.btnSaveSettingAdd = New System.Windows.Forms.Button
        Me.chkLstGridColAdd = New System.Windows.Forms.CheckedListBox
        Me.btnShowColAddress = New System.Windows.Forms.Button
        Me.btnEditAddress = New System.Windows.Forms.Button
        Me.btnDeleteAddress = New System.Windows.Forms.Button
        Me.btnNewAddress = New System.Windows.Forms.Button
        Me.grdViewAddress = New System.Windows.Forms.DataGridView
        Me.tpNewAddress = New System.Windows.Forms.TabPage
        Me.txtAddID = New System.Windows.Forms.TextBox
        Me.btnSaveAddress = New System.Windows.Forms.Button
        Me.btnCancelAddress = New System.Windows.Forms.Button
        Me.btnNewAddress2 = New System.Windows.Forms.Button
        Me.lblAddType = New System.Windows.Forms.Label
        Me.lblStreet = New System.Windows.Forms.Label
        Me.lblCity = New System.Windows.Forms.Label
        Me.lblArea = New System.Windows.Forms.Label
        Me.lblState = New System.Windows.Forms.Label
        Me.lblAddID = New System.Windows.Forms.Label
        Me.cboState = New System.Windows.Forms.ComboBox
        Me.cboAddType = New System.Windows.Forms.ComboBox
        Me.CboCity = New System.Windows.Forms.ComboBox
        Me.cboArea = New System.Windows.Forms.ComboBox
        Me.CboStreet = New System.Windows.Forms.ComboBox
        Me.lblBNF = New System.Windows.Forms.Label
        Me.txtBNF = New System.Windows.Forms.TextBox
        Me.grpLogInInfo = New System.Windows.Forms.GroupBox
        Me.lblUserLevel = New System.Windows.Forms.Label
        Me.lblPassword = New System.Windows.Forms.Label
        Me.lblUserName = New System.Windows.Forms.Label
        Me.cboUserLevel = New System.Windows.Forms.ComboBox
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.txtUserName = New System.Windows.Forms.TextBox
        Me.grpContactInfo = New System.Windows.Forms.GroupBox
        Me.TxtCel = New System.Windows.Forms.TextBox
        Me.lblCel = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.CheckedListBox2 = New System.Windows.Forms.CheckedListBox
        Me.lblTel = New System.Windows.Forms.Label
        Me.Button3 = New System.Windows.Forms.Button
        Me.lblEMail = New System.Windows.Forms.Label
        Me.txtTel = New System.Windows.Forms.TextBox
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.grpInfo = New System.Windows.Forms.GroupBox
        Me.cboCurrency = New System.Windows.Forms.ComboBox
        Me.lblCurrency = New System.Windows.Forms.Label
        Me.dtpEndDate = New System.Windows.Forms.DateTimePicker
        Me.dtpStartDate = New System.Windows.Forms.DateTimePicker
        Me.dtpDOB = New System.Windows.Forms.DateTimePicker
        Me.txtSalary = New System.Windows.Forms.TextBox
        Me.lblEDate = New System.Windows.Forms.Label
        Me.lblSDate = New System.Windows.Forms.Label
        Me.txtHours = New System.Windows.Forms.TextBox
        Me.lblHours = New System.Windows.Forms.Label
        Me.lblPeriod = New System.Windows.Forms.Label
        Me.cboPOB = New System.Windows.Forms.ComboBox
        Me.cboPeriod = New System.Windows.Forms.ComboBox
        Me.lblPOB = New System.Windows.Forms.Label
        Me.lblSalary = New System.Windows.Forms.Label
        Me.lblDOB = New System.Windows.Forms.Label
        Me.grpName = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.cboDepartment = New System.Windows.Forms.ComboBox
        Me.cboTitle = New System.Windows.Forms.ComboBox
        Me.txtLName = New System.Windows.Forms.TextBox
        Me.txtMName = New System.Windows.Forms.TextBox
        Me.txtFName = New System.Windows.Forms.TextBox
        Me.txtEmpNum = New System.Windows.Forms.TextBox
        Me.lblTitle = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.lblMN = New System.Windows.Forms.Label
        Me.lblFN = New System.Windows.Forms.Label
        Me.lblEmployeeID = New System.Windows.Forms.Label
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.BtnClose = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.tbEmployeeList = New System.Windows.Forms.TabPage
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnNewEmp = New BHBut.BouncingHoverButton
        Me.btnCloseList = New BHBut.BouncingHoverButton
        Me.btnEdit = New BHBut.BouncingHoverButton
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.txtFilByLName = New System.Windows.Forms.TextBox
        Me.lblLName = New System.Windows.Forms.Label
        Me.txtFiltByMName = New System.Windows.Forms.TextBox
        Me.lblMName = New System.Windows.Forms.Label
        Me.txtFiltByFName = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtFiltByNum = New System.Windows.Forms.TextBox
        Me.lblEmployeeNum = New System.Windows.Forms.Label
        Me.grdEmployeeList = New System.Windows.Forms.DataGridView
        Me.tbEmployee = New System.Windows.Forms.TabControl
        Me.lblFormTitleLine = New System.Windows.Forms.Panel
        Me.lblFormTitle = New System.Windows.Forms.Label
        Me.tbNewEmployee.SuspendLayout()
        Me.grpEmployee.SuspendLayout()
        Me.tcAddress.SuspendLayout()
        Me.tpViewAddress.SuspendLayout()
        Me.grpShowHideColumnsAdd.SuspendLayout()
        CType(Me.grdViewAddress, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpNewAddress.SuspendLayout()
        Me.grpLogInInfo.SuspendLayout()
        Me.grpContactInfo.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.grpInfo.SuspendLayout()
        Me.grpName.SuspendLayout()
        Me.grpButtons.SuspendLayout()
        Me.tbEmployeeList.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.grpFilter.SuspendLayout()
        CType(Me.grdEmployeeList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbEmployee.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtEmpID
        '
        Me.txtEmpID.Location = New System.Drawing.Point(257, 12)
        Me.txtEmpID.Name = "txtEmpID"
        Me.txtEmpID.Size = New System.Drawing.Size(67, 20)
        Me.txtEmpID.TabIndex = 343
        '
        'txtAcctName
        '
        Me.txtAcctName.Location = New System.Drawing.Point(270, 12)
        Me.txtAcctName.Name = "txtAcctName"
        Me.txtAcctName.Size = New System.Drawing.Size(32, 20)
        Me.txtAcctName.TabIndex = 10
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.CheckOnClick = True
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(5, 21)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(163, 184)
        Me.CheckedListBox1.TabIndex = 92
        Me.CheckedListBox1.ThreeDCheckBoxes = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(4, 215)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(163, 33)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Save Settings"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'tbNewEmployee
        '
        Me.tbNewEmployee.Controls.Add(Me.grpEmployee)
        Me.tbNewEmployee.Controls.Add(Me.grpButtons)
        Me.tbNewEmployee.Location = New System.Drawing.Point(4, 25)
        Me.tbNewEmployee.Name = "tbNewEmployee"
        Me.tbNewEmployee.Padding = New System.Windows.Forms.Padding(3)
        Me.tbNewEmployee.Size = New System.Drawing.Size(728, 520)
        Me.tbNewEmployee.TabIndex = 1
        Me.tbNewEmployee.Text = "New/Edit Employee"
        Me.tbNewEmployee.UseVisualStyleBackColor = True
        '
        'grpEmployee
        '
        Me.grpEmployee.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpEmployee.Controls.Add(Me.lstDataErr)
        Me.grpEmployee.Controls.Add(Me.btnDataErr)
        Me.grpEmployee.Controls.Add(Me.lblJobGrade)
        Me.grpEmployee.Controls.Add(Me.cboJobGrade)
        Me.grpEmployee.Controls.Add(Me.cboEmployeeType)
        Me.grpEmployee.Controls.Add(Me.lblEmployeeType)
        Me.grpEmployee.Controls.Add(Me.tcAddress)
        Me.grpEmployee.Controls.Add(Me.grpLogInInfo)
        Me.grpEmployee.Controls.Add(Me.grpContactInfo)
        Me.grpEmployee.Controls.Add(Me.grpInfo)
        Me.grpEmployee.Controls.Add(Me.grpName)
        Me.grpEmployee.Location = New System.Drawing.Point(3, 6)
        Me.grpEmployee.Name = "grpEmployee"
        Me.grpEmployee.Size = New System.Drawing.Size(722, 462)
        Me.grpEmployee.TabIndex = 3
        Me.grpEmployee.TabStop = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(522, 12)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(153, 17)
        Me.lstDataErr.TabIndex = 342
        Me.lstDataErr.Visible = False
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(675, 8)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(46, 25)
        Me.btnDataErr.TabIndex = 341
        Me.btnDataErr.Text = "Error"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'lblJobGrade
        '
        Me.lblJobGrade.AutoSize = True
        Me.lblJobGrade.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJobGrade.ForeColor = System.Drawing.Color.Maroon
        Me.lblJobGrade.Location = New System.Drawing.Point(512, 207)
        Me.lblJobGrade.Name = "lblJobGrade"
        Me.lblJobGrade.Size = New System.Drawing.Size(65, 13)
        Me.lblJobGrade.TabIndex = 346
        Me.lblJobGrade.Text = "Job Grade"
        '
        'cboJobGrade
        '
        Me.cboJobGrade.FormattingEnabled = True
        Me.cboJobGrade.Location = New System.Drawing.Point(508, 223)
        Me.cboJobGrade.Name = "cboJobGrade"
        Me.cboJobGrade.Size = New System.Drawing.Size(121, 21)
        Me.cboJobGrade.TabIndex = 345
        '
        'cboEmployeeType
        '
        Me.cboEmployeeType.FormattingEnabled = True
        Me.cboEmployeeType.Location = New System.Drawing.Point(508, 168)
        Me.cboEmployeeType.Name = "cboEmployeeType"
        Me.cboEmployeeType.Size = New System.Drawing.Size(121, 21)
        Me.cboEmployeeType.TabIndex = 343
        '
        'lblEmployeeType
        '
        Me.lblEmployeeType.AutoSize = True
        Me.lblEmployeeType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmployeeType.ForeColor = System.Drawing.Color.Maroon
        Me.lblEmployeeType.Location = New System.Drawing.Point(512, 154)
        Me.lblEmployeeType.Name = "lblEmployeeType"
        Me.lblEmployeeType.Size = New System.Drawing.Size(35, 13)
        Me.lblEmployeeType.TabIndex = 344
        Me.lblEmployeeType.Text = "Type"
        '
        'tcAddress
        '
        Me.tcAddress.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tcAddress.Controls.Add(Me.tpViewAddress)
        Me.tcAddress.Controls.Add(Me.tpNewAddress)
        Me.tcAddress.Location = New System.Drawing.Point(3, 255)
        Me.tcAddress.Name = "tcAddress"
        Me.tcAddress.SelectedIndex = 0
        Me.tcAddress.Size = New System.Drawing.Size(707, 201)
        Me.tcAddress.TabIndex = 13
        '
        'tpViewAddress
        '
        Me.tpViewAddress.Controls.Add(Me.grpShowHideColumnsAdd)
        Me.tpViewAddress.Controls.Add(Me.btnShowColAddress)
        Me.tpViewAddress.Controls.Add(Me.btnEditAddress)
        Me.tpViewAddress.Controls.Add(Me.btnDeleteAddress)
        Me.tpViewAddress.Controls.Add(Me.btnNewAddress)
        Me.tpViewAddress.Controls.Add(Me.grdViewAddress)
        Me.tpViewAddress.Location = New System.Drawing.Point(4, 22)
        Me.tpViewAddress.Name = "tpViewAddress"
        Me.tpViewAddress.Padding = New System.Windows.Forms.Padding(3)
        Me.tpViewAddress.Size = New System.Drawing.Size(699, 175)
        Me.tpViewAddress.TabIndex = 0
        Me.tpViewAddress.Text = "Address"
        Me.tpViewAddress.UseVisualStyleBackColor = True
        '
        'grpShowHideColumnsAdd
        '
        Me.grpShowHideColumnsAdd.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumnsAdd.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumnsAdd.Controls.Add(Me.btnSaveSettingAdd)
        Me.grpShowHideColumnsAdd.Controls.Add(Me.chkLstGridColAdd)
        Me.grpShowHideColumnsAdd.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumnsAdd.Location = New System.Drawing.Point(42, 28)
        Me.grpShowHideColumnsAdd.Name = "grpShowHideColumnsAdd"
        Me.grpShowHideColumnsAdd.Size = New System.Drawing.Size(175, 132)
        Me.grpShowHideColumnsAdd.TabIndex = 160
        Me.grpShowHideColumnsAdd.TabStop = False
        Me.grpShowHideColumnsAdd.Text = "Custom Columns"
        Me.grpShowHideColumnsAdd.Visible = False
        '
        'btnSaveSettingAdd
        '
        Me.btnSaveSettingAdd.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettingAdd.Location = New System.Drawing.Point(7, 103)
        Me.btnSaveSettingAdd.Name = "btnSaveSettingAdd"
        Me.btnSaveSettingAdd.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettingAdd.TabIndex = 0
        Me.btnSaveSettingAdd.Text = "Save Settings"
        Me.btnSaveSettingAdd.UseVisualStyleBackColor = True
        '
        'chkLstGridColAdd
        '
        Me.chkLstGridColAdd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridColAdd.CheckOnClick = True
        Me.chkLstGridColAdd.FormattingEnabled = True
        Me.chkLstGridColAdd.Location = New System.Drawing.Point(7, 15)
        Me.chkLstGridColAdd.Name = "chkLstGridColAdd"
        Me.chkLstGridColAdd.Size = New System.Drawing.Size(162, 64)
        Me.chkLstGridColAdd.TabIndex = 92
        Me.chkLstGridColAdd.ThreeDCheckBoxes = True
        '
        'btnShowColAddress
        '
        Me.btnShowColAddress.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowColAddress.BackColor = System.Drawing.Color.Linen
        Me.btnShowColAddress.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowColAddress.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowColAddress.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowColAddress.FlatAppearance.BorderSize = 2
        Me.btnShowColAddress.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColAddress.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowColAddress.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowColAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowColAddress.ForeColor = System.Drawing.Color.White
        Me.btnShowColAddress.Location = New System.Drawing.Point(6, 6)
        Me.btnShowColAddress.Name = "btnShowColAddress"
        Me.btnShowColAddress.Size = New System.Drawing.Size(36, 30)
        Me.btnShowColAddress.TabIndex = 159
        Me.btnShowColAddress.UseVisualStyleBackColor = False
        '
        'btnEditAddress
        '
        Me.btnEditAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEditAddress.ForeColor = System.Drawing.Color.Navy
        Me.btnEditAddress.Location = New System.Drawing.Point(617, 93)
        Me.btnEditAddress.Name = "btnEditAddress"
        Me.btnEditAddress.Size = New System.Drawing.Size(66, 23)
        Me.btnEditAddress.TabIndex = 19
        Me.btnEditAddress.Text = "Edit "
        Me.btnEditAddress.UseVisualStyleBackColor = True
        '
        'btnDeleteAddress
        '
        Me.btnDeleteAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDeleteAddress.ForeColor = System.Drawing.Color.Navy
        Me.btnDeleteAddress.Location = New System.Drawing.Point(556, 185)
        Me.btnDeleteAddress.Name = "btnDeleteAddress"
        Me.btnDeleteAddress.Size = New System.Drawing.Size(64, 23)
        Me.btnDeleteAddress.TabIndex = 18
        Me.btnDeleteAddress.Text = "Delete "
        Me.btnDeleteAddress.UseVisualStyleBackColor = True
        '
        'btnNewAddress
        '
        Me.btnNewAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNewAddress.ForeColor = System.Drawing.Color.Navy
        Me.btnNewAddress.Location = New System.Drawing.Point(616, 57)
        Me.btnNewAddress.Name = "btnNewAddress"
        Me.btnNewAddress.Size = New System.Drawing.Size(67, 23)
        Me.btnNewAddress.TabIndex = 17
        Me.btnNewAddress.Text = "New "
        Me.btnNewAddress.UseVisualStyleBackColor = True
        '
        'grdViewAddress
        '
        Me.grdViewAddress.AllowUserToAddRows = False
        Me.grdViewAddress.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdViewAddress.BackgroundColor = System.Drawing.Color.LightYellow
        Me.grdViewAddress.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdViewAddress.Location = New System.Drawing.Point(5, 6)
        Me.grdViewAddress.Name = "grdViewAddress"
        Me.grdViewAddress.ReadOnly = True
        Me.grdViewAddress.Size = New System.Drawing.Size(599, 163)
        Me.grdViewAddress.TabIndex = 0
        '
        'tpNewAddress
        '
        Me.tpNewAddress.BackColor = System.Drawing.Color.Lavender
        Me.tpNewAddress.Controls.Add(Me.txtAddID)
        Me.tpNewAddress.Controls.Add(Me.btnSaveAddress)
        Me.tpNewAddress.Controls.Add(Me.btnCancelAddress)
        Me.tpNewAddress.Controls.Add(Me.btnNewAddress2)
        Me.tpNewAddress.Controls.Add(Me.lblAddType)
        Me.tpNewAddress.Controls.Add(Me.lblStreet)
        Me.tpNewAddress.Controls.Add(Me.lblCity)
        Me.tpNewAddress.Controls.Add(Me.lblArea)
        Me.tpNewAddress.Controls.Add(Me.lblState)
        Me.tpNewAddress.Controls.Add(Me.lblAddID)
        Me.tpNewAddress.Controls.Add(Me.cboState)
        Me.tpNewAddress.Controls.Add(Me.cboAddType)
        Me.tpNewAddress.Controls.Add(Me.CboCity)
        Me.tpNewAddress.Controls.Add(Me.cboArea)
        Me.tpNewAddress.Controls.Add(Me.CboStreet)
        Me.tpNewAddress.Controls.Add(Me.lblBNF)
        Me.tpNewAddress.Controls.Add(Me.txtBNF)
        Me.tpNewAddress.Location = New System.Drawing.Point(4, 22)
        Me.tpNewAddress.Name = "tpNewAddress"
        Me.tpNewAddress.Padding = New System.Windows.Forms.Padding(3)
        Me.tpNewAddress.Size = New System.Drawing.Size(699, 175)
        Me.tpNewAddress.TabIndex = 1
        Me.tpNewAddress.Text = "NewAddress"
        '
        'txtAddID
        '
        Me.txtAddID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAddID.Location = New System.Drawing.Point(99, 14)
        Me.txtAddID.Name = "txtAddID"
        Me.txtAddID.ReadOnly = True
        Me.txtAddID.Size = New System.Drawing.Size(100, 20)
        Me.txtAddID.TabIndex = 49
        '
        'btnSaveAddress
        '
        Me.btnSaveAddress.Location = New System.Drawing.Point(552, 78)
        Me.btnSaveAddress.Name = "btnSaveAddress"
        Me.btnSaveAddress.Size = New System.Drawing.Size(66, 23)
        Me.btnSaveAddress.TabIndex = 48
        Me.btnSaveAddress.Text = "Save "
        Me.btnSaveAddress.UseVisualStyleBackColor = True
        '
        'btnCancelAddress
        '
        Me.btnCancelAddress.Location = New System.Drawing.Point(552, 105)
        Me.btnCancelAddress.Name = "btnCancelAddress"
        Me.btnCancelAddress.Size = New System.Drawing.Size(66, 23)
        Me.btnCancelAddress.TabIndex = 47
        Me.btnCancelAddress.Text = "Cancel "
        Me.btnCancelAddress.UseVisualStyleBackColor = True
        '
        'btnNewAddress2
        '
        Me.btnNewAddress2.Location = New System.Drawing.Point(552, 51)
        Me.btnNewAddress2.Name = "btnNewAddress2"
        Me.btnNewAddress2.Size = New System.Drawing.Size(67, 23)
        Me.btnNewAddress2.TabIndex = 46
        Me.btnNewAddress2.Text = "New "
        Me.btnNewAddress2.UseVisualStyleBackColor = True
        Me.btnNewAddress2.Visible = False
        '
        'lblAddType
        '
        Me.lblAddType.AutoSize = True
        Me.lblAddType.Location = New System.Drawing.Point(275, 17)
        Me.lblAddType.Name = "lblAddType"
        Me.lblAddType.Size = New System.Drawing.Size(73, 13)
        Me.lblAddType.TabIndex = 45
        Me.lblAddType.Text = "Address Type"
        '
        'lblStreet
        '
        Me.lblStreet.AutoSize = True
        Me.lblStreet.Location = New System.Drawing.Point(312, 79)
        Me.lblStreet.Name = "lblStreet"
        Me.lblStreet.Size = New System.Drawing.Size(37, 13)
        Me.lblStreet.TabIndex = 44
        Me.lblStreet.Text = "Street"
        '
        'lblCity
        '
        Me.lblCity.AutoSize = True
        Me.lblCity.Location = New System.Drawing.Point(62, 78)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(26, 13)
        Me.lblCity.TabIndex = 43
        Me.lblCity.Text = "City"
        '
        'lblArea
        '
        Me.lblArea.AutoSize = True
        Me.lblArea.Location = New System.Drawing.Point(318, 48)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(30, 13)
        Me.lblArea.TabIndex = 42
        Me.lblArea.Text = "Area"
        '
        'lblState
        '
        Me.lblState.AutoSize = True
        Me.lblState.Location = New System.Drawing.Point(55, 46)
        Me.lblState.Name = "lblState"
        Me.lblState.Size = New System.Drawing.Size(33, 13)
        Me.lblState.TabIndex = 39
        Me.lblState.Text = "State"
        '
        'lblAddID
        '
        Me.lblAddID.AutoSize = True
        Me.lblAddID.Location = New System.Drawing.Point(28, 16)
        Me.lblAddID.Name = "lblAddID"
        Me.lblAddID.Size = New System.Drawing.Size(60, 13)
        Me.lblAddID.TabIndex = 38
        Me.lblAddID.Text = "Address ID"
        '
        'cboState
        '
        Me.cboState.FormattingEnabled = True
        Me.cboState.Location = New System.Drawing.Point(99, 45)
        Me.cboState.Name = "cboState"
        Me.cboState.Size = New System.Drawing.Size(163, 21)
        Me.cboState.TabIndex = 2
        '
        'cboAddType
        '
        Me.cboAddType.FormattingEnabled = True
        Me.cboAddType.Location = New System.Drawing.Point(357, 14)
        Me.cboAddType.Name = "cboAddType"
        Me.cboAddType.Size = New System.Drawing.Size(163, 21)
        Me.cboAddType.TabIndex = 1
        '
        'CboCity
        '
        Me.CboCity.FormattingEnabled = True
        Me.CboCity.Location = New System.Drawing.Point(99, 75)
        Me.CboCity.Name = "CboCity"
        Me.CboCity.Size = New System.Drawing.Size(163, 21)
        Me.CboCity.TabIndex = 5
        '
        'cboArea
        '
        Me.cboArea.FormattingEnabled = True
        Me.cboArea.Location = New System.Drawing.Point(357, 45)
        Me.cboArea.Name = "cboArea"
        Me.cboArea.Size = New System.Drawing.Size(163, 21)
        Me.cboArea.TabIndex = 6
        '
        'CboStreet
        '
        Me.CboStreet.FormattingEnabled = True
        Me.CboStreet.Location = New System.Drawing.Point(357, 76)
        Me.CboStreet.Name = "CboStreet"
        Me.CboStreet.Size = New System.Drawing.Size(163, 21)
        Me.CboStreet.TabIndex = 7
        '
        'lblBNF
        '
        Me.lblBNF.AutoSize = True
        Me.lblBNF.Location = New System.Drawing.Point(3, 111)
        Me.lblBNF.Name = "lblBNF"
        Me.lblBNF.Size = New System.Drawing.Size(92, 13)
        Me.lblBNF.TabIndex = 7
        Me.lblBNF.Text = "Building And Floor"
        '
        'txtBNF
        '
        Me.txtBNF.Location = New System.Drawing.Point(99, 108)
        Me.txtBNF.Name = "txtBNF"
        Me.txtBNF.Size = New System.Drawing.Size(421, 20)
        Me.txtBNF.TabIndex = 8
        '
        'grpLogInInfo
        '
        Me.grpLogInInfo.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.grpLogInInfo.Controls.Add(Me.lblUserLevel)
        Me.grpLogInInfo.Controls.Add(Me.lblPassword)
        Me.grpLogInInfo.Controls.Add(Me.lblUserName)
        Me.grpLogInInfo.Controls.Add(Me.cboUserLevel)
        Me.grpLogInInfo.Controls.Add(Me.txtPassword)
        Me.grpLogInInfo.Controls.Add(Me.txtUserName)
        Me.grpLogInInfo.ForeColor = System.Drawing.Color.Blue
        Me.grpLogInInfo.Location = New System.Drawing.Point(252, 148)
        Me.grpLogInInfo.Name = "grpLogInInfo"
        Me.grpLogInInfo.Size = New System.Drawing.Size(248, 100)
        Me.grpLogInInfo.TabIndex = 3
        Me.grpLogInInfo.TabStop = False
        Me.grpLogInInfo.Text = "LogIn Info"
        '
        'lblUserLevel
        '
        Me.lblUserLevel.AutoSize = True
        Me.lblUserLevel.ForeColor = System.Drawing.Color.Navy
        Me.lblUserLevel.Location = New System.Drawing.Point(11, 23)
        Me.lblUserLevel.Name = "lblUserLevel"
        Me.lblUserLevel.Size = New System.Drawing.Size(54, 13)
        Me.lblUserLevel.TabIndex = 92
        Me.lblUserLevel.Text = "UserLevel"
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.ForeColor = System.Drawing.Color.Navy
        Me.lblPassword.Location = New System.Drawing.Point(13, 72)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(53, 13)
        Me.lblPassword.TabIndex = 91
        Me.lblPassword.Text = "Password"
        '
        'lblUserName
        '
        Me.lblUserName.AutoSize = True
        Me.lblUserName.ForeColor = System.Drawing.Color.Navy
        Me.lblUserName.Location = New System.Drawing.Point(9, 47)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(56, 13)
        Me.lblUserName.TabIndex = 90
        Me.lblUserName.Text = "UserName"
        '
        'cboUserLevel
        '
        Me.cboUserLevel.FormattingEnabled = True
        Me.cboUserLevel.Location = New System.Drawing.Point(73, 21)
        Me.cboUserLevel.Name = "cboUserLevel"
        Me.cboUserLevel.Size = New System.Drawing.Size(164, 21)
        Me.cboUserLevel.TabIndex = 10
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(73, 72)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(164, 20)
        Me.txtPassword.TabIndex = 12
        '
        'txtUserName
        '
        Me.txtUserName.Location = New System.Drawing.Point(73, 47)
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.Size = New System.Drawing.Size(164, 20)
        Me.txtUserName.TabIndex = 11
        '
        'grpContactInfo
        '
        Me.grpContactInfo.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.grpContactInfo.Controls.Add(Me.TxtCel)
        Me.grpContactInfo.Controls.Add(Me.lblCel)
        Me.grpContactInfo.Controls.Add(Me.GroupBox2)
        Me.grpContactInfo.Controls.Add(Me.lblTel)
        Me.grpContactInfo.Controls.Add(Me.Button3)
        Me.grpContactInfo.Controls.Add(Me.lblEMail)
        Me.grpContactInfo.Controls.Add(Me.txtTel)
        Me.grpContactInfo.Controls.Add(Me.txtEmail)
        Me.grpContactInfo.ForeColor = System.Drawing.Color.Blue
        Me.grpContactInfo.Location = New System.Drawing.Point(6, 149)
        Me.grpContactInfo.Name = "grpContactInfo"
        Me.grpContactInfo.Size = New System.Drawing.Size(235, 100)
        Me.grpContactInfo.TabIndex = 2
        Me.grpContactInfo.TabStop = False
        Me.grpContactInfo.Text = "Contact Info"
        '
        'TxtCel
        '
        Me.TxtCel.Location = New System.Drawing.Point(52, 70)
        Me.TxtCel.Name = "TxtCel"
        Me.TxtCel.Size = New System.Drawing.Size(159, 20)
        Me.TxtCel.TabIndex = 9
        '
        'lblCel
        '
        Me.lblCel.AutoSize = True
        Me.lblCel.ForeColor = System.Drawing.Color.Navy
        Me.lblCel.Location = New System.Drawing.Point(23, 77)
        Me.lblCel.Name = "lblCel"
        Me.lblCel.Size = New System.Drawing.Size(22, 13)
        Me.lblCel.TabIndex = 89
        Me.lblCel.Text = "Cel"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.GroupBox2.Controls.Add(Me.Button2)
        Me.GroupBox2.Controls.Add(Me.CheckedListBox2)
        Me.GroupBox2.ForeColor = System.Drawing.Color.Navy
        Me.GroupBox2.Location = New System.Drawing.Point(66, 157)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(175, 269)
        Me.GroupBox2.TabIndex = 162
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Custom Columns"
        Me.GroupBox2.Visible = False
        '
        'Button2
        '
        Me.Button2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.Location = New System.Drawing.Point(7, 240)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(162, 27)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "Save Settings"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'CheckedListBox2
        '
        Me.CheckedListBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CheckedListBox2.CheckOnClick = True
        Me.CheckedListBox2.FormattingEnabled = True
        Me.CheckedListBox2.Location = New System.Drawing.Point(7, 16)
        Me.CheckedListBox2.Name = "CheckedListBox2"
        Me.CheckedListBox2.Size = New System.Drawing.Size(162, 199)
        Me.CheckedListBox2.TabIndex = 92
        Me.CheckedListBox2.ThreeDCheckBoxes = True
        '
        'lblTel
        '
        Me.lblTel.AutoSize = True
        Me.lblTel.ForeColor = System.Drawing.Color.Navy
        Me.lblTel.Location = New System.Drawing.Point(23, 51)
        Me.lblTel.Name = "lblTel"
        Me.lblTel.Size = New System.Drawing.Size(21, 13)
        Me.lblTel.TabIndex = 90
        Me.lblTel.Text = "Tel"
        '
        'Button3
        '
        Me.Button3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button3.BackColor = System.Drawing.Color.Linen
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button3.FlatAppearance.BorderSize = 2
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(26, 156)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(36, 30)
        Me.Button3.TabIndex = 161
        Me.Button3.UseVisualStyleBackColor = False
        '
        'lblEMail
        '
        Me.lblEMail.AutoSize = True
        Me.lblEMail.ForeColor = System.Drawing.Color.Navy
        Me.lblEMail.Location = New System.Drawing.Point(12, 22)
        Me.lblEMail.Name = "lblEMail"
        Me.lblEMail.Size = New System.Drawing.Size(31, 13)
        Me.lblEMail.TabIndex = 87
        Me.lblEMail.Text = "EMail"
        '
        'txtTel
        '
        Me.txtTel.Location = New System.Drawing.Point(52, 46)
        Me.txtTel.Name = "txtTel"
        Me.txtTel.Size = New System.Drawing.Size(159, 20)
        Me.txtTel.TabIndex = 8
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(52, 22)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(159, 20)
        Me.txtEmail.TabIndex = 7
        '
        'grpInfo
        '
        Me.grpInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpInfo.BackColor = System.Drawing.Color.LightYellow
        Me.grpInfo.Controls.Add(Me.cboCurrency)
        Me.grpInfo.Controls.Add(Me.lblCurrency)
        Me.grpInfo.Controls.Add(Me.dtpEndDate)
        Me.grpInfo.Controls.Add(Me.dtpStartDate)
        Me.grpInfo.Controls.Add(Me.dtpDOB)
        Me.grpInfo.Controls.Add(Me.txtSalary)
        Me.grpInfo.Controls.Add(Me.lblEDate)
        Me.grpInfo.Controls.Add(Me.lblSDate)
        Me.grpInfo.Controls.Add(Me.txtHours)
        Me.grpInfo.Controls.Add(Me.lblHours)
        Me.grpInfo.Controls.Add(Me.lblPeriod)
        Me.grpInfo.Controls.Add(Me.cboPOB)
        Me.grpInfo.Controls.Add(Me.cboPeriod)
        Me.grpInfo.Controls.Add(Me.lblPOB)
        Me.grpInfo.Controls.Add(Me.lblSalary)
        Me.grpInfo.Controls.Add(Me.lblDOB)
        Me.grpInfo.Location = New System.Drawing.Point(3, 73)
        Me.grpInfo.Name = "grpInfo"
        Me.grpInfo.Size = New System.Drawing.Size(716, 72)
        Me.grpInfo.TabIndex = 1
        Me.grpInfo.TabStop = False
        '
        'cboCurrency
        '
        Me.cboCurrency.Enabled = False
        Me.cboCurrency.FormattingEnabled = True
        Me.cboCurrency.Location = New System.Drawing.Point(382, 18)
        Me.cboCurrency.Name = "cboCurrency"
        Me.cboCurrency.Size = New System.Drawing.Size(62, 21)
        Me.cboCurrency.TabIndex = 112
        '
        'lblCurrency
        '
        Me.lblCurrency.AutoSize = True
        Me.lblCurrency.ForeColor = System.Drawing.Color.Navy
        Me.lblCurrency.Location = New System.Drawing.Point(331, 21)
        Me.lblCurrency.Name = "lblCurrency"
        Me.lblCurrency.Size = New System.Drawing.Size(51, 13)
        Me.lblCurrency.TabIndex = 111
        Me.lblCurrency.Text = "Currency"
        '
        'dtpEndDate
        '
        Me.dtpEndDate.CustomFormat = "MMM dd, yyyy"
        Me.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpEndDate.Location = New System.Drawing.Point(523, 43)
        Me.dtpEndDate.Name = "dtpEndDate"
        Me.dtpEndDate.Size = New System.Drawing.Size(100, 20)
        Me.dtpEndDate.TabIndex = 6
        '
        'dtpStartDate
        '
        Me.dtpStartDate.CustomFormat = "MMM dd, yyyy"
        Me.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpStartDate.Location = New System.Drawing.Point(522, 16)
        Me.dtpStartDate.Name = "dtpStartDate"
        Me.dtpStartDate.Size = New System.Drawing.Size(100, 20)
        Me.dtpStartDate.TabIndex = 5
        '
        'dtpDOB
        '
        Me.dtpDOB.CustomFormat = "MMM dd, yyyy"
        Me.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDOB.Location = New System.Drawing.Point(48, 16)
        Me.dtpDOB.Name = "dtpDOB"
        Me.dtpDOB.Size = New System.Drawing.Size(107, 20)
        Me.dtpDOB.TabIndex = 0
        '
        'txtSalary
        '
        Me.txtSalary.Location = New System.Drawing.Point(215, 44)
        Me.txtSalary.Name = "txtSalary"
        Me.txtSalary.Size = New System.Drawing.Size(103, 20)
        Me.txtSalary.TabIndex = 3
        '
        'lblEDate
        '
        Me.lblEDate.AutoSize = True
        Me.lblEDate.ForeColor = System.Drawing.Color.Navy
        Me.lblEDate.Location = New System.Drawing.Point(466, 47)
        Me.lblEDate.Name = "lblEDate"
        Me.lblEDate.Size = New System.Drawing.Size(54, 13)
        Me.lblEDate.TabIndex = 11
        Me.lblEDate.Text = "End Date "
        '
        'lblSDate
        '
        Me.lblSDate.AutoSize = True
        Me.lblSDate.ForeColor = System.Drawing.Color.Navy
        Me.lblSDate.Location = New System.Drawing.Point(464, 18)
        Me.lblSDate.Name = "lblSDate"
        Me.lblSDate.Size = New System.Drawing.Size(57, 13)
        Me.lblSDate.TabIndex = 10
        Me.lblSDate.Text = "Start Date"
        '
        'txtHours
        '
        Me.txtHours.Location = New System.Drawing.Point(382, 44)
        Me.txtHours.Name = "txtHours"
        Me.txtHours.Size = New System.Drawing.Size(61, 20)
        Me.txtHours.TabIndex = 4
        '
        'lblHours
        '
        Me.lblHours.AutoSize = True
        Me.lblHours.ForeColor = System.Drawing.Color.Navy
        Me.lblHours.Location = New System.Drawing.Point(345, 48)
        Me.lblHours.Name = "lblHours"
        Me.lblHours.Size = New System.Drawing.Size(35, 13)
        Me.lblHours.TabIndex = 7
        Me.lblHours.Text = "Hours"
        '
        'lblPeriod
        '
        Me.lblPeriod.AutoSize = True
        Me.lblPeriod.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPeriod.ForeColor = System.Drawing.Color.Maroon
        Me.lblPeriod.Location = New System.Drawing.Point(8, 50)
        Me.lblPeriod.Name = "lblPeriod"
        Me.lblPeriod.Size = New System.Drawing.Size(37, 13)
        Me.lblPeriod.TabIndex = 6
        Me.lblPeriod.Text = "Period"
        '
        'cboPOB
        '
        Me.cboPOB.FormattingEnabled = True
        Me.cboPOB.Location = New System.Drawing.Point(215, 18)
        Me.cboPOB.Name = "cboPOB"
        Me.cboPOB.Size = New System.Drawing.Size(103, 21)
        Me.cboPOB.TabIndex = 1
        '
        'cboPeriod
        '
        Me.cboPeriod.FormattingEnabled = True
        Me.cboPeriod.Location = New System.Drawing.Point(48, 44)
        Me.cboPeriod.Name = "cboPeriod"
        Me.cboPeriod.Size = New System.Drawing.Size(107, 21)
        Me.cboPeriod.TabIndex = 2
        '
        'lblPOB
        '
        Me.lblPOB.AutoSize = True
        Me.lblPOB.ForeColor = System.Drawing.Color.Navy
        Me.lblPOB.Location = New System.Drawing.Point(183, 18)
        Me.lblPOB.Name = "lblPOB"
        Me.lblPOB.Size = New System.Drawing.Size(27, 13)
        Me.lblPOB.TabIndex = 2
        Me.lblPOB.Text = "POB"
        '
        'lblSalary
        '
        Me.lblSalary.AutoSize = True
        Me.lblSalary.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSalary.ForeColor = System.Drawing.Color.Maroon
        Me.lblSalary.Location = New System.Drawing.Point(176, 46)
        Me.lblSalary.Name = "lblSalary"
        Me.lblSalary.Size = New System.Drawing.Size(36, 13)
        Me.lblSalary.TabIndex = 1
        Me.lblSalary.Text = "Salary"
        '
        'lblDOB
        '
        Me.lblDOB.AutoSize = True
        Me.lblDOB.ForeColor = System.Drawing.Color.Navy
        Me.lblDOB.Location = New System.Drawing.Point(13, 18)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(28, 13)
        Me.lblDOB.TabIndex = 0
        Me.lblDOB.Text = "DOB"
        '
        'grpName
        '
        Me.grpName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpName.BackColor = System.Drawing.Color.Lavender
        Me.grpName.Controls.Add(Me.Label3)
        Me.grpName.Controls.Add(Me.cboDepartment)
        Me.grpName.Controls.Add(Me.cboTitle)
        Me.grpName.Controls.Add(Me.txtLName)
        Me.grpName.Controls.Add(Me.txtMName)
        Me.grpName.Controls.Add(Me.txtFName)
        Me.grpName.Controls.Add(Me.txtEmpNum)
        Me.grpName.Controls.Add(Me.lblTitle)
        Me.grpName.Controls.Add(Me.Label5)
        Me.grpName.Controls.Add(Me.lblMN)
        Me.grpName.Controls.Add(Me.lblFN)
        Me.grpName.Controls.Add(Me.lblEmployeeID)
        Me.grpName.Location = New System.Drawing.Point(3, 17)
        Me.grpName.Name = "grpName"
        Me.grpName.Size = New System.Drawing.Size(716, 53)
        Me.grpName.TabIndex = 0
        Me.grpName.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Maroon
        Me.Label3.Location = New System.Drawing.Point(595, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Department"
        '
        'cboDepartment
        '
        Me.cboDepartment.Enabled = False
        Me.cboDepartment.FormattingEnabled = True
        Me.cboDepartment.Location = New System.Drawing.Point(591, 26)
        Me.cboDepartment.Name = "cboDepartment"
        Me.cboDepartment.Size = New System.Drawing.Size(114, 21)
        Me.cboDepartment.TabIndex = 6
        '
        'cboTitle
        '
        Me.cboTitle.FormattingEnabled = True
        Me.cboTitle.Location = New System.Drawing.Point(458, 26)
        Me.cboTitle.Name = "cboTitle"
        Me.cboTitle.Size = New System.Drawing.Size(121, 21)
        Me.cboTitle.TabIndex = 3
        '
        'txtLName
        '
        Me.txtLName.Location = New System.Drawing.Point(346, 26)
        Me.txtLName.Name = "txtLName"
        Me.txtLName.Size = New System.Drawing.Size(100, 20)
        Me.txtLName.TabIndex = 2
        '
        'txtMName
        '
        Me.txtMName.Location = New System.Drawing.Point(234, 25)
        Me.txtMName.Name = "txtMName"
        Me.txtMName.Size = New System.Drawing.Size(100, 20)
        Me.txtMName.TabIndex = 1
        '
        'txtFName
        '
        Me.txtFName.Location = New System.Drawing.Point(122, 25)
        Me.txtFName.Name = "txtFName"
        Me.txtFName.Size = New System.Drawing.Size(100, 20)
        Me.txtFName.TabIndex = 0
        '
        'txtEmpNum
        '
        Me.txtEmpNum.BackColor = System.Drawing.Color.Maroon
        Me.txtEmpNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpNum.Location = New System.Drawing.Point(10, 26)
        Me.txtEmpNum.Name = "txtEmpNum"
        Me.txtEmpNum.ReadOnly = True
        Me.txtEmpNum.Size = New System.Drawing.Size(100, 20)
        Me.txtEmpNum.TabIndex = 5
        Me.txtEmpNum.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.Maroon
        Me.lblTitle.Location = New System.Drawing.Point(462, 12)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(32, 13)
        Me.lblTitle.TabIndex = 4
        Me.lblTitle.Text = "Title"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Maroon
        Me.Label5.Location = New System.Drawing.Point(347, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(82, 15)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = " Last Name    "
        '
        'lblMN
        '
        Me.lblMN.AutoSize = True
        Me.lblMN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMN.ForeColor = System.Drawing.Color.Maroon
        Me.lblMN.Location = New System.Drawing.Point(242, 8)
        Me.lblMN.Name = "lblMN"
        Me.lblMN.Size = New System.Drawing.Size(45, 15)
        Me.lblMN.TabIndex = 2
        Me.lblMN.Text = "Middle"
        '
        'lblFN
        '
        Me.lblFN.AutoSize = True
        Me.lblFN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFN.ForeColor = System.Drawing.Color.Maroon
        Me.lblFN.Location = New System.Drawing.Point(136, 8)
        Me.lblFN.Name = "lblFN"
        Me.lblFN.Size = New System.Drawing.Size(70, 15)
        Me.lblFN.TabIndex = 1
        Me.lblFN.Text = "First Name "
        '
        'lblEmployeeID
        '
        Me.lblEmployeeID.AutoSize = True
        Me.lblEmployeeID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmployeeID.ForeColor = System.Drawing.Color.Maroon
        Me.lblEmployeeID.Location = New System.Drawing.Point(9, 8)
        Me.lblEmployeeID.Name = "lblEmployeeID"
        Me.lblEmployeeID.Size = New System.Drawing.Size(92, 15)
        Me.lblEmployeeID.TabIndex = 0
        Me.lblEmployeeID.Text = "Employee Num"
        '
        'grpButtons
        '
        Me.grpButtons.Controls.Add(Me.BtnClose)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.grpButtons.Location = New System.Drawing.Point(3, 469)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(722, 48)
        Me.grpButtons.TabIndex = 81
        Me.grpButtons.TabStop = False
        '
        'BtnClose
        '
        Me.BtnClose.AlternativeGroup = Nothing
        Me.BtnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnClose.BackColor = System.Drawing.Color.Orange
        Me.BtnClose.BackColor1 = System.Drawing.Color.White
        Me.BtnClose.BackColor2 = System.Drawing.Color.Orange
        Me.BtnClose.BorderHover = True
        Me.BtnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.BtnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.BtnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.BtnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.BtnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.BtnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnClose.DrawBorder = True
        Me.BtnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.BtnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.BtnClose.ForeColor = System.Drawing.Color.Navy
        Me.BtnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.BtnClose.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.BtnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnClose.Location = New System.Drawing.Point(606, 14)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.SelectedColor1 = System.Drawing.Color.Khaki
        Me.BtnClose.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.BtnClose.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnClose.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.BtnClose.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.BtnClose.SelectedText = Nothing
        Me.BtnClose.Size = New System.Drawing.Size(105, 28)
        Me.BtnClose.TabIndex = 41
        Me.BtnClose.Text = "C l o s e"
        Me.BtnClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnSave.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.Location = New System.Drawing.Point(11, 13)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(105, 28)
        Me.btnSave.TabIndex = 17
        Me.btnSave.Text = "Edit"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCancel.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.Location = New System.Drawing.Point(122, 13)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(105, 28)
        Me.btnCancel.TabIndex = 40
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNew.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.Location = New System.Drawing.Point(11, 13)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(105, 28)
        Me.btnNew.TabIndex = 42
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'tbEmployeeList
        '
        Me.tbEmployeeList.BackColor = System.Drawing.SystemColors.Control
        Me.tbEmployeeList.Controls.Add(Me.grpShowHideColumns)
        Me.tbEmployeeList.Controls.Add(Me.btnShowCol)
        Me.tbEmployeeList.Controls.Add(Me.GroupBox1)
        Me.tbEmployeeList.Controls.Add(Me.grpFilter)
        Me.tbEmployeeList.Controls.Add(Me.grdEmployeeList)
        Me.tbEmployeeList.Location = New System.Drawing.Point(4, 25)
        Me.tbEmployeeList.Name = "tbEmployeeList"
        Me.tbEmployeeList.Padding = New System.Windows.Forms.Padding(3)
        Me.tbEmployeeList.Size = New System.Drawing.Size(728, 520)
        Me.tbEmployeeList.TabIndex = 0
        Me.tbEmployeeList.Text = "Employee List"
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(45, 54)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 266)
        Me.grpShowHideColumns.TabIndex = 159
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 237)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 214)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(7, 57)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 158
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox1.Controls.Add(Me.btnNewEmp)
        Me.GroupBox1.Controls.Add(Me.btnCloseList)
        Me.GroupBox1.Controls.Add(Me.btnEdit)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.GroupBox1.Location = New System.Drawing.Point(3, 472)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(722, 45)
        Me.GroupBox1.TabIndex = 82
        Me.GroupBox1.TabStop = False
        '
        'btnNewEmp
        '
        Me.btnNewEmp.AlternativeGroup = Nothing
        Me.btnNewEmp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNewEmp.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNewEmp.BackColor1 = System.Drawing.Color.White
        Me.btnNewEmp.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNewEmp.BorderHover = True
        Me.btnNewEmp.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNewEmp.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNewEmp.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNewEmp.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNewEmp.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNewEmp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNewEmp.DrawBorder = True
        Me.btnNewEmp.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNewEmp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnNewEmp.ForeColor = System.Drawing.Color.Navy
        Me.btnNewEmp.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNewEmp.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNewEmp.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewEmp.Location = New System.Drawing.Point(11, 10)
        Me.btnNewEmp.Name = "btnNewEmp"
        Me.btnNewEmp.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNewEmp.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNewEmp.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewEmp.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNewEmp.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNewEmp.SelectedText = Nothing
        Me.btnNewEmp.Size = New System.Drawing.Size(105, 28)
        Me.btnNewEmp.TabIndex = 42
        Me.btnNewEmp.Text = "N e w"
        Me.btnNewEmp.UseVisualStyleBackColor = False
        '
        'btnCloseList
        '
        Me.btnCloseList.AlternativeGroup = Nothing
        Me.btnCloseList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCloseList.BackColor = System.Drawing.Color.Orange
        Me.btnCloseList.BackColor1 = System.Drawing.Color.White
        Me.btnCloseList.BackColor2 = System.Drawing.Color.Orange
        Me.btnCloseList.BorderHover = True
        Me.btnCloseList.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCloseList.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCloseList.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnCloseList.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCloseList.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCloseList.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCloseList.DrawBorder = True
        Me.btnCloseList.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCloseList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnCloseList.ForeColor = System.Drawing.Color.Navy
        Me.btnCloseList.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnCloseList.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnCloseList.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCloseList.Location = New System.Drawing.Point(606, 11)
        Me.btnCloseList.Name = "btnCloseList"
        Me.btnCloseList.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnCloseList.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnCloseList.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCloseList.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnCloseList.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnCloseList.SelectedText = Nothing
        Me.btnCloseList.Size = New System.Drawing.Size(105, 28)
        Me.btnCloseList.TabIndex = 41
        Me.btnCloseList.Text = "C l o s e"
        Me.btnCloseList.UseVisualStyleBackColor = False
        '
        'btnEdit
        '
        Me.btnEdit.AlternativeGroup = Nothing
        Me.btnEdit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnEdit.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BackColor1 = System.Drawing.Color.White
        Me.btnEdit.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEdit.BorderHover = True
        Me.btnEdit.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEdit.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEdit.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnEdit.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEdit.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEdit.DrawBorder = True
        Me.btnEdit.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnEdit.ForeColor = System.Drawing.Color.Navy
        Me.btnEdit.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnEdit.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnEdit.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEdit.Location = New System.Drawing.Point(131, 11)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnEdit.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnEdit.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEdit.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnEdit.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnEdit.SelectedText = Nothing
        Me.btnEdit.Size = New System.Drawing.Size(105, 28)
        Me.btnEdit.TabIndex = 17
        Me.btnEdit.Text = "E d i t"
        Me.btnEdit.UseVisualStyleBackColor = False
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.txtFilByLName)
        Me.grpFilter.Controls.Add(Me.lblLName)
        Me.grpFilter.Controls.Add(Me.txtFiltByMName)
        Me.grpFilter.Controls.Add(Me.lblMName)
        Me.grpFilter.Controls.Add(Me.txtFiltByFName)
        Me.grpFilter.Controls.Add(Me.Label1)
        Me.grpFilter.Controls.Add(Me.txtFiltByNum)
        Me.grpFilter.Controls.Add(Me.lblEmployeeNum)
        Me.grpFilter.Location = New System.Drawing.Point(3, 3)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(720, 45)
        Me.grpFilter.TabIndex = 1
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Filter By"
        '
        'txtFilByLName
        '
        Me.txtFilByLName.Location = New System.Drawing.Point(577, 13)
        Me.txtFilByLName.Name = "txtFilByLName"
        Me.txtFilByLName.Size = New System.Drawing.Size(137, 20)
        Me.txtFilByLName.TabIndex = 8
        '
        'lblLName
        '
        Me.lblLName.AutoSize = True
        Me.lblLName.ForeColor = System.Drawing.Color.Maroon
        Me.lblLName.Location = New System.Drawing.Point(533, 17)
        Me.lblLName.Name = "lblLName"
        Me.lblLName.Size = New System.Drawing.Size(39, 13)
        Me.lblLName.TabIndex = 7
        Me.lblLName.Text = "LName"
        '
        'txtFiltByMName
        '
        Me.txtFiltByMName.Location = New System.Drawing.Point(376, 13)
        Me.txtFiltByMName.Name = "txtFiltByMName"
        Me.txtFiltByMName.Size = New System.Drawing.Size(153, 20)
        Me.txtFiltByMName.TabIndex = 6
        '
        'lblMName
        '
        Me.lblMName.AutoSize = True
        Me.lblMName.ForeColor = System.Drawing.Color.Maroon
        Me.lblMName.Location = New System.Drawing.Point(325, 17)
        Me.lblMName.Name = "lblMName"
        Me.lblMName.Size = New System.Drawing.Size(42, 13)
        Me.lblMName.TabIndex = 5
        Me.lblMName.Text = "MName"
        '
        'txtFiltByFName
        '
        Me.txtFiltByFName.AcceptsReturn = True
        Me.txtFiltByFName.Location = New System.Drawing.Point(188, 13)
        Me.txtFiltByFName.Name = "txtFiltByFName"
        Me.txtFiltByFName.Size = New System.Drawing.Size(137, 20)
        Me.txtFiltByFName.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Maroon
        Me.Label1.Location = New System.Drawing.Point(150, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "FName"
        '
        'txtFiltByNum
        '
        Me.txtFiltByNum.Location = New System.Drawing.Point(73, 13)
        Me.txtFiltByNum.Name = "txtFiltByNum"
        Me.txtFiltByNum.Size = New System.Drawing.Size(74, 20)
        Me.txtFiltByNum.TabIndex = 1
        '
        'lblEmployeeNum
        '
        Me.lblEmployeeNum.AutoSize = True
        Me.lblEmployeeNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblEmployeeNum.Location = New System.Drawing.Point(3, 18)
        Me.lblEmployeeNum.Name = "lblEmployeeNum"
        Me.lblEmployeeNum.Size = New System.Drawing.Size(64, 13)
        Me.lblEmployeeNum.TabIndex = 0
        Me.lblEmployeeNum.Text = "Employee #"
        '
        'grdEmployeeList
        '
        Me.grdEmployeeList.AllowUserToAddRows = False
        Me.grdEmployeeList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdEmployeeList.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdEmployeeList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdEmployeeList.Location = New System.Drawing.Point(5, 53)
        Me.grdEmployeeList.Name = "grdEmployeeList"
        Me.grdEmployeeList.ReadOnly = True
        Me.grdEmployeeList.Size = New System.Drawing.Size(727, 409)
        Me.grdEmployeeList.TabIndex = 0
        '
        'tbEmployee
        '
        Me.tbEmployee.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbEmployee.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tbEmployee.Controls.Add(Me.tbEmployeeList)
        Me.tbEmployee.Controls.Add(Me.tbNewEmployee)
        Me.tbEmployee.Location = New System.Drawing.Point(0, 47)
        Me.tbEmployee.Name = "tbEmployee"
        Me.tbEmployee.SelectedIndex = 0
        Me.tbEmployee.Size = New System.Drawing.Size(736, 549)
        Me.tbEmployee.TabIndex = 343
        '
        'lblFormTitleLine
        '
        Me.lblFormTitleLine.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblFormTitleLine.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblFormTitleLine.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lblFormTitleLine.Location = New System.Drawing.Point(0, 40)
        Me.lblFormTitleLine.Name = "lblFormTitleLine"
        Me.lblFormTitleLine.Size = New System.Drawing.Size(736, 3)
        Me.lblFormTitleLine.TabIndex = 393
        '
        'lblFormTitle
        '
        Me.lblFormTitle.AutoEllipsis = True
        Me.lblFormTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblFormTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblFormTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.Black
        Me.lblFormTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(736, 40)
        Me.lblFormTitle.TabIndex = 392
        Me.lblFormTitle.Text = " Employee"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmEmployeeV1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(736, 592)
        Me.Controls.Add(Me.lblFormTitleLine)
        Me.Controls.Add(Me.lblFormTitle)
        Me.Controls.Add(Me.tbEmployee)
        Me.Controls.Add(Me.txtAcctName)
        Me.Controls.Add(Me.txtEmpID)
        Me.Name = "frmEmployeeV1"
        Me.Text = "Employee"
        Me.tbNewEmployee.ResumeLayout(False)
        Me.grpEmployee.ResumeLayout(False)
        Me.grpEmployee.PerformLayout()
        Me.tcAddress.ResumeLayout(False)
        Me.tpViewAddress.ResumeLayout(False)
        Me.grpShowHideColumnsAdd.ResumeLayout(False)
        CType(Me.grdViewAddress, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpNewAddress.ResumeLayout(False)
        Me.tpNewAddress.PerformLayout()
        Me.grpLogInInfo.ResumeLayout(False)
        Me.grpLogInInfo.PerformLayout()
        Me.grpContactInfo.ResumeLayout(False)
        Me.grpContactInfo.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.grpInfo.ResumeLayout(False)
        Me.grpInfo.PerformLayout()
        Me.grpName.ResumeLayout(False)
        Me.grpName.PerformLayout()
        Me.grpButtons.ResumeLayout(False)
        Me.tbEmployeeList.ResumeLayout(False)
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        CType(Me.grdEmployeeList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbEmployee.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
   Friend WithEvents txtAcctName As System.Windows.Forms.TextBox
   Friend WithEvents CheckedListBox1 As System.Windows.Forms.CheckedListBox
	Friend WithEvents Button1 As System.Windows.Forms.Button
   Friend WithEvents txtEmpID As System.Windows.Forms.TextBox
   Friend WithEvents tbNewEmployee As System.Windows.Forms.TabPage
   Friend WithEvents grpEmployee As System.Windows.Forms.GroupBox
   Friend WithEvents lblJobGrade As System.Windows.Forms.Label
   Friend WithEvents cboJobGrade As System.Windows.Forms.ComboBox
   Friend WithEvents cboEmployeeType As System.Windows.Forms.ComboBox
   Friend WithEvents lblEmployeeType As System.Windows.Forms.Label
   Friend WithEvents tcAddress As System.Windows.Forms.TabControl
   Friend WithEvents tpViewAddress As System.Windows.Forms.TabPage
   Friend WithEvents grpShowHideColumnsAdd As System.Windows.Forms.GroupBox
   Friend WithEvents btnSaveSettingAdd As System.Windows.Forms.Button
   Friend WithEvents chkLstGridColAdd As System.Windows.Forms.CheckedListBox
   Friend WithEvents btnShowColAddress As System.Windows.Forms.Button
   Friend WithEvents btnEditAddress As System.Windows.Forms.Button
   Friend WithEvents btnDeleteAddress As System.Windows.Forms.Button
   Friend WithEvents btnNewAddress As System.Windows.Forms.Button
   Friend WithEvents grdViewAddress As System.Windows.Forms.DataGridView
   Friend WithEvents tpNewAddress As System.Windows.Forms.TabPage
   Friend WithEvents txtAddID As System.Windows.Forms.TextBox
   Friend WithEvents btnSaveAddress As System.Windows.Forms.Button
   Friend WithEvents btnCancelAddress As System.Windows.Forms.Button
   Friend WithEvents btnNewAddress2 As System.Windows.Forms.Button
   Friend WithEvents lblAddType As System.Windows.Forms.Label
   Friend WithEvents lblStreet As System.Windows.Forms.Label
   Friend WithEvents lblCity As System.Windows.Forms.Label
   Friend WithEvents lblArea As System.Windows.Forms.Label
   Friend WithEvents lblState As System.Windows.Forms.Label
   Friend WithEvents lblAddID As System.Windows.Forms.Label
   Friend WithEvents cboState As System.Windows.Forms.ComboBox
   Friend WithEvents cboAddType As System.Windows.Forms.ComboBox
   Friend WithEvents CboCity As System.Windows.Forms.ComboBox
   Friend WithEvents cboArea As System.Windows.Forms.ComboBox
   Friend WithEvents CboStreet As System.Windows.Forms.ComboBox
   Friend WithEvents lblBNF As System.Windows.Forms.Label
   Friend WithEvents txtBNF As System.Windows.Forms.TextBox
   Friend WithEvents grpLogInInfo As System.Windows.Forms.GroupBox
   Friend WithEvents lblUserLevel As System.Windows.Forms.Label
   Friend WithEvents lblPassword As System.Windows.Forms.Label
   Friend WithEvents lblUserName As System.Windows.Forms.Label
   Friend WithEvents cboUserLevel As System.Windows.Forms.ComboBox
   Friend WithEvents txtPassword As System.Windows.Forms.TextBox
   Friend WithEvents txtUserName As System.Windows.Forms.TextBox
   Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
   Friend WithEvents btnDataErr As System.Windows.Forms.Button
   Friend WithEvents grpContactInfo As System.Windows.Forms.GroupBox
   Friend WithEvents TxtCel As System.Windows.Forms.TextBox
   Friend WithEvents lblCel As System.Windows.Forms.Label
   Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
   Friend WithEvents Button2 As System.Windows.Forms.Button
   Friend WithEvents CheckedListBox2 As System.Windows.Forms.CheckedListBox
   Friend WithEvents lblTel As System.Windows.Forms.Label
   Friend WithEvents Button3 As System.Windows.Forms.Button
   Friend WithEvents lblEMail As System.Windows.Forms.Label
   Friend WithEvents txtTel As System.Windows.Forms.TextBox
   Friend WithEvents txtEmail As System.Windows.Forms.TextBox
   Friend WithEvents grpInfo As System.Windows.Forms.GroupBox
   Friend WithEvents cboCurrency As System.Windows.Forms.ComboBox
   Friend WithEvents lblCurrency As System.Windows.Forms.Label
   Friend WithEvents dtpEndDate As System.Windows.Forms.DateTimePicker
   Friend WithEvents dtpStartDate As System.Windows.Forms.DateTimePicker
   Friend WithEvents dtpDOB As System.Windows.Forms.DateTimePicker
   Friend WithEvents txtSalary As System.Windows.Forms.TextBox
   Friend WithEvents lblEDate As System.Windows.Forms.Label
   Friend WithEvents lblSDate As System.Windows.Forms.Label
   Friend WithEvents txtHours As System.Windows.Forms.TextBox
   Friend WithEvents lblHours As System.Windows.Forms.Label
   Friend WithEvents lblPeriod As System.Windows.Forms.Label
   Friend WithEvents cboPOB As System.Windows.Forms.ComboBox
   Friend WithEvents cboPeriod As System.Windows.Forms.ComboBox
   Friend WithEvents lblPOB As System.Windows.Forms.Label
   Friend WithEvents lblSalary As System.Windows.Forms.Label
   Friend WithEvents lblDOB As System.Windows.Forms.Label
   Friend WithEvents grpName As System.Windows.Forms.GroupBox
   Friend WithEvents Label3 As System.Windows.Forms.Label
   Friend WithEvents cboDepartment As System.Windows.Forms.ComboBox
   Friend WithEvents cboTitle As System.Windows.Forms.ComboBox
   Friend WithEvents txtLName As System.Windows.Forms.TextBox
   Friend WithEvents txtMName As System.Windows.Forms.TextBox
   Friend WithEvents txtFName As System.Windows.Forms.TextBox
   Friend WithEvents txtEmpNum As System.Windows.Forms.TextBox
   Friend WithEvents lblTitle As System.Windows.Forms.Label
   Friend WithEvents Label5 As System.Windows.Forms.Label
   Friend WithEvents lblMN As System.Windows.Forms.Label
   Friend WithEvents lblFN As System.Windows.Forms.Label
   Friend WithEvents lblEmployeeID As System.Windows.Forms.Label
   Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
   Friend WithEvents BtnClose As BHBut.BouncingHoverButton
   Friend WithEvents btnSave As BHBut.BouncingHoverButton
   Friend WithEvents btnCancel As BHBut.BouncingHoverButton
   Friend WithEvents btnNew As BHBut.BouncingHoverButton
   Friend WithEvents tbEmployeeList As System.Windows.Forms.TabPage
   Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
   Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
   Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
   Friend WithEvents btnShowCol As System.Windows.Forms.Button
   Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
   Friend WithEvents btnNewEmp As BHBut.BouncingHoverButton
   Friend WithEvents btnCloseList As BHBut.BouncingHoverButton
   Friend WithEvents btnEdit As BHBut.BouncingHoverButton
   Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
   Friend WithEvents txtFilByLName As System.Windows.Forms.TextBox
   Friend WithEvents lblLName As System.Windows.Forms.Label
   Friend WithEvents txtFiltByMName As System.Windows.Forms.TextBox
   Friend WithEvents lblMName As System.Windows.Forms.Label
   Friend WithEvents txtFiltByFName As System.Windows.Forms.TextBox
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents txtFiltByNum As System.Windows.Forms.TextBox
   Friend WithEvents lblEmployeeNum As System.Windows.Forms.Label
   Friend WithEvents grdEmployeeList As System.Windows.Forms.DataGridView
   Friend WithEvents tbEmployee As System.Windows.Forms.TabControl
   Friend WithEvents lblFormTitleLine As System.Windows.Forms.Panel
   Friend WithEvents lblFormTitle As System.Windows.Forms.Label
End Class
