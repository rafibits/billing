<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOverFlightTransactionPreparation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOverFlightTransactionPreparation))
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.grpFilter = New System.Windows.Forms.GroupBox
        Me.lblInvoiceNum = New System.Windows.Forms.Label
        Me.txtInvoiceNum = New System.Windows.Forms.TextBox
        Me.chkInvoiced = New System.Windows.Forms.CheckBox
        Me.dtpDateTo = New System.Windows.Forms.DateTimePicker
        Me.lblDateFrom = New System.Windows.Forms.Label
        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker
        Me.lblDateTo = New System.Windows.Forms.Label
        Me.lblClient = New System.Windows.Forms.Label
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.grdOverFlightList = New System.Windows.Forms.DataGridView
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnPrint = New BHBut.BouncingHoverButton
        Me.btnUpdatePrice = New BHBut.BouncingHoverButton
        Me.btnAutoGenerateInvoice = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.btnRefresh = New System.Windows.Forms.Button
        Me.lblNbDocuments = New System.Windows.Forms.Label
        Me.txtCount = New System.Windows.Forms.TextBox
        Me.grpFilter.SuspendLayout()
        CType(Me.grdOverFlightList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpShowHideColumns.SuspendLayout()
        Me.grpButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(918, 40)
        Me.lblfrmTitle.TabIndex = 351
        Me.lblfrmTitle.Text = "Over Flight Preparations"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(918, 3)
        Me.pnlTitle.TabIndex = 352
        '
        'grpFilter
        '
        Me.grpFilter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFilter.BackColor = System.Drawing.Color.LightYellow
        Me.grpFilter.Controls.Add(Me.lblInvoiceNum)
        Me.grpFilter.Controls.Add(Me.txtInvoiceNum)
        Me.grpFilter.Controls.Add(Me.chkInvoiced)
        Me.grpFilter.Controls.Add(Me.dtpDateTo)
        Me.grpFilter.Controls.Add(Me.lblDateFrom)
        Me.grpFilter.Controls.Add(Me.dtpDateFrom)
        Me.grpFilter.Controls.Add(Me.lblDateTo)
        Me.grpFilter.Controls.Add(Me.lblClient)
        Me.grpFilter.Controls.Add(Me.cboClient)
        Me.grpFilter.ForeColor = System.Drawing.Color.LightSteelBlue
        Me.grpFilter.Location = New System.Drawing.Point(3, 43)
        Me.grpFilter.Name = "grpFilter"
        Me.grpFilter.Size = New System.Drawing.Size(912, 46)
        Me.grpFilter.TabIndex = 353
        Me.grpFilter.TabStop = False
        Me.grpFilter.Text = "Data Filter"
        '
        'lblInvoiceNum
        '
        Me.lblInvoiceNum.AutoSize = True
        Me.lblInvoiceNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblInvoiceNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblInvoiceNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInvoiceNum.Location = New System.Drawing.Point(588, 20)
        Me.lblInvoiceNum.Name = "lblInvoiceNum"
        Me.lblInvoiceNum.Size = New System.Drawing.Size(52, 13)
        Me.lblInvoiceNum.TabIndex = 373
        Me.lblInvoiceNum.Text = "Invoice #"
        Me.lblInvoiceNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtInvoiceNum
        '
        Me.txtInvoiceNum.ForeColor = System.Drawing.Color.Navy
        Me.txtInvoiceNum.Location = New System.Drawing.Point(646, 16)
        Me.txtInvoiceNum.Name = "txtInvoiceNum"
        Me.txtInvoiceNum.Size = New System.Drawing.Size(89, 20)
        Me.txtInvoiceNum.TabIndex = 374
        Me.txtInvoiceNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkInvoiced
        '
        Me.chkInvoiced.AutoSize = True
        Me.chkInvoiced.CausesValidation = False
        Me.chkInvoiced.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkInvoiced.ForeColor = System.Drawing.Color.Red
        Me.chkInvoiced.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkInvoiced.Location = New System.Drawing.Point(754, 18)
        Me.chkInvoiced.Name = "chkInvoiced"
        Me.chkInvoiced.Size = New System.Drawing.Size(75, 17)
        Me.chkInvoiced.TabIndex = 372
        Me.chkInvoiced.Text = "Invoiced"
        '
        'dtpDateTo
        '
        Me.dtpDateTo.CustomFormat = "dd MMM yyyy"
        Me.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateTo.Location = New System.Drawing.Point(490, 16)
        Me.dtpDateTo.Name = "dtpDateTo"
        Me.dtpDateTo.Size = New System.Drawing.Size(92, 20)
        Me.dtpDateTo.TabIndex = 16
        '
        'lblDateFrom
        '
        Me.lblDateFrom.AutoSize = True
        Me.lblDateFrom.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateFrom.Location = New System.Drawing.Point(304, 20)
        Me.lblDateFrom.Name = "lblDateFrom"
        Me.lblDateFrom.Size = New System.Drawing.Size(57, 13)
        Me.lblDateFrom.TabIndex = 15
        Me.lblDateFrom.Text = "Date From"
        Me.lblDateFrom.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpDateFrom
        '
        Me.dtpDateFrom.CustomFormat = "dd MMM yyyy"
        Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateFrom.Location = New System.Drawing.Point(367, 16)
        Me.dtpDateFrom.Name = "dtpDateFrom"
        Me.dtpDateFrom.Size = New System.Drawing.Size(92, 20)
        Me.dtpDateFrom.TabIndex = 14
        '
        'lblDateTo
        '
        Me.lblDateTo.AutoSize = True
        Me.lblDateTo.ForeColor = System.Drawing.Color.Maroon
        Me.lblDateTo.Location = New System.Drawing.Point(465, 20)
        Me.lblDateTo.Name = "lblDateTo"
        Me.lblDateTo.Size = New System.Drawing.Size(19, 13)
        Me.lblDateTo.TabIndex = 7
        Me.lblDateTo.Text = "To"
        Me.lblDateTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblClient
        '
        Me.lblClient.AutoSize = True
        Me.lblClient.ForeColor = System.Drawing.Color.Maroon
        Me.lblClient.Location = New System.Drawing.Point(2, 20)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(34, 13)
        Me.lblClient.TabIndex = 5
        Me.lblClient.Text = "Client"
        Me.lblClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboClient
        '
        Me.cboClient.ForeColor = System.Drawing.Color.Maroon
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(42, 16)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(256, 21)
        Me.cboClient.TabIndex = 2
        '
        'grdOverFlightList
        '
        Me.grdOverFlightList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdOverFlightList.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdOverFlightList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdOverFlightList.Location = New System.Drawing.Point(5, 96)
        Me.grdOverFlightList.Name = "grdOverFlightList"
        Me.grdOverFlightList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdOverFlightList.Size = New System.Drawing.Size(907, 272)
        Me.grdOverFlightList.TabIndex = 354
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(47, 99)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 178)
        Me.grpShowHideColumns.TabIndex = 355
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 149)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 124)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnPrint)
        Me.grpButtons.Controls.Add(Me.btnUpdatePrice)
        Me.grpButtons.Controls.Add(Me.btnAutoGenerateInvoice)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Location = New System.Drawing.Point(8, 398)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(904, 47)
        Me.grpButtons.TabIndex = 357
        Me.grpButtons.TabStop = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.Enabled = False
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(105, 12)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(94, 27)
        Me.btnSave.TabIndex = 170
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnPrint
        '
        Me.btnPrint.AlternativeGroup = Nothing
        Me.btnPrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPrint.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPrint.BackColor1 = System.Drawing.Color.White
        Me.btnPrint.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPrint.BorderHover = True
        Me.btnPrint.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPrint.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPrint.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPrint.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPrint.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPrint.DrawBorder = True
        Me.btnPrint.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPrint.ForeColor = System.Drawing.Color.Navy
        Me.btnPrint.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.HoverColor2 = System.Drawing.Color.White
        Me.btnPrint.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPrint.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPrint.Location = New System.Drawing.Point(205, 12)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPrint.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPrint.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPrint.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPrint.SelectedText = Nothing
        Me.btnPrint.Size = New System.Drawing.Size(94, 27)
        Me.btnPrint.TabIndex = 168
        Me.btnPrint.Text = "Preview"
        Me.btnPrint.UseVisualStyleBackColor = False
        '
        'btnUpdatePrice
        '
        Me.btnUpdatePrice.AlternativeGroup = Nothing
        Me.btnUpdatePrice.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnUpdatePrice.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnUpdatePrice.BackColor1 = System.Drawing.Color.White
        Me.btnUpdatePrice.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnUpdatePrice.BorderHover = True
        Me.btnUpdatePrice.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnUpdatePrice.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnUpdatePrice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnUpdatePrice.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnUpdatePrice.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnUpdatePrice.DrawBorder = True
        Me.btnUpdatePrice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnUpdatePrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnUpdatePrice.ForeColor = System.Drawing.Color.Navy
        Me.btnUpdatePrice.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnUpdatePrice.HoverColor2 = System.Drawing.Color.White
        Me.btnUpdatePrice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnUpdatePrice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnUpdatePrice.Location = New System.Drawing.Point(6, 12)
        Me.btnUpdatePrice.Name = "btnUpdatePrice"
        Me.btnUpdatePrice.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnUpdatePrice.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnUpdatePrice.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnUpdatePrice.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnUpdatePrice.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnUpdatePrice.SelectedText = Nothing
        Me.btnUpdatePrice.Size = New System.Drawing.Size(94, 27)
        Me.btnUpdatePrice.TabIndex = 166
        Me.btnUpdatePrice.Text = "Update Price"
        Me.btnUpdatePrice.UseVisualStyleBackColor = False
        '
        'btnAutoGenerateInvoice
        '
        Me.btnAutoGenerateInvoice.AlternativeGroup = Nothing
        Me.btnAutoGenerateInvoice.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnAutoGenerateInvoice.BackColor = System.Drawing.Color.Red
        Me.btnAutoGenerateInvoice.BackColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.BackColor2 = System.Drawing.Color.Red
        Me.btnAutoGenerateInvoice.BorderHover = True
        Me.btnAutoGenerateInvoice.BorderHoverColor = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnAutoGenerateInvoice.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnAutoGenerateInvoice.ClickColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnAutoGenerateInvoice.DrawBorder = True
        Me.btnAutoGenerateInvoice.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnAutoGenerateInvoice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAutoGenerateInvoice.ForeColor = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.HoverColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.HoverColor2 = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnAutoGenerateInvoice.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnAutoGenerateInvoice.Location = New System.Drawing.Point(305, 12)
        Me.btnAutoGenerateInvoice.Name = "btnAutoGenerateInvoice"
        Me.btnAutoGenerateInvoice.SelectedColor1 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnAutoGenerateInvoice.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnAutoGenerateInvoice.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnAutoGenerateInvoice.SelectedHoverColor2 = System.Drawing.Color.Maroon
        Me.btnAutoGenerateInvoice.SelectedText = Nothing
        Me.btnAutoGenerateInvoice.Size = New System.Drawing.Size(249, 28)
        Me.btnAutoGenerateInvoice.TabIndex = 164
        Me.btnAutoGenerateInvoice.Text = "Generate Invoice for Above Selection"
        Me.btnAutoGenerateInvoice.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(779, 12)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(113, 27)
        Me.btnClose.TabIndex = 157
        Me.btnClose.Text = "C l o s e"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = CType(resources.GetObject("btnShowCol.BackgroundImage"), System.Drawing.Image)
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(10, 99)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 26)
        Me.btnShowCol.TabIndex = 356
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'btnRefresh
        '
        Me.btnRefresh.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRefresh.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnRefresh.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnRefresh.Location = New System.Drawing.Point(811, 12)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(95, 23)
        Me.btnRefresh.TabIndex = 317
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'lblNbDocuments
        '
        Me.lblNbDocuments.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblNbDocuments.BackColor = System.Drawing.Color.Maroon
        Me.lblNbDocuments.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNbDocuments.ForeColor = System.Drawing.Color.White
        Me.lblNbDocuments.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblNbDocuments.Location = New System.Drawing.Point(831, 374)
        Me.lblNbDocuments.Name = "lblNbDocuments"
        Me.lblNbDocuments.Size = New System.Drawing.Size(82, 23)
        Me.lblNbDocuments.TabIndex = 364
        Me.lblNbDocuments.Text = "Transaction(s)"
        Me.lblNbDocuments.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtCount
        '
        Me.txtCount.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtCount.BackColor = System.Drawing.Color.LightYellow
        Me.txtCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCount.ForeColor = System.Drawing.Color.Maroon
        Me.txtCount.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtCount.Location = New System.Drawing.Point(695, 374)
        Me.txtCount.Multiline = True
        Me.txtCount.Name = "txtCount"
        Me.txtCount.ReadOnly = True
        Me.txtCount.Size = New System.Drawing.Size(130, 23)
        Me.txtCount.TabIndex = 363
        Me.txtCount.TabStop = False
        Me.txtCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'frmOverFlightTransactionPreparation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(918, 457)
        Me.Controls.Add(Me.lblNbDocuments)
        Me.Controls.Add(Me.txtCount)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.grpShowHideColumns)
        Me.Controls.Add(Me.btnShowCol)
        Me.Controls.Add(Me.grdOverFlightList)
        Me.Controls.Add(Me.grpFilter)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.KeyPreview = True
        Me.Name = "frmOverFlightTransactionPreparation"
        Me.Text = "frmOverFlightTransactionPreparation"
        Me.grpFilter.ResumeLayout(False)
        Me.grpFilter.PerformLayout()
        CType(Me.grdOverFlightList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.grpButtons.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
   Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
   Friend WithEvents pnlTitle As System.Windows.Forms.Panel
   Friend WithEvents grpFilter As System.Windows.Forms.GroupBox
   Friend WithEvents dtpDateTo As System.Windows.Forms.DateTimePicker
   Friend WithEvents lblDateFrom As System.Windows.Forms.Label
   Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker
   Friend WithEvents lblDateTo As System.Windows.Forms.Label
   Friend WithEvents lblClient As System.Windows.Forms.Label
   Friend WithEvents cboClient As System.Windows.Forms.ComboBox
   Friend WithEvents grdOverFlightList As System.Windows.Forms.DataGridView
   Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
   Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
   Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
   Friend WithEvents btnShowCol As System.Windows.Forms.Button
   Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
   Friend WithEvents btnPrint As BHBut.BouncingHoverButton
   Friend WithEvents btnUpdatePrice As BHBut.BouncingHoverButton
    Friend WithEvents btnAutoGenerateInvoice As BHBut.BouncingHoverButton
   Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents btnSave As BHBut.BouncingHoverButton
	Friend WithEvents chkInvoiced As System.Windows.Forms.CheckBox
	Friend WithEvents lblInvoiceNum As System.Windows.Forms.Label
	Friend WithEvents txtInvoiceNum As System.Windows.Forms.TextBox
	Friend WithEvents btnRefresh As System.Windows.Forms.Button
	Friend WithEvents lblNbDocuments As System.Windows.Forms.Label
	Friend WithEvents txtCount As System.Windows.Forms.TextBox
End Class
