Imports BITSConn
Imports System.Data.SqlClient

Public Class frmBillList

#Region "Form-Declaration..."
    Private dsdata As DataSet
    Private clsMr As ClsMain
    Private daTafkeet As SqlDataAdapter
    Private blnLoading As Boolean
    Private mstrCurrentGridName As String
    Private mStrSubKeyName As String = "Software\BIT Solutions\BS\BillList\Settings"
    Public arrPay(1) As Integer
#End Region

#Region "Form-Load..."

    Private Sub frmBillList_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmBillList_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        clsMr = New ClsMain(conSql)
        ''
        blnLoading = True
        MakeDataAdapter()
        FillComboBox()

        blnLoading = False
        DrawGrid()
        ''set defaults
        cboClient.SelectedIndex = -1
        cboStatus.SelectedIndex = -1
        cboCategory.SelectedIndex = -1
        FilterGrid()
        lblCurrSymbol.Text = GetCompanyCurrencySymbol()
        lblCurrSymbol2.Text = GetCompanyCurrencySymbol2()
    End Sub

#End Region

#Region "Form-Initialisation..."

    Private Sub MakeDataAdapter()
        ''
        '' set SQL for selecting active emp recs...
        daTafkeet = clsMr.BuildSqlAdapter("SELECT * FROM tblTafkeet", "tblTafkeet")
        clsMr.BuildSqlAdapter("SELECT * FROM vwInvoiceList WHERE Del=0 AND CatID = 4", "vwInvoiceList")
        clsMr.BuildSqlAdapter("SELECT ClientID,ClientName  from tblClient WHERE Del =0  ORDER BY ClientName", "ClientName")
        clsMr.BuildSqlAdapter("SELECT CatID,CatType  FROM tblServiceCategory WHERE Del =0 AND CatID = 4 ", "tblServiceCategory")
        '	clsMr.BuildSqlAdapter("SELECT * FROM tblInvoice WHERE Del=0 AND InvoiceID=0", "tblInvoice")
        '	clsMr.BuildSqlAdapter("SELECT * FROM tblInvoiceDetail WHERE Del=0 AND InvoiceID=0", "tblInvoiceDetail")
        'clsMr.BuildSqlAdapter("SELECT *  from tblTrx WHERE Del =0  and trxid=-1", "tblTrx")
        dsdata = clsMr.getDataSet

    End Sub

    Private Sub FillComboBox()
        clsMr.FillComboBox("ClientName", cboClient, "ClientName", "ClientID")
        'clsMr.FillComboBox("tblVisitStatus", cboStatus, "status", "StatusID")
        clsMr.FillComboBox("tblServiceCategory", cboCategory, "CatType", "CatID")
    End Sub

    Private Sub SetDefaultValue()
        'clsMr.SetDefaults("tblInvoice", "CreateByID", gIntUserID, "CreateDate", Now.Date, "Del", 0, "StatusID", 1, "InvoiceDate", Now.Date, "InvoiceFrom", Now.Date, "InvoiceTo", Now.Date)
    End Sub

    Private Sub SetAutoNumber()
        'clsMr.SetAutoNumber("tblInvoice", "InvoiceID")
        'clsMr.SetAutoNumber("tblInvoice", "InvoiceNumber")
    End Sub

#End Region

#Region "Form-UI/Methods..."

    Private Sub btnPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreview.Click
        ''
        If grdInvoiceList.Rows.Count = 0 Then Exit Sub

        Dim frm As New frmQuickReport

        ClearTable()
        Windows.Forms.Cursor.Current = Cursors.WaitCursor()
        Dim rpt As New rptInvoice
        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table

        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo
        ''
        For Each tbCurrent In rpt.Database.Tables
            tliCurrent = tbCurrent.LogOnInfo
            ''
            With tliCurrent.ConnectionInfo
                .ServerName = gStrServerName
                .DatabaseName = gStrDataBaseName
                .UserID = "" 'gStrUserName
                .Password = ""  'gStrPassword
            End With

            tbCurrent.ApplyLogOnInfo(tliCurrent)
        Next tbCurrent
        'frm.crvInstantViewer.SelectionFormula = "{vwInvoiceRpt.ClientName}=" & cboClient.SelectedText
        rpt.SetParameterValue("CurrSybl1", GetCompanyCurrencySymbol())
        rpt.SetParameterValue("CurrSybl2", GetCompanyCurrencySymbol2())
        Dim dv As DataView = dsdata.Tables("vwInvoicelist").DefaultView
        Dim drv As DataRowView
        For Each drv In dv


            Dim dRdr As SqlClient.SqlDataReader
            Dim cmdX As SqlClient.SqlCommand

            ''
            Dim strUnitName As String
            Dim strPartUnitName As String
            Dim strSymbol As String
            Dim strUnitNameEn As String
            Dim strPartUnitNameEn As String
            Dim strSymbolEn As String
            ''
            strSQL = "select *   FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID
            ''
            'strSQL = "select *   FROM  dbo.tblCurrency INNER JOIN dbo.tblCompany ON dbo.tblCurrency.CurrID = dbo.tblCompany.CurrID WHERE dbo.tblCompany.companyID=  " & gIntCompanyCurrID
            ''
            cmdX = New SqlClient.SqlCommand(strSQL, conSql)
            cmdX.CommandType = CommandType.Text

            conSql.Open()
            dRdr = cmdX.ExecuteReader()
            If dRdr.Read Then
                strUnitName = dRdr("UnitName")
                strPartUnitName = dRdr("PartUnitName")
                strSymbol = dRdr("Symbol")
            End If
            dRdr.Close()
            conSql.Close()

            strSQL = "select *   FROM  dbo.tblCurrency WHERE CurrID=  " & gIntCompanyCurrID2
            ''
            cmdX = New SqlClient.SqlCommand(strSQL, conSql)
            cmdX.CommandType = CommandType.Text

            conSql.Open()
            dRdr = cmdX.ExecuteReader()
            If dRdr.Read Then
                strUnitNameEn = dRdr("UnitName")
                strPartUnitNameEn = dRdr("PartUnitName")
                strSymbolEn = dRdr("Symbol")
            End If
            dRdr.Close()
            conSql.Close()

            ''
            Dim strWord As String
            Dim strWordEn As String

            'strWord = ToWords(JobCards.Current()("Total"), strUnitName, strPartUnitName)
            'rpt.DataDefinition.FormulaFields.("TotalCurrSybl1", strWord)
            'rpt.DataDefinition.FormulaFields("TotalCurrSybl1", strWord)

            strWord = ToWords(drv("Total"), strUnitName, strPartUnitName)
            strWordEn = ToWordsEn(drv("TotalCurr2"), strUnitNameEn, strPartUnitNameEn)

            Dim drNew As DataRow = dsdata.Tables("tblTafkeet").NewRow
            drNew("Tafkeet") = strWord
            drNew("TafkeetEn") = strWordEn
            drNew("InvoiceID") = drv("InvoiceID")
            dsdata.Tables("tblTafkeet").Rows.Add(drNew)
            daTafkeet.Update(dsdata, "tblTafkeet")
            'rpt.SetParameterValue("Words", strWord)
        Next

        Dim strFilter As String = InvoiceFilterString()
        frm.crvInstantViewer.SelectionFormula = strFilter

        frm.crvInstantViewer.ReportSource = rpt
        frm.crvInstantViewer.Refresh()
        frm.Show()

        frm.crvInstantViewer.DisplayToolbar = True
        Windows.Forms.Cursor.Current = Cursors.Default()
    End Sub

    Private Sub chkCurrent_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        FilterGrid()

    End Sub

    Private Sub chkDue_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        FilterGrid()

    End Sub

    Private Sub chkPaid_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkPaid.Click
        FilterGrid()
    End Sub

    Private Sub chkOverDue30_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        FilterGrid()

    End Sub

    Private Sub chkOverDue60_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        FilterGrid()

    End Sub

    Private Sub chkOverDue90_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        FilterGrid()

    End Sub

    Private Sub chkOverDue120_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        FilterGrid()

    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        EditInvoice()
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        ''new invoice
        Windows.Forms.Cursor.Current = Cursors.WaitCursor

        Dim frm As New frmInvoice(-1, -1, 2)
        'frm.Show()
        appMain.addTabPage(frm, frmApplicationMain.eFormType.Invoice)

        AddHandler frm.Closed, AddressOf RefreshList

        Windows.Forms.Cursor.Current = Cursors.Default
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If grdInvoiceList.Rows.Count = 0 Then Exit Sub

        If MsgBox("Are you sure you want to delete?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub
        '' update invoiceDetail

        Dim cmd As New SqlCommand("UPDATE tblInvoiceDetail SET Del=1 WHERE InvoiceID=" & grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value, conSql)
        conSql.Open()
        cmd.ExecuteNonQuery()
        conSql.Close()

        ''update tblInvoice
        cmd.CommandText = "UPDATE tblInvoice SET Del=1 WHERE InvoiceID=" & grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value
        cmd.Connection = conSql
        conSql.Open()
        cmd.ExecuteNonQuery()
        conSql.Close()

        dsdata.Tables("vwInvoiceList").DefaultView(grdInvoiceList.CurrentRow.Index).Delete()
        SetStatus()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        If grdInvoiceList.Rows.Count <> 0 Then
            arrPay(0) = grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value
        End If

        Me.Close()
    End Sub

    Private Sub grdInvoiceList_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdInvoiceList.DoubleClick
        EditInvoice()
    End Sub

    Private Sub cboClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboClient.KeyPress
        AutoComplete(cboClient, e)
    End Sub

    Private Sub cboClient_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboClient.KeyUp
        FilterGrid()
    End Sub

    Private Sub cboClient_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClient.SelectedIndexChanged
        FilterGrid()
    End Sub

    Private Sub dtpDateFrom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateFrom.ValueChanged
        FilterGrid()
    End Sub

    Private Sub dtpDateTo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDateTo.ValueChanged
        FilterGrid()
    End Sub

    Private Sub txtInvoiceNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInvoiceNum.TextChanged
        FilterGrid()
    End Sub

    Private Sub CboType_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        FilterGrid()
    End Sub

    Private Sub CboType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FilterGrid()
    End Sub

    Private Sub chkNew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkNew.Click
        FilterGrid()
    End Sub

    Private Sub chkPosted_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkPosted.Click
        FilterGrid()
    End Sub

    Private Sub chkNotPosted_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkNotPosted.Click
        FilterGrid()
    End Sub

    Private Sub txtInvoiceType_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FilterGrid()
    End Sub

    Private Sub cboCategory_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboCategory.KeyPress
        AutoComplete(cboCategory, e)
    End Sub

    Private Sub cboCategory_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboCategory.KeyUp
        FilterGrid()
    End Sub

    Private Sub cboCategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCategory.SelectedIndexChanged
        FilterGrid()
    End Sub

    Private Sub btnAutoGenerateInvoice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAutoGenerateInvoice.Click
        'Dim frm As New frmClientGet()
        'frm.ShowDialog()

        ' ''getchoosenClients to autogeneratevoucher
        'Dim i As Integer
        'For i = 0 To frm.arr.Length - 1
        '	If frm.arr(i) <> 0 Then

        '		dsdata.Tables("tblTrx").Rows.Clear()
        '		clsMr.BuildSqlAdapter("SELECT * FROM tblTrx WHERE Not (InvoiceID IS Null) AND ClientID= " & frm.arr(i), "tblTrx")
        '		Dim drs() As DataRow = dsdata.Tables("tblTrx").Select("ClientID=" & frm.arr(i))
        '		If drs.Length <> 0 Then
        '			''autoGenerateInvoice for Client

        '			Dim drInvoice As DataRow = dsdata.Tables("tblInvoice").NewRow

        '			drInvoice("InvoiceType") = "t"
        '			drInvoice("Description") = "AutoGenerated"
        '			dsdata.Tables("tblInvoice").Rows.Add(drInvoice)
        '			''invoice detail

        '			drInvoice("Total") = "t"
        '		End If

        '	End If
        'Next

        Dim frm As New frmInvoicePrepare
        'frm.ShowDialog()
        appMain.addTabPage(frm, frmApplicationMain.eFormType.InvoicePrepare)
        AddHandler frm.Closed, AddressOf RefreshList

    End Sub

    Private Sub btnAdvancedSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''
        ''
        ''
        Static bAdvacedSearch As Boolean

        'Dim i As Integer
        'i = grdViewPSearch.Top
        ''
        If bAdvacedSearch Then
            grpGrid.Top -= 60
            grpFilter.Height -= 60
            'btnShowCol.Top -= 60
        Else
            grpGrid.Top += 60
            grpFilter.Height += 60
            'btnShowCol.Top += 60
        End If

        ''
        '' switch...
        bAdvacedSearch = Not bAdvacedSearch

    End Sub

#End Region

#Region "Form-Functions..."

    Private Function InvoiceFilterString()
        If blnLoading Then
            Exit Function
        End If
        '
        ''
        Dim strStatus As String
        Dim strfilter As String = "" '""" True"
        ''


        'strfilter = " ({vwInvoiceRpt.InvoiceDate} >= #" & Format(dtpDateFrom.Value, "dd /MMM / yyyy") & "#) AND ({vwInvoiceRpt.InvoiceDate} <= #" & Format(dtpDateTo.Value, "dd /MMM / yyyy") & "#)"
        strfilter = " ({vwInvoiceRpt.InvoiceDate} >= #" & dtpDateFrom.Value.ToString("yyyy-M-d") & "#) AND ({vwInvoiceRpt.InvoiceDate} <= #" & dtpDateTo.Value.ToString("yyyy-M-d") & "#)"

        ''
        If txtInvoiceNum.Text <> String.Empty Then
            Dim tn As Integer
            Try
                tn = Convert.ToInt32(txtInvoiceNum.Text)
                If strfilter = "" Then
                    strfilter = strfilter & "   ({vwInvoiceRpt.InvoiceNumber} = " & tn & ")"
                Else
                    strfilter = strfilter & " AND  ({vwInvoiceRpt.InvoiceNumber} = " & tn & ")"
                End If

            Catch ex As Exception
                txtInvoiceNum.Text = ""
            End Try
        End If
        ''

        'If txtInvoiceType.Text <> String.Empty Then
        '	strfilter = strfilter & " AND  (vwInvoiceRpt.InvoiceType = '" & txtInvoiceType.Text & "')"
        'End If

        If cboClient.SelectedIndex <> -1 Then
            If strfilter = "" Then
                strfilter = "  ({vwInvoiceRpt.ClientID} = " & cboClient.SelectedValue & ")"
            Else
                strfilter = strfilter & " AND ({vwInvoiceRpt.ClientID} = " & cboClient.SelectedValue & ")"
            End If

        Else

            If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
                If strfilter = "" Then
                    strfilter = "  ({vwInvoiceRpt.ClientID = " & -1 & ")"
                Else
                    strfilter = strfilter & " AND ({vwInvoiceRpt.ClientID = " & -1 & ")"
                End If

            End If
        End If
        ''
        If chkPosted.Checked = False And chkNotPosted.Checked = False And chkNew.Checked = False Then
            '' Do Nothing
        Else

            If chkPosted.Checked = True Then

                strStatus = " ( {vwInvoiceRpt.StatusID}=" & 2

            End If
            ''
            If chkNotPosted.Checked = True Then
                If strStatus = "" Then
                    strStatus = " ( {vwInvoiceRpt.StatusID}=" & 3
                Else
                    strStatus = strStatus & " OR {vwInvoiceRpt.StatusID}=" & 3
                End If

            End If
            ''
            If chkNew.Checked = True Then
                If strStatus = "" Then
                    strStatus = " ( {vwInvoiceRpt.StatusID}=" & 1
                Else
                    strStatus = strStatus & " OR {vwInvoiceRpt.StatusID}=" & 1
                End If

            End If
            If strStatus <> "" And Not (strStatus.EndsWith(")")) Then
                strStatus = strStatus & " )"
            End If
        End If
        If strfilter <> "" And strStatus <> "" Then

            strfilter = strfilter & " AND" & strStatus
        Else
            strfilter = strfilter & strStatus
        End If
        ''

        Return strfilter
    End Function

    Private Sub ClearTable()
        Dim cmd As New SqlClient.SqlCommand("Delete from tblTafkeet", conSql)
        conSql.Open()
        cmd.ExecuteNonQuery()
        conSql.Close()
        dsdata.Tables("tblTafkeet").Rows.Clear()

    End Sub

    Private Sub DrawGrid()

        grdInvoiceList.DataSource = dsdata.Tables("vwInvoiceList").DefaultView
        LoadProfile(mStrSubKeyName, Me.grdInvoiceList)

        dsdata.Tables("vwInvoiceList").DefaultView.AllowNew = False

        With grdInvoiceList
            .ReadOnly = True
            .Columns("statusID").Visible = False
            .Columns("ClientID").Visible = False
            .Columns("InvoiceID").Visible = False
            .Columns("CatID").Visible = False
            .Columns("Del").Visible = False
            .Columns("AutoGel").Visible = False
            .Columns("CatType").Visible = False
            .Columns("InvoiceYY").Visible = False
            .Columns("InvoiceFrom").Visible = False
            .Columns("InvoiceTo").Visible = False
            .Columns("Status").Visible = False
            .Columns("BillStatus").Visible = False

            .Columns("InvoiceDate").HeaderText = "Bill Date"
            .Columns("InvoiceNumber").HeaderText = "Bill #"
            .Columns("ClientName").HeaderText = "Client"
            '.Columns("BillStatus").HeaderText = "Bill Status"
            '.Columns("CatType").HeaderText = "Category"
            .Columns("Total").DefaultCellStyle.Format = "#0#"
            .ColumnHeadersHeight = btnShowCol.Height + 2
            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
            .Columns("TotalCurr2").HeaderText = "Total " & GetCompanyCurrencySymbol2()


        End With

        grdInvoiceList.Columns("Total").DefaultCellStyle.ForeColor = System.Drawing.Color.Maroon
        'grdInvoiceList.Columns("Total").DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))



    End Sub

    Private Sub FilterGrid()
        If blnLoading = True Then Exit Sub

        Dim s As String '= " True"
        Dim strStatus As String
        's = "(InvoiceDate >= '" & CDate(Format(dtpDateFrom.Value, "MM/dd/yyyy")) & "') AND (InvoiceDate <= '" & CDate(Format(dtpDateTo.Value, "MM/dd/yyyy")) & "')"
        s = "(InvoiceDate >= '" & dtpDateFrom.Value.ToString("yyyy-M-d") & "') AND (InvoiceDate <= '" & dtpDateTo.Value.ToString("yyyy-M-d") & "')"

        If txtInvoiceNum.Text <> String.Empty Then
            Dim tn As Integer
            Try
                tn = Convert.ToInt32(txtInvoiceNum.Text)
                s = s & " AND  (InvoiceNumber = " & tn & ")"
            Catch ex As Exception
                txtInvoiceNum.Text = ""
            End Try
        End If

        'If txtInvoiceType.Text <> String.Empty Then
        '	s = s & " AND  (InvoiceType = '" & txtInvoiceType.Text & "')"
        'End If
        If cboCategory.SelectedIndex <> -1 Then
            s = s & " AND (CatID = " & cboCategory.SelectedValue & ")"
        Else
            If cboCategory.Text <> "" And cboCategory.SelectedIndex = -1 Then
                s = s & " AND (CatID = " & -1 & ")"
            End If

        End If

        If cboClient.SelectedIndex <> -1 Then
            s = s & " AND (ClientID = " & cboClient.SelectedValue & ")"
        Else
            If cboClient.Text <> "" And cboClient.SelectedIndex = -1 Then
                s = s & " AND (ClientID = " & -1 & ")"
            End If

        End If



        'If cboStatus.SelectedIndex <> -1 Then
        '   s = s & " AND (StatusID = " & cboStatus.SelectedValue & ")"
        'Else
        '   If cboStatus.Text <> "" And cboStatus.SelectedIndex = -1 Then
        '      s = s & " AND (StatusID = " & -1 & ")"
        '   End If
        'End If
        If chkPosted.Checked = False And chkNotPosted.Checked = False And chkNew.Checked = False And chkPaid.Checked = False Then

            ' s = "0"
            s = s & " AND StatusID=0"
        Else
            strStatus = " AND StatusID IN ("
            If chkPosted.Checked = True Then

                strStatus = strStatus & "2"

            End If
            If chkNotPosted.Checked = True Then
                If strStatus = " AND StatusID IN (" Then
                    strStatus = strStatus & "3"
                Else
                    strStatus = strStatus & ",3"
                End If

            End If
            If chkNew.Checked = True Then
                If strStatus = " AND StatusID IN (" Then
                    strStatus = strStatus & "1"
                Else
                    strStatus = strStatus & ",1"
                End If

            End If
            If chkPaid.Checked = True Then
                If strStatus = " AND StatusID IN (" Then
                    strStatus = strStatus & "4"
                Else
                    strStatus = strStatus & ",4"
                End If

            End If
            strStatus = strStatus & ")"
        End If
        s = s & strStatus

        dsdata.Tables("vwInvoiceList").DefaultView.RowFilter = s

        ChangeColor()
        SetStatus()
        CalculateTotal()
    End Sub

    Private Sub ChangeColor()
        ''change color of visits according to status
        Dim i As Integer
        Dim intStatus As Integer
        For i = 0 To dsdata.Tables("vwInvoiceList").DefaultView.Count - 1
            intStatus = dsdata.Tables("vwInvoiceList").DefaultView.Item(i)("StatusID")

            Select Case intStatus
                Case 1
                    grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.LightYellow

                Case 2
                    grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.LightSteelBlue

                Case 3
                    grdInvoiceList.Rows(i).DefaultCellStyle.BackColor = Color.MistyRose

            End Select



        Next
    End Sub

    Private Sub EditInvoice()
        If grdInvoiceList.Rows.Count = 0 Then Exit Sub
        If grdInvoiceList.Item("StatusID", grdInvoiceList.CurrentRow.Index).Value = 4 Then
            MsgBox("Cannot edit a paid invoice")
            Exit Sub
        End If

        ''
        Windows.Forms.Cursor.Current = Cursors.WaitCursor

        Dim frm As New frmInvoice(grdInvoiceList.Item("InvoiceID", grdInvoiceList.CurrentRow.Index).Value, 2)
        appMain.addTabPage(frm, frmApplicationMain.eFormType.Invoice)
        'frm.Show()

        Windows.Forms.Cursor.Current = Cursors.Default
        ''refresh


        AddHandler frm.Closed, AddressOf RefreshList
    End Sub

    Private Sub RefreshList(ByVal sender As Object, ByVal e As System.EventArgs)
        dsdata.Tables("vwInvoiceList").Rows.Clear()
        clsMr.BuildSqlAdapter("SELECT * FROM vwInvoiceList WHERE Del=0 AND CatID = 4", "vwInvoiceList")
        FilterGrid()
        'MakeDataAdapter()
    End Sub

    Private Sub SetStatus()
        If grdInvoiceList.Rows.Count = 0 Then
            btnEdit.Enabled = False
            btnDelete.Enabled = False
            btnPreview.Enabled = False
        Else
            btnEdit.Enabled = True
            btnDelete.Enabled = True
            btnPreview.Enabled = True
        End If
        ''
        DGCA.LoadPermissionsSetState(Me, Me.Name)
    End Sub

    Private Sub CalculateTotal()
        If blnLoading Then Exit Sub
        Dim dv As DataView = dsdata.Tables("vwInvoiceList").DefaultView
        Dim drv As DataRowView
        Dim gt As Double
        Dim gtCurr2 As Double

        For Each drv In dv
            If drv("Total") Is DBNull.Value Then
                drv("Total") = 0
            End If
            If drv("TotalCurr2") Is DBNull.Value Then
                drv("TotalCurr2") = 0
            End If
            gt += drv("Total")
            gtCurr2 += drv("TotalCurr2")
        Next
        txtTotal.Text = gt.ToString("#0#")
        txtTotalCurr2.Text = gtCurr2.ToString("#0#")
    End Sub

#End Region

#Region "GrdSetUp..."

    Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()
            mstrCurrentGridName = "InvoiceList"
            ''
            '' populate list with grid's dataSource fields...
            ''

            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdInvoiceList.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next
            chkLstGridCol.Items.Remove("StatusID")
            chkLstGridCol.Items.Remove("ClientID")
            chkLstGridCol.Items.Remove("InvoiceID")
            chkLstGridCol.Items.Remove("Del")
            chkLstGridCol.Items.Remove("CatID")
            chkLstGridCol.Items.Remove("AutoGel")

        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If
    End Sub

    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
        Dim i As Integer

        For i = 0 To Me.chkLstGridCol.Items.Count - 1
            Me.grdInvoiceList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
        Next

        ''
        Me.grpShowHideColumns.Visible = False

    End Sub

    Private Sub frmInvoiceList_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        SaveProfile(mStrSubKeyName, Me.grdInvoiceList)
    End Sub

#End Region


    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

    End Sub
End Class