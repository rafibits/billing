<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLedger
   Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLedger))
        Me.grdLedger = New System.Windows.Forms.DataGridView
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.lblTitle = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtNum = New System.Windows.Forms.TextBox
        Me.cboAccountType = New System.Windows.Forms.ComboBox
        Me.txtName = New System.Windows.Forms.TextBox
        Me.btnNewLedger = New BHBut.BouncingHoverButton
        Me.btnEditLedger = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.grpControls = New System.Windows.Forms.GroupBox
        Me.btnSelect = New BHBut.BouncingHoverButton
        Me.grpLedger = New System.Windows.Forms.GroupBox
        Me.btnClosegrp = New BHBut.BouncingHoverButton
        Me.btnDelete = New BHBut.BouncingHoverButton
        Me.btnSaveLedger = New BHBut.BouncingHoverButton
        Me.txtLedgerName = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtLedger1 = New System.Windows.Forms.TextBox
        Me.txtLedgerNumber = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtLedgerID = New System.Windows.Forms.TextBox
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.lblFormTitleLine = New System.Windows.Forms.Panel
        CType(Me.grdLedger, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpControls.SuspendLayout()
        Me.grpLedger.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        Me.SuspendLayout()
        '
        'grdLedger
        '
        Me.grdLedger.AllowUserToAddRows = False
        Me.grdLedger.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdLedger.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.grdLedger.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdLedger.GridColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.grdLedger.Location = New System.Drawing.Point(-1, 97)
        Me.grdLedger.Name = "grdLedger"
        Me.grdLedger.Size = New System.Drawing.Size(598, 361)
        Me.grdLedger.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Panel1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Panel1.Location = New System.Drawing.Point(-145, 39)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(925, 1)
        Me.Panel1.TabIndex = 3
        '
        'lblTitle
        '
        Me.lblTitle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTitle.AutoEllipsis = True
        Me.lblTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.Black
        Me.lblTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(597, 36)
        Me.lblTitle.TabIndex = 2
        Me.lblTitle.Text = "General Ledger"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(12, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Account Type"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label2.Location = New System.Drawing.Point(12, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Ledger Number"
        '
        'txtNum
        '
        Me.txtNum.Location = New System.Drawing.Point(101, 74)
        Me.txtNum.Name = "txtNum"
        Me.txtNum.Size = New System.Drawing.Size(58, 20)
        Me.txtNum.TabIndex = 3
        '
        'cboAccountType
        '
        Me.cboAccountType.FormattingEnabled = True
        Me.cboAccountType.Location = New System.Drawing.Point(101, 47)
        Me.cboAccountType.Name = "cboAccountType"
        Me.cboAccountType.Size = New System.Drawing.Size(175, 21)
        Me.cboAccountType.TabIndex = 1
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(165, 74)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(210, 20)
        Me.txtName.TabIndex = 4
        '
        'btnNewLedger
        '
        Me.btnNewLedger.AlternativeGroup = Nothing
        Me.btnNewLedger.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNewLedger.BackColor1 = System.Drawing.Color.White
        Me.btnNewLedger.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNewLedger.BorderHover = True
        Me.btnNewLedger.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNewLedger.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNewLedger.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnNewLedger.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNewLedger.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNewLedger.DrawBorder = True
        Me.btnNewLedger.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNewLedger.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnNewLedger.ForeColor = System.Drawing.Color.Navy
        Me.btnNewLedger.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnNewLedger.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnNewLedger.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewLedger.Location = New System.Drawing.Point(6, 13)
        Me.btnNewLedger.Name = "btnNewLedger"
        Me.btnNewLedger.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnNewLedger.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnNewLedger.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewLedger.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnNewLedger.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnNewLedger.SelectedText = Nothing
        Me.btnNewLedger.Size = New System.Drawing.Size(103, 24)
        Me.btnNewLedger.TabIndex = 44
        Me.btnNewLedger.Text = "New Ledger"
        Me.btnNewLedger.UseVisualStyleBackColor = False
        '
        'btnEditLedger
        '
        Me.btnEditLedger.AlternativeGroup = Nothing
        Me.btnEditLedger.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnEditLedger.BackColor1 = System.Drawing.Color.White
        Me.btnEditLedger.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnEditLedger.BorderHover = True
        Me.btnEditLedger.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnEditLedger.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnEditLedger.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnEditLedger.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnEditLedger.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnEditLedger.DrawBorder = True
        Me.btnEditLedger.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnEditLedger.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnEditLedger.ForeColor = System.Drawing.Color.Navy
        Me.btnEditLedger.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnEditLedger.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnEditLedger.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEditLedger.Location = New System.Drawing.Point(132, 13)
        Me.btnEditLedger.Name = "btnEditLedger"
        Me.btnEditLedger.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnEditLedger.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnEditLedger.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnEditLedger.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnEditLedger.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnEditLedger.SelectedText = Nothing
        Me.btnEditLedger.Size = New System.Drawing.Size(103, 24)
        Me.btnEditLedger.TabIndex = 45
        Me.btnEditLedger.Text = "Edit Ledger"
        Me.btnEditLedger.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.Location = New System.Drawing.Point(467, 13)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(103, 24)
        Me.btnClose.TabIndex = 46
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'grpControls
        '
        Me.grpControls.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpControls.Controls.Add(Me.btnSelect)
        Me.grpControls.Controls.Add(Me.btnNewLedger)
        Me.grpControls.Controls.Add(Me.btnClose)
        Me.grpControls.Controls.Add(Me.btnEditLedger)
        Me.grpControls.Location = New System.Drawing.Point(6, 458)
        Me.grpControls.Name = "grpControls"
        Me.grpControls.Size = New System.Drawing.Size(576, 43)
        Me.grpControls.TabIndex = 47
        Me.grpControls.TabStop = False
        '
        'btnSelect
        '
        Me.btnSelect.AlternativeGroup = Nothing
        Me.btnSelect.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSelect.BackColor1 = System.Drawing.Color.White
        Me.btnSelect.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSelect.BorderHover = True
        Me.btnSelect.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSelect.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSelect.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnSelect.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSelect.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSelect.DrawBorder = True
        Me.btnSelect.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnSelect.ForeColor = System.Drawing.Color.Navy
        Me.btnSelect.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnSelect.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnSelect.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelect.Location = New System.Drawing.Point(258, 13)
        Me.btnSelect.Name = "btnSelect"
        Me.btnSelect.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnSelect.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnSelect.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelect.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnSelect.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnSelect.SelectedText = Nothing
        Me.btnSelect.Size = New System.Drawing.Size(103, 24)
        Me.btnSelect.TabIndex = 47
        Me.btnSelect.Text = "Select"
        Me.btnSelect.UseVisualStyleBackColor = False
        '
        'grpLedger
        '
        Me.grpLedger.Controls.Add(Me.btnClosegrp)
        Me.grpLedger.Controls.Add(Me.btnDelete)
        Me.grpLedger.Controls.Add(Me.btnSaveLedger)
        Me.grpLedger.Controls.Add(Me.txtLedgerName)
        Me.grpLedger.Controls.Add(Me.Label4)
        Me.grpLedger.Controls.Add(Me.txtLedger1)
        Me.grpLedger.Controls.Add(Me.txtLedgerNumber)
        Me.grpLedger.Controls.Add(Me.Label3)
        Me.grpLedger.Location = New System.Drawing.Point(59, 288)
        Me.grpLedger.Name = "grpLedger"
        Me.grpLedger.Size = New System.Drawing.Size(481, 98)
        Me.grpLedger.TabIndex = 48
        Me.grpLedger.TabStop = False
        '
        'btnClosegrp
        '
        Me.btnClosegrp.AlternativeGroup = Nothing
        Me.btnClosegrp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClosegrp.BackColor = System.Drawing.Color.Orange
        Me.btnClosegrp.BackColor1 = System.Drawing.Color.White
        Me.btnClosegrp.BackColor2 = System.Drawing.Color.Orange
        Me.btnClosegrp.BorderHover = True
        Me.btnClosegrp.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClosegrp.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClosegrp.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnClosegrp.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClosegrp.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClosegrp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClosegrp.DrawBorder = True
        Me.btnClosegrp.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClosegrp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnClosegrp.ForeColor = System.Drawing.Color.Navy
        Me.btnClosegrp.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClosegrp.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnClosegrp.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClosegrp.Location = New System.Drawing.Point(392, 68)
        Me.btnClosegrp.Name = "btnClosegrp"
        Me.btnClosegrp.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnClosegrp.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnClosegrp.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClosegrp.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnClosegrp.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnClosegrp.SelectedText = Nothing
        Me.btnClosegrp.Size = New System.Drawing.Size(79, 24)
        Me.btnClosegrp.TabIndex = 12
        Me.btnClosegrp.Text = "Close"
        Me.btnClosegrp.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.AlternativeGroup = Nothing
        Me.btnDelete.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnDelete.BackColor1 = System.Drawing.Color.White
        Me.btnDelete.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnDelete.BorderHover = True
        Me.btnDelete.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnDelete.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnDelete.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnDelete.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnDelete.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.DrawBorder = True
        Me.btnDelete.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.Navy
        Me.btnDelete.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnDelete.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnDelete.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDelete.Location = New System.Drawing.Point(121, 68)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnDelete.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnDelete.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDelete.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnDelete.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnDelete.SelectedText = Nothing
        Me.btnDelete.Size = New System.Drawing.Size(79, 24)
        Me.btnDelete.TabIndex = 11
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnSaveLedger
        '
        Me.btnSaveLedger.AlternativeGroup = Nothing
        Me.btnSaveLedger.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSaveLedger.BackColor1 = System.Drawing.Color.White
        Me.btnSaveLedger.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSaveLedger.BorderHover = True
        Me.btnSaveLedger.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSaveLedger.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSaveLedger.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Normal
        Me.btnSaveLedger.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSaveLedger.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSaveLedger.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSaveLedger.DrawBorder = True
        Me.btnSaveLedger.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSaveLedger.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnSaveLedger.ForeColor = System.Drawing.Color.Navy
        Me.btnSaveLedger.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnSaveLedger.HoverColor2 = System.Drawing.SystemColors.Highlight
        Me.btnSaveLedger.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSaveLedger.Location = New System.Drawing.Point(22, 68)
        Me.btnSaveLedger.Name = "btnSaveLedger"
        Me.btnSaveLedger.SelectedColor1 = System.Drawing.Color.Khaki
        Me.btnSaveLedger.SelectedColor2 = System.Drawing.Color.DarkGoldenrod
        Me.btnSaveLedger.SelectedForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSaveLedger.SelectedHoverColor1 = System.Drawing.Color.DarkGoldenrod
        Me.btnSaveLedger.SelectedHoverColor2 = System.Drawing.Color.Khaki
        Me.btnSaveLedger.SelectedText = Nothing
        Me.btnSaveLedger.Size = New System.Drawing.Size(79, 24)
        Me.btnSaveLedger.TabIndex = 10
        Me.btnSaveLedger.Text = "Save"
        Me.btnSaveLedger.UseVisualStyleBackColor = False
        '
        'txtLedgerName
        '
        Me.txtLedgerName.Location = New System.Drawing.Point(244, 13)
        Me.txtLedgerName.Name = "txtLedgerName"
        Me.txtLedgerName.Size = New System.Drawing.Size(229, 20)
        Me.txtLedgerName.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(172, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Ledger Name"
        '
        'txtLedger1
        '
        Me.txtLedger1.Location = New System.Drawing.Point(122, 13)
        Me.txtLedger1.Name = "txtLedger1"
        Me.txtLedger1.Size = New System.Drawing.Size(49, 20)
        Me.txtLedger1.TabIndex = 7
        '
        'txtLedgerNumber
        '
        Me.txtLedgerNumber.Enabled = False
        Me.txtLedgerNumber.Location = New System.Drawing.Point(78, 13)
        Me.txtLedgerNumber.Name = "txtLedgerNumber"
        Me.txtLedgerNumber.Size = New System.Drawing.Size(38, 20)
        Me.txtLedgerNumber.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(0, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(80, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Ledger Number"
        '
        'txtLedgerID
        '
        Me.txtLedgerID.Location = New System.Drawing.Point(407, 119)
        Me.txtLedgerID.Name = "txtLedgerID"
        Me.txtLedgerID.Size = New System.Drawing.Size(75, 20)
        Me.txtLedgerID.TabIndex = 48
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(42, 100)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(175, 180)
        Me.grpShowHideColumns.TabIndex = 299
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Show/Hide Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 148)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(162, 27)
        Me.btnSaveSettings.TabIndex = 0
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(162, 109)
        Me.chkLstGridCol.TabIndex = 92
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = CType(resources.GetObject("btnShowCol.BackgroundImage"), System.Drawing.Image)
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!)
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnShowCol.Location = New System.Drawing.Point(2, 98)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 298
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'lblFormTitleLine
        '
        Me.lblFormTitleLine.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblFormTitleLine.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblFormTitleLine.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lblFormTitleLine.Location = New System.Drawing.Point(-1, 37)
        Me.lblFormTitleLine.Name = "lblFormTitleLine"
        Me.lblFormTitleLine.Size = New System.Drawing.Size(772, 3)
        Me.lblFormTitleLine.TabIndex = 394
        '
        'frmLedger
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(589, 505)
        Me.Controls.Add(Me.lblFormTitleLine)
        Me.Controls.Add(Me.grpShowHideColumns)
        Me.Controls.Add(Me.btnShowCol)
        Me.Controls.Add(Me.grpLedger)
        Me.Controls.Add(Me.grpControls)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.cboAccountType)
        Me.Controls.Add(Me.txtNum)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.grdLedger)
        Me.Controls.Add(Me.txtLedgerID)
        Me.Name = "frmLedger"
        Me.Text = "General Ledger"
        CType(Me.grdLedger, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpControls.ResumeLayout(False)
        Me.grpLedger.ResumeLayout(False)
        Me.grpLedger.PerformLayout()
        Me.grpShowHideColumns.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grdLedger As System.Windows.Forms.DataGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtNum As System.Windows.Forms.TextBox
    Friend WithEvents cboAccountType As System.Windows.Forms.ComboBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox

    Public Sub New(Optional ByVal Ledger As Long = -1)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        mLedger = Ledger
    End Sub
    Friend WithEvents btnNewLedger As BHBut.BouncingHoverButton
    Friend WithEvents btnEditLedger As BHBut.BouncingHoverButton
    Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents grpControls As System.Windows.Forms.GroupBox
    Friend WithEvents grpLedger As System.Windows.Forms.GroupBox
    Friend WithEvents txtLedgerName As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtLedger1 As System.Windows.Forms.TextBox
    Friend WithEvents txtLedgerNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnSaveLedger As BHBut.BouncingHoverButton
    Friend WithEvents btnClosegrp As BHBut.BouncingHoverButton
    Friend WithEvents btnDelete As BHBut.BouncingHoverButton
   Friend WithEvents txtLedgerID As System.Windows.Forms.TextBox
   Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
   Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
   Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
   Friend WithEvents btnShowCol As System.Windows.Forms.Button
    Friend WithEvents btnSelect As BHBut.BouncingHoverButton
    Friend WithEvents lblFormTitleLine As System.Windows.Forms.Panel
End Class
