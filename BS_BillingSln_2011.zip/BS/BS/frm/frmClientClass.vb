Imports BITSConn
Imports System.Data.SqlClient

Public Class frmClientClass

#Region " Form Declaration  .  .  ."
    ''
    Dim dsData As DataSet
    Dim clsMr As ClsMain
    Dim daClientClass As SqlDataAdapter
    Dim blnLoading As Boolean
    Dim dataChange As Boolean
    Dim WithEvents Nav As BitsNav
    Private mStrSubKeyName As String = "Software\BIT Solutions\Billing\Client\Client Class"
    Private mstrCurrentGridName As String
#End Region

#Region " Form Initialization . . ."

    Private Sub frmClientClass_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ''
        conSql = New SqlConnection("Data Source=BITSSERVER;Initial Catalog=Billing;Integrated Security=True")
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav
        ''
        blnLoading = True
        MakeDataAdapter()
        SetDataBinding()
        SetAutoNumber()
        SetDefaults()
        SetCurrency()
        ''
        btnSave.Text = "Edit"
        grdClientClass.ReadOnly = True
        DrawGrid()
        blnLoading = False

    End Sub

    Private Sub MakeDataAdapter()
        ''
        strSQL = "SELECT Code, Description, ClientClassID, Del FROM tblClientClass WHERE Del = 0"
        daClientClass = clsMr.BuildSqlAdapter(strSQL, "tblClientClass")
        dsData = clsMr.getDataSet
    End Sub

    Private Sub SetDataBinding()
        clsMr.BindTextBox(txtClientClassID, "tblClientClass", "ClientClassID")
    End Sub

    Private Sub SetAutoNumber()
        clsMr.SetAutoNumber("tblClientClass", "ClientClassID")
    End Sub

    Private Sub SetDefaults()
        clsMr.SetDefaults("tblClientClass", "Del", 0)
    End Sub

    Private Sub SetCurrency()
        Nav.SetCurrency(Me, clsMr.getDataSet, "tblClientClass")
    End Sub

#End Region

#Region " Form Functions   .  .  . "

    Private Sub DrawGrid()
        With grdClientClass
            .DataSource = dsData.Tables("tblClientClass").DefaultView
            .Columns("ClientClassID").Visible = False
            .Columns("Del").Visible = False
            .ColumnHeadersHeight = btnShowCol.Height + 2

            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        End With
        dsData.Tables("tblClientClass").DefaultView.AllowNew = False
        ''
        RemoveGrdListItems()
        LoadProfile(mStrSubKeyName, Me.grdClientClass)
    End Sub

    Private Sub RemoveGrdListItems()
        ''
        chkLstGridCol.Items.Remove("ClientClassID")
        chkLstGridCol.Items.Remove("Del")
    End Sub

    Private Sub refrech()
        ''
        clsMr.BuildSqlAdapter("SELECT * FROM tblClientClass ", "tblClientClass")
        dsData = clsMr.getDataSet
        grdClientClass.DataSource = dsData.Tables("tblClientClass")
        grdClientClass.Columns("ClientClassID").Visible = False
    End Sub

#End Region

#Region " UI - Events     .  .  .  "

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        ''
        If dataChange Then
            ''
            Dim res As MsgBoxResult
            res = MsgBox("Do you want to save changes?", MsgBoxStyle.YesNoCancel)
            ''
            Select Case res
                Case MsgBoxResult.Yes
                    btnSave.PerformClick()
                    Me.Close()
                Case MsgBoxResult.No
                    Nav.CancelCurrentEdit()
                    Me.Close()
                Case MsgBoxResult.Cancel
                    Exit Sub
            End Select
        End If
        Me.Close()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        ''
        If grdClientClass.RowCount = 0 Then
            Exit Sub
        End If
        ''
        If MsgBox("Are you sure you want to delete Client Class?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            ''
            strSQL = "Update tblClientClass SET Del = 1 WHERE ClientClassID = " & txtClientClassID.Text
            Dim cmd As New SqlCommand(strSQL, conSql)
            ''
            Try
                conSql.Open()
                cmd.ExecuteNonQuery()
                conSql.Close()
                ''
                grdClientClass.Item("Del", grdClientClass.CurrentRow.Index).Value = 1
                dsData.Tables("tblClientClass").DefaultView(grdClientClass.CurrentRow.Index).Delete()
            Catch ex As Exception
                conSql.Close()
            End Try
        End If
        ''
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ''
        If dataChange = True Then
            If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Nav.CancelCurrentEdit()
                dsData.Tables("tblClientClass").DefaultView.AllowNew = False
                btnSave.Text = "Edit"
                btnNew.Enabled = True
                grdClientClass.ReadOnly = True
                dataChange = False
            End If
        End If
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        ''
        dsData.Tables("tblClientClass").DefaultView.AllowNew = True
        Nav.AddNew()
        btnSave.Text = "Save"
        grdClientClass.ReadOnly = False
        btnNew.Enabled = False
        btnCancel.Enabled = True
        dataChange = True
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        ''
        If btnSave.Text = "Edit" Then
            btnSave.Text = "Save"
            btnNew.Enabled = False
            grdClientClass.ReadOnly = False
            dataChange = True
        Else
            btnSave.Text = "Edit"
            btnNew.Enabled = True
            grdClientClass.ReadOnly = True
            Nav.EndCurrentEdit()
            daClientClass.Update(dsData, "tblClientClass")
            dataChange = False
            dsData.Tables("tblClientClass").DefaultView.AllowNew = False
        End If
    End Sub

    Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
        ''
        If Me.grpShowHideColumns.Visible = False Then
            Me.grpShowHideColumns.Visible = True
            Me.grpShowHideColumns.BringToFront()
            mstrCurrentGridName = "Client Class"
            ''
            '' populate list with grid's dataSource fields...
            ''
            Dim col As Windows.Forms.DataGridViewColumn
            ''
            Me.chkLstGridCol.Items.Clear()
            For Each col In grdClientClass.Columns
                Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
            Next

        Else
            Me.grpShowHideColumns.Visible = False
            Me.grpShowHideColumns.SendToBack()
        End If
        RemoveGrdListItems()
    End Sub

    Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
        ''
        Dim i As Integer

        For i = 0 To Me.chkLstGridCol.Items.Count - 1
            Me.grdClientClass.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
        Next
        ''
        Me.grpShowHideColumns.Visible = False
    End Sub

    Private Sub frmClientClass_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        '' Save User Grid Setting...
        SaveProfile(mStrSubKeyName, Me.grdClientClass)
    End Sub

#End Region

End Class