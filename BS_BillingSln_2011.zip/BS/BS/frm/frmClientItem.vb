Imports BITSConn
Imports System.Data.SqlClient
''
Public Class frmClientItem


#Region " From Declaration . . . "
	''
	Dim clsMr As ClsMain
	Dim dsdata As New DataSet
	Dim WithEvents Nav As BitsNav
	Dim daClientItem As SqlDataAdapter
	Dim blnLoading As Boolean
	Dim mClientID As Integer
	Dim dataChange As Boolean
	'' addMode :: is a variable used to flag save() 
	'' to  add  new  row to the gird or  update it.
	Dim addMode As Boolean
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\ClientItem\Settings"
	Private mstrCurrentGridName As String
#End Region


#Region " From Initialization . . . "

    Private Sub frmClientItem_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmClientItem_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ''
        blnLoading = True
        ''
        clsMr = New ClsMain(conSql)
        Nav = New BitsNav
        MakeDataAdapter()
        SetDataBinding()
        SetCurrency()
        FillComboBox()
        setAutoNumber()
        SetDefaults()
        ''
        DrawGrid()
        '' Check if the current Client has item (s) to Edit
        '' Otherwise  the  form  will  open  in  a new mode
        Dim dv As DataView
        dv = dsdata.Tables("tblClientItem").DefaultView
        dv.RowFilter = "ClientID = " & mClientID
        ''
        If dv.Count = 0 Then
            '' N E W
            btnNew.PerformClick()
        Else
            '' E D I T
            Nav.CurrentPosition = GetRowIndex(dv(0)("ClientID"))
            txtClientID.Text = dv(0)("ClientID")
            setState("BROWSE")
            FilterGrid()
        End If
        dsdata.Tables("vwClientItem").DefaultView.RowFilter = "ClientID =" & mClientID
        txtClientID.Text = mClientID
        blnLoading = False
    End Sub

    Private Sub MakeDataAdapter()
        ''
        daClientItem = clsMr.BuildSqlAdapter("SELECT * FROM tblClientItem WHERE Del = 0 AND ClientID = " & mClientID, "tblClientItem")
        clsMr.BuildSqlAdapter("SELECT Make, MakeID, Del FROM tblMake WHERE Del = 0 ", "tblMake")
        clsMr.BuildSqlAdapter("SELECT Model, ModelID , MakeID FROM tblModel WHERE Del = 0 ", "tblModel")
        clsMr.BuildSqlAdapter("SELECT WeightUnit, WeightUnitID FROM tblWeightUnit WHERE Del = 0 ", "tblWeightUnit")
        ''
        clsMr.BuildSqlAdapter("SELECT * FROM vwClientItem WHERE Del = 0", "vwClientItem")
        dsdata = clsMr.getDataSet
    End Sub

    Private Sub SetDataBinding()
        ''
        clsMr.BindTextBox(txtClientItemID, "tblClientItem", "ClientItemID")
        clsMr.BindTextBox(txtClientID, "tblClientItem", "ClientID")
        clsMr.BindTextBox(txtRegistrationCode, "tblClientItem", "RegCode")
        clsMr.BindComboBox(cboMake, "tblClientItem", "MakeID")
        clsMr.BindComboBox(cboModel, "tblClientItem", "ModelID")
        clsMr.BindTextBox(txtCallSign, "tblClientItem", "CallSign")
        clsMr.BindTextBox(txtDiscount, "tblClientItem", "WeightDiscount")
        clsMr.BindTextBox(txtWeight, "tblClientItem", "Weight")
        clsMr.BindComboBox(cboUnit, "tblClientItem", "WeightUnitID")
        clsMr.BindTextBox(txtDescription, "tblClientItem", "Description")
    End Sub

    Private Sub FillComboBox()
        clsMr.FillComboBox("tblMake", cboMake, "Make", "MakeID")
        clsMr.FillComboBox("tblModel", cboModel, "Model", "ModelID")
        clsMr.FillComboBox("tblWeightUnit", cboUnit, "WeightUnit", "WeightUnitID")
    End Sub

    Private Sub SetCurrency()
        Nav.SetCurrency(Me, clsMr.getDataSet, "tblClientItem")
    End Sub

    Private Sub setAutoNumber()
        ''
        clsMr.SetAutoNumber("tblClientItem", "ClientItemID")
    End Sub

    Private Sub SetDefaults()
        ''
        clsMr.SetDefaults("tblClientItem", "CreateDate", Now.Date, "CreateByID", gIntUserID, "Del", 0)
    End Sub

#End Region


#Region " From Functions . . . "

	Public Sub New(ByVal intClientID)

		' This call is required by the Windows Form Designer.
		InitializeComponent()
        mClientID = intClientID

		' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

	Private Sub DrawGrid()
		''
		With grdClientItem
			.DataSource = dsdata.Tables("vwClientItem").DefaultView
			.Columns("ClientItemID").Visible = False
			.Columns("ClientID").Visible = False
			.Columns("Del").Visible = False
			.ReadOnly = True
			''
			.ColumnHeadersHeight = btnShowCol.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		End With
		dsdata.Tables("vwClientItem").DefaultView.AllowNew = False
		LoadProfile(mStrSubKeyName, Me.grdClientItem)
	End Sub

	Private Sub RemoveGrdListItems()
		''
		chkLstGridCol.Items.Remove("ClientItemID")
		chkLstGridCol.Items.Remove("ClientID")
		chkLstGridCol.Items.Remove("Del")
	End Sub

	Private Function GetRowIndex(ByVal pClientID As Long) As Integer
		''
		Dim i As Integer
		''
		For i = 0 To dsdata.Tables("tblClientItem").DefaultView.Count - 1
			If dsdata.Tables("tblClientItem").DefaultView.Item(i)("ClientItemID") = pClientID Then
				Return i
			End If
		Next
		''
		Return -1
	End Function

	Private Sub FilterGrid()
		''
		If txtClientID.Text = String.Empty Then Exit Sub
		dsdata.Tables("vwClientItem").DefaultView.RowFilter = "ClientID = " & txtClientID.Text
	End Sub

	Private Sub setState(ByRef pStrMode As String)
		''
		Dim mStrCurrentState As String
		mStrCurrentState = UCase(pStrMode)
		'' 
		Select Case mStrCurrentState

			Case Is = "NEW"
                ''
				btnNew.Enabled = False
				grdClientItem.Enabled = False
				btnSave.Text = "Save"
				btnCancel.Enabled = True
				grpInfo.Enabled = True

            Case Is = "EDIT"
                ''
                btnSave.Text = "Save"
                btnCancel.Enabled = True
                grpInfo.Enabled = True
				

			Case Is = "SAVE"
                ''
				btnNew.Enabled = True
				grdClientItem.Enabled = True
				btnSave.Text = "Edit"
				btnCancel.Enabled = False
				grpInfo.Enabled = False
				

            Case Is = "BROWSE"
                ''
                grdClientItem.Enabled = True
                btnSave.Text = "Edit"
                grpInfo.Enabled = False
				

			Case Is = "CANCEL"
				btnSave.Text = "Edit"
				btnNew.Enabled = True
				btnCancel.Enabled = True
				grdClientItem.Enabled = True
				grpInfo.Enabled = False
        End Select
        ''
        DGCA.LoadPermissionsSetState(Me, Me.Name)
    End Sub

	Private Sub Save()
		''
		Nav.EndCurrentEdit()
		daClientItem.Update(dsdata, "tblClientItem")
		'' U p d a t e - G r i d - b y  - n e w - r o w
		Dim dr As DataRow
		''
		If addMode Then
			'' N E W
			dr = dsdata.Tables("vwClientItem").NewRow()
			dr("RegCode") = txtRegistrationCode.Text
			dr("CallSign") = txtCallSign.Text
			If cboMake.SelectedIndex <> -1 Then
				dr("Make") = cboMake.Text
			End If
			If cboModel.SelectedIndex <> -1 Then
				dr("Model") = cboModel.Text
			End If
			dr("Weight") = txtWeight.Text
			If cboUnit.SelectedIndex <> -1 Then
				dr("WeightUnit") = cboUnit.Text
			End If
			dr("WeightDiscount") = txtDiscount.Text
			dr("Description") = txtDescription.Text()
			dsdata.Tables("vwClientItem").Rows.Add(dr)
		Else
			'' E D I T 
			dr = dsdata.Tables("vwClientItem").DefaultView.Item(Nav.CurrentPosition).Row
			''
			dr("RegCode") = txtRegistrationCode.Text
			dr("CallSign") = txtCallSign.Text
			If cboMake.SelectedIndex <> -1 Then
				dr("Make") = cboMake.Text
			End If
			If cboModel.SelectedIndex <> -1 Then
				dr("Model") = cboModel.Text
			End If
			dr("Weight") = txtWeight.Text
			If cboUnit.SelectedIndex <> -1 Then
				dr("WeightUnit") = cboUnit.Text
			End If
			dr("WeightDiscount") = txtDiscount.Text
			dr("Description") = txtDescription.Text()
			''
			addMode = False
		End If
	End Sub

	Private Sub CheckValues()
		''
		If blnLoading = True Then Exit Sub
		''
		dataChange = True
		''
		'' clear entire list & start fresh check...
		''
		lstDataErr.Items.Clear()
		Dim intErrCount As Int16 = 0
		''
		If txtRegistrationCode.Text = String.Empty Then
			lstDataErr.Items.Add("Please Enter Registration Code")
			intErrCount += 1
		End If

		If txtCallSign.Text = String.Empty Then
			lstDataErr.Items.Add("Please Enter Call Sign")
			intErrCount += 1
		End If

		If txtWeight.Text = String.Empty Then
			lstDataErr.Items.Add("Please Enter Weight")
			intErrCount += 1
		End If

		If cboUnit.Text = String.Empty Then
			lstDataErr.Items.Add("Please Choose Weight Unit")
			intErrCount += 1
		End If

		''
		If lstDataErr.Items.Count = 0 Then
			lstDataErr.Visible = False
			btnDataErr.Visible = False
		Else
			btnDataErr.Visible = True
		End If
		''
		If dataChange And intErrCount = 0 Then
			btnSave.Enabled = True
		Else
			btnSave.Enabled = False
		End If

	End Sub

	Private Sub RefreshGrdAfterSave()
		dsdata.Tables("vwClientItem").Clear()
		clsMr.BuildSqlAdapter("SELECT * FROM vwClientItem WHERE Del = 0", "vwClientItem")
	End Sub

#End Region


#Region " UI - Events . . . "

	Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
		''
		If dataChange Then
			''
			Dim res As MsgBoxResult
			res = MsgBox("Do you want to save changes?", MsgBoxStyle.YesNoCancel)
			''
			Select Case res
				Case MsgBoxResult.Yes
					btnSave.PerformClick()
					Me.Close()
				Case MsgBoxResult.No
					Nav.CancelCurrentEdit()
					Me.Close()
				Case MsgBoxResult.Cancel
					btnSave.Text = "Edit"
					Exit Sub
			End Select
		End If
		Me.Close()
	End Sub

	Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
		''
		dsdata.Tables("vwClientItem").DefaultView.AllowNew = True
		Nav.AddNew()
		txtClientID.Text = mClientID
		dataChange = True
		setState("NEW")
		dsdata.Tables("vwClientItem").DefaultView.AllowNew = False
		CheckValues()
		addMode = True
	End Sub

	Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
		''
		If grdClientItem.RowCount = 0 Then Exit Sub
		''
		''clsMr.BuildSqlAdapter("SELECT * FROM tblInvoiceDetail WHERE Del = 0 AND ClientItemID = " & txtClientItemID.Text, "tblInvoiceDetail")
		''dsdata = clsMr.getDataSet
		''
		'Dim dr As DataView
		'dr = dsdata.Tables("tblInvoiceDetail").DefaultView
		' ''
		'If dr.Count <> 0 Then
		'    MsgBox("Can not Delete Item, it has been Billed")
		'    Exit Sub
		'Else
		Dim sqlCommand As New SqlCommand("Update tblClientItem SET Del = 1 WHERE ClientItemID=" & txtClientItemID.Text, conSql)
		''
		Try
			conSql.Open()
			sqlCommand.ExecuteNonQuery()
			conSql.Close()
			dsdata.Tables("vwClientItem").DefaultView.Item(grdClientItem.CurrentRow.Index).Delete()
		Catch ex As Exception
			conSql.Close()
		End Try
		'End If
		setState("BROWSE")
	End Sub

	Private Sub OkToDelete()

	End Sub

	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
		''
		If dataChange = True Then
			If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
				dsdata.Tables("vwClientItem").DefaultView.AllowNew = False
				Nav.CancelCurrentEdit()
				dataChange = False
			End If
		End If
		setState("CANCEL")
	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
		''
		If btnSave.Text = "Edit" Then
			dataChange = True
			setState("Edit")
		Else
			''Save
			dataChange = False
			setState("SAVE")
			Save()
			RefreshGrdAfterSave()
		End If
	End Sub

	Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
		''
		If Me.grpShowHideColumns.Visible = False Then
			Me.grpShowHideColumns.Visible = True
			Me.grpShowHideColumns.BringToFront()
			mstrCurrentGridName = "Client Item"
			''
			'' populate list with grid's dataSource fields...
			''
			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridCol.Items.Clear()
			For Each col In grdClientItem.Columns
				Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
			Next
		Else
			Me.grpShowHideColumns.Visible = False
			Me.grpShowHideColumns.SendToBack()
		End If
		RemoveGrdListItems()
	End Sub

	Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
		''
		Dim i As Integer
		For i = 0 To Me.chkLstGridCol.Items.Count - 1
			Me.grdClientItem.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
		Next
		''
		Me.grpShowHideColumns.Visible = False
	End Sub

	Private Sub frmClientItem_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		'' Save User Grid Setting...
		SaveProfile(mStrSubKeyName, Me.grdClientItem)
	End Sub

	Private Sub grdClientItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grdClientItem.Click
		''
		If grdClientItem.RowCount = 0 Then Exit Sub
		Dim dr As DataRow
		dr = dsdata.Tables("vwClientItem").DefaultView.Item(grdClientItem.CurrentRow.Index).Row
		Nav.CurrentPosition = GetRowIndex(dr("ClientItemID"))
	End Sub

	Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
		''
		If lstDataErr.Visible = True Then
			lstDataErr.Visible = False
		Else
			lstDataErr.Visible = True
			lstDataErr.Height = 100
			lstDataErr.BringToFront()
		End If
	End Sub

	Private Sub txtRegistrationCode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRegistrationCode.TextChanged
		If blnLoading = True Then Exit Sub
		CheckValues()
	End Sub

	Private Sub txtCallSign_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCallSign.TextChanged
		If blnLoading = True Then Exit Sub
		CheckValues()
	End Sub

	Private Sub txtWeight_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtWeight.TextChanged
		If blnLoading = True Then Exit Sub
		If txtWeight.Text = String.Empty Then
			txtWeight.Text = 0
		End If
		CheckValues()
	End Sub

	Private Sub cboUnit_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboUnit.SelectedIndexChanged
		If blnLoading = True Then Exit Sub
		CheckValues()
	End Sub

	Private Sub txtDiscount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDiscount.TextChanged
		If txtDiscount.Text = String.Empty Then
			txtDiscount.Text = 0
		End If
	End Sub

	Private Sub txtDescription_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDescription.TextChanged
		''
		If txtDescription.Text.Length > 75 Then
			MsgBox("Description can not exceed 75 character")
		End If
	End Sub

	Private Sub cboMake_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboMake.SelectedIndexChanged
		''
		If blnLoading = True Then Exit Sub
		''
		''dsdata.Tables("tblModel").DefaultView.RowFilter = "MakeID = " & cboMake.SelectedValue
		If cboMake.Text = "" Then
			cboMake.SelectedIndex = -1
			dsdata.Tables("tblModel").DefaultView.RowFilter = String.Empty
		Else
			dsdata.Tables("tblModel").DefaultView.RowFilter = " MakeID =" & cboMake.SelectedValue
		End If
	End Sub

#End Region


#Region "Permissions.."
	''Done by Mohamad March, 2008''

	'Weight'
	Private Sub txtWeight_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtWeight.KeyPress
		If AscW(e.KeyChar) = 8 Or e.KeyChar = "." Then
			Exit Sub
		End If

		If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
			e.Handled = True
		End If
	End Sub

	'Discount'
	Private Sub txtDiscount_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDiscount.KeyPress
		If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Or e.KeyChar = "." Then
			Exit Sub
		End If

		If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
			e.Handled = True
		End If
	End Sub
#End Region


End Class