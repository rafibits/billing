<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInvoice
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboClient = New System.Windows.Forms.ComboBox
        Me.lblClient = New System.Windows.Forms.Label
        Me.txtDescription = New System.Windows.Forms.TextBox
        Me.lblDescription = New System.Windows.Forms.Label
        Me.dtpInvoiceDate = New System.Windows.Forms.DateTimePicker
        Me.txtInvoiceID = New System.Windows.Forms.TextBox
        Me.lstDataErr = New System.Windows.Forms.ListBox
        Me.lblDate = New System.Windows.Forms.Label
        Me.lblInvoiceNum = New System.Windows.Forms.Label
        Me.txtInvoiceNum = New System.Windows.Forms.TextBox
        Me.lblStatus = New System.Windows.Forms.Label
        Me.cboStatus = New System.Windows.Forms.ComboBox
        Me.btnDataErr = New System.Windows.Forms.Button
        Me.grpInvoiceInfo = New System.Windows.Forms.GroupBox
        Me.lblEmployee = New System.Windows.Forms.Label
        Me.cboEmployee = New System.Windows.Forms.ComboBox
        Me.cboCategory = New System.Windows.Forms.ComboBox
        Me.lblDG = New System.Windows.Forms.Label
        Me.cboDG = New System.Windows.Forms.ComboBox
        Me.dtpBilledDate = New System.Windows.Forms.DateTimePicker
        Me.lblBilledDate = New System.Windows.Forms.Label
        Me.lblCurrency = New System.Windows.Forms.Label
        Me.cboCurrency = New System.Windows.Forms.ComboBox
        Me.dtpInvoiceDateTo = New System.Windows.Forms.DateTimePicker
        Me.lblInvoiceDateTo = New System.Windows.Forms.Label
        Me.lblInvoiceDateFrom = New System.Windows.Forms.Label
        Me.dtpInvoiceDateFrom = New System.Windows.Forms.DateTimePicker
        Me.txtInvoiceYY = New System.Windows.Forms.TextBox
        Me.lblType = New System.Windows.Forms.Label
        Me.pnlTitle = New System.Windows.Forms.Panel
        Me.lblfrmTitle = New System.Windows.Forms.Label
        Me.grpShowHideColumns = New System.Windows.Forms.GroupBox
        Me.btnSaveSettings = New System.Windows.Forms.Button
        Me.chkLstGridCol = New System.Windows.Forms.CheckedListBox
        Me.grdInvoiceDetail = New System.Windows.Forms.DataGridView
        Me.grpButtons = New System.Windows.Forms.GroupBox
        Me.btnPreview = New BHBut.BouncingHoverButton
        Me.btnPost = New BHBut.BouncingHoverButton
        Me.btnCancel = New BHBut.BouncingHoverButton
        Me.btnRemoveService = New BHBut.BouncingHoverButton
        Me.btnGetService = New BHBut.BouncingHoverButton
        Me.btnClose = New BHBut.BouncingHoverButton
        Me.btnSave = New BHBut.BouncingHoverButton
        Me.btnNew = New BHBut.BouncingHoverButton
        Me.lblTotal = New System.Windows.Forms.Label
        Me.txtTotal = New System.Windows.Forms.TextBox
        Me.grpGrid = New System.Windows.Forms.GroupBox
        Me.lblCurrSymbol = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblHotKeys = New System.Windows.Forms.Label
        Me.lblCurrSymbol2 = New System.Windows.Forms.Label
        Me.txtTotalCurr2 = New System.Windows.Forms.TextBox
        Me.btnShowCol = New System.Windows.Forms.Button
        Me.txtRate = New System.Windows.Forms.TextBox
        Me.txtRefID = New System.Windows.Forms.TextBox
        Me.txtRefIDTo = New System.Windows.Forms.TextBox
        Me.txtOverDueRemark = New System.Windows.Forms.TextBox
        Me.lblOverDueRemark = New System.Windows.Forms.Label
        Me.grpInvoiceInfo.SuspendLayout()
        Me.grpShowHideColumns.SuspendLayout()
        CType(Me.grdInvoiceDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpButtons.SuspendLayout()
        Me.grpGrid.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboClient
        '
        Me.cboClient.BackColor = System.Drawing.SystemColors.Window
        Me.cboClient.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboClient.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cboClient.FormattingEnabled = True
        Me.cboClient.Location = New System.Drawing.Point(80, 47)
        Me.cboClient.Name = "cboClient"
        Me.cboClient.Size = New System.Drawing.Size(269, 24)
        Me.cboClient.TabIndex = 9
        '
        'lblClient
        '
        Me.lblClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblClient.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.lblClient.ForeColor = System.Drawing.Color.Maroon
        Me.lblClient.Location = New System.Drawing.Point(32, 50)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(48, 18)
        Me.lblClient.TabIndex = 8
        Me.lblClient.Text = "Client"
        Me.lblClient.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDescription
        '
        Me.txtDescription.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtDescription.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtDescription.ForeColor = System.Drawing.Color.Maroon
        Me.txtDescription.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtDescription.Location = New System.Drawing.Point(80, 105)
        Me.txtDescription.MaxLength = 100
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(714, 23)
        Me.txtDescription.TabIndex = 19
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescription.ForeColor = System.Drawing.Color.Maroon
        Me.lblDescription.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDescription.Location = New System.Drawing.Point(8, 110)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(72, 13)
        Me.lblDescription.TabIndex = 18
        Me.lblDescription.Text = "Invoice Desc."
        Me.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'dtpInvoiceDate
        '
        Me.dtpInvoiceDate.CalendarForeColor = System.Drawing.Color.Maroon
        Me.dtpInvoiceDate.CustomFormat = "dd MMM yyyy"
        Me.dtpInvoiceDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpInvoiceDate.Location = New System.Drawing.Point(413, 19)
        Me.dtpInvoiceDate.Name = "dtpInvoiceDate"
        Me.dtpInvoiceDate.Size = New System.Drawing.Size(123, 22)
        Me.dtpInvoiceDate.TabIndex = 6
        '
        'txtInvoiceID
        '
        Me.txtInvoiceID.Location = New System.Drawing.Point(125, 20)
        Me.txtInvoiceID.Name = "txtInvoiceID"
        Me.txtInvoiceID.ReadOnly = True
        Me.txtInvoiceID.Size = New System.Drawing.Size(10, 20)
        Me.txtInvoiceID.TabIndex = 7
        Me.txtInvoiceID.TabStop = False
        '
        'lstDataErr
        '
        Me.lstDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstDataErr.FormattingEnabled = True
        Me.lstDataErr.Location = New System.Drawing.Point(555, 16)
        Me.lstDataErr.Name = "lstDataErr"
        Me.lstDataErr.Size = New System.Drawing.Size(198, 17)
        Me.lstDataErr.TabIndex = 6
        Me.lstDataErr.TabStop = False
        Me.lstDataErr.Visible = False
        '
        'lblDate
        '
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.ForeColor = System.Drawing.Color.Maroon
        Me.lblDate.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDate.Location = New System.Drawing.Point(350, 21)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(59, 17)
        Me.lblDate.TabIndex = 5
        Me.lblDate.Text = " Date"
        Me.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblInvoiceNum
        '
        Me.lblInvoiceNum.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.lblInvoiceNum.ForeColor = System.Drawing.Color.Maroon
        Me.lblInvoiceNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInvoiceNum.Location = New System.Drawing.Point(16, 21)
        Me.lblInvoiceNum.Name = "lblInvoiceNum"
        Me.lblInvoiceNum.Size = New System.Drawing.Size(64, 19)
        Me.lblInvoiceNum.TabIndex = 0
        Me.lblInvoiceNum.Text = "Number"
        Me.lblInvoiceNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtInvoiceNum
        '
        Me.txtInvoiceNum.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtInvoiceNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInvoiceNum.ForeColor = System.Drawing.Color.White
        Me.txtInvoiceNum.Location = New System.Drawing.Point(80, 19)
        Me.txtInvoiceNum.Name = "txtInvoiceNum"
        Me.txtInvoiceNum.ReadOnly = True
        Me.txtInvoiceNum.Size = New System.Drawing.Size(69, 22)
        Me.txtInvoiceNum.TabIndex = 1
        Me.txtInvoiceNum.TabStop = False
        Me.txtInvoiceNum.Text = "000"
        Me.txtInvoiceNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblStatus
        '
        Me.lblStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblStatus.AutoSize = True
        Me.lblStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblStatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.ForeColor = System.Drawing.Color.Navy
        Me.lblStatus.Location = New System.Drawing.Point(608, 46)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(38, 13)
        Me.lblStatus.TabIndex = 22
        Me.lblStatus.Text = "Status"
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboStatus
        '
        Me.cboStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple
        Me.cboStatus.Enabled = False
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Location = New System.Drawing.Point(657, 42)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(138, 21)
        Me.cboStatus.TabIndex = 23
        Me.cboStatus.TabStop = False
        '
        'btnDataErr
        '
        Me.btnDataErr.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDataErr.BackColor = System.Drawing.Color.Lavender
        Me.btnDataErr.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDataErr.ForeColor = System.Drawing.Color.Red
        Me.btnDataErr.Location = New System.Drawing.Point(754, 11)
        Me.btnDataErr.Name = "btnDataErr"
        Me.btnDataErr.Size = New System.Drawing.Size(52, 25)
        Me.btnDataErr.TabIndex = 5
        Me.btnDataErr.TabStop = False
        Me.btnDataErr.Text = "E r r o r"
        Me.btnDataErr.UseVisualStyleBackColor = False
        Me.btnDataErr.Visible = False
        '
        'grpInvoiceInfo
        '
        Me.grpInvoiceInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpInvoiceInfo.BackColor = System.Drawing.Color.Lavender
        Me.grpInvoiceInfo.Controls.Add(Me.lblOverDueRemark)
        Me.grpInvoiceInfo.Controls.Add(Me.txtOverDueRemark)
        Me.grpInvoiceInfo.Controls.Add(Me.lblEmployee)
        Me.grpInvoiceInfo.Controls.Add(Me.cboEmployee)
        Me.grpInvoiceInfo.Controls.Add(Me.cboCategory)
        Me.grpInvoiceInfo.Controls.Add(Me.lblDG)
        Me.grpInvoiceInfo.Controls.Add(Me.cboDG)
        Me.grpInvoiceInfo.Controls.Add(Me.dtpBilledDate)
        Me.grpInvoiceInfo.Controls.Add(Me.lblBilledDate)
        Me.grpInvoiceInfo.Controls.Add(Me.lblCurrency)
        Me.grpInvoiceInfo.Controls.Add(Me.cboCurrency)
        Me.grpInvoiceInfo.Controls.Add(Me.dtpInvoiceDateTo)
        Me.grpInvoiceInfo.Controls.Add(Me.lblInvoiceDateTo)
        Me.grpInvoiceInfo.Controls.Add(Me.lblInvoiceDateFrom)
        Me.grpInvoiceInfo.Controls.Add(Me.dtpInvoiceDateFrom)
        Me.grpInvoiceInfo.Controls.Add(Me.txtInvoiceYY)
        Me.grpInvoiceInfo.Controls.Add(Me.lblType)
        Me.grpInvoiceInfo.Controls.Add(Me.cboStatus)
        Me.grpInvoiceInfo.Controls.Add(Me.lblInvoiceNum)
        Me.grpInvoiceInfo.Controls.Add(Me.lblDate)
        Me.grpInvoiceInfo.Controls.Add(Me.txtInvoiceNum)
        Me.grpInvoiceInfo.Controls.Add(Me.lblClient)
        Me.grpInvoiceInfo.Controls.Add(Me.lblStatus)
        Me.grpInvoiceInfo.Controls.Add(Me.dtpInvoiceDate)
        Me.grpInvoiceInfo.Controls.Add(Me.lblDescription)
        Me.grpInvoiceInfo.Controls.Add(Me.cboClient)
        Me.grpInvoiceInfo.Controls.Add(Me.txtDescription)
        Me.grpInvoiceInfo.Controls.Add(Me.txtInvoiceID)
        Me.grpInvoiceInfo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.grpInvoiceInfo.Location = New System.Drawing.Point(12, 49)
        Me.grpInvoiceInfo.Name = "grpInvoiceInfo"
        Me.grpInvoiceInfo.Size = New System.Drawing.Size(809, 165)
        Me.grpInvoiceInfo.TabIndex = 2
        Me.grpInvoiceInfo.TabStop = False
        Me.grpInvoiceInfo.Text = "I n v o i c e"
        '
        'lblEmployee
        '
        Me.lblEmployee.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblEmployee.AutoSize = True
        Me.lblEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblEmployee.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmployee.ForeColor = System.Drawing.Color.Navy
        Me.lblEmployee.Location = New System.Drawing.Point(593, 20)
        Me.lblEmployee.Name = "lblEmployee"
        Me.lblEmployee.Size = New System.Drawing.Size(53, 13)
        Me.lblEmployee.TabIndex = 20
        Me.lblEmployee.Text = "Employee"
        Me.lblEmployee.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboEmployee
        '
        Me.cboEmployee.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEmployee.Enabled = False
        Me.cboEmployee.FormattingEnabled = True
        Me.cboEmployee.Location = New System.Drawing.Point(657, 19)
        Me.cboEmployee.Name = "cboEmployee"
        Me.cboEmployee.Size = New System.Drawing.Size(138, 21)
        Me.cboEmployee.TabIndex = 21
        '
        'cboCategory
        '
        Me.cboCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCategory.FormattingEnabled = True
        Me.cboCategory.Location = New System.Drawing.Point(201, 19)
        Me.cboCategory.Name = "cboCategory"
        Me.cboCategory.Size = New System.Drawing.Size(102, 24)
        Me.cboCategory.TabIndex = 3
        '
        'lblDG
        '
        Me.lblDG.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblDG.AutoSize = True
        Me.lblDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblDG.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDG.ForeColor = System.Drawing.Color.Navy
        Me.lblDG.Location = New System.Drawing.Point(625, 67)
        Me.lblDG.Name = "lblDG"
        Me.lblDG.Size = New System.Drawing.Size(21, 13)
        Me.lblDG.TabIndex = 24
        Me.lblDG.Text = "DG"
        Me.lblDG.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboDG
        '
        Me.cboDG.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboDG.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDG.Enabled = False
        Me.cboDG.FormattingEnabled = True
        Me.cboDG.Location = New System.Drawing.Point(657, 67)
        Me.cboDG.Name = "cboDG"
        Me.cboDG.Size = New System.Drawing.Size(138, 21)
        Me.cboDG.TabIndex = 25
        '
        'dtpBilledDate
        '
        Me.dtpBilledDate.CustomFormat = "dd MMM yyyy"
        Me.dtpBilledDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpBilledDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpBilledDate.Location = New System.Drawing.Point(414, 77)
        Me.dtpBilledDate.Name = "dtpBilledDate"
        Me.dtpBilledDate.Size = New System.Drawing.Size(123, 22)
        Me.dtpBilledDate.TabIndex = 17
        Me.dtpBilledDate.TabStop = False
        '
        'lblBilledDate
        '
        Me.lblBilledDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblBilledDate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBilledDate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblBilledDate.Location = New System.Drawing.Point(351, 79)
        Me.lblBilledDate.Name = "lblBilledDate"
        Me.lblBilledDate.Size = New System.Drawing.Size(59, 17)
        Me.lblBilledDate.TabIndex = 16
        Me.lblBilledDate.Text = "Billed Date"
        Me.lblBilledDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCurrency
        '
        Me.lblCurrency.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblCurrency.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrency.ForeColor = System.Drawing.Color.DarkRed
        Me.lblCurrency.Location = New System.Drawing.Point(351, 50)
        Me.lblCurrency.Name = "lblCurrency"
        Me.lblCurrency.Size = New System.Drawing.Size(59, 19)
        Me.lblCurrency.TabIndex = 10
        Me.lblCurrency.Text = "Currency"
        Me.lblCurrency.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cboCurrency
        '
        Me.cboCurrency.Enabled = False
        Me.cboCurrency.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboCurrency.FormattingEnabled = True
        Me.cboCurrency.Location = New System.Drawing.Point(414, 47)
        Me.cboCurrency.Name = "cboCurrency"
        Me.cboCurrency.Size = New System.Drawing.Size(123, 21)
        Me.cboCurrency.TabIndex = 11
        '
        'dtpInvoiceDateTo
        '
        Me.dtpInvoiceDateTo.CustomFormat = "dd MMM yyyy"
        Me.dtpInvoiceDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpInvoiceDateTo.Location = New System.Drawing.Point(229, 77)
        Me.dtpInvoiceDateTo.Name = "dtpInvoiceDateTo"
        Me.dtpInvoiceDateTo.Size = New System.Drawing.Size(120, 20)
        Me.dtpInvoiceDateTo.TabIndex = 15
        '
        'lblInvoiceDateTo
        '
        Me.lblInvoiceDateTo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInvoiceDateTo.ForeColor = System.Drawing.Color.Navy
        Me.lblInvoiceDateTo.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInvoiceDateTo.Location = New System.Drawing.Point(199, 79)
        Me.lblInvoiceDateTo.Name = "lblInvoiceDateTo"
        Me.lblInvoiceDateTo.Size = New System.Drawing.Size(27, 21)
        Me.lblInvoiceDateTo.TabIndex = 14
        Me.lblInvoiceDateTo.Text = "To"
        Me.lblInvoiceDateTo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblInvoiceDateFrom
        '
        Me.lblInvoiceDateFrom.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInvoiceDateFrom.ForeColor = System.Drawing.Color.Navy
        Me.lblInvoiceDateFrom.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInvoiceDateFrom.Location = New System.Drawing.Point(9, 79)
        Me.lblInvoiceDateFrom.Name = "lblInvoiceDateFrom"
        Me.lblInvoiceDateFrom.Size = New System.Drawing.Size(71, 17)
        Me.lblInvoiceDateFrom.TabIndex = 12
        Me.lblInvoiceDateFrom.Text = "Service From"
        Me.lblInvoiceDateFrom.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpInvoiceDateFrom
        '
        Me.dtpInvoiceDateFrom.CustomFormat = "dd MMM yyyy"
        Me.dtpInvoiceDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpInvoiceDateFrom.Location = New System.Drawing.Point(80, 77)
        Me.dtpInvoiceDateFrom.Name = "dtpInvoiceDateFrom"
        Me.dtpInvoiceDateFrom.Size = New System.Drawing.Size(112, 20)
        Me.dtpInvoiceDateFrom.TabIndex = 13
        '
        'txtInvoiceYY
        '
        Me.txtInvoiceYY.BackColor = System.Drawing.Color.LightYellow
        Me.txtInvoiceYY.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtInvoiceYY.ForeColor = System.Drawing.Color.Maroon
        Me.txtInvoiceYY.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtInvoiceYY.Location = New System.Drawing.Point(306, 19)
        Me.txtInvoiceYY.Multiline = True
        Me.txtInvoiceYY.Name = "txtInvoiceYY"
        Me.txtInvoiceYY.ReadOnly = True
        Me.txtInvoiceYY.Size = New System.Drawing.Size(42, 23)
        Me.txtInvoiceYY.TabIndex = 4
        Me.txtInvoiceYY.TabStop = False
        Me.txtInvoiceYY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblType
        '
        Me.lblType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblType.ForeColor = System.Drawing.Color.Maroon
        Me.lblType.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblType.Location = New System.Drawing.Point(150, 21)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(54, 17)
        Me.lblType.TabIndex = 2
        Me.lblType.Text = "Category"
        Me.lblType.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'pnlTitle
        '
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.pnlTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.pnlTitle.Location = New System.Drawing.Point(0, 40)
        Me.pnlTitle.Name = "pnlTitle"
        Me.pnlTitle.Size = New System.Drawing.Size(833, 3)
        Me.pnlTitle.TabIndex = 1
        '
        'lblfrmTitle
        '
        Me.lblfrmTitle.AutoEllipsis = True
        Me.lblfrmTitle.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lblfrmTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblfrmTitle.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrmTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblfrmTitle.Location = New System.Drawing.Point(0, 0)
        Me.lblfrmTitle.Name = "lblfrmTitle"
        Me.lblfrmTitle.Size = New System.Drawing.Size(833, 40)
        Me.lblfrmTitle.TabIndex = 0
        Me.lblfrmTitle.Text = " Invoice"
        Me.lblfrmTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'grpShowHideColumns
        '
        Me.grpShowHideColumns.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.grpShowHideColumns.BackColor = System.Drawing.Color.LightSteelBlue
        Me.grpShowHideColumns.Controls.Add(Me.btnSaveSettings)
        Me.grpShowHideColumns.Controls.Add(Me.chkLstGridCol)
        Me.grpShowHideColumns.ForeColor = System.Drawing.Color.Navy
        Me.grpShowHideColumns.Location = New System.Drawing.Point(50, 14)
        Me.grpShowHideColumns.Name = "grpShowHideColumns"
        Me.grpShowHideColumns.Size = New System.Drawing.Size(186, 156)
        Me.grpShowHideColumns.TabIndex = 2
        Me.grpShowHideColumns.TabStop = False
        Me.grpShowHideColumns.Text = "Custom Columns"
        Me.grpShowHideColumns.Visible = False
        '
        'btnSaveSettings
        '
        Me.btnSaveSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveSettings.Location = New System.Drawing.Point(7, 127)
        Me.btnSaveSettings.Name = "btnSaveSettings"
        Me.btnSaveSettings.Size = New System.Drawing.Size(173, 27)
        Me.btnSaveSettings.TabIndex = 1
        Me.btnSaveSettings.Text = "Save Settings"
        Me.btnSaveSettings.UseVisualStyleBackColor = True
        '
        'chkLstGridCol
        '
        Me.chkLstGridCol.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLstGridCol.CheckOnClick = True
        Me.chkLstGridCol.FormattingEnabled = True
        Me.chkLstGridCol.Location = New System.Drawing.Point(7, 16)
        Me.chkLstGridCol.Name = "chkLstGridCol"
        Me.chkLstGridCol.Size = New System.Drawing.Size(173, 94)
        Me.chkLstGridCol.TabIndex = 0
        Me.chkLstGridCol.ThreeDCheckBoxes = True
        '
        'grdInvoiceDetail
        '
        Me.grdInvoiceDetail.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdInvoiceDetail.BackgroundColor = System.Drawing.Color.Lavender
        Me.grdInvoiceDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdInvoiceDetail.Location = New System.Drawing.Point(9, 12)
        Me.grdInvoiceDetail.Name = "grdInvoiceDetail"
        Me.grdInvoiceDetail.Size = New System.Drawing.Size(794, 179)
        Me.grdInvoiceDetail.TabIndex = 1
        '
        'grpButtons
        '
        Me.grpButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpButtons.Controls.Add(Me.btnPreview)
        Me.grpButtons.Controls.Add(Me.btnPost)
        Me.grpButtons.Controls.Add(Me.btnCancel)
        Me.grpButtons.Controls.Add(Me.btnRemoveService)
        Me.grpButtons.Controls.Add(Me.btnGetService)
        Me.grpButtons.Controls.Add(Me.btnClose)
        Me.grpButtons.Controls.Add(Me.btnSave)
        Me.grpButtons.Controls.Add(Me.btnNew)
        Me.grpButtons.Location = New System.Drawing.Point(12, 451)
        Me.grpButtons.Name = "grpButtons"
        Me.grpButtons.Size = New System.Drawing.Size(809, 46)
        Me.grpButtons.TabIndex = 4
        Me.grpButtons.TabStop = False
        '
        'btnPreview
        '
        Me.btnPreview.AlternativeGroup = Nothing
        Me.btnPreview.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPreview.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPreview.BackColor1 = System.Drawing.Color.White
        Me.btnPreview.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPreview.BorderHover = True
        Me.btnPreview.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPreview.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPreview.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPreview.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPreview.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPreview.DrawBorder = True
        Me.btnPreview.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPreview.ForeColor = System.Drawing.Color.Navy
        Me.btnPreview.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.HoverColor2 = System.Drawing.Color.White
        Me.btnPreview.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPreview.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPreview.Location = New System.Drawing.Point(548, 10)
        Me.btnPreview.Name = "btnPreview"
        Me.btnPreview.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPreview.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPreview.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPreview.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPreview.SelectedText = Nothing
        Me.btnPreview.Size = New System.Drawing.Size(99, 27)
        Me.btnPreview.TabIndex = 5
        Me.btnPreview.Text = "P r e v i e w"
        Me.btnPreview.UseVisualStyleBackColor = False
        '
        'btnPost
        '
        Me.btnPost.AlternativeGroup = Nothing
        Me.btnPost.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPost.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnPost.BackColor1 = System.Drawing.Color.White
        Me.btnPost.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnPost.BorderHover = True
        Me.btnPost.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnPost.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnPost.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnPost.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnPost.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnPost.DrawBorder = True
        Me.btnPost.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnPost.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnPost.ForeColor = System.Drawing.Color.Navy
        Me.btnPost.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPost.HoverColor2 = System.Drawing.Color.White
        Me.btnPost.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPost.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnPost.Location = New System.Drawing.Point(446, 10)
        Me.btnPost.Name = "btnPost"
        Me.btnPost.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnPost.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnPost.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnPost.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnPost.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnPost.SelectedText = Nothing
        Me.btnPost.Size = New System.Drawing.Size(99, 27)
        Me.btnPost.TabIndex = 4
        Me.btnPost.Text = "P o s t"
        Me.btnPost.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.AlternativeGroup = Nothing
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BackColor1 = System.Drawing.Color.White
        Me.btnCancel.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.BorderHover = True
        Me.btnCancel.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnCancel.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnCancel.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnCancel.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnCancel.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnCancel.DrawBorder = True
        Me.btnCancel.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.HoverColor2 = System.Drawing.Color.White
        Me.btnCancel.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnCancel.Location = New System.Drawing.Point(344, 10)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnCancel.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnCancel.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnCancel.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnCancel.SelectedText = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(99, 27)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "C a n c e l"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnRemoveService
        '
        Me.btnRemoveService.AlternativeGroup = Nothing
        Me.btnRemoveService.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnRemoveService.BackColor = System.Drawing.Color.Maroon
        Me.btnRemoveService.BackColor1 = System.Drawing.Color.White
        Me.btnRemoveService.BackColor2 = System.Drawing.Color.Maroon
        Me.btnRemoveService.BorderHover = True
        Me.btnRemoveService.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnRemoveService.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnRemoveService.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnRemoveService.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnRemoveService.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnRemoveService.DrawBorder = True
        Me.btnRemoveService.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnRemoveService.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnRemoveService.ForeColor = System.Drawing.Color.Navy
        Me.btnRemoveService.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnRemoveService.HoverColor2 = System.Drawing.Color.White
        Me.btnRemoveService.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnRemoveService.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnRemoveService.Location = New System.Drawing.Point(214, 10)
        Me.btnRemoveService.Name = "btnRemoveService"
        Me.btnRemoveService.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnRemoveService.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnRemoveService.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnRemoveService.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnRemoveService.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnRemoveService.SelectedText = Nothing
        Me.btnRemoveService.Size = New System.Drawing.Size(127, 27)
        Me.btnRemoveService.TabIndex = 2
        Me.btnRemoveService.Text = "Remove Service"
        Me.btnRemoveService.UseVisualStyleBackColor = False
        '
        'btnGetService
        '
        Me.btnGetService.AlternativeGroup = Nothing
        Me.btnGetService.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnGetService.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnGetService.BackColor1 = System.Drawing.Color.White
        Me.btnGetService.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnGetService.BorderHover = True
        Me.btnGetService.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnGetService.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnGetService.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnGetService.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnGetService.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnGetService.DrawBorder = True
        Me.btnGetService.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnGetService.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnGetService.ForeColor = System.Drawing.Color.Navy
        Me.btnGetService.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnGetService.HoverColor2 = System.Drawing.Color.White
        Me.btnGetService.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnGetService.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnGetService.Location = New System.Drawing.Point(106, 10)
        Me.btnGetService.Name = "btnGetService"
        Me.btnGetService.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnGetService.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnGetService.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnGetService.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnGetService.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnGetService.SelectedText = Nothing
        Me.btnGetService.Size = New System.Drawing.Size(106, 27)
        Me.btnGetService.TabIndex = 1
        Me.btnGetService.Text = "Get Service"
        Me.btnGetService.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.AlternativeGroup = Nothing
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Orange
        Me.btnClose.BackColor1 = System.Drawing.Color.White
        Me.btnClose.BackColor2 = System.Drawing.Color.Orange
        Me.btnClose.BorderHover = True
        Me.btnClose.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnClose.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnClose.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnClose.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnClose.DrawBorder = True
        Me.btnClose.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnClose.ForeColor = System.Drawing.Color.Navy
        Me.btnClose.HoverColor1 = System.Drawing.SystemColors.Window
        Me.btnClose.HoverColor2 = System.Drawing.Color.DarkOrange
        Me.btnClose.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnClose.Location = New System.Drawing.Point(703, 10)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.SelectedColor1 = System.Drawing.Color.Orange
        Me.btnClose.SelectedColor2 = System.Drawing.Color.White
        Me.btnClose.SelectedForeColor = System.Drawing.Color.DarkOrange
        Me.btnClose.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnClose.SelectedHoverColor2 = System.Drawing.Color.Orange
        Me.btnClose.SelectedText = Nothing
        Me.btnClose.Size = New System.Drawing.Size(99, 27)
        Me.btnClose.TabIndex = 6
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.AlternativeGroup = Nothing
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BackColor1 = System.Drawing.Color.White
        Me.btnSave.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnSave.BorderHover = True
        Me.btnSave.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnSave.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnSave.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnSave.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnSave.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnSave.DrawBorder = True
        Me.btnSave.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnSave.ForeColor = System.Drawing.Color.Navy
        Me.btnSave.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.HoverColor2 = System.Drawing.Color.White
        Me.btnSave.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnSave.Location = New System.Drawing.Point(5, 10)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnSave.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSave.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnSave.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnSave.SelectedText = Nothing
        Me.btnSave.Size = New System.Drawing.Size(99, 27)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "E d i t"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnNew
        '
        Me.btnNew.AlternativeGroup = Nothing
        Me.btnNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNew.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BackColor1 = System.Drawing.Color.White
        Me.btnNew.BackColor2 = System.Drawing.Color.LightSteelBlue
        Me.btnNew.BorderHover = True
        Me.btnNew.BorderHoverColor = System.Drawing.SystemColors.Highlight
        Me.btnNew.BorderNormalColor = System.Drawing.SystemColors.ControlDark
        Me.btnNew.ButtonType = BHBut.BouncingHoverButton.BouncingHoverButtonType.Alternative
        Me.btnNew.ClickColor1 = System.Drawing.SystemColors.Highlight
        Me.btnNew.ClickColor2 = System.Drawing.SystemColors.Window
        Me.btnNew.DrawBorder = True
        Me.btnNew.FlatStyle = BHBut.BouncingHoverButton.FltStyle.BouncingHover
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.btnNew.ForeColor = System.Drawing.Color.Navy
        Me.btnNew.HoverColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.HoverColor2 = System.Drawing.Color.White
        Me.btnNew.HoverForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnNew.Location = New System.Drawing.Point(5, 10)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.SelectedColor1 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedColor2 = System.Drawing.Color.WhiteSmoke
        Me.btnNew.SelectedForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnNew.SelectedHoverColor1 = System.Drawing.Color.White
        Me.btnNew.SelectedHoverColor2 = System.Drawing.Color.RoyalBlue
        Me.btnNew.SelectedText = Nothing
        Me.btnNew.Size = New System.Drawing.Size(99, 27)
        Me.btnNew.TabIndex = 156
        Me.btnNew.Text = "N e w"
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'lblTotal
        '
        Me.lblTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTotal.BackColor = System.Drawing.Color.Maroon
        Me.lblTotal.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.ForeColor = System.Drawing.Color.White
        Me.lblTotal.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblTotal.Location = New System.Drawing.Point(452, 194)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(350, 28)
        Me.lblTotal.TabIndex = 5
        Me.lblTotal.Text = "  Total"
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTotal
        '
        Me.txtTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotal.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotal.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotal.Location = New System.Drawing.Point(541, 197)
        Me.txtTotal.Multiline = True
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(105, 23)
        Me.txtTotal.TabIndex = 7
        Me.txtTotal.TabStop = False
        '
        'grpGrid
        '
        Me.grpGrid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpGrid.Controls.Add(Me.lblCurrSymbol)
        Me.grpGrid.Controls.Add(Me.Label1)
        Me.grpGrid.Controls.Add(Me.lblHotKeys)
        Me.grpGrid.Controls.Add(Me.lblCurrSymbol2)
        Me.grpGrid.Controls.Add(Me.txtTotalCurr2)
        Me.grpGrid.Controls.Add(Me.grpShowHideColumns)
        Me.grpGrid.Controls.Add(Me.btnShowCol)
        Me.grpGrid.Controls.Add(Me.grdInvoiceDetail)
        Me.grpGrid.Controls.Add(Me.txtTotal)
        Me.grpGrid.Controls.Add(Me.lblTotal)
        Me.grpGrid.Location = New System.Drawing.Point(12, 220)
        Me.grpGrid.Name = "grpGrid"
        Me.grpGrid.Size = New System.Drawing.Size(809, 225)
        Me.grpGrid.TabIndex = 3
        Me.grpGrid.TabStop = False
        '
        'lblCurrSymbol
        '
        Me.lblCurrSymbol.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCurrSymbol.BackColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblCurrSymbol.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol.Location = New System.Drawing.Point(504, 198)
        Me.lblCurrSymbol.Name = "lblCurrSymbol"
        Me.lblCurrSymbol.Size = New System.Drawing.Size(34, 20)
        Me.lblCurrSymbol.TabIndex = 6
        Me.lblCurrSymbol.Text = "Curr"
        Me.lblCurrSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.Red
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label1.Location = New System.Drawing.Point(9, 197)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 21)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Hot Keys"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblHotKeys
        '
        Me.lblHotKeys.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblHotKeys.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblHotKeys.ForeColor = System.Drawing.Color.Red
        Me.lblHotKeys.Location = New System.Drawing.Point(64, 197)
        Me.lblHotKeys.Name = "lblHotKeys"
        Me.lblHotKeys.Size = New System.Drawing.Size(313, 21)
        Me.lblHotKeys.TabIndex = 4
        Me.lblHotKeys.Text = " F3= Client Search, F5= Get Service"
        Me.lblHotKeys.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblCurrSymbol2
        '
        Me.lblCurrSymbol2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCurrSymbol2.BackColor = System.Drawing.Color.Maroon
        Me.lblCurrSymbol2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrSymbol2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblCurrSymbol2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblCurrSymbol2.Location = New System.Drawing.Point(654, 198)
        Me.lblCurrSymbol2.Name = "lblCurrSymbol2"
        Me.lblCurrSymbol2.Size = New System.Drawing.Size(34, 20)
        Me.lblCurrSymbol2.TabIndex = 8
        Me.lblCurrSymbol2.Text = "Curr"
        Me.lblCurrSymbol2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTotalCurr2
        '
        Me.txtTotalCurr2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalCurr2.BackColor = System.Drawing.Color.LightYellow
        Me.txtTotalCurr2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalCurr2.ForeColor = System.Drawing.Color.Maroon
        Me.txtTotalCurr2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTotalCurr2.Location = New System.Drawing.Point(691, 197)
        Me.txtTotalCurr2.Multiline = True
        Me.txtTotalCurr2.Name = "txtTotalCurr2"
        Me.txtTotalCurr2.ReadOnly = True
        Me.txtTotalCurr2.Size = New System.Drawing.Size(105, 23)
        Me.txtTotalCurr2.TabIndex = 9
        Me.txtTotalCurr2.TabStop = False
        '
        'btnShowCol
        '
        Me.btnShowCol.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnShowCol.BackColor = System.Drawing.Color.Linen
        Me.btnShowCol.BackgroundImage = Global.BS.My.Resources.Resources.docNArrwa
        Me.btnShowCol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnShowCol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnShowCol.FlatAppearance.BorderSize = 2
        Me.btnShowCol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnShowCol.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowCol.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowCol.ForeColor = System.Drawing.Color.White
        Me.btnShowCol.Location = New System.Drawing.Point(12, 14)
        Me.btnShowCol.Name = "btnShowCol"
        Me.btnShowCol.Size = New System.Drawing.Size(36, 30)
        Me.btnShowCol.TabIndex = 0
        Me.btnShowCol.TabStop = False
        Me.btnShowCol.UseVisualStyleBackColor = False
        '
        'txtRate
        '
        Me.txtRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtRate.ForeColor = System.Drawing.Color.Maroon
        Me.txtRate.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtRate.Location = New System.Drawing.Point(312, 11)
        Me.txtRate.Multiline = True
        Me.txtRate.Name = "txtRate"
        Me.txtRate.ReadOnly = True
        Me.txtRate.Size = New System.Drawing.Size(69, 23)
        Me.txtRate.TabIndex = 7
        Me.txtRate.TabStop = False
        '
        'txtRefID
        '
        Me.txtRefID.Location = New System.Drawing.Point(206, 11)
        Me.txtRefID.Name = "txtRefID"
        Me.txtRefID.Size = New System.Drawing.Size(100, 20)
        Me.txtRefID.TabIndex = 8
        '
        'txtRefIDTo
        '
        Me.txtRefIDTo.Location = New System.Drawing.Point(312, 11)
        Me.txtRefIDTo.Name = "txtRefIDTo"
        Me.txtRefIDTo.Size = New System.Drawing.Size(100, 20)
        Me.txtRefIDTo.TabIndex = 9
        '
        'txtOverDueRemark
        '
        Me.txtOverDueRemark.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtOverDueRemark.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtOverDueRemark.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOverDueRemark.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.txtOverDueRemark.ForeColor = System.Drawing.Color.Maroon
        Me.txtOverDueRemark.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtOverDueRemark.Location = New System.Drawing.Point(80, 134)
        Me.txtOverDueRemark.MaxLength = 200
        Me.txtOverDueRemark.Multiline = True
        Me.txtOverDueRemark.Name = "txtOverDueRemark"
        Me.txtOverDueRemark.Size = New System.Drawing.Size(714, 23)
        Me.txtOverDueRemark.TabIndex = 26
        '
        'lblOverDueRemark
        '
        Me.lblOverDueRemark.AutoSize = True
        Me.lblOverDueRemark.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOverDueRemark.ForeColor = System.Drawing.Color.Maroon
        Me.lblOverDueRemark.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblOverDueRemark.Location = New System.Drawing.Point(1, 138)
        Me.lblOverDueRemark.Name = "lblOverDueRemark"
        Me.lblOverDueRemark.Size = New System.Drawing.Size(79, 13)
        Me.lblOverDueRemark.TabIndex = 27
        Me.lblOverDueRemark.Text = "Over Due Desc"
        Me.lblOverDueRemark.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmInvoice
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(833, 509)
        Me.Controls.Add(Me.btnDataErr)
        Me.Controls.Add(Me.lstDataErr)
        Me.Controls.Add(Me.grpGrid)
        Me.Controls.Add(Me.grpButtons)
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.grpInvoiceInfo)
        Me.Controls.Add(Me.lblfrmTitle)
        Me.Controls.Add(Me.txtRate)
        Me.Controls.Add(Me.txtRefIDTo)
        Me.Controls.Add(Me.txtRefID)
        Me.KeyPreview = True
        Me.Name = "frmInvoice"
        Me.Text = "Invoice"
        Me.grpInvoiceInfo.ResumeLayout(False)
        Me.grpInvoiceInfo.PerformLayout()
        Me.grpShowHideColumns.ResumeLayout(False)
        CType(Me.grdInvoiceDetail, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpButtons.ResumeLayout(False)
        Me.grpGrid.ResumeLayout(False)
        Me.grpGrid.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cboClient As System.Windows.Forms.ComboBox
    Friend WithEvents lblClient As System.Windows.Forms.Label
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents dtpInvoiceDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtInvoiceID As System.Windows.Forms.TextBox
    Friend WithEvents lstDataErr As System.Windows.Forms.ListBox
    Friend WithEvents lblDate As System.Windows.Forms.Label
    Friend WithEvents lblInvoiceNum As System.Windows.Forms.Label
    Friend WithEvents txtInvoiceNum As System.Windows.Forms.TextBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents btnDataErr As System.Windows.Forms.Button
    Friend WithEvents grpInvoiceInfo As System.Windows.Forms.GroupBox
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblfrmTitle As System.Windows.Forms.Label
    Friend WithEvents grpShowHideColumns As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveSettings As System.Windows.Forms.Button
    Friend WithEvents chkLstGridCol As System.Windows.Forms.CheckedListBox
    Friend WithEvents btnShowCol As System.Windows.Forms.Button
    Friend WithEvents grdInvoiceDetail As System.Windows.Forms.DataGridView
    Friend WithEvents grpButtons As System.Windows.Forms.GroupBox
    Friend WithEvents btnGetService As BHBut.BouncingHoverButton
    Friend WithEvents btnClose As BHBut.BouncingHoverButton
    Friend WithEvents btnNew As BHBut.BouncingHoverButton
    Friend WithEvents btnSave As BHBut.BouncingHoverButton
    Friend WithEvents txtInvoiceYY As System.Windows.Forms.TextBox
    Friend WithEvents lblType As System.Windows.Forms.Label
    Friend WithEvents dtpInvoiceDateTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblInvoiceDateTo As System.Windows.Forms.Label
    Friend WithEvents lblInvoiceDateFrom As System.Windows.Forms.Label
    Friend WithEvents dtpInvoiceDateFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnCancel As BHBut.BouncingHoverButton
    Friend WithEvents btnRemoveService As BHBut.BouncingHoverButton
    Friend WithEvents btnPost As BHBut.BouncingHoverButton
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents grpGrid As System.Windows.Forms.GroupBox
    Friend WithEvents lblCurrency As System.Windows.Forms.Label
    Friend WithEvents cboCurrency As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblHotKeys As System.Windows.Forms.Label
    Friend WithEvents dtpBilledDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblBilledDate As System.Windows.Forms.Label
    Friend WithEvents btnPreview As BHBut.BouncingHoverButton
    Friend WithEvents lblDG As System.Windows.Forms.Label
    Friend WithEvents cboDG As System.Windows.Forms.ComboBox
    Friend WithEvents txtRate As System.Windows.Forms.TextBox
    Friend WithEvents cboCategory As System.Windows.Forms.ComboBox
    Friend WithEvents lblEmployee As System.Windows.Forms.Label
    Friend WithEvents cboEmployee As System.Windows.Forms.ComboBox
    Friend WithEvents lblCurrSymbol As System.Windows.Forms.Label
    Friend WithEvents lblCurrSymbol2 As System.Windows.Forms.Label
    Friend WithEvents txtTotalCurr2 As System.Windows.Forms.TextBox
    Friend WithEvents txtRefID As System.Windows.Forms.TextBox
    Friend WithEvents txtRefIDTo As System.Windows.Forms.TextBox
    Friend WithEvents lblOverDueRemark As System.Windows.Forms.Label
    Friend WithEvents txtOverDueRemark As System.Windows.Forms.TextBox
End Class
