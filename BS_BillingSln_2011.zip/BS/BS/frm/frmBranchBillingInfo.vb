Imports BITSConn
Imports System.Data.SqlClient

Public Class frmBranchBillingInfo


#Region "Form-Declaration..."

	Private dsdata As DataSet
	Private clsMr As ClsMain
	Private blnLoading As Boolean
	Private WithEvents Nav As BitsNav
	Dim dataChange As Boolean = False
	Private AddMode As Boolean = False
	Private daBranchBillingInfo As SqlDataAdapter
	Private mStrCurrentState As String
#End Region


#Region "Form-Initialisation..."

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)
    End Sub

    Private Sub MakeDataAdapter()
        ''8
        '' set SQL for selecting active emp recs...
        daBranchBillingInfo = clsMr.BuildSqlAdapter("SELECT *  FROM tblBranchBillingInfo WHERE BranchBillingInfoID =1 ", "tblBranchBillingInfo")
        clsMr.BuildSqlAdapter("SELECT EmployeeID,FName + ' ' + LName as FullName FROM tblEmployee WHERE Del =0 ", "tblEmployee")
        clsMr.BuildSqlAdapter("SELECT EmployeeID,FName + ' ' + LName as FullName FROM tblEmployee WHERE Del =0 ", "tblTreasurer")
        clsMr.BuildSqlAdapter("SELECT EmployeeID,FName + ' ' + LName as FullName FROM tblEmployee WHERE Del =0 ", "tblControler")
        clsMr.BuildSqlAdapter("SELECT EmployeeID,FName + ' ' + LName as FullName FROM tblEmployee WHERE Del =0 ", "tblOverFlight")
        clsMr.BuildSqlAdapter("SELECT EmployeeID,FName + ' ' + LName as FullName FROM tblEmployee WHERE Del =0 ", "tblContract")
        clsMr.BuildSqlAdapter("SELECT EmployeeID,FName + ' ' + LName as FullName FROM tblEmployee WHERE Del =0 ", "tblClsBMsg")

        dsdata = clsMr.getDataSet

    End Sub

    Private Sub FillComboBox()
        ''
        clsMr.FillComboBox("tblEmployee", cboDG, "FullName", "EmployeeID")
        clsMr.FillComboBox("tblTreasurer", cboTreasurer, "FullName", "EmployeeID")
        clsMr.FillComboBox("tblControler", cboControler, "FullName", "EmployeeID")
        clsMr.FillComboBox("tblOverFlight", cboOverFlight, "FullName", "EmployeeID")
        clsMr.FillComboBox("tblContract", cboContract, "FullName", "EmployeeID")
        clsMr.FillComboBox("tblClsBMsg", cboClsBMsg, "FullName", "EmployeeID")

        ''
    End Sub

    Private Sub SetCurrencyManager()
        Nav.SetCurrency(Me, clsMr.getDataSet(), "tblBranchBillingInfo")
    End Sub

    Private Sub SetDefaultValue()
        ''
        clsMr.SetDefaults("tblBranchBillingInfo", "BranchID", gIntBranchID, "ModifiedBy", gIntUserID, "ModifyDate", Now.Date)
        ''
    End Sub

    Private Sub SetAutoNumber()
        ''
        clsMr.SetAutoNumber("tblBranchBillingInfo", "BranchBillingInfoID")
        ''
    End Sub

    Private Sub SetDataBinding()
        ''
        clsMr.BindTextBox(txtID, "tblBranchBillingInfo", "BranchBillingInfoID")
        clsMr.BindTextBox(txtBankName, "tblBranchBillingInfo", "BankName")
        clsMr.BindTextBox(txtSwift, "tblBranchBillingInfo", "Swift")
        clsMr.BindTextBox(txtFax, "tblBranchBillingInfo", "Fax")
        clsMr.BindTextBox(txtDGTitle, "tblBranchBillingInfo", "DGTitle")
        clsMr.BindTextBox(txtDGSubTitle, "tblBranchBillingInfo", "DGSubTitle")
        clsMr.BindTextBox(txtNr, "tblBranchBillingInfo", "AcctNum")
        clsMr.BindTextBox(txtNote, "tblBranchBillingInfo", "Note")
        clsMr.BindTextBox(txtCurrency, "tblBranchBillingInfo", "Currency")
        clsMr.BindTextBox(txtTreasurerTitle, "tblBranchBillingInfo", "TreasurerTitle")
        clsMr.BindTextBox(txtTreasurerSubTitle, "tblBranchBillingInfo", "TreasurerSubTitle")
        clsMr.BindTextBox(txtControlerTitle, "tblBranchBillingInfo", "ControlerTitle")
        clsMr.BindTextBox(txtControlerSubTitle, "tblBranchBillingInfo", "ControlerSubTitle")
        clsMr.BindTextBox(txtIBAN, "tblBranchBillingInfo", "IBAN")

        clsMr.BindTextBox(txtOverFlightTitle, "tblBranchBillingInfo", "OverFltTitle")
        clsMr.BindTextBox(txtOverFlightSubTitle, "tblBranchBillingInfo", "OverFltSubTitle")
        clsMr.BindTextBox(txtContractTitle, "tblBranchBillingInfo", "ContractTitle")
        clsMr.BindTextBox(txtContractSubTitle, "tblBranchBillingInfo", "ContractSubTitle")
        clsMr.BindTextBox(txtClsBMsgTitle, "tblBranchBillingInfo", "ClsBMsgTitle")
        clsMr.BindTextBox(txtClsBMsgSubTitle, "tblBranchBillingInfo", "ClsBMsgSubTitle")

        clsMr.BindComboBox(cboDG, "tblBranchBillingInfo", "DGID")
        clsMr.BindComboBox(cboTreasurer, "tblBranchBillingInfo", "TreasurerID")
        clsMr.BindComboBox(cboControler, "tblBranchBillingInfo", "ControlerID")
        clsMr.BindComboBox(cboOverFlight, "tblBranchBillingInfo", "OverFltID")
        clsMr.BindComboBox(cboContract, "tblBranchBillingInfo", "ContractID")
        clsMr.BindComboBox(cboClsBMsg, "tblBranchBillingInfo", "ClsBMsgID")

        ''
    End Sub
#End Region


#Region "Form-Load..."

    Private Sub frmBranchBillingInfo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

    Private Sub frmBranchBillingInfo_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        clsMr = New ClsMain(conSql)
        ''
        Nav = New BitsNav()
        blnLoading = True
        MakeDataAdapter()
        FillComboBox()
        SetDataBinding()
        SetAutoNumber()
        SetCurrencyManager()
        SetDefaultValue()

        blnLoading = False
        setState("BROWSE")
    End Sub

#End Region


#Region "Form-UI/Methods..."

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Nav.AddNew()
        setState("NEW")
        txtBankName.Focus()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If btnSave.Text = "E d i t" Then
            setState("EDIT")
            txtBankName.Focus()
            Exit Sub
        End If
        dsdata.Tables("tblBranchBillingInfo").DefaultView.Item(Nav.CurrentPosition)("ModifiedBy") = gIntUserID
        dsdata.Tables("tblBranchBillingInfo").DefaultView.Item(Nav.CurrentPosition)("ModifyDate") = Now.Date
        Nav.EndCurrentEdit()
        daBranchBillingInfo.Update(dsdata, "tblBranchBillingInfo")
        dataChange = False
        AddMode = False
        setState("SAVE")
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        If dataChange Then
            If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

                Try
                    Nav.CancelCurrentEdit()
                Catch ex As Exception

                End Try

                dataChange = False
                AddMode = False
                setState("BROWSE")
            End If
        Else
            setState("BROWSE")
            'AddMode = False
        End If


    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        '' check OK to close...
        If dataChange Then
            Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
                Case MsgBoxResult.Yes
                    '' call save...
                    If lstDataErr.Items.Count <> 0 Then
                        MsgBox("Cannot save.Please check error list")
                        Exit Sub
                    Else
                        btnSave.PerformClick()
                        Me.Close()
                    End If
                Case MsgBoxResult.No
                    '' ignore changes...

                    Try
                        Nav.CancelCurrentEdit()
                    Catch ex As Exception

                    End Try
                    Me.Close()
                Case MsgBoxResult.Cancel
                    '' ignore close press..
                    '' do nothing...

            End Select
        Else
            Me.Close()
        End If
    End Sub

    Private Sub cboOverFlight_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboOverFlight.SelectedIndexChanged
        CheckValues()
    End Sub

    Private Sub cboContract_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboContract.SelectedIndexChanged
        CheckValues()
    End Sub

    Private Sub cboClsBMsg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboClsBMsg.SelectedIndexChanged
        CheckValues()
    End Sub

    Private Sub txtOverFlightTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtOverFlightTitle.TextChanged
        CheckValues()
    End Sub

    Private Sub txtOverFlightSubTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtOverFlightSubTitle.TextChanged
        CheckValues()
    End Sub

    Private Sub txtContractTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContractTitle.TextChanged
        CheckValues()
    End Sub

    Private Sub txtContractSubTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContractSubTitle.TextChanged
        CheckValues()
    End Sub

    Private Sub txtClsBMsgTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtClsBMsgTitle.TextChanged
        CheckValues()
    End Sub

    Private Sub txtClsBMsgSubTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtClsBMsgSubTitle.TextChanged
        CheckValues()
    End Sub

    Private Sub txtIBAN_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtIBAN.TextChanged
        ''
        CheckValues()
    End Sub

#End Region


#Region "Form-Functions..."
	Private Sub setState(ByRef pStrMode As String)
		''
		mStrCurrentState = UCase(pStrMode)
		'' 
		Select Case mStrCurrentState
			Case Is = "NEW"

				Me.btnSave.Enabled = False
				Me.btnCancel.Enabled = True
				Me.btnNew.Enabled = False
				grpInfo.Enabled = True
				btnSave.Text = "S a v e"


				AddMode = True
			Case Is = "EDIT"

				Me.btnSave.Enabled = False
				Me.btnCancel.Enabled = True
				Me.btnNew.Enabled = False
				grpInfo.Enabled = True
				btnSave.Text = "S a v e"

			Case Is = "SAVE"

				Me.btnSave.Enabled = True
				Me.btnCancel.Enabled = False
				Me.btnNew.Enabled = True
				btnSave.Text = "E d i t"
				grpInfo.Enabled = False
				AddMode = False
			Case Is = "BROWSE"

				Me.btnSave.Enabled = True
				Me.btnCancel.Enabled = False
				Me.btnNew.Enabled = True
				btnSave.Text = "E d i t"
				grpInfo.Enabled = False
        End Select
        '  ''
        DGCA.LoadPermissionsSetState(Me, Me.Name)
    End Sub

#End Region


#Region "Form-CheckValues..."

	Private Sub CheckValues()
		''
		If blnLoading = True Then Exit Sub
		''
		dataChange = True
		'btnCancel.Enabled = True
		''
		'' clear entir list & start fresh check...
		''
		lstDataErr.Items.Clear()
		Dim intErrCount As Int16 = 0

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' check Error - Mandatory Data Objects...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		''
		If Me.txtBankName.Text = "" Then
			lstDataErr.Items.Add("Error: Missing Bank Name")
			intErrCount += 1
		End If
		If Me.txtSwift.Text = "" Then
			lstDataErr.Items.Add("Error: Missing Swift")
			intErrCount += 1
		End If
		If Me.txtFax.Text = "" Then
			lstDataErr.Items.Add("Error: Missing Fax Number")
			intErrCount += 1
		End If
		If Me.txtDGTitle.Text = "" Then
			lstDataErr.Items.Add("Error: Missing Account")
			intErrCount += 1
		End If
		If Me.txtNr.Text = "" Then
			lstDataErr.Items.Add("Error: Missing Number")
			intErrCount += 1
		End If
		If Me.txtNote.Text = "" Then
			lstDataErr.Items.Add("Error: Missing Note")
			intErrCount += 1
		End If
		If Me.cboDG.SelectedIndex = -1 Then
			lstDataErr.Items.Add("Error: Missing DG")
			intErrCount += 1
		End If
		If Me.txtCurrency.Text = "" Then
			lstDataErr.Items.Add("Error: Missing Currency")
			intErrCount += 1
		End If
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' Set appropriate controls based on errors check results...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		If lstDataErr.Items.Count = 0 Then
			lstDataErr.Visible = False
			btnDataErr.Visible = False
			'lblHelpErr.Visible = False
		Else
			btnDataErr.Visible = True
			'lblHelpErr.Visible = True
		End If
		''
		If dataChange And intErrCount = 0 Then
			btnSave.Enabled = True


		Else
			btnSave.Enabled = False

		End If
	End Sub

	Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
		''
		'' Show/Hide error list...
		If lstDataErr.Visible = True Then
			lstDataErr.Visible = False
		Else
			lstDataErr.Visible = True
			lstDataErr.Height = 251
			lstDataErr.BringToFront()
		End If
	End Sub

	Private Sub txtBankName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtBankName.TextChanged
		CheckValues()
	End Sub

	Private Sub txtFax_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFax.TextChanged
		CheckValues()
	End Sub

	Private Sub txtSwift_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSwift.TextChanged
		CheckValues()
	End Sub

	Private Sub txtAccount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDGTitle.TextChanged
		CheckValues()
	End Sub

	Private Sub txtNr_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNr.TextChanged
		CheckValues()
	End Sub

	Private Sub cboDG_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboDG.KeyUp
		CheckValues()
	End Sub

	Private Sub cboDG_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDG.SelectedIndexChanged
		CheckValues()
	End Sub

	Private Sub txtNote_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNote.TextChanged
		CheckValues()
	End Sub
	Private Sub txtCurrency_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCurrency.TextChanged
		CheckValues()
	End Sub

	Private Sub txtDGSubTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDGSubTitle.TextChanged
		CheckValues()
	End Sub

	Private Sub cboTreasurer_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboTreasurer.SelectedIndexChanged
		CheckValues()
	End Sub

	Private Sub txtTreasurerTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtTreasurerTitle.TextChanged
		CheckValues()
	End Sub

	Private Sub txtTreasurerSubTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtTreasurerSubTitle.TextChanged
		CheckValues()
	End Sub

	Private Sub cboControler_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboControler.SelectedIndexChanged
		CheckValues()
	End Sub

	Private Sub txtControlerTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtControlerTitle.TextChanged
		CheckValues()
	End Sub

	Private Sub txtControlerSubTitle_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtControlerSubTitle.TextChanged
		CheckValues()
	End Sub

#End Region


#Region "Permissions.."
	''Done by Mohamad March, 2008''

	'Bank Name'
	Private Sub txtBankName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtBankName.KeyPress
		If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
			e.Handled = True
		End If

		Static PreviousLetter As Char
		If PreviousLetter = " "c Or txtBankName.Text.Length = 0 Then

			e.KeyChar = Char.ToUpper(e.KeyChar)

		End If

		PreviousLetter = e.KeyChar
	End Sub

	'Fax'
	Private Sub txtFax_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFax.KeyPress
		If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
			Exit Sub
		End If
		If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
			e.Handled = True
		End If
	End Sub

	'Number'
	Private Sub txtNr_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtNr.KeyPress
		If AscW(e.KeyChar) = 8 Or e.KeyChar = "-" Then
			Exit Sub
		End If
		If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
			e.Handled = True
		End If
	End Sub

	'DG Title'
	Private Sub txtDGTitle_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDGTitle.KeyPress
		If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
			e.Handled = True
		End If

		Static PreviousLetter As Char
		If PreviousLetter = " "c Or txtBankName.Text.Length = 0 Then

			e.KeyChar = Char.ToUpper(e.KeyChar)

		End If

		PreviousLetter = e.KeyChar
	End Sub

	'DG SubTitle'
	Private Sub txtDGSubTitle_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDGSubTitle.KeyPress
		If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
			e.Handled = True
		End If

		Static PreviousLetter As Char
		If PreviousLetter = " "c Or txtBankName.Text.Length = 0 Then

			e.KeyChar = Char.ToUpper(e.KeyChar)

		End If

		PreviousLetter = e.KeyChar
	End Sub

	'Treasurer Title'
	Private Sub txtTreasurerTitle_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtTreasurerTitle.KeyPress
		If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
			e.Handled = True
		End If

		Static PreviousLetter As Char
		If PreviousLetter = " "c Or txtBankName.Text.Length = 0 Then

			e.KeyChar = Char.ToUpper(e.KeyChar)

		End If

		PreviousLetter = e.KeyChar
	End Sub

	'Treasurer SubTitle'
	Private Sub txtTreasurerSubTitle_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtTreasurerSubTitle.KeyPress
		If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
			e.Handled = True
		End If

		Static PreviousLetter As Char
		If PreviousLetter = " "c Or txtBankName.Text.Length = 0 Then

			e.KeyChar = Char.ToUpper(e.KeyChar)

		End If

		PreviousLetter = e.KeyChar
	End Sub

#End Region


End Class