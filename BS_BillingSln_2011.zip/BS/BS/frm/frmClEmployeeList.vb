''
Imports BITSConn
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Public Class frmClEmployeeList

#Region "Form-Declaration"
	Private dsdata As DataSet
	Private clsMr As ClsMain
	Private WithEvents Nav As BitsNav
	Private daClEmployee As SqlDataAdapter
	Private daClAddress As SqlDataAdapter
	Private blnLoading As Boolean	  '' Used to flag when loading form (T/F)...
	Private AddMode As Boolean
	Private AddressAddMode As Boolean
	Dim mStrTableName As String = "tblClientEmployee"
	'' Var for Registry Usage...
	Private mStrSubKeyName As String = "Software\BIT Solutions\BS\Employee\Settings"
	Private mStrSubKeyNameAdd As String = "Software\BIT Solutions\BS\Employee\Address\Settings"
	Private mstrCurrentGridName As String
	Private mstrCurrentGridNameAdd As String
	Dim DataChange As Boolean = False
	Dim blnPic As Boolean = False	' Pic Boolean 
	Dim mStrPicSource As String '' Pic source path 
	Dim ifSave As Boolean = False
	Dim mID As Integer
	Private mStrCurrentState As String
#End Region


#Region "Form-Load"

	Private Sub frmEmployeeV1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		SaveProfile(mStrSubKeyName, grdClEmpList)
		SaveProfile(mstrCurrentGridNameAdd, grdViewAddress)
    End Sub

    Private Sub frmClEmployeeList_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ''
        DGCA.modMiscTools.HotKeys_KeyDown(sender, e)
        ''
        If e.Control And e.KeyCode = Keys.P Then
            If gUserLevel = enmUserLevel.AdminLevel Then
                ''
                Dim frm As New DGCA.frmUserLevelPermissions(Me, 2)
                frm.ShowDialog()
            End If
        End If
    End Sub

	Private Sub frmEmployee_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		clsMr = New ClsMain(conSql)
		Nav = New BitsNav
		''
		blnLoading = True

		MakeDataAdapter()
		FillComboBox()
		SetAutoNumber()
		SetDataBinding()

		SetCurrencyManager()
		SetDefaultValue()

		DrawGrid()

		blnLoading = False
		BringPicFromDataBase()

		FilterList()
		FilterAddress()

		tcMain.TabPages.Remove(tbNewEditEmpList)
		txtClientID.Text = mID
      setState("BROWSE")

      tcAddress.TabPages.Remove(tpNewAddress)

   End Sub

#End Region


#Region "Form-Initialisation"

	Public Sub MakeDataAdapter()
		'      ''
		' '' set SQL for selecting active emp recs...
		strSQL = "SELECT * FROM tblClientEmployee "
		strSQL &= "WHERE (Del=0)"
		daClEmployee = clsMr.BuildSqlAdapter(strSQL, mStrTableName)
		''List Of Client Employee List
		clsMr.BuildSqlAdapter("SELECT * From vwClientEmpList", "vwClientEmpList")
		'' List of Employee Titles...
		clsMr.BuildSqlAdapter("SELECT * FROM tblEmployeeTitle WHERE Del=0", "tblEmployeeTitle")
		'      '' List of Employee Pay Periods...
		clsMr.BuildSqlAdapter("SELECT * FROM tblEmployeePayPeriod WHERE Del=0", "tblEmployeePayPeriod")
		'  ''List Of Marital Status
		clsMr.BuildSqlAdapter("SELECT * FROM tblMaritalStatus WHERE Del=0", "tblMaritalStatus")
		'      '' List of City Of Birth...
		clsMr.BuildSqlAdapter("SELECT * FROM tblAddCity WHERE del =0", "CityOfBirth")

		'      '' List of Streets...
		clsMr.BuildSqlAdapter("SELECT * FROM tblAddStreet WHERE del=0", "Street")


		'      ''List Of tbls Respect To Address...
		clsMr.BuildSqlAdapter("SELECT CityID,City_en,Del,StateID FROM tblAddCity WHERE del =0", "City")

		clsMr.BuildSqlAdapter("SELECT StreetID,AreaID,Street_en,Del FROM tblAddStreet WHERE del=0", "Street")

		clsMr.BuildSqlAdapter("SELECT CityID,AreaID,Area_en,Del FROM tblAddArea WHERE del =0", "Area")

		clsMr.BuildSqlAdapter("SELECT * FROM tblAddressType ", "AddressType")

		clsMr.BuildSqlAdapter("SELECT StateID,State_en,Del FROM tblAddState WHERE del=0", "State")

		clsMr.BuildSqlAdapter("SELECT *  FROM vwAddress WHERE del =0", "vwAddress")

		daClAddress = clsMr.BuildSqlAdapter("SELECT *  FROM tblAddress WHERE del =0", "tblAddress")

		dsdata = clsMr.getDataSet

	End Sub

	Public Sub FillComboBox()
		'' Title...
		clsMr.FillComboBox("tblEmployeeTitle", cboTitle, "Title", "TitleID")


		'      '' CityOfBirth...
		If gStrLang = "en" Then
			clsMr.FillComboBox("city", CboCity, "City_en", "CityID")
			clsMr.FillComboBox("Street", CboStreet, "Street_en", "StreetID")

			clsMr.FillComboBox("Area", cboArea, "Area_en", "AreaID")
			clsMr.FillComboBox("State", cboState, "State_en", "StateID")
			clsMr.FillComboBox("CityOfBirth", cboSOB, "City_en", "CityID")
		Else
			clsMr.FillComboBox("city", CboCity, "City_ar", "CityID")
			clsMr.FillComboBox("Street", CboStreet, "Street_ar", "StreetID")

			clsMr.FillComboBox("Area", cboArea, "Area_ar", "AreaID")
			clsMr.FillComboBox("State", cboState, "State_ar", "StateID")
			clsMr.FillComboBox("CityOfBirth", cboSOB, "City_ar", "CityID")
		End If

		clsMr.FillComboBox("AddressType", cboAddType, "AddType", "AddTypeID")
		clsMr.FillComboBox("State", cboNationality, "State_en", "StateID")
		clsMr.FillComboBox("tblMaritalStatus", CboMaritalStatus, "MaritalStatus", "MaritalStatusID")


	End Sub

	Public Sub SetAutoNumber()
		clsMr.SetAutoNumber(mStrTableName, "ClEmployeeID")
		Dim lngMax As Long
		lngMax = clsMr.GetMaxNumber("SELECT max(ClEmployeeNumber) FROM tblClientEmployee ") + 1
		clsMr.SetAutoNumber(mStrTableName, "ClEmployeeNumber", lngMax)
	End Sub

	Public Sub SetCurrencyManager()
		Nav.SetCurrency(Me, clsMr.getDataSet(), mStrTableName)
	End Sub

	Public Sub SetDataBinding()
		clsMr.BindTextBox(txtClEmpID, mStrTableName, "ClEmployeeID")
		clsMr.BindTextBox(txtClEmpNum, mStrTableName, "ClEmployeeNumber")
		clsMr.BindComboBox(cboTitle, mStrTableName, "ClEmployeeTitleID")
		clsMr.BindTextBox(txtFName, mStrTableName, "FName_En")
		clsMr.BindTextBox(txtMName, mStrTableName, "MName_En")
		clsMr.BindTextBox(txtLName, mStrTableName, "LName_En")
		clsMr.BindTextBox(txtMFName, mStrTableName, "MotherFN")
		clsMr.BindTextBox(txtMLName, mStrTableName, "MotherLN")
		clsMr.BindTextBox(txtSFName, mStrTableName, "SpouseFN")
		clsMr.BindTextBox(txtSLName, mStrTableName, "SpouseLN")
		clsMr.BindComboBox(CboMaritalStatus, mStrTableName, "MaritalStatusID")
		clsMr.BindDateTimePicker(dtpDOB, mStrTableName, "DOB")
		clsMr.BindComboBox(cboAOB, mStrTableName, "AreaOfBirthID")
		clsMr.BindComboBox(cboCOB, mStrTableName, "CityOfBirthID")
		clsMr.BindComboBox(cboSOB, mStrTableName, "StateOfBirthID")
		clsMr.BindTextBox(txtCensNum, mStrTableName, "CensusNum")
		clsMr.BindComboBox(cboCOCen, mStrTableName, "CensusCityID")
		clsMr.BindComboBox(cboQOCen, mStrTableName, "CensusQadaID")
		clsMr.BindComboBox(cboNationality, mStrTableName, "NationalityID")
		clsMr.BindTextBox(txtTel, mStrTableName, "WorkPhone")
		clsMr.BindTextBox(txtExt, mStrTableName, "Ext")
		clsMr.BindTextBox(txtHomePhone, mStrTableName, "HomePhone")
		clsMr.BindTextBox(txtCel, mStrTableName, "Cell")
		clsMr.BindTextBox(txtFax, mStrTableName, "Fax")
		clsMr.BindTextBox(txtEmail, mStrTableName, "Email")
		clsMr.BindTextBox(txtDriverLicNum, mStrTableName, "DriverLicenseNum")
		clsMr.BindTextBox(txtNote, mStrTableName, "Note")
		clsMr.BindTextBox(txtClientID, mStrTableName, "ClientID")

	End Sub

	Public Sub SetDefaultValue()
		clsMr.SetDefaults(mStrTableName, "Del", 0, "CreateDate", Now.Date, "CreateBy", gIntUserID, "DOB", Now.Date)
	End Sub
#End Region


#Region "frmAddress..."

	Private Sub btnNewAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewAddress.Click
		NewAddress()
		tpNewAddress.Text = "New"
	End Sub

	Private Sub btnEditAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditAddress.Click
		EditAddress()
	End Sub



	Private Sub NewAddress()
		''Add tab Page if not found
		If Not tcAddress.TabPages.Contains(tpNewAddress) Then
			tcAddress.TabPages.Add(tpNewAddress)
			'tpNewAddress.Text = "New Address"
		End If

		' tcAddress.SelectedIndex = 1
		tcAddress.SelectedTab = tpNewAddress

		''Get Auto Number for AddressID
		Dim AddressID As Long
		Try
			Dim cmdAddressID As New SqlClient.SqlCommand("SELECT CASE WHEN MAX(AddressID) IS NULL THEN 1 ELSE MAX(AddressID)+1 END FROM tblAddress", conSql)
			conSql.Open()
			AddressID = cmdAddressID.ExecuteScalar
			conSql.Close()
		Catch ex As Exception
			conSql.Close()
		End Try

		txtAddID.Text = AddressID

		btnSaveAddress.Enabled = True
		tpNewAddress.Visible = True

		''clear address combos
		If cboAddType.Items.Count <> 0 Then
			cboAddType.SelectedIndex = 0
		End If

		cboArea.SelectedIndex = -1
		CboCity.SelectedIndex = -1
		CboStreet.SelectedIndex = -1

		If cboState.Items.Count <> 0 Then
			cboState.SelectedIndex = 0
		End If


		cboArea.Text = ""
		CboCity.Text = ""
		CboStreet.Text = ""

		btnSaveAddress.Enabled = True
		AddressAddMode = True
	End Sub

	Private Function CheckAddressValues() As Boolean
		strMsg = ""

		If cboAddType.Text = "" Then
			strMsg = "Please insert AddressType " & vbCrLf
		End If

		If CboCity.Text = "" Then
			strMsg = strMsg & "Please enter City  " & vbCrLf
		End If
		If CboStreet.Text = "" Then
			strMsg = strMsg & "Please enter  Street  " & vbCrLf
		End If
		If strMsg <> "" Then
			strMsg = "The following value(s) is/are not valid: " & vbCrLf & strMsg
			MsgBox(strMsg)
			Return False
		Else
			Return True
		End If

	End Function
	Private Sub SaveAddress()
      If CheckAddressValues() = False Then Exit Sub

      If lstDataErr.Items.Count <> 0 Then
         MsgBox("Cannot save. Please check error list")
         Exit Sub
      Else
         Save()
      End If

		If AddressAddMode = True Then
			dsdata.Tables("vwAddress").DefaultView.AllowNew = True
			''adding new Address
			Dim drAddress As DataRow
			Dim drNew As DataRow

			''add new row
			drAddress = dsdata.Tables("vwAddress").NewRow
			drNew = dsdata.Tables("tblAddress").NewRow


			drAddress("ClientID") = mID
			drNew("ClientID") = mID
			drAddress("ClEmpID") = txtClEmpID.Text
			drNew("ClEmpID") = txtClEmpID.Text

			''add values to fields
			UpdateAddressDataRow(drAddress)
			UpdateAddressDataRow(drNew)

			drAddress("AddType") = cboAddType.Text
			drAddress("State_en") = cboState.Text
			drAddress("City_en") = CboCity.Text
			drAddress("Area_en") = cboArea.Text
			drAddress("Street_en") = CboStreet.Text

			drAddress("Del") = 0
			drNew("Del") = 0
			''add the created row
			dsdata.Tables("vwAddress").Rows.Add(drAddress)
			drAddress.EndEdit()
			dsdata.Tables("tblAddress").Rows.Add(drNew)
			clsMr.Update(daClAddress, "tblAddress")

			dsdata.Tables("vwAddress").DefaultView.AllowNew = False

			AddressAddMode = False
			'If AddMode Then
			'   save()
			'End If

		Else
			Dim drAddress() As DataRow
			Dim drUpdate() As DataRow
			drUpdate = dsdata.Tables("tblAddress").Select("AddressID = " & txtAddID.Text)
			drAddress = dsdata.Tables("vwAddress").Select("AddressID = " & txtAddID.Text)

			UpdateAddressDataRow(drAddress(0))
			UpdateAddressDataRow(drUpdate(0))
			drAddress(0)("AddType") = cboAddType.Text
			drAddress(0)("State_en") = cboState.Text
			drAddress(0)("City_en") = CboCity.Text
			drAddress(0)("Area_en") = cboArea.Text
			drAddress(0)("Street_en") = CboStreet.Text
			drAddress(0).EndEdit()
			clsMr.Update(daClAddress, "tblAddress")
			dsdata.Tables("vwAddress").DefaultView.AllowNew = False

		End If
      btnEditAddress.Visible = True
		tcAddress.TabPages.Remove(tpNewAddress)
	End Sub
	Private Sub UpdateAddressDataRow(ByVal pDr As DataRow)
		pDr("AddressID") = txtAddID.Text

		If cboAddType.SelectedIndex = -1 Then
			pDr("AddTypeID") = DBNull.Value
		Else
			pDr("AddTypeID") = cboAddType.SelectedValue

		End If

		If cboState.SelectedIndex = -1 Then
			pDr("StateID") = DBNull.Value
		Else
			pDr("StateID") = cboState.SelectedValue

		End If




		If CboCity.SelectedIndex = -1 Then
			pDr("CityID") = DBNull.Value
		Else
			pDr("CityID") = CboCity.SelectedValue

		End If

		If cboArea.SelectedIndex = -1 Then
			pDr("AreaID") = DBNull.Value
		Else
			pDr("AreaID") = cboArea.SelectedValue

		End If


		If CboStreet.SelectedIndex = -1 Then
			pDr("StreetID") = DBNull.Value
		Else
			pDr("StreetID") = CboStreet.SelectedValue


		End If

		If txtBNF.Text <> "" Then
			pDr("BNF") = txtBNF.Text & ""
		End If
	End Sub

	Private Sub filterCity()
		If blnLoading = True Then
			Exit Sub
		End If

		If cboState.Text = "" Then
			cboState.SelectedIndex = -1
			dsdata.Tables("city").DefaultView.RowFilter = String.Empty
		Else
			dsdata.Tables("city").DefaultView.RowFilter = "StateID =" & cboState.SelectedValue
		End If
	End Sub
	Private Sub filterAreaANDStreet()
		If blnLoading = True Then
			Exit Sub
		End If
		If CboCity.Text = "" Then
			CboCity.SelectedIndex = -1
			dsdata.Tables("Area").DefaultView.RowFilter = String.Empty
			dsdata.Tables("Street").DefaultView.RowFilter = String.Empty
		Else
			dsdata.Tables("Area").DefaultView.RowFilter = "CityID =" & CboCity.SelectedValue
			dsdata.Tables("Street").DefaultView.RowFilter = "CityID =" & CboCity.SelectedValue
		End If

	End Sub
	Private Sub filterStreet()
		If blnLoading = True Then
			Exit Sub
		End If
		If cboArea.Text = "" Then
			cboArea.SelectedIndex = -1
			dsdata.Tables("Street").DefaultView.RowFilter = String.Empty
		Else

			dsdata.Tables("Street").DefaultView.RowFilter = " AreaID =" & cboArea.SelectedValue

		End If
	End Sub


	Private Sub cboState_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboState.SelectedIndexChanged
		filterCity()
	End Sub

	Private Sub cboCity_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboCity.SelectedIndexChanged

		filterAreaANDStreet()
	End Sub

	Private Sub CboArea_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboArea.SelectedIndexChanged
		filterStreet()

	End Sub

	Private Sub EditAddress()
		If grdViewAddress.Rows.Count = 0 Then
			Exit Sub
		End If

		If Not tcAddress.TabPages.Contains(tpNewAddress) Then
			tcAddress.TabPages.Add(tpNewAddress)
			tpNewAddress.Text = "Edit Address"
		End If

		tcAddress.SelectedTab = tpNewAddress
		Dim drAddress As DataView
		drAddress = dsdata.Tables("vwAddress").DefaultView

		txtAddID.Text = drAddress(grdViewAddress.CurrentRow.Index)("AddressID") & ""
		If Not (drAddress(grdViewAddress.CurrentRow.Index)("AddTypeID") Is DBNull.Value) Then
			cboAddType.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("AddTypeID") & ""
		Else
			cboAddType.SelectedValue = DBNull.Value
			cboAddType.SelectedIndex = -1
		End If

		If Not (drAddress(grdViewAddress.CurrentRow.Index)("StateID") Is DBNull.Value) Then
			cboState.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("StateID") & ""
		Else
			cboState.SelectedValue = DBNull.Value
			cboState.SelectedIndex = -1
		End If

		If Not (drAddress(grdViewAddress.CurrentRow.Index)("CityID") Is DBNull.Value) Then
			CboCity.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("CityID")
		Else
			CboCity.SelectedValue = DBNull.Value
			CboCity.SelectedIndex = -1
		End If
		If Not (drAddress(grdViewAddress.CurrentRow.Index)("AreaID") Is DBNull.Value) Then
			cboArea.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("AreaID")
		Else
			cboArea.SelectedValue = DBNull.Value
			cboArea.SelectedIndex = -1
		End If

		If Not (drAddress(grdViewAddress.CurrentRow.Index)("StreetID") Is DBNull.Value) Then
			CboStreet.SelectedValue = drAddress(grdViewAddress.CurrentRow.Index)("StreetID")
		Else
			CboStreet.SelectedValue = DBNull.Value
			CboStreet.SelectedIndex = -1
		End If
		If Not (drAddress(grdViewAddress.CurrentRow.Index)("BNF") Is DBNull.Value) Then
			txtBNF.Text = drAddress(grdViewAddress.CurrentRow.Index)("BNF")
		End If
	End Sub


	Private Sub btnDeleteAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteAddress.Click

		If grdViewAddress.Rows.Count = -1 Then Exit Sub

		Dim drAddress As DataView
		drAddress = dsdata.Tables("vwAddress").DefaultView

		If MsgBox(" Are you sure you want to Delete? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "BitSolution") = MsgBoxResult.Yes Then

			Dim drDel() As DataRow
			drDel = dsdata.Tables("tblAddress").Select("AddressID = " & drAddress(grdViewAddress.CurrentRow.Index)("AddressID"))
			If drDel.Length > 0 Then
				drDel(0).Delete()
				Nav.EndCurrentEdit()
				clsMr.Update(daClAddress, "tblAddress")
			End If

			dsdata.Tables("vwAddress").DefaultView(grdViewAddress.CurrentRow.Index).Delete()

			If grdViewAddress.Rows.Count = 0 Then
				btnDeleteAddress.Enabled = False
			End If
		End If


	End Sub

	Private Sub btnNewAddress2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewAddress2.Click
		NewAddress()
	End Sub

	Private Sub btnSaveAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveAddress.Click
		SaveAddress()

	End Sub

	Private Sub btnCancelAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAddress.Click
		tcAddress.TabPages.Remove(tpNewAddress)
      tcAddress.SelectedTab = tpViewAddress

		btnNewAddress.Enabled = True
		btnNewAddress.Enabled = True
		btnSaveAddress.Enabled = True

	End Sub

	Private Sub cboStreet_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboStreet.Leave
		If cboArea.Text = "" And CboCity.Text = "" Then Exit Sub
		'AddStreet()
	End Sub

#End Region


#Region "Form-ClientEmployeeList"

	Private Sub FilterList()

		Dim strFilter As String = "True"

		strFilter = strFilter & " AND ClientID = " & mID


		If txtFiltByNum.Text <> "" Then
			strFilter = strFilter & " AND ClEmployeeNumber='" & txtFiltByNum.Text & "'"
		End If
		If txtFiltByFName.Text <> "" Then
			strFilter = strFilter & " AND FName_En LIKE '" & txtFiltByFName.Text & "%'"
		End If
		If txtFiltByMName.Text <> "" Then
			strFilter = strFilter & " AND MName_En LIKE '" & txtFiltByMName.Text & "%'"
		End If
		If txtFilByLName.Text <> "" Then
			strFilter = strFilter & " AND LName_En LIKE '" & txtFilByLName.Text & "%'"

		End If
		If strFilter <> "" Then
			dsdata.Tables("vwClientEmpList").DefaultView.RowFilter = strFilter
		End If
	End Sub
	Private Sub txtFiltByNum_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFiltByNum.TextChanged
		FilterList()
	End Sub

	Private Sub txtFiltByMName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFiltByMName.TextChanged
		FilterList()
	End Sub

	Private Sub txtFilByLName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFilByLName.TextChanged
		FilterList()
	End Sub

	Private Sub txtFiltByFName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFiltByFName.TextChanged
		FilterList()
	End Sub


#End Region


#Region "Form-UI/Methods"


	Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
		''
      If DataChange Then

         If MsgBox("Are you sure you want to cancel", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            Try
               Nav.CancelCurrentEdit()
               If AddMode = True Then
                  Me.Close()
               End If
            Catch ex As Exception

            End Try

            DataChange = False
            AddMode = False
            setState("BROWSE")
         End If
      Else

         setState("BROWSE")
      End If



	End Sub
	Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click


		Dim dr As DataRow = dsdata.Tables("vwClientEmpList").DefaultView.Item(grdClEmpList.CurrentRow.Index).Row
		Nav.CurrentPosition = GetRowIndex(dr("ClEmployeeID"))
		If Not tcMain.TabPages.Contains(tbNewEditEmpList) Then
			tcMain.TabPages.Add(tbNewEditEmpList)
		End If
		tcMain.SelectedIndex = 1
		FilterAddress()

		'setState("BROWSE")

	End Sub
	Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
		If Not tcMain.TabPages.Contains(tbNewEditEmpList) Then
			tcMain.TabPages.Add(tbNewEditEmpList)
		End If
		tcMain.SelectedIndex = 1
		''
		'Add New Record
		NewRecord()

	End Sub

	Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveClientEmp.Click

		If btnSaveClientEmp.Text = "E d i t" Then
			setState("EDIT")
			Exit Sub
		End If
		Save()
		DataChange = False
		setState("SAVE")

	End Sub

	Private Sub btnCloseList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseList.Click
		''Close the List
		Me.Close()
   End Sub

   Private Sub cboNationality_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cboNationality.KeyUp
      checkListValues()
   End Sub

	Private Sub cboNationality_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboNationality.TextChanged
		''Check Values
		checkListValues()
	End Sub

	Private Sub btnNewClientEmp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewClientEmp.Click
		'Add New Record
		NewRecord()
	End Sub

	Private Sub BtnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClose.Click
		'' check OK to close...
		If DataChange Then
			Select Case MsgBox("SAVE Changes?", MsgBoxStyle.Critical + MsgBoxStyle.YesNoCancel)
				Case MsgBoxResult.Yes
					'' call save...
					If lstDataErr.Items.Count <> 0 Then
						MsgBox("Cannot save.Please check error list")
						Exit Sub
					Else
						Save()
						tcMain.SelectedIndex = 0
					End If
				Case MsgBoxResult.No
					'' ignore changes...

					Try
						Nav.CancelCurrentEdit()
					Catch ex As Exception

					End Try
					tcMain.SelectedIndex = 0
				Case MsgBoxResult.Cancel
					'' ignore close press..
					'' do nothing...
               btnNew.Enabled = False
               btnEdit.Enabled = False
               Exit Sub
			End Select
		Else
			tcMain.SelectedIndex = 0
		End If

		''Close the tab New/Save
		tcMain.SelectedIndex = 0

		''RefreshEmployee
      RefreshEmployee()

      btnNew.Enabled = True
      btnEdit.Enabled = True
      tcAddress.TabPages.Remove(tpNewAddress)
   End Sub
#End Region


#Region "Form-Functions"

	Private Sub NewRecord()
		''
		checkListValues()
		''Add New Record
		Nav.AddNew()

		''Reset Fields
		txtFName.Text = ""
		txtMName.Text = ""
		txtLName.Text = ""
		txtMFName.Text = ""
		txtMLName.Text = ""
		txtSFName.Text = ""
		txtSLName.Text = ""
		txtDriverLicNum.Text = ""
		CboMaritalStatus.SelectedIndex = -1
		cboTitle.SelectedIndex = -1

		dtpDOB.Value = Now.Date
		cboSOB.SelectedIndex = -1
		cboCOB.SelectedIndex = -1
		cboAOB.SelectedIndex = -1
		txtCensNum.Text = ""
		cboROCen.SelectedIndex = -1
		cboQOCen.SelectedIndex = -1
		cboCOCen.SelectedIndex = -1

		cboNationality.SelectedIndex = -1
		txtHomePhone.Text = ""
		txtFax.Text = ""
		txtTel.Text = ""
		txtExt.Text = ""
		txtCel.Text = ""
		txtEmail.Text = ""
		txtNote.Text = ""
		''

		setState("NEW")



		''Filter Address
		FilterAddress()
		txtClientID.Text = mID

	End Sub

	Private Sub RefreshEmployee()
		dsdata.Tables("vwClientEmpList").Clear()
		''List Of Client Employee List
		clsMr.BuildSqlAdapter("SELECT * From vwClientEmpList", "vwClientEmpList")
	End Sub

	Private Sub SetStateGrp(ByVal pBlnState As Boolean)
		''
		grpName.Enabled = pBlnState
		grpInfo.Enabled = pBlnState
      grpOthers.Enabled = pBlnState
      tcAddress.Enabled = pBlnState
		''
	End Sub

	Private Sub setState(ByRef pStrMode As String)
		''
		mStrCurrentState = UCase(pStrMode)
		'' 
      Select Case mStrCurrentState

         Case Is = "NEW"
            btnSaveClientEmp.Enabled = False
            btnNewClientEmp.Enabled = False
            btnCancel.Enabled = True
            btnNew.Enabled = False
            btnEdit.Enabled = False
            SetStateGrp(True)
            btnSaveClientEmp.Text = "S a v e"
            AddMode = True

         Case Is = "EDIT"
            btnSaveClientEmp.Enabled = False
            btnNewClientEmp.Enabled = False
            btnCancel.Enabled = True
            btnNew.Enabled = False
            btnEdit.Enabled = False
            SetStateGrp(True)
            btnSaveClientEmp.Text = "S a v e"

         Case Is = "SAVE"
            btnSaveClientEmp.Enabled = True
            btnCancel.Enabled = False
            btnNew.Enabled = True
            btnNewClientEmp.Enabled = True
            btnEdit.Enabled = True
            btnSaveClientEmp.Text = "E d i t"
            SetStateGrp(False)
            AddMode = False

         Case Is = "BROWSE"
            btnNewClientEmp.Enabled = True
            btnNew.Enabled = True
            btnEdit.Enabled = True
            btnSaveClientEmp.Enabled = True
            btnCancel.Enabled = False
            btnDataErr.Visible = False
            btnSaveClientEmp.Text = "E d i t"
            SetStateGrp(False)

      End Select
	End Sub

	Private Sub FilterAddress()
		If txtClEmpID.Text <> "" Then
			dsdata.Tables("vwAddress").DefaultView.RowFilter = "ClEmpID= '" & txtClEmpID.Text & "'"
		End If
		If grdViewAddress.Rows.Count = 0 Then
			btnDeleteAddress.Visible = False
			btnEditAddress.Visible = False
		Else
			btnEditAddress.Visible = True
			btnDeleteAddress.Visible = True
		End If

	End Sub

	Private Sub DrawGrid()
		''Set Properties Of EmplpoyeeListGrid


		grdClEmpList.DataSource = dsdata.Tables("vwClientEmpList").DefaultView
		With grdClEmpList
			.Columns("ClEmployeeID").Visible = False
			.Columns("ClEmployeeTitleID").Visible = False
			.Columns("ClientID").Visible = False

			.Columns("ClientName").HeaderText = "Name"
			.Columns("ClEmployeeNumber").HeaderText = "Number"
			.Columns("FName_En").HeaderText = "First Name"
			.Columns("MName_En").HeaderText = "Middle Name"
			.Columns("LName_En").HeaderText = "Last Name"
			.Columns("MotherName").HeaderText = "Mother Name"

			.ReadOnly = True
			.ColumnHeadersHeight = btnShowCol.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		End With
		'RemoveGrdListItems()

		''Set Properties Of EmplpoyeeAddressGrid
		grdViewAddress.DataSource = dsdata.Tables("vwAddress").DefaultView
		dsdata.Tables("vwAddress").DefaultView.AllowNew = False
		grdViewAddress.Columns("State_en").HeaderText = "State"
		grdViewAddress.Columns("Street_en").HeaderText = "Street"
		grdViewAddress.Columns("Area_en").HeaderText = "Area"
		grdViewAddress.Columns("City_en").HeaderText = "City"
		grdViewAddress.Columns("AddType").HeaderText = "Type"

		grdViewAddress.Columns("Del").Visible = False
		grdViewAddress.Columns("AddressID").Visible = False
		grdViewAddress.Columns("StreetID").Visible = False
		grdViewAddress.Columns("CityID").Visible = False
		grdViewAddress.Columns("StateID").Visible = False
		grdViewAddress.Columns("AreaID").Visible = False
		grdViewAddress.Columns("EmployeeID").Visible = False
		grdViewAddress.Columns("AddTypeID").Visible = False
		grdViewAddress.Columns("ClientID").Visible = False
		grdViewAddress.Columns("ClEmpID").Visible = False

		With grdViewAddress
			.ReadOnly = True
			.ColumnHeadersHeight = btnShowColAddress.Height + 2
			.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		End With

		LoadProfile(mStrSubKeyName, grdClEmpList)
		LoadProfile(mStrSubKeyNameAdd, grdViewAddress)
		RemoveGrdListItems()
	End Sub

	Private Sub BringPicFromDataBase()

		'Bring picture from data base 

		' ask if there is any records in the db 
		If dsdata.Tables(mStrTableName).Rows.Count = 0 Then Exit Sub

		' ask if the field Photo is null in the database 
		If IsDBNull(dsdata.Tables(mStrTableName).Rows(GetRowIndex(txtClEmpID.Text))("Picture")) Then picPersonnel.Image = Nothing : Exit Sub
		Dim arrPicture() As Byte = _
		CType(dsdata.Tables(mStrTableName).Rows(GetRowIndex(txtClEmpID.Text))("Picture"), Byte())
		Dim ms As New System.IO.MemoryStream(arrPicture)
		With picPersonnel
			.Image = Image.FromStream(ms)
			.SizeMode = PictureBoxSizeMode.StretchImage
			.BorderStyle = BorderStyle.Fixed3D
		End With
	End Sub

	Public Function GetRowIndex(ByVal pClEmployeeID As Long) As Integer

		Dim i As Integer
		For i = 0 To dsdata.Tables(mStrTableName).DefaultView.Count - 1
			If dsdata.Tables(mStrTableName).DefaultView.Item(i)("ClEmployeeID") = pClEmployeeID Then
				Return i
			End If
		Next

		Return -1
	End Function

	Private Sub Save()
		''
		If blnPic Then SavePicToDB()
      checkListValues()
      Nav.EndCurrentEdit()
      DataChange = False
      daClEmployee.Update(dsdata, mStrTableName)
		''
	End Sub

#End Region


#Region "CustomControl Of Address"
	Private Sub btnShowColAddress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowColAddress.Click
		If Me.grpShowHideColumnsAdd.Visible = False Then
			Me.grpShowHideColumnsAdd.Visible = True
			Me.grpShowHideColumnsAdd.BringToFront()
			mstrCurrentGridNameAdd = "Address"
			''
			'' populate list with grid's dataSource fields...
			''
			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridColAdd.Items.Clear()
			For Each col In grdViewAddress.Columns
				Me.chkLstGridColAdd.Items.Add(col.HeaderText, col.Visible)
			Next
			chkLstGridColAdd.Items.Remove("Del")
			chkLstGridColAdd.Items.Remove("AddressID")
			chkLstGridColAdd.Items.Remove("StreetID")
			chkLstGridColAdd.Items.Remove("CityID")
			chkLstGridColAdd.Items.Remove("StateID")
			chkLstGridColAdd.Items.Remove("AreaID")
			chkLstGridColAdd.Items.Remove("EmployeeID")
			chkLstGridColAdd.Items.Remove("AddTypeID")
			chkLstGridColAdd.Items.Remove("ClientID")
			chkLstGridColAdd.Items.Remove("ClEmpID")
		Else
			Me.grpShowHideColumnsAdd.Visible = False
			Me.grpShowHideColumnsAdd.SendToBack()
		End If
	End Sub

	Private Sub btnSaveSettingAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettingAdd.Click
		Dim i As Integer

		For i = 0 To Me.chkLstGridColAdd.Items.Count - 1
			Me.grdViewAddress.Columns(i).Visible = Me.chkLstGridColAdd.GetItemChecked(i)
		Next

		''
		Me.grpShowHideColumnsAdd.Visible = False

	End Sub
#End Region


#Region "CustomControls"
	Private Sub btnShowCol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCol.Click
		If Me.grpShowHideColumns.Visible = False Then
			Me.grpShowHideColumns.Visible = True
			Me.grpShowHideColumns.BringToFront()
			mstrCurrentGridName = "ClientEmployeeList"
			''
			'' populate list with grid's dataSource fields...
			''

			Dim col As Windows.Forms.DataGridViewColumn
			''
			Me.chkLstGridCol.Items.Clear()
			For Each col In grdClEmpList.Columns
				Me.chkLstGridCol.Items.Add(col.HeaderText, col.Visible)
			Next
			RemoveGrdListItems()
		Else
			Me.grpShowHideColumns.Visible = False
			Me.grpShowHideColumns.SendToBack()
		End If
	End Sub

	Private Sub btnSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSettings.Click
		Dim i As Integer

		For i = 0 To Me.chkLstGridCol.Items.Count - 1
			Me.grdClEmpList.Columns(i).Visible = Me.chkLstGridCol.GetItemChecked(i)
		Next

		''
		Me.grpShowHideColumns.Visible = False

	End Sub
#End Region


#Region "CheckValues"

	Private Sub btnDataErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataErr.Click
		'' Show/Hide error list...
		If lstDataErr.Visible = True Then
			lstDataErr.Visible = False
		Else
			lstDataErr.Visible = True
			lstDataErr.Height = 100
			lstDataErr.BringToFront()
		End If
	End Sub

	Private Sub checkListValues()
		If blnLoading = True Then Exit Sub
		DataChange = True

		lstDataErr.Items.Clear()
		Dim intErrCount As Int16 = 0

		If txtFName.Text.Trim = String.Empty Then
			lstDataErr.Items.Add("Please Enter First Name")
			intErrCount += 1
		End If
		If txtMName.Text.Trim = String.Empty Then
			lstDataErr.Items.Add("Please Enter Middle Name")
			intErrCount += 1
		End If

		If txtLName.Text.Trim = String.Empty Then
			lstDataErr.Items.Add("Please Enter Last Name")
			intErrCount += 1
		End If

		If txtTel.Text.Trim = String.Empty Then
			lstDataErr.Items.Add("Please Enter Telephone Number")
			intErrCount += 1
		End If

		If cboNationality.SelectedIndex = -1 Then
			lstDataErr.Items.Add("Please Enter Nationality")
			intErrCount += 1
		End If

		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		'' Set appropriate controls based on errors check results...
		'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
		If lstDataErr.Items.Count = 0 Then
			lstDataErr.Visible = False
			btnDataErr.Visible = False
			btnSaveClientEmp.Enabled = True
		Else
			btnDataErr.Visible = True
			btnSaveClientEmp.Enabled = False
		End If
		''

	End Sub

	Private Sub RemoveGrdListItems()
		''
		chkLstGridCol.Items.Remove("ClEmployeeID")
		chkLstGridCol.Items.Remove("ClEmployeeTitleID")
		chkLstGridCol.Items.Remove("ClientID")
		''
	End Sub

	Private Sub txtFName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFName.TextChanged, txtCel.TextChanged, txtCensNum.TextChanged, txtDriverLicNum.TextChanged, txtEmail.TextChanged, txtExt.TextChanged, txtFax.TextChanged, txtHomePhone.TextChanged, txtLName.TextChanged, txtMFName.TextChanged, txtMLName.TextChanged, txtMName.TextChanged, txtNote.TextChanged, txtSFName.TextChanged, txtSLName.TextChanged, txtTel.TextChanged
		''Check Values
		checkListValues()
	End Sub

	'Private Sub txtLName_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLName.TextChanged
	'   ''Check Values
	'   checkListValues()
	'End Sub

	'Private Sub txtTel_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTel.TextChanged
	'   ''Check Values
	'   checkListValues()
	'End Sub

#End Region


#Region "Form_Image..."

   Private Sub btnGetSign_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetSign.Click
      ''
      blnPic = True
      OFDGetPhoto.Filter = "jpg (*.jpg)|*.jpg|bmp (*.bmp)|*.bmp|All files (*.*)|*.*"
      OFDGetPhoto.FilterIndex = 1
      OFDGetPhoto.RestoreDirectory = True

      If OFDGetPhoto.ShowDialog() = Windows.Forms.DialogResult.OK Then
         txtLocation.Text = OFDGetPhoto.FileName
         mStrPicSource = OFDGetPhoto.FileName
         If Not mStrPicSource = "" Then picPersonnel.Image = Image.FromFile(txtLocation.Text)
         ifSave = True
         btnSaveClientEmp.Enabled = True
      End If
      ''
   End Sub

	Private Sub SavePicToDB() ''''''' Save Picture to data base 

		If mStrPicSource = "" Then Exit Sub
		Dim ms As New System.IO.MemoryStream

		''read Picture and convert to bytes 
		picPersonnel.Image.Save(ms, picPersonnel.Image.RawFormat)
		Dim arrImage() As Byte = ms.GetBuffer

		' Close the stream object to release the resource.
		ms.Close()

		Dim strSQL As String = _
			 "update  tblClientEmployee  set  picture = @Picture where ClEmployeeID= " & txtClEmpID.Text

		Dim cmd As New SqlClient.SqlCommand(strSQL, conSql)
		With cmd
			.Parameters.Add(New SqlClient.SqlParameter("@Picture", _
			  SqlDbType.Image)).Value = arrImage
		End With
		conSql.Open()
		cmd.ExecuteNonQuery()
		conSql.Close()

		MsgBox("Picture Changes will appear next time you Login to Form")


		blnPic = False
	End Sub


#End Region


	Public Sub New(Optional ByVal PID As Long = -1)
		' This call is required by the Windows Form Designer.
		InitializeComponent()
		mID = PID
        ' Add any initialization after the InitializeComponent() call.
        DGCA.LoadPermissions(Me, Me.Name)

	End Sub

	Private Sub cboQOCen_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboQOCen.TextChanged, cboAOB.TextChanged, CboMaritalStatus.TextChanged, cboTitle.TextChanged, cboSOB.TextChanged, cboCOB.TextChanged, cboCOB.TextChanged, cboROCen.TextChanged, cboCOCen.TextChanged, cboNationality.TextChanged
		''Check Values
		checkListValues()
	End Sub

#Region "Permissions.."
    ''Done by Mohamad March, 2008''

    'First Name'
    Private Sub txtFName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtFName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Middle Name'
    Private Sub txtMName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtMName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtMName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Last Name'
    Private Sub txtLName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtLName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtLName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Mother First Name'
    Private Sub txtMFName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtMFName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtMFName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Mother Last Name'
    Private Sub txtMLName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtMLName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtMLName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Spouse First Name'
    Private Sub txtSFName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSFName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtSFName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Spouse Last Name'
    Private Sub txtSLName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSLName.KeyPress
        If (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If

        Static PreviousLetter As Char
        If PreviousLetter = " "c Or txtSLName.Text.Length = 0 Then

            e.KeyChar = Char.ToUpper(e.KeyChar)

        End If

        PreviousLetter = e.KeyChar
    End Sub

    'Home Phone'
    Private Sub txtHomePhone_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtHomePhone.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Cell Phone'
    Private Sub txtCel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCel.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Work Phone'
    Private Sub txtTel_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtTel.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Extension'
    Private Sub txtExt_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtExt.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Fax'
    Private Sub txtFax_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFax.KeyPress
        If AscW(e.KeyChar) = 8 Or e.KeyChar = "+" Then
            Exit Sub
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9") Then
            e.Handled = True
        End If
    End Sub

    'Email'
    Private Sub txtEmail_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEmail.Leave
        Dim Pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim EmailAddressMatch As Match = Regex.Match(txtEmail.Text, Pattern)

        If EmailAddressMatch.Success = True Then
            'Do Nothing
        Else
            MsgBox("Invalid Email Address")
            txtEmail.Text = ""
        End If
    End Sub

#End Region

End Class


